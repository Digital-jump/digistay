# DigiStay API Contract (v1)

Base: same origin. All endpoints are Next.js route handlers under `src/app/api/`.
Auth: `Authorization: Bearer <token>` header (token from login). 401 on missing/invalid token, 403 on insufficient role.

Success: `200` JSON body as specified (or `{ ok: true, ... }` for pure mutations).
Error: `{ "error": "message" }` with status 400/401/403/404/500.

Common value conventions:
- Money: numbers (INR). Dates: ISO strings. All enum-like fields are strings.
- Reservation status: `PENDING | CONFIRMED | CHECKED_IN | CHECKED_OUT | CANCELLED | NO_SHOW`
- Room status: `AVAILABLE | OCCUPIED | RESERVED | DIRTY | MAINTENANCE`
- Order status: `PENDING | ACCEPTED | DELIVERED | PARTIALLY_DELIVERED | CANCELLED`
- Reservation source: `DIRECT | WEBSITE | OTA_BOOKING_COM | OTA_MAKE_MY_TRIP | OTA_AIRBNB | OTA_EXPEDIA | OTA_GOIBIBO | PHONE | WALK_IN | COMPANY`
- Payment method: `CASH | UPI | DEBIT_CARD | CREDIT_CARD | BANK_TRANSFER | RAZORPAY | OTHER`
- Invoice status: `UNPAID | PARTIAL | PAID | VOID`; billingType: `INDIVIDUAL | COMPANY | OTA`
- Folio: type `COMPANY | INDIVIDUAL | OTA`, status `OPEN | SETTLED`; entry type `CHARGE | PAYMENT | ADJUSTMENT`
- Roles: `ADMIN | RECEPTIONIST | ACCOUNTANT | STAFF`
- Prisma includes: relations are returned nested (e.g. reservation includes `guest`, `roomType`, `room`).

## Auth
- `POST /api/auth/login` `{ email, password }` → `{ token, user: { id, name, email, role, phone } }`. Creates Session (7d), audit LOGIN.
- `POST /api/auth/logout` (auth) → `{ ok: true }`
- `GET /api/auth/me` (auth) → `{ user }`

## Dashboard
- `GET /api/dashboard` (module: dashboard) →
```json
{
  "stats": { "totalRooms": 24, "availableRooms": 17, "occupiedRooms": 4, "reservedRooms": 0, "dirtyRooms": 1, "maintenanceRooms": 1, "occupancyRate": 16.7, "arrivalsToday": 3, "departuresToday": 2, "inHouseGuests": 8, "todayRevenue": 12000, "monthRevenue": 350000, "outstandingBalance": 20000, "pendingOrders": 1 },
  "occupancyTrend": [{ "date": "2025-01-01", "occupancy": 62.5, "revenue": 35000 }],
  "revenueByMonth": [{ "month": "Aug", "room": 120000, "fb": 45000 }],
  "sourceBreakdown": [{ "source": "OTA_BOOKING_COM", "count": 5 }],
  "roomStatusBreakdown": [{ "status": "AVAILABLE", "count": 17 }],
  "recentActivity": [{ "id": "...", "action": "CHECKIN", "userName": "Priya", "entity": "Reservation", "details": "...", "createdAt": "ISO" }],
  "arrivalsTodayList": [{ reservation with guest/roomType/room }],
  "departuresTodayList": [same shape]
}
```
  - occupancyTrend = last 14 days: occupancy% = (rooms occupied that night)/totalRooms*100; revenue = payments received that day.
  - revenueByMonth = last 6 months: room revenue (ROOM invoices issued) vs fb (FOOD invoices issued).

## Guests
- `GET /api/guests?search=&page=1&pageSize=20&sort=createdAt` (module: guests | checkins) → `{ items: [Guest + { reservationCount, lastStay }], total, page, pageSize }`
- `GET /api/guests/stats` (module: guests) → `{ totalGuests, repeatGuests, avgStayNights, noShowRate, newByMonth: [{month:"2025-01", count}], idDocsRecorded, missingId, missingContact, duplicates, nationalityBreakdown: [{name, count}], sourceBreakdown: [{name, count}] }`
- `POST /api/guests` `{ firstName, lastName, email?, phone?, idType?, idNumber?, nationality?, address?, city?, company?, vip?, notes? }` → Guest (validates firstName/lastName required; email/phone format if present; duplicate phone+idNumber flagged)
- `GET /api/guests/[id]` → `{ guest, reservations: [Reservation incl roomType/room], orders, reviews, stats: { stays, spend } }`
- `PUT /api/guests/[id]` same fields → Guest
- `DELETE /api/guests/[id]` → 409 if guest has active (PENDING/CONFIRMED/CHECKED_IN) reservations, else deletes. `{ ok: true }`

## Companies
- `GET /api/companies?search=` → `[Company + openFolioAmount]`
- `POST /api/companies` `{ name, contactPerson?, email?, phone?, address?, gstin?, creditLimit? }` → Company
- `PUT /api/companies/[id]` → Company; `DELETE /api/companies/[id]` → 409 if company has OPEN folios.

## Rooms & Types
- `GET /api/rooms?status=&search=&roomTypeId=` (module: room-view | stay-view) → `{ items: [Room + roomType], stats: { AVAILABLE, OCCUPIED, RESERVED, DIRTY, MAINTENANCE } }`
- `POST /api/rooms` `{ number, floor, roomTypeId, notes? }` → Room (409 if number exists)
- `PUT /api/rooms/[id]` `{ number?, floor?, roomTypeId?, notes?, status? }` → Room (409 on number conflict; cannot set OCCUPIED manually — use check-in)
- `DELETE /api/rooms/[id]` → 409 if room has ACTIVE reservations
- `POST /api/rooms/[id]/status` `{ status: AVAILABLE|DIRTY|MAINTENANCE|RESERVED }` → Room (housekeeping transitions; audit)
- `GET /api/room-types` → `[RoomType + roomCount + activeReservations]`
- `POST /api/room-types` `{ name, description?, baseRate, capacity, extraAdultCharge?, amenities: string[] }` → RoomType
- `PUT /api/room-types/[id]` → RoomType; `DELETE /api/room-types/[id]` → 409 if rooms exist for type.

## Stay view (availability grid)
- `GET /api/stay-view?start=YYYY-MM-DD&days=14` (module: stay-view) →
```json
{ "rooms": [{ "id": "roomId", "number": "101", "floor": 1, "roomType": { "id": "...", "name": "Standard Room" } }],
  "days": ["2025-01-01", ...],
  "cells": { "roomId": { "2025-01-01": { "status": "OCCUPIED", "reservationId": "...", "guestName": "...", "code": "RSV-..." } | { "status": "AVAILABLE" } } },
  "stats": { "AVAILABLE": 8, "OCCUPIED": 4, "CHECKOUT_DUE": 2, "HOUSEKEEPING": 1 } }
```
  Cell status: date within an ACTIVE reservation's [checkIn, checkOut) for that room → reservation info; `CHECKOUT_DUE` when checkOut === that day; else AVAILABLE.

## Reservations
- `GET /api/reservations?tab=upcoming|checkedin|history|all&search=&from=&to=&status=&source=` (module: reservations) →
  `{ items: [Reservation + guest + roomType + room], counts: { upcoming, checkedin, history } }`
  - upcoming: status PENDING/CONFIRMED and checkOut >= today, ordered by checkIn
  - checkedin: status CHECKED_IN
  - history: CHECKED_OUT/CANCELLED/NO_SHOW or past checkOut
- `GET /api/reservations/availability?roomTypeId=&checkIn=YYYY-MM-DD&checkOut=YYYY-MM-DD&excludeReservationId=` (module: reservations | booking-engine) → `{ available: [{ id, number, floor }], totalOfType: 6, nights: 3, rate: 3500, roomType: {...} }` — used for room picker + engine.
- `POST /api/reservations` `{ guestId, roomTypeId, roomId?, checkIn: 'YYYY-MM-DD', checkOut: 'YYYY-MM-DD', adults, children?, rate?, source?, status?, specialRequests?, notes?, folio?: { type, name, contact?, phone?, gstin?, dueDate? } }` → Reservation (with guest/roomType/room). Server computes: nights, totalAmount = nights*rate(+extraAdult for adults>capacity? no — rate is final), tax NOT included in totalAmount (rooms stored net; tax applied on invoice). Overlap guard (409 `"Room 101 is already booked for the selected dates"`): same roomId OR (roomId null → per roomType availability) with status PENDING/CONFIRMED/CHECKED_IN. Room MAINTENANCE → 409. Auto-create folio when `folio` provided. audit CREATE.
- `GET /api/reservations/[id]` → `{ reservation (+guest, roomType, room, folio+entries, invoices, orders, review), canCheckIn, canCheckOut }`
- `PUT /api/reservations/[id]` `{ guestId?, roomTypeId?, roomId?, checkIn?, checkOut?, adults?, children?, rate?, source?, specialRequests?, notes? }` → revalidates overlap (excluding self); recomputes totalAmount. 409s as above. audit UPDATE.
- `POST /api/reservations/[id]/cancel` `{ reason? }` → status CANCELLED; if roomId set → room back to AVAILABLE (unless occupied by another stay); folio OPEN stays. audit CANCEL.
- `POST /api/reservations/[id]/no-show` → status NO_SHOW. audit.
- `POST /api/reservations/[id]/checkin` `{ roomId }` (module: checkins | reservations) → sets status CHECKED_IN, actualCheckIn=now, assigns room (roomId from body overrides reservation.roomId; validates room belongs to roomTypeId, room status AVAILABLE/RESERVED/DIRTY), room.status=OCCUPIED. Creates INDIVIDUAL folio (open) if none. → `{ reservation }`. 409 if overlap. audit CHECKIN.
- `POST /api/reservations/[id]/checkout` (module: checkins | reservations) → checks folio balance: if open charges exist and `force` not true → 409 `{ error: "Folio has unsettled charges", balance: 5000 }`. Sets CHECKED_OUT + actualCheckOut, room.status=DIRTY (housekeeping DIRTY). audit CHECKOUT. → `{ reservation }`.
- `POST /api/reservations/[id]/payment` `{ amount, method, reference? }` (module: invoices | checkins) → records Payment (invoiceId null, reservationId-linked via invoice with reservation; if reservation has no invoice, create one from current folio first), updates reservation.paidAmount, adds folio PAYMENT entry. → `{ payment }`.

## Food & Beverage
- `GET /api/menu?category=&available=` (module: food-menu) → `[MenuItem]`
- `POST /api/menu` `{ name, category, description?, price, isVeg?, available? }` → MenuItem
- `PUT /api/menu/[id]` → MenuItem; `DELETE /api/menu/[id]` → 409 if used in orders (else delete).
- `GET /api/orders?status=&type=&search=&scope=all|checkins|restaurant|bar` (module: food-orders) → `{ items: [RestaurantOrder + items.menuItem + guest + reservation.room], counts: { PENDING, ACCEPTED, DELIVERED, PARTIALLY_DELIVERED, CANCELLED } }`
- `POST /api/orders` `{ type: ROOM_SERVICE|RESTAURANT|BAR, reservationId?, guestId?, roomId?, tableNumber?, notes?, items: [{ menuItemId, quantity }] }` → computes subtotal/tax(5%)/total; status PENDING. If reservationId & type ROOM_SERVICE → folio CHARGE entry (category FOOD) on reservation folio & chargedToRoom=true. audit CREATE. → order (+items).
- `PUT /api/orders/[id]` `{ status?, items?, notes? }` → updates status (PENDING→ACCEPTED→DELIVERED / PARTIALLY_DELIVERED / CANCELLED — CANCELLED only from PENDING/ACCEPTED), deliveredAt when DELIVERED; items replace recomputes totals and folio charge (if chargedToRoom). audit UPDATE.
- `POST /api/orders/[id]/invoice` (module: invoices) → creates Invoice for the order (billingType INDIVIDUAL, subtotal/tax/total from order, items FOOD). → `{ invoice }`.

## Ledger (petty cash / cash in / cash out)
- `GET /api/ledger?from=&to=&type=&method=` (module: ledger) →
```json
{ "entries": [LedgerEntry desc], "summary": { "opening": 50000, "cashIn": 25000, "cashOut": 4700, "closing": 70300,
  "inByMethod": { "CASH": 18000, "UPI": 7000, ... }, "outByMethod": {...},
  "paymentsByMethod": { "CASH": 5000, "UPI": 1200, "DEBIT_CARD": 0, "CREDIT_CARD": 0, "BANK_TRANSFER": 0, "RAZORPAY": 0, "OTHER": 0 } } }
```
  - `paymentsByMethod` from Payment rows in range (direction IN).
- `POST /api/ledger` `{ type: OPENING|CASH_IN|CASH_OUT, amount, method, category?, remarks? }` → entry (amount>0). audit.
- `GET /api/payments?from=&to=&method=&category=` (module: invoices | ledger) → `[Payment + invoice.number]`

## Invoices
- `GET /api/invoices?billingType=&status=&search=&from=&to=` (module: invoices) → `{ items: [Invoice + guest + reservation.code], counts: { all, company, individual, ota, uninvoiced } }`
- `GET /api/invoices/[id]` → `{ invoice + items + payments + guest + reservation(+roomType/room) }`
- `POST /api/invoices` (module: invoices) `{ reservationId? }` → generates invoice from reservation folio: ROOM charges + FOOD/SERVICE entries as items, tax 12% on room, 5% on food (config in HotelSetting). If exists UNPAID invoice for reservation → 409 `"Invoice already exists"`. → invoice. audit CREATE.
- `POST /api/invoices` `{ orderId }` → from order (see /api/orders/[id]/invoice).
- `POST /api/invoices/[id]/payments` `{ amount, method, reference?, remarks? }` → Payment, invoice.paidAmount & status PARTIAL/PAID. If invoice.folioId → folio PAYMENT entry. audit PAYMENT. → `{ payment, invoice }`
- `POST /api/invoices/[id]/void` → status VOID (only if paidAmount==0). audit.
- `PUT /api/invoices/[id]` `{ discount?, notes? }` → recompute total = subtotal + tax − discount − paid? (keep simple: total = subtotal + tax − discount; status from paidAmount).

## Folios
- `GET /api/folios/summary` (module: folio-company | folio-ota) → `{ totalUnsettled, individualUnsettled, companyUnsettled, otaUnsettled }`
- `GET /api/folios?type=COMPANY|INDIVIDUAL|OTA&search=&status=` → `{ items: [Folio + company + reservation.code, balance computed = charges − payments] }` (balance via entries)
- `POST /api/folios` `{ type, name, contact?, phone?, gstin?, otaName?, guestId?, companyId?, reservationId?, dueDate?, notes?, entries?: [{type, description, amount, category?}] }` → Folio (+entries). audit.
- `GET /api/folios/[id]` → `{ folio + entries + company + guest + reservation + invoices }`
- `PUT /api/folios/[id]` `{ name?, contact?, phone?, gstin?, dueDate?, notes?, status? }` → Folio
- `POST /api/folios/[id]/entries` `{ type: CHARGE|PAYMENT|ADJUSTMENT, description, amount, category? }` → entry. PAYMENT negative amount. audit.
- `DELETE /api/folios/[id]/entries?entryId=` → removes entry (audit).
- `POST /api/folios/[id]/settle` `{ method }` → validates balance==0? No: creates PAYMENT entry for remaining balance, marks SETTLED, creates Invoice if none (billingType from folio.type). → `{ folio, invoice? }`. audit.
- `DELETE /api/folios/[id]` → 409 if SETTLED or has invoices; else delete (+entries cascade).

## OTA & Website (public booking engine)
- `GET /api/website/config` (public) → `{ name, tagline, address, phone, currency, bookingEngineEnabled, paymentMode, roomTypes: [{ id, name, description, baseRate, capacity, amenities, roomCount }] }`
- `GET /api/website/availability?checkIn=YYYY-MM-DD&checkOut=YYYY-MM-DD&adults=2` (public) → `{ roomTypes: [{ id, name, description, baseRate, capacity, amenities, available: 3, total: 6, nights, totalForStay }] }`
- `POST /api/website/book` (public) `{ guest: { firstName, lastName, email, phone }, roomTypeId, checkIn, checkOut, adults, children?, specialRequests?, source?: WEBSITE | OTA_<name> }` → creates Guest (if new by email) + Reservation (status CONFIRMED, source default WEBSITE, totalAmount = nights*rate; tax at invoice). Overlap guard. audit CREATE. → `{ reservation: { code, checkIn, checkOut, roomTypeName, totalAmount } }`
- `GET /api/ota/bookings?source=OTA_BOOKING_COM|...&status=&search=` (module: channel-manager) → `{ items: [Reservation + guest + roomType + room], counts by source }`
- `PUT /api/ota/bookings/[id]/status` `{ status: CONFIRMED|CANCELLED }` (channel-manager) → for OTA bookings. audit.

## Reports (module: reports-standard / reports-custom / reports-bi)
- `GET /api/reports/revenue?from=&to=` → `{ from, to, rows: [{ date, roomRevenue, fbRevenue, other, total }], totals: { room, fb, other, total }, taxTotals: { room, fb } }`
- `GET /api/reports/payments?from=&to=` → `{ rows: [{ date, CASH, UPI, DEBIT_CARD, CREDIT_CARD, BANK_TRANSFER, RAZORPAY, OTHER, total }], totals }`
- `GET /api/reports/outstanding` → `{ rows: [{ invoiceNumber, billingType, guestName, folioName, issuedAt, total, paidAmount, balance, daysDue }], totals: { total, collected, outstanding } }`
- `GET /api/reports/invoice-summary?from=&to=` → `{ rows: [{ number, issuedAt, billingType, guestName, subtotal, tax, discount, total, paidAmount, status }], totals }`
- `GET /api/reports/room-sales?from=&to=` → `{ rows: [{ roomNumber, roomTypeName, nights, revenue, reservations }], totals }`
- `GET /api/reports/night-audit?date=YYYY-MM-DD` →
```json
{ "date": "...",
  "revenue": { "roomRevenue", "fbRoomService", "fbRestaurant", "roomDiscount", "foodDiscount", "total" },
  "tax": { "roomTaxes", "fbTaxes", "total" },
  "payments": { "CASH": 0, "UPI": 0, ..., "total" },
  "reservationsActivity": [{ "code", "guestName", "roomNumber", "action": "ARRIVAL|DEPARTURE|CREATED|CANCELLED", "time" }],
  "checkinActivity": [{ "code", "guestName", "roomNumber", "time" }],
  "occupancy": { "totalRooms", "occupiedTonight", "occupancyRate", "arrivals", "departures", "inHouse" } }
```
- `GET /api/reports/ota?from=&to=` → `{ rows: [{ source, bookings, nights, revenue, commissionRate, commission }], totals }` (reservations source OTA_*, revenue = totalAmount of non-cancelled)
- `GET /api/reports/police?date=YYYY-MM-DD` → `{ rows: [{ guestName, nationality, idType, idNumber, phone, roomNumber, checkIn, checkOut }], date }` (guests in-house or arrived that day)
- `GET /api/reports/occupancy?from=&to=` (BI) → `{ occupancyTrend: [{date, occupancy, revenue}], totals: { availableRoomNights, soldRoomNights, occupancyRate, avgStayNights, avgRate } }`
- `GET /api/reports/reservations?from=&to=&status=&source=` → `{ rows: [Reservation + guest + roomType + room], summary: { total, byStatus: {...}, bySource: [...] } }`

## Reviews
- `GET /api/reviews?period=30|90|365&channel=` (module: reviews) → `{ items: [Review + guest], insights: { avgRating, count, distribution: {5: n, 4: n, ...}, byChannel: [{channel, count, avg}], needsReply } }`
- `POST /api/reviews` `{ guestId?, reservationId?, channel?, rating, title?, comment }` → Review
- `PUT /api/reviews/[id]` `{ reply?, status? }` → Review (audit reply)
- `DELETE /api/reviews/[id]` → `{ ok: true }`

## Support (DigiAI)
- `GET /api/support/messages?sessionId=` → `[SupportMessage asc]`
- `POST /api/support/chat` `{ sessionId, message }` (auth) → **DigiAI 2.0 agentic assistant** (z-ai-web-dev-sdk). System prompt carries a live snapshot (occupancy/arrivals/departures/outstanding/pending orders) + 9 read-only tools executed server-side in an agentic loop (max 3 tool rounds): `get_occupancy`, `get_arrivals_departures`, `search_reservations`, `get_room_availability`, `get_guest_profile`, `list_pending_food_orders`, `get_reviews_summary` (any staff) and `get_outstanding_invoices`, `get_revenue_summary` (ADMIN/ACCOUNTANT only — forbidden tools return `{"error":"not permitted for your role"}` and the assistant explains politely). Saves USER + final ASSISTANT messages (history window 10). → `{ reply, messages: last 50 asc, actions }` where `actions: [{ tool, summary }]` is a one-line human-readable description of every tool call attempted (empty array when no tools were used). LLM failures → graceful fallback reply (never 500; 400 only for bad body).
- `GET /api/support/tutorials?search=` → static array of tutorial objects `{ id, title, category, duration, description, steps: string[] }` (10 items, categories: Check-in, Reports, Invoices, Settings, Languages, Group Booking, PMS - Basic).

## AI Automation (DigiAI 2.0)
Shared lib: `src/lib/ai.ts` (cached ZAI factory `getZAI()`, robust `extractJson()`, `callLLM()` with 1 retry, hotel context builders). LLM responses are zod-validated; every route below has a deterministic fallback so it NEVER 500s because of an LLM hiccup (400 only for bad bodies, 401/403 from auth).

- `GET /api/ai/insights?refresh=` (ADMIN only) → `{ insights: [{ title (≤60), detail (≤220, cites numbers), severity: "positive"|"warning"|"critical"|"info", action (≤100) }] (4-6), generatedAt: ISO, cached: boolean }`.
  Real metrics: today's occupancy (+out-of-service), 14-day occupancy trend, ADR & RevPAR (last 14d, pro-rated room charges), outstanding invoiced total, pending F&B orders, arrivals next 7d, per-type next-7d sell-out pressure, avg review rating + buckets, top channel (30d), cancellations/no-shows (30d). LLM output zod-validated, invalid entries dropped (<4 valid → padded/fulfilled by rule-based insights). In-memory cache TTL 5 min (`cached: true` on hits); `?refresh=1` bypasses; concurrent duplicate computations share one in-flight promise.
- `GET /api/ai/pricing` (ADMIN only) → `{ suggestions: [{ roomTypeId, roomTypeName, currentRate, suggestedRate, deltaPercent, occupancy14d (0..1, past 14d), next14dBookedRatio (0..1, next 14d), reason }], generatedAt }`. One entry per room type. Deterministic band-based suggestion first (±5-20% by demand/occupancy, weekend-skew bump, rounded to nearest ₹100, never below 0.8× base), then ONE LLM call writes the `reason` per type (rule-based reason strings on failure). **NO DB WRITES** — apply via the existing `PUT /api/room-types/[id]` `{ baseRate }`.
- `POST /api/ai/review-reply` (ADMIN | RECEPTIONIST) `{ reviewId }` → `{ reply (≤120 words, warm hotelier tone, no refund promises), sentiment: "positive"|"neutral"|"negative", themes: string[] (2-4) }`. LLM returns strict JSON (zod-validated); fallback = template reply by rating band + sentiment by rating (≥4 positive, 3 neutral, ≤2 negative) + keyword-derived themes. **NO DB WRITES** — staff post the reply themselves via `PUT /api/reviews/[id]` `{ reply }`.
- `POST /api/ai/smart-assign` (ADMIN | RECEPTIONIST) `{ reservationId }` → `{ suggestions: [{ roomId, roomNumber, typeName, score, reasons: string[] (2-3) }], bestRoomId: string|null }`. Candidates: AVAILABLE rooms of the reservation's type (falls back to higher-rate types when none free), no overlap with PENDING/CONFIRMED/CHECKED_IN reservations, capacity ≥ guests (relaxed only if pool would be empty). Deterministic scoring: stayed-in-room-before +3, special-request keyword matches (high/low floor, quiet, view, accessible) +2 each, capacity fit +1, housekeeping-ready +1, floor/number tiebreak. Top 5 → ONE LLM call writes reasons (rule-based reasons on failure); scores & order always come from our scoring. **NO DB WRITES.**
  - **Applying a suggestion:** the existing `PUT /api/reservations/[id]` `{ roomId }` already re-validates overlap (excluding self), room-type match and maintenance status — the UI calls it directly. For an upgraded type, send `{ roomTypeId, rate }` too (rate = new type's baseRate). A separate AI apply endpoint was therefore NOT needed.

## Settings & Users
- `GET /api/settings` (any authenticated) → HotelSetting
- `PUT /api/settings` (module: settings, ADMIN only) `{ ...fields }` → HotelSetting. audit.
- `GET /api/users` (ADMIN) → `[User - passwordHash + sessionCount]`
- `POST /api/users` (ADMIN) `{ name, email, password, role, phone? }` → 409 dup email
- `PUT /api/users/[id]` (ADMIN) `{ name?, role?, phone?, active?, password? }` → User (prevent demoting/deactivating last active ADMIN)
- `DELETE /api/users/[id]` (ADMIN) → 409 if last active admin or has sessions? (delete sessions)
- `GET /api/audit-logs?search=&limit=100` (ADMIN) → `[AuditLog desc]`

## Frontend routing note
Single page `/` SPA. Sidebar module → view component registry. Use `X-` free plain fetch wrapper `apiGet/apiPost/apiPut/apiDelete` from `src/lib/api-client.ts` (adds Bearer token from zustand auth store, unwraps error json → throws Error(message)).
