import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit, parseBody } from "@/lib/api-helpers";
import { recordInvoicePayment } from "@/lib/billing";

// POST /api/invoices/[id]/payments { amount, method, reference?, remarks? } (module: invoices)
export const POST = withAuth(
  async (req, { user, params }) => {
    const b = await parseBody<Record<string, unknown>>(req);
    const amount = Number(b.amount);
    const method = typeof b.method === "string" && b.method ? b.method : "CASH";
    if (!Number.isFinite(amount) || amount <= 0) throw new ApiError("Payment amount must be greater than zero", 400);

    const payment = await recordInvoicePayment(params.id, {
      amount,
      method,
      reference: typeof b.reference === "string" ? b.reference : undefined,
      remarks: typeof b.remarks === "string" ? b.remarks : undefined,
      receivedBy: user.name,
    });
    const invoice = await db.invoice.findUnique({
      where: { id: params.id },
      include: { payments: true, items: true, guest: true },
    });
    await audit(user, "PAYMENT", "Invoice", params.id, `Payment ${amount} via ${method} on invoice ${invoice?.number ?? params.id}`);
    return ok({ payment, invoice });
  },
  { module: "invoices" }
);
