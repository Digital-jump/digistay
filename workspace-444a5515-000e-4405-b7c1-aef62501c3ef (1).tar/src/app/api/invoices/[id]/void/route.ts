import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit } from "@/lib/api-helpers";

// POST /api/invoices/[id]/void (module: invoices)
export const POST = withAuth(
  async (req, { user, params }) => {
    const invoice = await db.invoice.findUnique({ where: { id: params.id } });
    if (!invoice) throw new ApiError("Invoice not found", 404);
    if (invoice.paidAmount > 0) throw new ApiError("Cannot void invoice with payments", 400);
    if (invoice.status === "VOID") throw new ApiError("Invoice is already void", 400);

    const updated = await db.invoice.update({ where: { id: invoice.id }, data: { status: "VOID" } });
    await audit(user, "VOID", "Invoice", invoice.id, `Voided invoice ${invoice.number}`);
    return ok(updated);
  },
  { module: "invoices" }
);
