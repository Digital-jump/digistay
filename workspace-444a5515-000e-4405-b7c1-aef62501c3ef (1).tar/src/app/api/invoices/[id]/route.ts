import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit, money, parseBody } from "@/lib/api-helpers";

// GET /api/invoices/[id]
export const GET = withAuth(
  async (req, { params }) => {
    const invoice = await db.invoice.findUnique({
      where: { id: params.id },
      include: {
        items: true,
        payments: true,
        guest: true,
        reservation: { include: { roomType: true, room: true } },
        folio: true,
      },
    });
    if (!invoice) throw new ApiError("Invoice not found", 404);
    return ok(invoice);
  },
  { module: "invoices" }
);

// PUT /api/invoices/[id] { discount?, notes? } — recompute total + status
export const PUT = withAuth(
  async (req, { user, params }) => {
    const b = await parseBody<Record<string, unknown>>(req);
    const invoice = await db.invoice.findUnique({ where: { id: params.id } });
    if (!invoice) throw new ApiError("Invoice not found", 404);

    const data: Record<string, unknown> = {};
    if (b.discount !== undefined) {
      const discount = Number(b.discount);
      if (!Number.isFinite(discount) || discount < 0) throw new ApiError("Invalid discount", 400);
      data.discount = discount;
    }
    if (typeof b.notes === "string" || b.notes === null) data.notes = b.notes;

    const discount = typeof data.discount === "number" ? data.discount : invoice.discount;
    const total = money(invoice.subtotal + invoice.tax - discount);
    data.total = total;
    if (invoice.status !== "VOID") {
      data.status = invoice.paidAmount >= total - 0.005 ? "PAID" : invoice.paidAmount > 0 ? "PARTIAL" : "UNPAID";
    }

    const updated = await db.invoice.update({
      where: { id: invoice.id },
      data,
      include: { items: true, payments: true, guest: true },
    });
    await audit(user, "UPDATE", "Invoice", invoice.id, `Updated invoice ${invoice.number}`);
    return ok(updated);
  },
  { module: "invoices" }
);
