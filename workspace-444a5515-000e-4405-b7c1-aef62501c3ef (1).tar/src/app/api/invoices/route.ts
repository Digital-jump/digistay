import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit, parseBody, endOfDay } from "@/lib/api-helpers";
import { ensureInvoiceForReservation, ensureInvoiceForOrder, folioBalanceOf } from "@/lib/billing";

// GET /api/invoices?billingType=&status=&search=&from=&to=&include=uninvoiced (module: invoices)
export const GET = withAuth(
  async (req) => {
    const url = new URL(req.url);
    const billingType = url.searchParams.get("billingType") ?? undefined;
    const status = url.searchParams.get("status") ?? undefined;
    const search = url.searchParams.get("search")?.trim() ?? "";
    const fromStr = url.searchParams.get("from");
    const toStr = url.searchParams.get("to");

    const issuedAt: Record<string, Date> = {};
    if (fromStr && /^\d{4}-\d{2}-\d{2}$/.test(fromStr)) issuedAt.gte = new Date(`${fromStr}T00:00:00`);
    if (toStr && /^\d{4}-\d{2}-\d{2}$/.test(toStr)) issuedAt.lte = endOfDay(new Date(`${toStr}T00:00:00`));

    const where: Record<string, unknown> = {
      ...(billingType ? { billingType } : {}),
      ...(status ? { status } : {}),
      ...(Object.keys(issuedAt).length ? { issuedAt } : {}),
    };
    if (search) {
      where.OR = [
        { number: { contains: search } },
        { orderId: { contains: search } },
        { guest: { OR: [{ firstName: { contains: search } }, { lastName: { contains: search } }] } },
      ];
    }

    const [items, groups, checkedIn] = await Promise.all([
      db.invoice.findMany({
        where,
        include: {
          guest: true,
          reservation: { include: { roomType: true, room: true } },
          folio: true,
        },
        orderBy: { issuedAt: "desc" },
      }),
      db.invoice.groupBy({ by: ["billingType"], _count: true }),
      db.reservation.findMany({
        where: { status: "CHECKED_IN" },
        include: {
          guest: true,
          room: true,
          invoices: { select: { id: true, status: true } },
          folio: { include: { entries: true } },
        },
      }),
    ]);

    const counts: Record<string, number> = { all: 0, company: 0, individual: 0, ota: 0, uninvoiced: 0 };
    counts.all = groups.reduce((s, g) => s + g._count, 0);
    for (const g of groups) {
      if (g.billingType === "COMPANY") counts.company = g._count;
      if (g.billingType === "INDIVIDUAL") counts.individual = g._count;
      if (g.billingType === "OTA") counts.ota = g._count;
    }

    const uninvoiced = checkedIn.filter((r) => !r.invoices.some((i) => i.status !== "VOID"));
    counts.uninvoiced = uninvoiced.length;

    const result: Record<string, unknown> = { items, counts };
    if (url.searchParams.get("include") === "uninvoiced") {
      result.uninvoicedReservations = uninvoiced.map((r) => ({
        reservationId: r.id,
        code: r.code,
        guestName: `${r.guest.firstName} ${r.guest.lastName}`,
        roomNumber: r.room?.number ?? null,
        folioBalance: r.folio ? folioBalanceOf(r.folio.entries) : 0,
      }));
    }
    return ok(result);
  },
  { module: "invoices" }
);

// POST /api/invoices { reservationId? } or { orderId? } (module: invoices)
export const POST = withAuth(
  async (req, { user }) => {
    const b = await parseBody<Record<string, unknown>>(req);
    if (typeof b.reservationId === "string" && b.reservationId) {
      const invoice = await ensureInvoiceForReservation(b.reservationId);
      await audit(user, "CREATE", "Invoice", invoice?.id, `Invoice ${invoice?.number ?? ""} generated`);
      return ok(invoice);
    }
    if (typeof b.orderId === "string" && b.orderId) {
      const invoice = await ensureInvoiceForOrder(b.orderId);
      await audit(user, "CREATE", "Invoice", invoice?.id, `Invoice ${invoice?.number ?? ""} generated`);
      return ok(invoice);
    }
    throw new ApiError("Provide reservationId or orderId", 400);
  },
  { module: "invoices" }
);
