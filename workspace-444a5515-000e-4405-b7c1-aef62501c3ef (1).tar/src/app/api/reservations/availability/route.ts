import { db } from "@/lib/db";
import { ApiError, fail, money, nightsBetween, ok, overlappingReservationsFilter, withAuth } from "@/lib/api-helpers";
import { canAccessAny, parseDateStr } from "@/lib/reservation-helpers";

export const GET = withAuth(async (req, { user }) => {
  if (!canAccessAny(user.role, ["reservations", "booking-engine"])) {
    return fail("Forbidden: module not allowed for your role", 403);
  }
  const url = new URL(req.url);
  const roomTypeId = url.searchParams.get("roomTypeId") ?? "";
  const checkInParam = url.searchParams.get("checkIn");
  const checkOutParam = url.searchParams.get("checkOut");
  const excludeReservationId = url.searchParams.get("excludeReservationId") ?? undefined;
  if (!roomTypeId || !checkInParam || !checkOutParam) {
    throw new ApiError("roomTypeId, checkIn and checkOut are required", 400);
  }

  const roomType = await db.roomType.findUnique({ where: { id: roomTypeId } });
  if (!roomType) throw new ApiError("Room type not found", 404);

  const checkIn = parseDateStr(checkInParam, "checkIn");
  const checkOut = parseDateStr(checkOutParam, "checkOut");
  const nights = nightsBetween(checkIn, checkOut);
  if (nights < 1) throw new ApiError("Check-out must be after check-in", 409);

  const rooms = await db.room.findMany({ where: { roomTypeId }, orderBy: { number: "asc" } });
  const available: { id: string; number: string; floor: number }[] = [];
  for (const room of rooms) {
    if (room.status === "MAINTENANCE") continue;
    const clash = await db.reservation.findFirst({
      where: overlappingReservationsFilter({
        roomId: room.id,
        checkIn,
        checkOut,
        excludeId: excludeReservationId,
      }),
    });
    if (!clash) available.push({ id: room.id, number: room.number, floor: room.floor });
  }

  const rateParam = parseFloat(url.searchParams.get("rate") ?? "");
  const rate = Number.isFinite(rateParam) && rateParam >= 0 ? rateParam : roomType.baseRate;

  return ok({
    available,
    totalOfType: rooms.length,
    nights,
    rate: money(rate),
    roomType,
  });
});
