import { db } from "@/lib/db";
import {
  ACTIVE_RESERVATION_STATUSES,
  ApiError,
  audit,
  fail,
  endOfDay,
  money,
  nightsBetween,
  nextCode,
  ok,
  startOfDay,
  withAuth,
} from "@/lib/api-helpers";
import { canAccessAny, assertNoOverlap, parseDateStr } from "@/lib/reservation-helpers";

const RESERVATION_STATUSES = ["PENDING", "CONFIRMED", "CHECKED_IN", "CHECKED_OUT", "CANCELLED", "NO_SHOW"];
const SOURCES = [
  "DIRECT", "WEBSITE", "OTA_BOOKING_COM", "OTA_MAKE_MY_TRIP", "OTA_AIRBNB",
  "OTA_EXPEDIA", "OTA_GOIBIBO", "PHONE", "WALK_IN", "COMPANY",
];

export const GET = withAuth(async (req, { user }) => {
  if (!canAccessAny(user.role, ["reservations"])) {
    return fail("Forbidden: module not allowed for your role", 403);
  }
  const url = new URL(req.url);
  const tab = url.searchParams.get("tab") ?? "all";
  const search = (url.searchParams.get("search") ?? "").trim().toLowerCase();
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  const status = url.searchParams.get("status") ?? "";
  const source = url.searchParams.get("source") ?? "";

  const reservations = await db.reservation.findMany({
    include: { guest: true, roomType: true, room: true },
    orderBy: { createdAt: "desc" },
  });

  const today = startOfDay(new Date()).getTime();
  const fromTs = from ? startOfDay(new Date(`${from}T00:00:00`)).getTime() : null;
  const toTs = to ? endOfDay(new Date(`${to}T00:00:00`)).getTime() : null;

  const filtered = reservations.filter((r) => {
    if (status && r.status !== status) return false;
    if (source && r.source !== source) return false;
    const checkInTs = startOfDay(r.checkIn).getTime();
    if (fromTs !== null && checkInTs < fromTs) return false;
    if (toTs !== null && checkInTs > toTs) return false;
    if (search) {
      const guestName = `${r.guest.firstName} ${r.guest.lastName}`.toLowerCase();
      const phone = (r.guest.phone ?? "").toLowerCase();
      if (!r.code.toLowerCase().includes(search) && !guestName.includes(search) && !phone.includes(search)) {
        return false;
      }
    }
    return true;
  });

  const isUpcoming = (r: (typeof filtered)[number]) =>
    ["PENDING", "CONFIRMED"].includes(r.status) && startOfDay(r.checkOut).getTime() >= today;
  const isCheckedin = (r: (typeof filtered)[number]) => r.status === "CHECKED_IN";
  const isHistory = (r: (typeof filtered)[number]) =>
    ["CHECKED_OUT", "CANCELLED", "NO_SHOW"].includes(r.status) || startOfDay(r.checkOut).getTime() < today;

  const counts = {
    upcoming: filtered.filter(isUpcoming).length,
    checkedin: filtered.filter(isCheckedin).length,
    history: filtered.filter(isHistory).length,
  };

  let items = filtered;
  if (tab === "upcoming") {
    items = filtered.filter(isUpcoming).sort((a, b) => a.checkIn.getTime() - b.checkIn.getTime());
  } else if (tab === "checkedin") {
    items = filtered.filter(isCheckedin).sort((a, b) => a.checkIn.getTime() - b.checkIn.getTime());
  } else if (tab === "history") {
    items = filtered.filter(isHistory).sort((a, b) => b.checkIn.getTime() - a.checkIn.getTime());
  }

  return ok({ items, counts });
});

export const POST = withAuth(async (req, { user }) => {
  if (!canAccessAny(user.role, ["reservations"])) {
    return fail("Forbidden: module not allowed for your role", 403);
  }
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

  const guestId = typeof body.guestId === "string" ? body.guestId : "";
  const roomTypeId = typeof body.roomTypeId === "string" ? body.roomTypeId : "";
  if (!guestId || !roomTypeId || !body.checkIn || !body.checkOut) {
    throw new ApiError("guestId, roomTypeId, checkIn and checkOut are required", 400);
  }

  const guest = await db.guest.findUnique({ where: { id: guestId } });
  if (!guest) throw new ApiError("Guest not found", 404);
  const roomType = await db.roomType.findUnique({ where: { id: roomTypeId } });
  if (!roomType) throw new ApiError("Room type not found", 404);

  const checkIn = parseDateStr(body.checkIn, "checkIn");
  const checkOut = parseDateStr(body.checkOut, "checkOut");
  const nights = nightsBetween(checkIn, checkOut);
  if (nights < 1) throw new ApiError("Check-out must be after check-in", 409);

  const rate = typeof body.rate === "number" && body.rate >= 0 ? body.rate : roomType.baseRate;
  const source = typeof body.source === "string" && SOURCES.includes(body.source) ? body.source : "DIRECT";
  const status =
    typeof body.status === "string" && RESERVATION_STATUSES.includes(body.status) ? body.status : "CONFIRMED";
  const roomId = typeof body.roomId === "string" && body.roomId ? body.roomId : null;

  await assertNoOverlap({ roomTypeId, roomId, checkIn, checkOut });

  const totalAmount = money(nights * rate);
  const code = await nextCode("RSV", db.reservation);

  const reservation = await db.reservation.create({
    data: {
      code,
      guestId,
      roomTypeId,
      roomId,
      checkIn,
      checkOut,
      adults: typeof body.adults === "number" && body.adults >= 1 ? Math.floor(body.adults) : 1,
      children: typeof body.children === "number" && body.children >= 0 ? Math.floor(body.children) : 0,
      status,
      source,
      rate,
      totalAmount,
      specialRequests:
        typeof body.specialRequests === "string" && body.specialRequests.trim() ? body.specialRequests.trim() : null,
      notes: typeof body.notes === "string" && body.notes.trim() ? body.notes.trim() : null,
    },
  });

  const folioPayload = body.folio as Record<string, unknown> | undefined;
  if (folioPayload && typeof folioPayload === "object") {
    const folioCode = await nextCode("FOL", db.folio);
    await db.folio.create({
      data: {
        code: folioCode,
        type: typeof folioPayload.type === "string" ? folioPayload.type : "INDIVIDUAL",
        name:
          typeof folioPayload.name === "string" && folioPayload.name.trim()
            ? folioPayload.name.trim()
            : `${guest.firstName} ${guest.lastName}`,
        contact: typeof folioPayload.contact === "string" ? folioPayload.contact : null,
        phone: typeof folioPayload.phone === "string" ? folioPayload.phone : null,
        gstin: typeof folioPayload.gstin === "string" ? folioPayload.gstin : null,
        dueDate: typeof folioPayload.dueDate === "string" ? new Date(folioPayload.dueDate) : null,
        guestId,
        reservationId: reservation.id,
      },
    });
  }

  await audit(user, "CREATE", "Reservation", reservation.id, `${code} — ${guest.firstName} ${guest.lastName}`);
  const full = await db.reservation.findUnique({
    where: { id: reservation.id },
    include: { guest: true, roomType: true, room: true },
  });
  return ok(full);
});
