import { db } from "@/lib/db";
import {
  ApiError,
  audit,
  fail,
  money,
  nightsBetween,
  nextCode,
  ok,
  overlappingReservationsFilter,
  withAuth,
} from "@/lib/api-helpers";
import { canAccessAny } from "@/lib/reservation-helpers";

export const POST = withAuth(async (req, { user, params }) => {
  if (!canAccessAny(user.role, ["checkins", "reservations"])) {
    return fail("Forbidden: module not allowed for your role", 403);
  }
  const reservation = await db.reservation.findUnique({
    where: { id: params.id },
    include: { guest: true, roomType: true },
  });
  if (!reservation) throw new ApiError("Reservation not found", 404);
  if (!["PENDING", "CONFIRMED"].includes(reservation.status)) {
    throw new ApiError("Reservation is not awaiting check-in", 400);
  }

  const body = (await req.json().catch(() => ({}))) as { roomId?: unknown };
  const roomId = typeof body.roomId === "string" && body.roomId ? body.roomId : reservation.roomId;
  if (!roomId) throw new ApiError("Select a room to check in", 400);

  const room = await db.room.findUnique({ where: { id: roomId } });
  if (!room) throw new ApiError("Room not found", 404);
  if (room.roomTypeId !== reservation.roomTypeId) {
    throw new ApiError("Room does not belong to the reserved room type", 400);
  }
  if (room.status === "MAINTENANCE" || room.status === "OCCUPIED") {
    throw new ApiError("Room is not available", 409);
  }

  const clash = await db.reservation.findFirst({
    where: overlappingReservationsFilter({
      roomId,
      checkIn: reservation.checkIn,
      checkOut: reservation.checkOut,
      excludeId: reservation.id,
    }),
  });
  if (clash) throw new ApiError(`Room ${room.number} is already booked for the selected dates`, 409);

  const now = new Date();
  await db.reservation.update({
    where: { id: reservation.id },
    data: { status: "CHECKED_IN", actualCheckIn: now, roomId },
  });
  await db.room.update({ where: { id: roomId }, data: { status: "OCCUPIED", housekeeping: "CLEAN" } });

  // Ensure an INDIVIDUAL folio exists with the room charge
  let folio = await db.folio.findFirst({ where: { reservationId: reservation.id }, include: { entries: true } });
  if (!folio) {
    const folioCode = await nextCode("FOL", db.folio);
    folio = await db.folio.create({
      data: {
        code: folioCode,
        type: "INDIVIDUAL",
        name: `${reservation.guest.firstName} ${reservation.guest.lastName}`.trim(),
        guestId: reservation.guestId,
        reservationId: reservation.id,
      },
      include: { entries: true },
    });
  }
  const hasRoomCharge = folio.entries.some((e) => e.type === "CHARGE" && e.category === "ROOM");
  if (!hasRoomCharge) {
    const nights = Math.max(1, nightsBetween(reservation.checkIn, reservation.checkOut));
    await db.folioEntry.create({
      data: {
        folioId: folio.id,
        type: "CHARGE",
        description: `Room charges (${nights} nights × ₹${money(reservation.rate)})`,
        amount: money(nights * reservation.rate),
        category: "ROOM",
        createdBy: user.name,
      },
    });
  }

  await audit(
    user,
    "CHECKIN",
    "Reservation",
    reservation.id,
    `${reservation.code} checked in to Room ${room.number}`
  );

  const updated = await db.reservation.findUnique({
    where: { id: reservation.id },
    include: { guest: true, roomType: true, room: true, folio: { include: { entries: true } } },
  });
  return ok(updated);
});
