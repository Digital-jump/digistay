import { db } from "@/lib/db";
import { ApiError, audit, fail, ok, withAuth } from "@/lib/api-helpers";
import { canAccessAny } from "@/lib/reservation-helpers";

export const POST = withAuth(async (_req, { user, params }) => {
  if (!canAccessAny(user.role, ["reservations", "checkins"])) {
    return fail("Forbidden: module not allowed for your role", 403);
  }
  const existing = await db.reservation.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Reservation not found", 404);
  if (!["PENDING", "CONFIRMED"].includes(existing.status)) {
    throw new ApiError("Only pending or confirmed reservations can be marked as no-show", 400);
  }

  if (existing.roomId) {
    const room = await db.room.findUnique({ where: { id: existing.roomId } });
    if (room && room.status === "RESERVED") {
      await db.room.update({ where: { id: room.id }, data: { status: "AVAILABLE" } });
    }
  }

  const reservation = await db.reservation.update({
    where: { id: params.id },
    data: { status: "NO_SHOW" },
    include: { guest: true, roomType: true, room: true },
  });

  await audit(user, "NO_SHOW", "Reservation", reservation.id, `${reservation.code} marked as no-show`);
  return ok(reservation);
});
