import { db } from "@/lib/db";
import { ApiError, audit, fail, ok, withAuth } from "@/lib/api-helpers";
import { canAccessAny } from "@/lib/reservation-helpers";
import { ensureInvoiceForReservation, recordInvoicePayment } from "@/lib/billing";

const METHODS = ["CASH", "UPI", "DEBIT_CARD", "CREDIT_CARD", "BANK_TRANSFER", "RAZORPAY", "OTHER"];

export const POST = withAuth(async (req, { user, params }) => {
  if (!canAccessAny(user.role, ["invoices", "checkins"])) {
    return fail("Forbidden: module not allowed for your role", 403);
  }
  const reservation = await db.reservation.findUnique({ where: { id: params.id } });
  if (!reservation) throw new ApiError("Reservation not found", 404);

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const amount = typeof body.amount === "number" ? body.amount : NaN;
  if (!(amount > 0)) throw new ApiError("Payment amount must be greater than zero", 400);
  const method = typeof body.method === "string" ? body.method : "";
  if (!METHODS.includes(method)) throw new ApiError("Invalid payment method", 400);

  const baseInvoice = await ensureInvoiceForReservation(reservation.id);
  if (!baseInvoice) throw new ApiError("Could not create invoice for this reservation", 500);

  const payment = await recordInvoicePayment(baseInvoice.id, {
    amount,
    method,
    reference: typeof body.reference === "string" ? body.reference : undefined,
    remarks: typeof body.remarks === "string" ? body.remarks : undefined,
    receivedBy: user.name,
  });

  const invoice = await db.invoice.findUnique({
    where: { id: baseInvoice.id },
    include: { items: true, payments: true },
  });

  await audit(
    user,
    "PAYMENT",
    "Reservation",
    reservation.id,
    `${reservation.code} — ₹${amount} via ${method}`
  );

  return ok({ payment, invoice });
});
