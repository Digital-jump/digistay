import { db } from "@/lib/db";
import { ApiError, audit, fail, money, ok, withAuth } from "@/lib/api-helpers";
import { canAccessAny } from "@/lib/reservation-helpers";
import { folioBalanceOf } from "@/lib/billing";

export const POST = withAuth(async (req, { user, params }) => {
  if (!canAccessAny(user.role, ["checkins", "reservations"])) {
    return fail("Forbidden: module not allowed for your role", 403);
  }
  const existing = await db.reservation.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Reservation not found", 404);
  if (existing.status !== "CHECKED_IN") {
    throw new ApiError("Reservation is not checked in", 400);
  }

  const folio = await db.folio.findFirst({ where: { reservationId: existing.id }, include: { entries: true } });
  const balance = folio ? folioBalanceOf(folio.entries) : 0;

  const body = (await req.json().catch(() => ({}))) as { force?: unknown };
  if (balance > 0.005 && body.force !== true) {
    return ok({ error: "Folio has unsettled charges", balance }, 409);
  }

  const now = new Date();
  const reservation = await db.reservation.update({
    where: { id: existing.id },
    data: { status: "CHECKED_OUT", actualCheckOut: now },
  });

  if (existing.roomId) {
    await db.room.update({
      where: { id: existing.roomId },
      data: { status: "DIRTY", housekeeping: "DIRTY" },
    });
  }

  await audit(
    user,
    "CHECKOUT",
    "Reservation",
    reservation.id,
    `${reservation.code} checked out — folio balance ₹${money(balance)}${body.force === true && balance > 0.005 ? " (forced)" : ""}`
  );

  const full = await db.reservation.findUnique({
    where: { id: reservation.id },
    include: { guest: true, roomType: true, room: true },
  });
  return ok({ reservation: full });
});
