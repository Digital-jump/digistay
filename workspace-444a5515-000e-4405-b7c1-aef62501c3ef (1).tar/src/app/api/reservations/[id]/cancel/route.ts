import { db } from "@/lib/db";
import { ApiError, audit, fail, ok, withAuth } from "@/lib/api-helpers";
import { canAccessAny } from "@/lib/reservation-helpers";

export const POST = withAuth(async (req, { user, params }) => {
  if (!canAccessAny(user.role, ["reservations", "checkins"])) {
    return fail("Forbidden: module not allowed for your role", 403);
  }
  const existing = await db.reservation.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Reservation not found", 404);
  if (["CHECKED_IN", "CHECKED_OUT"].includes(existing.status)) {
    throw new ApiError("Cannot cancel an in-house or completed stay", 400);
  }
  if (existing.status === "CANCELLED") {
    return ok(existing);
  }

  const body = (await req.json().catch(() => ({}))) as { reason?: unknown };
  const reason = typeof body.reason === "string" && body.reason.trim() ? body.reason.trim() : "";

  if (existing.roomId) {
    const room = await db.room.findUnique({ where: { id: existing.roomId } });
    if (room && room.status === "RESERVED") {
      await db.room.update({ where: { id: room.id }, data: { status: "AVAILABLE" } });
    }
  }

  const notes = reason
    ? `${existing.notes ? `${existing.notes}\n` : ""}Cancelled: ${reason}`
    : existing.notes;

  const reservation = await db.reservation.update({
    where: { id: params.id },
    data: { status: "CANCELLED", notes },
    include: { guest: true, roomType: true, room: true },
  });

  await audit(user, "CANCEL", "Reservation", reservation.id, `${reservation.code} cancelled${reason ? ` — ${reason}` : ""}`);
  return ok(reservation);
});
