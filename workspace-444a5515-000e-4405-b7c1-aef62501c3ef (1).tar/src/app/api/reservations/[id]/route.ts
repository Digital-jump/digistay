import { db } from "@/lib/db";
import { ApiError, audit, fail, money, nightsBetween, ok, withAuth } from "@/lib/api-helpers";
import { assertNoOverlap, canAccessAny, parseDateStr } from "@/lib/reservation-helpers";

export const GET = withAuth(async (_req, { user, params }) => {
  if (!canAccessAny(user.role, ["reservations", "checkins"])) {
    return fail("Forbidden: module not allowed for your role", 403);
  }
  const reservation = await db.reservation.findUnique({
    where: { id: params.id },
    include: {
      guest: true,
      roomType: true,
      room: true,
      folio: { include: { entries: { orderBy: { createdAt: "asc" } } } },
      invoices: { orderBy: { createdAt: "desc" } },
      orders: { include: { items: { include: { menuItem: true } } }, orderBy: { createdAt: "desc" } },
      review: true,
    },
  });
  if (!reservation) throw new ApiError("Reservation not found", 404);

  return ok({
    reservation,
    canCheckIn: ["PENDING", "CONFIRMED"].includes(reservation.status),
    canCheckOut: reservation.status === "CHECKED_IN",
  });
});

export const PUT = withAuth(async (req, { user, params }) => {
  if (!canAccessAny(user.role, ["reservations", "checkins"])) {
    return fail("Forbidden: module not allowed for your role", 403);
  }
  const existing = await db.reservation.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Reservation not found", 404);

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

  const guestId = typeof body.guestId === "string" && body.guestId ? body.guestId : existing.guestId;
  const roomTypeId = typeof body.roomTypeId === "string" && body.roomTypeId ? body.roomTypeId : existing.roomTypeId;
  const roomId = "roomId" in body ? (typeof body.roomId === "string" && body.roomId ? body.roomId : null) : existing.roomId;

  if (guestId !== existing.guestId) {
    const guest = await db.guest.findUnique({ where: { id: guestId } });
    if (!guest) throw new ApiError("Guest not found", 404);
  }
  if (roomTypeId !== existing.roomTypeId) {
    const roomType = await db.roomType.findUnique({ where: { id: roomTypeId } });
    if (!roomType) throw new ApiError("Room type not found", 404);
  }

  const checkIn = body.checkIn !== undefined ? parseDateStr(body.checkIn, "checkIn") : existing.checkIn;
  const checkOut = body.checkOut !== undefined ? parseDateStr(body.checkOut, "checkOut") : existing.checkOut;
  const nights = nightsBetween(checkIn, checkOut);
  if (nights < 1) throw new ApiError("Check-out must be after check-in", 409);

  const rate = typeof body.rate === "number" && body.rate >= 0 ? body.rate : existing.rate;

  // Overlap re-validation excluding this reservation
  const datesChanged =
    checkIn.getTime() !== new Date(existing.checkIn).getTime() ||
    checkOut.getTime() !== new Date(existing.checkOut).getTime();
  if (roomId !== existing.roomId || datesChanged || roomTypeId !== existing.roomTypeId) {
    await assertNoOverlap({ roomTypeId, roomId, checkIn, checkOut, excludeId: existing.id });
  }

  const reservation = await db.reservation.update({
    where: { id: params.id },
    data: {
      guestId,
      roomTypeId,
      roomId,
      checkIn,
      checkOut,
      adults: typeof body.adults === "number" && body.adults >= 1 ? Math.floor(body.adults) : existing.adults,
      children: typeof body.children === "number" && body.children >= 0 ? Math.floor(body.children) : existing.children,
      rate,
      totalAmount: money(nights * rate),
      source: typeof body.source === "string" && body.source ? body.source : existing.source,
      specialRequests:
        body.specialRequests !== undefined
          ? typeof body.specialRequests === "string" && body.specialRequests.trim()
            ? body.specialRequests.trim()
            : null
          : existing.specialRequests,
      notes:
        body.notes !== undefined
          ? typeof body.notes === "string" && body.notes.trim()
            ? body.notes.trim()
            : null
          : existing.notes,
    },
    include: { guest: true, roomType: true, room: true },
  });

  await audit(user, "UPDATE", "Reservation", reservation.id, `${reservation.code} updated`);
  return ok(reservation);
});

export const DELETE = withAuth(async (_req, { user, params }) => {
  if (!canAccessAny(user.role, ["reservations", "checkins"])) {
    return fail("Forbidden: module not allowed for your role", 403);
  }
  const existing = await db.reservation.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Reservation not found", 404);

  if (!["PENDING", "CANCELLED", "NO_SHOW"].includes(existing.status)) {
    throw new ApiError("Only PENDING, CANCELLED or NO_SHOW reservations can be deleted", 409);
  }

  // Release a held room if it was merely reserved for this stay
  if (existing.roomId) {
    const room = await db.room.findUnique({ where: { id: existing.roomId } });
    if (room && room.status === "RESERVED") {
      await db.room.update({ where: { id: room.id }, data: { status: "AVAILABLE" } });
    }
  }

  await db.reservation.delete({ where: { id: params.id } });
  await audit(user, "DELETE", "Reservation", params.id, `${existing.code} deleted`);
  return ok({ ok: true });
});
