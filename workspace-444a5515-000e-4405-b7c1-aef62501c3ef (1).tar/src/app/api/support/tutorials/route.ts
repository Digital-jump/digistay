import { withAuth, ok } from "@/lib/api-helpers";

type Tutorial = {
  id: string;
  title: string;
  category: string;
  duration: string;
  description: string;
  steps: string[];
  languages: number;
};

const TUTORIALS: Tutorial[] = [
  {
    id: "night-audit",
    title: "Night Audit",
    category: "PMS - Basic",
    duration: "07:00",
    description: "Run the end-of-day close: post room charges, settle folios, roll the business date and review the night audit report.",
    steps: [
      "Open Reports → Night Audit and pick the business date.",
      "Review arrivals, departures and no-shows listed in the activity panel.",
      "Post pending room charges to all in-house folios.",
      "Settle or flag any folio with an open balance.",
      "Click Run Night Audit to roll over the business date.",
      "Export or print the audit summary for the records.",
    ],
    languages: 12,
  },
  {
    id: "stay-view",
    title: "Stay View",
    category: "PMS - Basic",
    duration: "05:30",
    description: "Use the tape-chart grid to see every reservation across rooms and dates, and drag to extend or move stays.",
    steps: [
      "Go to Front Desk → Stay View to open the availability grid.",
      "Scroll horizontally to browse dates; each cell shows the stay status.",
      "Click a reservation cell to open its details.",
      "Drag the right edge of a stay to extend the checkout date.",
      "Right-click an empty cell to create a new booking for that room.",
    ],
    languages: 12,
  },
  {
    id: "room-view",
    title: "Room View",
    category: "Basic",
    duration: "04:45",
    description: "A visual floor map of every room: occupancy status, housekeeping state and quick actions for check-in and cleaning.",
    steps: [
      "Open Front Desk → Room View to see rooms grouped by floor.",
      "Colour coding shows AVAILABLE, OCCUPIED, DIRTY and MAINTENANCE rooms.",
      "Click a room to see the current guest, rate and stay details.",
      "Use Mark Clean or Mark Dirty to update housekeeping instantly.",
      "Start a walk-in check-in directly from any available room tile.",
    ],
    languages: 10,
  },
  {
    id: "language",
    title: "Use DigiStay in your own language",
    category: "Languages",
    duration: "03:20",
    description: "Switch the entire interface language and translate custom labels for your staff.",
    steps: [
      "Go to Settings → Languages.",
      "Pick one of the 12 supported languages from the list.",
      "Use the inline editor to adjust any translated label.",
      "Save and reload — the whole UI switches instantly.",
    ],
    languages: 12,
  },
  {
    id: "users-roles",
    title: "User & Roles - Settings",
    category: "Settings",
    duration: "06:10",
    description: "Create staff accounts, assign roles and control which sidebar modules each role can access.",
    steps: [
      "Open Settings → Users to see all staff accounts.",
      "Click Add User and fill in name, email and password.",
      "Assign a role: Admin, Receptionist, Accountant or Staff.",
      "Review the module permission matrix for the chosen role.",
      "Deactivate (don't delete) users who leave to keep the audit trail.",
    ],
    languages: 9,
  },
  {
    id: "rooms-rates",
    title: "Rooms & Rates - Settings",
    category: "Settings",
    duration: "05:40",
    description: "Set up room types, base rates, extra-adult charges, amenities and individual rooms per floor.",
    steps: [
      "Go to Settings → Rooms & Rates.",
      "Create a room type with base rate, capacity and amenities.",
      "Set the extra adult / child charges that apply above capacity.",
      "Add individual rooms and assign them to floors.",
      "Use the Maintenance toggle to pull a room out of inventory.",
    ],
    languages: 9,
  },
  {
    id: "invoices",
    title: "Invoices",
    category: "Invoices",
    duration: "06:45",
    description: "Generate invoices from folios or orders, apply discounts, record part payments and void when needed.",
    steps: [
      "Open Finance → Invoices and press New Invoice.",
      "Choose a reservation folio or a restaurant order as the source.",
      "Verify the auto-computed subtotal, GST and total.",
      "Apply a discount if approved (a reason is logged).",
      "Record payments — the status moves UNPAID → PARTIAL → PAID.",
      "Void is only available while paid amount is zero.",
    ],
    languages: 12,
  },
  {
    id: "custom-reports",
    title: "Custom Reports",
    category: "Reports",
    duration: "07:30",
    description: "Build your own date-range reports across revenue, payments, occupancy and reservations, then export them.",
    steps: [
      "Open Reports → Custom Reports.",
      "Pick a report template: revenue, payments, occupancy or reservations.",
      "Set the date range and any filters (source, status, method).",
      "Preview the totals row and per-day breakdown.",
      "Export to CSV or print a PDF copy for management.",
    ],
    languages: 8,
  },
  {
    id: "early-checkin-late-checkout",
    title: "Early Check & Late Checkout",
    category: "Check-in",
    duration: "04:15",
    description: "Handle early arrivals and late departures without breaking availability or housekeeping schedules.",
    steps: [
      "Open the reservation that arrives today from Stay View.",
      "For early check-in, verify the room is AVAILABLE (not reserved by a departing guest).",
      "Check the guest in — the room flips to OCCUPIED immediately.",
      "For late checkout, extend the checkout date from the reservation panel.",
      "Housekeeping sees the delayed departure on the Room View board.",
    ],
    languages: 10,
  },
  {
    id: "advance-room-management",
    title: "Advance Room Management",
    category: "Group Booking",
    duration: "08:00",
    description: "Manage group blocks: hold room inventories, split master folios and check in groups room by room.",
    steps: [
      "Create a group folio from Finance → Folios (type COMPANY).",
      "Link every group reservation to the master folio.",
      "Use Advance Room Management to assign rooms in bulk.",
      "Check in members one by one; charges post to the master folio.",
      "Settle the group folio once and generate a single invoice.",
    ],
    languages: 7,
  },
];

// GET /api/support/tutorials?search=&category= (auth)
export const GET = withAuth(
  async (req) => {
    const url = new URL(req.url);
    const search = url.searchParams.get("search")?.trim().toLowerCase() ?? "";
    const category = url.searchParams.get("category")?.trim() ?? "";

    let items = TUTORIALS;
    if (category) items = items.filter((t) => t.category.toLowerCase() === category.toLowerCase());
    if (search) {
      items = items.filter(
        (t) =>
          t.title.toLowerCase().includes(search) ||
          t.description.toLowerCase().includes(search) ||
          t.steps.some((s) => s.toLowerCase().includes(search))
      );
    }
    return ok(items);
  },
  { module: undefined }
);
