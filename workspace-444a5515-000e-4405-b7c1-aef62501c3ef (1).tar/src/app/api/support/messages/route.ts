import { db } from "@/lib/db";
import { withAuth, ok, ApiError } from "@/lib/api-helpers";

// GET /api/support/messages?sessionId= (auth)
export const GET = withAuth(
  async (req) => {
    const sessionId = new URL(req.url).searchParams.get("sessionId");
    if (!sessionId) throw new ApiError("sessionId is required", 400);
    const messages = await db.supportMessage.findMany({
      where: { sessionId },
      orderBy: { createdAt: "asc" },
      take: 100,
    });
    return ok(messages);
  },
  { module: undefined }
);
