import { z } from "zod";
import { db } from "@/lib/db";
import {
  ApiError,
  money,
  nightsBetween,
  ok,
  parseBody,
  startOfDay,
  withAuth,
} from "@/lib/api-helpers";
import {
  callLLM,
  extractJson,
  getHotelSnapshot,
  getRevenueSummary,
  getRoomTypeAvailability,
  inr,
  ymd,
  type HotelSnapshot,
  type LLMMessage,
} from "@/lib/ai";

const ChatBody = z.object({
  sessionId: z.string().min(1, "sessionId is required"),
  message: z.string().min(1, "message is required"),
});

// ─── Tool registry (READ-ONLY, zod-validated, role-gated) ─────────────────

type ToolOutcome = { summary: string; data: unknown };

type ToolEntry = {
  description: string;
  /** Roles allowed to run this tool; omit = any authenticated staff. */
  roles?: string[];
  execute: (rawArgs: unknown) => Promise<ToolOutcome>;
};

function defineTool<A>(
  description: string,
  schema: z.ZodType<A>,
  run: (args: A) => Promise<ToolOutcome>,
  roles?: string[]
): ToolEntry {
  return {
    description,
    roles,
    execute: async (rawArgs) => {
      // Light arg normalization: accept snake_case keys the model may emit (check_in → checkIn).
      let normalized: unknown = rawArgs;
      if (rawArgs && typeof rawArgs === "object" && !Array.isArray(rawArgs)) {
        const src = rawArgs as Record<string, unknown>;
        const out: Record<string, unknown> = { ...src };
        for (const [k, v] of Object.entries(src)) {
          const camel = k.replace(/_([a-z])/g, (_, c: string) => c.toUpperCase());
          if (camel !== k && !(camel in out)) out[camel] = v;
        }
        normalized = out;
      }
      const parsed = schema.safeParse(normalized ?? {});
      if (!parsed.success) {
        const msg = parsed.error.issues[0]?.message ?? "invalid arguments";
        const shapeObj = (schema as unknown as { shape?: Record<string, unknown> }).shape;
        const shape = shapeObj && typeof shapeObj === "object" ? Object.keys(shapeObj) : [];
        return {
          summary: `Rejected invalid arguments (${msg})`,
          data: {
            error: `invalid arguments: ${msg}`,
            expectedArgs: shape,
            hint: "Resend the tool call as {\"tool\":\"<name>\",\"args\":{...}} with these argument names.",
          },
        };
      }
      return run(parsed.data);
    },
  };
}

const RESERVATION_STATUSES = ["PENDING", "CONFIRMED", "CHECKED_IN", "CHECKED_OUT", "CANCELLED", "NO_SHOW"];

function parseYmdDay(s: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const d = startOfDay(new Date(`${s}T00:00:00`));
  return isNaN(d.getTime()) ? null : d;
}

const TOOLS: Array<[string, ToolEntry]> = [
  [
    "get_occupancy",
    defineTool(
    "Rooms occupied/available/out-of-service per status + occupancy % today.",
    z.object({}),
    async () => {
      const [total, occupied, reserved, dirty, maintenance] = await Promise.all([
        db.room.count(),
        db.room.count({ where: { status: "OCCUPIED" } }),
        db.room.count({ where: { status: "RESERVED" } }),
        db.room.count({ where: { status: "DIRTY" } }),
        db.room.count({ where: { status: "MAINTENANCE" } }),
      ]);
      const available = Math.max(0, total - occupied - reserved - dirty - maintenance);
      return {
        summary: `Checked occupancy (${occupied}/${total} rooms occupied)`,
        data: {
          occupied,
          available,
          reserved,
          dirty,
          outOfService: maintenance,
          total,
          occupancyPct: total ? Math.round((occupied / total) * 1000) / 10 : 0,
        },
      };
    }
  ),
  ],
  [
    "get_arrivals_departures",
    defineTool(
    "Arrivals & departures lists (name, room, status, nights) for a day; args {\"date\":\"YYYY-MM-DD\"} optional (default today).",
    z.object({ date: z.string().optional() }),
    async (args) => {
      const day = args.date ? parseYmdDay(args.date) : startOfDay(new Date());
      if (!day) return { summary: "Rejected invalid date", data: { error: "invalid date, expected YYYY-MM-DD" } };
      const next = day.getTime() + 86400000;
      const range = { gte: day, lt: new Date(next) };
      const [arrivals, departures] = await Promise.all([
        db.reservation.findMany({
          where: { checkIn: range, status: { in: ["PENDING", "CONFIRMED", "CHECKED_IN"] } },
          include: { guest: true, room: true, roomType: true },
          orderBy: { checkIn: "asc" },
          take: 15,
        }),
        db.reservation.findMany({
          where: { checkOut: range, status: { in: ["CHECKED_IN", "CHECKED_OUT"] } },
          include: { guest: true, room: true, roomType: true },
          orderBy: { checkOut: "asc" },
          take: 15,
        }),
      ]);
      const map = (r: (typeof arrivals)[number]) => ({
        code: r.code,
        guest: `${r.guest.firstName} ${r.guest.lastName}`,
        room: r.room?.number ?? null,
        typeName: r.roomType.name,
        status: r.status,
        nights: nightsBetween(r.checkIn, r.checkOut),
      });
      return {
        summary: `Listed arrivals & departures for ${ymd(day)} (${arrivals.length} arrivals, ${departures.length} departures)`,
        data: {
          date: ymd(day),
          arrivals: arrivals.map(map),
          departures: departures.map(map),
        },
      };
    }
  ),
  ],
  [
    "search_reservations",
    defineTool(
    "Find reservations by guest name / reservation code / room number; args {\"query\":string?, \"status\":string?, \"limit\":number?}.",
    z.object({
      query: z.string().max(80).optional(),
      status: z.string().max(20).optional(),
      limit: z.coerce.number().int().min(1).max(20).optional(),
    }),
    async (args) => {
      const status = args.status?.trim().toUpperCase();
      if (status && !RESERVATION_STATUSES.includes(status)) {
        return { summary: `Rejected invalid status "${status}"`, data: { error: `invalid status "${status}"` } };
      }
      const q = args.query?.trim();
      const words = q ? q.split(/\s+/).filter(Boolean).slice(0, 4) : [];
      const or = q
        ? [
            ...words.flatMap((w) => [
              { guest: { is: { firstName: { contains: w } } } },
              { guest: { is: { lastName: { contains: w } } } },
            ]),
            { code: { contains: q } },
            { room: { is: { number: { contains: q } } } },
          ]
        : undefined;
      const rows = await db.reservation.findMany({
        where: { ...(status ? { status } : {}), ...(or ? { OR: or } : {}) },
        include: { guest: true, room: true, roomType: true },
        orderBy: { checkIn: "desc" },
        take: Math.min(20, Math.max(1, args.limit ?? 8)),
      });
      return {
        summary: q
          ? `Searched reservations for "${q}" (${rows.length} found)`
          : `Listed recent reservations (${rows.length})`,
        data: {
          count: rows.length,
          results: rows.map((r) => ({
            code: r.code,
            guest: `${r.guest.firstName} ${r.guest.lastName}`,
            room: r.room?.number ?? null,
            typeName: r.roomType.name,
            status: r.status,
            checkIn: ymd(r.checkIn),
            checkOut: ymd(r.checkOut),
            totalAmount: money(r.totalAmount),
            source: r.source,
          })),
        },
      };
    }
  ),
  ],
  [
    "get_room_availability",
    defineTool(
    "Per room type availability for a stay window; args {\"checkIn\":\"YYYY-MM-DD\",\"checkOut\":\"YYYY-MM-DD\",\"guests\":number?} — both dates REQUIRED.",
    z.object({
      checkIn: z.string().min(10),
      checkOut: z.string().min(10),
      guests: z.coerce.number().int().min(1).max(10).optional(),
    }),
    async (args) => {
      const ci = parseYmdDay(args.checkIn.slice(0, 10));
      const co = parseYmdDay(args.checkOut.slice(0, 10));
      if (!ci || !co) {
        return { summary: "Rejected invalid dates", data: { error: "invalid dates, expected YYYY-MM-DD" } };
      }
      if (co.getTime() <= ci.getTime()) {
        return { summary: "Rejected invalid date range", data: { error: "checkOut must be after checkIn" } };
      }
      const types = await getRoomTypeAvailability(ci, co);
      return {
        summary: `Checked availability ${ymd(ci)} → ${ymd(co)} (${types.length} room types)`,
        data: {
          checkIn: ymd(ci),
          checkOut: ymd(co),
          nights: nightsBetween(ci, co),
          types: types.map((t) => ({
            ...t,
            suitableForGuests: args.guests ? t.capacity >= args.guests : undefined,
          })),
        },
      };
    }
  ),
  ],
  [
    "get_guest_profile",
    defineTool(
    "Top 3 matching guests by name/email/phone with stay count, lifetime spend, last room; args {\"query\":\"name or email or phone\"}.",
    z.object({ query: z.string().min(1).max(80) }),
    async (args) => {
      const q = args.query.trim();
      const words = q.split(/\s+/).filter(Boolean).slice(0, 4);
      const nameConds = words.flatMap((w) => [
        { firstName: { contains: w } },
        { lastName: { contains: w } },
      ]);
      const guests = await db.guest.findMany({
        where: {
          OR: [
            ...nameConds,
            { email: { contains: q } },
            { phone: { contains: q } },
          ],
        },
        take: 3,
      });
      const ids = guests.map((g) => g.id);
      const reservations = ids.length
        ? await db.reservation.findMany({
            where: { guestId: { in: ids } },
            include: { room: true },
            orderBy: { checkIn: "desc" },
          })
        : [];
      const matches = guests.map((g) => {
        const mine = reservations.filter((r) => r.guestId === g.id);
        const counted = mine.filter((r) => r.status !== "CANCELLED" && r.status !== "NO_SHOW");
        const lastWithRoom = mine.find((r) => r.roomId && r.room);
        return {
          name: `${g.firstName} ${g.lastName}`,
          email: g.email,
          phone: g.phone,
          vip: g.vip,
          stays: counted.length,
          lifetimeSpend: money(counted.reduce((s, r) => s + r.totalAmount, 0)),
          lastRoom: lastWithRoom?.room?.number ?? null,
          lastStay: mine[0] ? ymd(mine[0].checkIn) : null,
        };
      });
      return { summary: `Looked up guest "${q}" (${matches.length} matches)`, data: { matches } };
    }
  ),
  ],
  [
    "list_pending_food_orders",
    defineTool(
    "Pending/preparing F&B orders (oldest first, capped 10).",
    z.object({}),
    async () => {
      const orders = await db.restaurantOrder.findMany({
        where: { status: { in: ["PENDING", "ACCEPTED"] } },
        include: {
          items: { include: { menuItem: true } },
          guest: true,
          reservation: { include: { room: true } },
        },
        orderBy: { createdAt: "asc" },
        take: 10,
      });
      const roomIds = [...new Set(orders.map((o) => o.roomId).filter((id): id is string => !!id))];
      const roomRows = roomIds.length
        ? await db.room.findMany({ where: { id: { in: roomIds } }, select: { id: true, number: true } })
        : [];
      const roomNumberById = new Map(roomRows.map((r) => [r.id, r.number]));
      return {
        summary: `Listed pending F&B orders (${orders.length})`,
        data: {
          count: orders.length,
          orders: orders.map((o) => ({
            orderNumber: o.orderNumber,
            type: o.type,
            status: o.status,
            guest: o.guest ? `${o.guest.firstName} ${o.guest.lastName}` : null,
            room: o.reservation?.room?.number ?? (o.roomId ? (roomNumberById.get(o.roomId) ?? null) : null),
            total: money(o.totalAmount),
            items: o.items.map((i) => `${i.quantity}× ${i.menuItem.name}`),
            placedAt: o.createdAt.toISOString(),
          })),
        },
      };
    }
  ),
  ],
  [
    "get_outstanding_invoices",
    defineTool(
    "Unpaid invoices: count, total outstanding, top 5 oldest with balances.",
    z.object({}),
    async () => {
      const invoices = await db.invoice.findMany({
        where: { status: { in: ["UNPAID", "PARTIAL"] } },
        include: { guest: true, folio: { select: { name: true } } },
        orderBy: { issuedAt: "asc" },
      });
      const rows = invoices.map((i) => ({
        number: i.number,
        billedTo: i.guest ? `${i.guest.firstName} ${i.guest.lastName}` : (i.folio?.name ?? "—"),
        issuedAt: ymd(i.issuedAt),
        balance: money(i.total - i.paidAmount),
      }));
      return {
        summary: `Checked outstanding invoices (${rows.length}, ${inr(rows.reduce((s, r) => s + r.balance, 0))})`,
        data: {
          count: rows.length,
          totalOutstanding: money(rows.reduce((s, r) => s + r.balance, 0)),
          oldest: rows.slice(0, 5),
        },
      };
    },
    ["ADMIN", "ACCOUNTANT"]
  ),
  ],
  [
    "get_revenue_summary",
    defineTool(
    "Room revenue + F&B revenue + payments received over the last N days; args {\"days\":number?} (default 30).",
    z.object({ days: z.coerce.number().int().min(1).max(365).optional() }),
    async (args) => {
      const days = Math.min(365, Math.max(1, args.days ?? 30));
      const summary = await getRevenueSummary(days);
      return {
        summary: `Summarized revenue for last ${days} days (room ${inr(summary.roomRevenue)} · F&B ${inr(summary.fbRevenue)} · collected ${inr(summary.paymentsReceived)})`,
        data: summary,
      };
    },
    ["ADMIN", "ACCOUNTANT"]
  ),
  ],
  [
    "get_reviews_summary",
    defineTool(
    "Guest review health: average rating, count per rating bucket, latest 3 review snippets.",
    z.object({}),
    async () => {
      const reviews = await db.review.findMany({ orderBy: { createdAt: "desc" }, take: 200 });
      const buckets: Record<string, number> = { "1": 0, "2": 0, "3": 0, "4": 0, "5": 0 };
      let sum = 0;
      for (const r of reviews) {
        buckets[String(r.rating)] = (buckets[String(r.rating)] ?? 0) + 1;
        sum += r.rating;
      }
      return {
        summary: `Summarized guest reviews (avg ${reviews.length ? Math.round((sum / reviews.length) * 100) / 100 : 0} across ${reviews.length})`,
        data: {
          count: reviews.length,
          avgRating: reviews.length ? Math.round((sum / reviews.length) * 100) / 100 : 0,
          buckets,
          latest: reviews.slice(0, 3).map((r) => ({
            rating: r.rating,
            title: r.title,
            snippet: r.comment.slice(0, 90),
          })),
        },
      };
    }
    ),
  ],
];

const TOOL_REGISTRY: Record<string, ToolEntry> = Object.fromEntries(TOOLS);

function executeTool(name: string, rawArgs: unknown, role: string): Promise<ToolOutcome> {
  const entry = TOOL_REGISTRY[name];
  if (!entry) {
    return Promise.resolve({ summary: `Unknown tool "${name}" requested`, data: { error: `unknown tool "${name}"` } });
  }
  if (entry.roles && !entry.roles.includes(role)) {
    return Promise.resolve({
      summary: `Requested ${name} — not permitted for your role`,
      data: { error: "not permitted for your role" },
    });
  }
  return entry.execute(rawArgs);
}

// ─── System prompt ────────────────────────────────────────────────────────

function buildSystemPrompt(s: HotelSnapshot): string {
  const toolLines = Object.entries(TOOL_REGISTRY).map(
    ([name, t]) => `- ${name}: ${t.description}${t.roles ? " (ADMIN/ACCOUNTANT only)" : ""}`
  );
  return [
    "You are DigiAI 2.0, the AI operations copilot inside DigiStay hotel management software (DigiStay Grand Hotel, Mumbai).",
    "You help hotel staff with front-desk operations, reservations, check-ins, F&B orders, folios, invoices, payments, reports, reviews and how to use DigiStay.",
    "",
    `CURRENT HOTEL SNAPSHOT (today, ${s.date}):`,
    `- Occupancy: ${s.occupancyPct}% (${s.occupiedRooms}/${s.totalRooms} rooms occupied, ${s.outOfServiceRooms} out of service)`,
    `- Arrivals today: ${s.arrivalsToday} | Departures today: ${s.departuresToday}`,
    `- Outstanding invoiced balance: ${inr(s.outstandingTotal)}`,
    `- Pending food orders: ${s.pendingFoodOrders}`,
    "",
    "TOOLS (all read-only) — to call one, reply with ONLY this JSON object (no prose, no code fences):",
    '{"tool":"<name>","args":{...}}',
    "You will then receive a user message starting with TOOL_RESULT containing JSON data.",
    ...toolLines,
    "",
    "RULES:",
    "- If the snapshot above already answers the question, answer directly WITHOUT any tool call.",
    "- At most 3 tool calls per question (one per turn), then you MUST give the final answer.",
    '- If a TOOL_RESULT contains {"error":"not permitted for your role"}, politely tell the user this data is restricted by their role.',
    "- FINAL ANSWERS are plain text only — never JSON, never code fences. Be concise, friendly and actionable. Use ₹ for money.",
    "- Cite real numbers only from the snapshot or tool results; never invent data.",
  ].join("\n");
}

function pickToolCall(parsed: unknown): { tool: string; args: unknown } | null {
  if (!parsed || typeof parsed !== "object") return null;
  if (Array.isArray(parsed)) return parsed.length ? pickToolCall(parsed[0]) : null;
  const obj = parsed as Record<string, unknown>;
  if (typeof obj.tool === "string" && obj.tool.trim()) return { tool: obj.tool.trim(), args: obj.args ?? {} };
  return null;
}

// POST /api/support/chat { sessionId, message } (auth) — DigiAI 2.0 agentic assistant
export const POST = withAuth(
  async (req, { user }) => {
    const parsed = ChatBody.safeParse(await parseBody(req));
    if (!parsed.success) throw new ApiError("sessionId and non-empty message are required", 400);
    const { sessionId, message } = parsed.data;

    const snapshot = await getHotelSnapshot();

    // ── Conversation history (before this message) ────────────
    const historyRows = await db.supportMessage.findMany({
      where: { sessionId },
      orderBy: { createdAt: "desc" },
      take: 10,
    });
    const history = historyRows.reverse();

    await db.supportMessage.create({ data: { sessionId, role: "USER", content: message } });

    const messages: LLMMessage[] = [
      { role: "system", content: buildSystemPrompt(snapshot) },
      ...history.map((m) => ({
        role: m.role === "ASSISTANT" ? ("assistant" as const) : ("user" as const),
        content: m.content,
      })),
      { role: "user", content: message },
    ];

    const actions: { tool: string; summary: string }[] = [];
    let reply: string | null = null;
    const MAX_ROUNDS = 3;

    try {
      for (let round = 0; round <= MAX_ROUNDS; round++) {
        const text = await callLLM(messages);
        if (!text) break; // LLM failure → graceful fallback below
        const toolCall = pickToolCall(extractJson<unknown>(text));
        if (!toolCall) {
          reply = text.trim();
          break;
        }
        if (round === MAX_ROUNDS) {
          messages.push({ role: "assistant", content: text });
          messages.push({
            role: "user",
            content:
              "You have reached the maximum of 3 tool calls. Using the data you already have, reply with your final answer as plain text now (no JSON).",
          });
          const finalText = await callLLM(messages);
          reply =
            finalText && !pickToolCall(extractJson<unknown>(finalText))
              ? finalText.trim()
              : "I gathered the data but couldn't compose a final answer. Please try rephrasing your question.";
          break;
        }
        const outcome = await executeTool(toolCall.tool, toolCall.args, user.role);
        actions.push({ tool: toolCall.tool, summary: outcome.summary });
        messages.push({ role: "assistant", content: text });
        messages.push({ role: "user", content: `TOOL_RESULT ${JSON.stringify(outcome.data)}` });
      }
    } catch (e) {
      console.error("[support/chat] agentic loop error:", e);
    }

    if (!reply) {
      reply = "I'm having trouble reaching my AI backend right now. Please try again soon.";
    }

    await db.supportMessage.create({ data: { sessionId, role: "ASSISTANT", content: reply } });

    const lastRows = await db.supportMessage.findMany({
      where: { sessionId },
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    return ok({ reply, messages: lastRows.reverse(), actions });
  },
  { module: undefined }
);
