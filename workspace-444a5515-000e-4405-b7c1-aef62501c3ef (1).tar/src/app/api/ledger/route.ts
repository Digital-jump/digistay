import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit, money, parseBody, startOfDay, endOfDay } from "@/lib/api-helpers";

const METHODS = ["CASH", "UPI", "DEBIT_CARD", "CREDIT_CARD", "BANK_TRANSFER", "RAZORPAY", "OTHER"];
const TYPES = ["OPENING", "CASH_IN", "CASH_OUT"];

function emptyMethodMap(): Record<string, number> {
  return Object.fromEntries(METHODS.map((m) => [m, 0]));
}

// GET /api/ledger?from=&to=&type=&method= (module: ledger)
export const GET = withAuth(
  async (req) => {
    const url = new URL(req.url);
    const now = new Date();
    const fromStr = url.searchParams.get("from");
    const toStr = url.searchParams.get("to");
    const from =
      fromStr && /^\d{4}-\d{2}-\d{2}$/.test(fromStr)
        ? startOfDay(new Date(`${fromStr}T00:00:00`))
        : startOfDay(new Date(now.getFullYear(), now.getMonth(), 1));
    const to =
      toStr && /^\d{4}-\d{2}-\d{2}$/.test(toStr) ? endOfDay(new Date(`${toStr}T00:00:00`)) : endOfDay(now);
    const type = url.searchParams.get("type") ?? undefined;
    const method = url.searchParams.get("method") ?? undefined;

    const [entries, payments] = await Promise.all([
      db.ledgerEntry.findMany({
        where: {
          createdAt: { gte: from, lte: to },
          ...(type ? { type } : {}),
          ...(method ? { method } : {}),
        },
        orderBy: { createdAt: "desc" },
      }),
      db.payment.findMany({
        where: { direction: "IN", paidAt: { gte: from, lte: to } },
        select: { amount: true, method: true },
      }),
    ]);

    const opening = money(entries.filter((e) => e.type === "OPENING").reduce((s, e) => s + e.amount, 0));
    const cashIn = money(entries.filter((e) => e.type === "CASH_IN").reduce((s, e) => s + e.amount, 0));
    const cashOut = money(entries.filter((e) => e.type === "CASH_OUT").reduce((s, e) => s + e.amount, 0));

    const inByMethod = emptyMethodMap();
    const outByMethod = emptyMethodMap();
    for (const e of entries) {
      if (e.type === "CASH_IN") inByMethod[e.method] = money((inByMethod[e.method] ?? 0) + e.amount);
      if (e.type === "CASH_OUT") outByMethod[e.method] = money((outByMethod[e.method] ?? 0) + e.amount);
    }

    const paymentsByMethod = emptyMethodMap();
    for (const p of payments) {
      paymentsByMethod[p.method] = money((paymentsByMethod[p.method] ?? 0) + p.amount);
    }

    return ok({
      entries,
      summary: {
        opening,
        cashIn,
        cashOut,
        closing: money(opening + cashIn - cashOut),
        inByMethod,
        outByMethod,
        paymentsByMethod,
      },
    });
  },
  { module: "ledger" }
);

// POST /api/ledger — add opening / cash in / cash out entry
export const POST = withAuth(
  async (req, { user }) => {
    const b = await parseBody<Record<string, unknown>>(req);
    const type = typeof b.type === "string" ? b.type : "";
    if (!TYPES.includes(type)) throw new ApiError("Invalid entry type", 400);
    const amount = Number(b.amount);
    if (!Number.isFinite(amount) || amount <= 0) throw new ApiError("Amount must be greater than zero", 400);
    const method = typeof b.method === "string" && b.method ? b.method : "CASH";
    if (!METHODS.includes(method)) throw new ApiError("Invalid payment method", 400);

    const entry = await db.ledgerEntry.create({
      data: {
        type,
        amount,
        method,
        category: typeof b.category === "string" ? b.category : null,
        remarks: typeof b.remarks === "string" ? b.remarks : null,
        createdBy: user.name,
      },
    });
    await audit(user, "CREATE", "LedgerEntry", entry.id, `${type} of ${amount} via ${method}`);
    return ok(entry);
  },
  { module: "ledger" }
);
