import { db } from "@/lib/db";
import { withAuth, ok, fail, money } from "@/lib/api-helpers";
import { folioBalanceOf } from "@/lib/billing";
import { canAccess } from "@/lib/permissions";

// GET /api/folios/summary (module: folio-company | folio-ota)
export const GET = withAuth(
  async (req, { user }) => {
    const allowed = canAccess(user.role, "folio-company") || canAccess(user.role, "folio-ota");
    if (!allowed) return fail("Forbidden: module not allowed for your role", 403);

    const folios = await db.folio.findMany({
      where: { status: "OPEN" },
      include: { entries: true },
    });

    let individual = 0;
    let company = 0;
    let ota = 0;
    for (const f of folios) {
      const bal = folioBalanceOf(f.entries);
      if (f.type === "INDIVIDUAL") individual += bal;
      else if (f.type === "COMPANY") company += bal;
      else if (f.type === "OTA") ota += bal;
    }
    return ok({
      totalUnsettled: money(individual + company + ota),
      individualUnsettled: money(individual),
      companyUnsettled: money(company),
      otaUnsettled: money(ota),
    });
  },
  { module: undefined }
);
