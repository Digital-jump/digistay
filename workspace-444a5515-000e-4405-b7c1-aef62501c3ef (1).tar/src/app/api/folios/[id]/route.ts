import { db } from "@/lib/db";
import { withAuth, ok, fail, ApiError, audit, parseBody } from "@/lib/api-helpers";
import { folioBalanceOf } from "@/lib/billing";
import { canAccess } from "@/lib/permissions";

function canFolios(role: string) {
  return canAccess(role, "folio-company") || canAccess(role, "folio-ota");
}

// GET /api/folios/[id]
export const GET = withAuth(
  async (req, { user, params }) => {
    if (!canFolios(user.role)) return fail("Forbidden: module not allowed for your role", 403);
    const folio = await db.folio.findUnique({
      where: { id: params.id },
      include: {
        entries: { orderBy: { createdAt: "asc" } },
        company: true,
        reservation: { include: { roomType: true, room: true } },
        invoices: true,
      },
    });
    if (!folio) throw new ApiError("Folio not found", 404);
    const guest = folio.guestId ? await db.guest.findUnique({ where: { id: folio.guestId } }) : null;
    return ok({ ...folio, guest, balance: folioBalanceOf(folio.entries) });
  },
  { module: undefined }
);

// PUT /api/folios/[id]
export const PUT = withAuth(
  async (req, { user, params }) => {
    if (!canFolios(user.role)) return fail("Forbidden: module not allowed for your role", 403);
    const b = await parseBody<Record<string, unknown>>(req);
    const existing = await db.folio.findUnique({ where: { id: params.id } });
    if (!existing) throw new ApiError("Folio not found", 404);

    const data: Record<string, unknown> = {};
    if (typeof b.name === "string" && b.name.trim()) data.name = b.name.trim();
    if (typeof b.contact === "string" || b.contact === null) data.contact = b.contact;
    if (typeof b.phone === "string" || b.phone === null) data.phone = b.phone;
    if (typeof b.gstin === "string" || b.gstin === null) data.gstin = b.gstin;
    if (typeof b.dueDate === "string" && b.dueDate) data.dueDate = new Date(b.dueDate);
    if (b.dueDate === null) data.dueDate = null;
    if (typeof b.notes === "string" || b.notes === null) data.notes = b.notes;
    if (typeof b.status === "string") {
      if (!["OPEN", "SETTLED"].includes(b.status)) throw new ApiError("Invalid folio status", 400);
      data.status = b.status;
    }

    const folio = await db.folio.update({ where: { id: params.id }, data });
    await audit(user, "UPDATE", "Folio", folio.id, `Updated folio ${folio.code}`);
    return ok(folio);
  },
  { module: undefined }
);

// DELETE /api/folios/[id]
export const DELETE = withAuth(
  async (req, { user, params }) => {
    if (!canFolios(user.role)) return fail("Forbidden: module not allowed for your role", 403);
    const folio = await db.folio.findUnique({ where: { id: params.id }, include: { invoices: true } });
    if (!folio) throw new ApiError("Folio not found", 404);
    if (folio.status === "SETTLED") throw new ApiError("Settled folios cannot be deleted", 409);
    if (folio.invoices.length > 0) throw new ApiError("Folio has invoices", 409);

    await db.folioEntry.deleteMany({ where: { folioId: folio.id } });
    await db.folio.delete({ where: { id: folio.id } });
    await audit(user, "DELETE", "Folio", folio.id, `Deleted folio ${folio.code}`);
    return ok({ ok: true });
  },
  { module: undefined }
);
