import { db } from "@/lib/db";
import { withAuth, ok, fail, ApiError, audit, parseBody, money } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

const ENTRY_TYPES = ["CHARGE", "PAYMENT", "ADJUSTMENT"];

function canFolios(role: string) {
  return canAccess(role, "folio-company") || canAccess(role, "folio-ota");
}

// POST /api/folios/[id]/entries { type, description, amount, category? }
export const POST = withAuth(
  async (req, { user, params }) => {
    if (!canFolios(user.role)) return fail("Forbidden: module not allowed for your role", 403);
    const b = await parseBody<Record<string, unknown>>(req);
    const folio = await db.folio.findUnique({ where: { id: params.id } });
    if (!folio) throw new ApiError("Folio not found", 404);

    const type = typeof b.type === "string" ? b.type : "";
    if (!ENTRY_TYPES.includes(type)) throw new ApiError("Invalid entry type", 400);
    const description = typeof b.description === "string" ? b.description.trim() : "";
    if (!description) throw new ApiError("Description is required", 400);
    const amount = Number(b.amount);
    if (!Number.isFinite(amount) || amount === 0) throw new ApiError("Amount must be a non-zero number", 400);

    const stored =
      type === "PAYMENT" ? -Math.abs(amount) : type === "CHARGE" ? Math.abs(amount) : amount;

    const entry = await db.folioEntry.create({
      data: {
        folioId: folio.id,
        type,
        description,
        amount: money(stored),
        category: typeof b.category === "string" ? b.category : null,
        createdBy: user.name,
      },
    });
    await audit(user, "CREATE", "FolioEntry", entry.id, `${type} ${stored} on folio ${folio.code}`);
    return ok(entry);
  },
  { module: undefined }
);

// DELETE /api/folios/[id]/entries?entryId=
export const DELETE = withAuth(
  async (req, { user, params }) => {
    if (!canFolios(user.role)) return fail("Forbidden: module not allowed for your role", 403);
    const folio = await db.folio.findUnique({ where: { id: params.id } });
    if (!folio) throw new ApiError("Folio not found", 404);
    const entryId = new URL(req.url).searchParams.get("entryId");
    if (!entryId) throw new ApiError("entryId query param is required", 400);
    const entry = await db.folioEntry.findUnique({ where: { id: entryId } });
    if (!entry || entry.folioId !== folio.id) throw new ApiError("Folio entry not found", 404);

    await db.folioEntry.delete({ where: { id: entry.id } });
    await audit(user, "DELETE", "FolioEntry", entry.id, `Deleted ${entry.type} entry from folio ${folio.code}`);
    return ok({ ok: true });
  },
  { module: undefined }
);
