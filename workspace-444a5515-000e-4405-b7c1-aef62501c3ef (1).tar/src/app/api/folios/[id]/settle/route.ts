import { db } from "@/lib/db";
import { withAuth, ok, fail, ApiError, audit, nextCode, money, parseBody } from "@/lib/api-helpers";
import { folioBalanceOf, ensureInvoiceForReservation, recordInvoicePayment } from "@/lib/billing";
import { canAccess } from "@/lib/permissions";

function canFolios(role: string) {
  return canAccess(role, "folio-company") || canAccess(role, "folio-ota");
}

// POST /api/folios/[id]/settle { method } (module: folio-company | folio-ota)
export const POST = withAuth(
  async (req, { user, params }) => {
    if (!canFolios(user.role)) return fail("Forbidden: module not allowed for your role", 403);
    const b = await parseBody<Record<string, unknown>>(req);
    const method = typeof b.method === "string" && b.method ? b.method : "CASH";

    let folio = await db.folio.findUnique({ where: { id: params.id }, include: { entries: true, invoices: true } });
    if (!folio) throw new ApiError("Folio not found", 404);

    const balance = folioBalanceOf(folio.entries);
    if (balance < -0.005) throw new ApiError("Folio has credit balance", 400);

    // 1) Settlement payment entry on the folio (covers the outstanding folio balance)
    if (balance > 0.005) {
      await db.folioEntry.create({
        data: {
          folioId: folio.id,
          type: "PAYMENT",
          description: `Settlement via ${method}`,
          amount: -balance,
          category: "OTHER",
          createdBy: user.name,
        },
      });
    }

    // 2) Mark settled
    await db.folio.update({ where: { id: folio.id }, data: { status: "SETTLED" } });

    // 3) Ensure an invoice exists for the folio
    let invoice;
    if (folio.reservationId) {
      invoice = await ensureInvoiceForReservation(folio.reservationId);
    } else {
      const fresh = await db.folio.findUnique({ where: { id: folio.id }, include: { entries: true } });
      const entries = fresh?.entries ?? [];
      const existing = folio.invoices.find((i) => i.status !== "VOID");
      if (existing) {
        invoice = existing;
      } else {
        const subtotal = money(entries.filter((e) => e.type !== "PAYMENT").reduce((s, e) => s + e.amount, 0));
        const total = subtotal; // tax 0 for folio-generated invoices
        const paidAtFolio = money(-entries.filter((e) => e.type === "PAYMENT").reduce((s, e) => s + e.amount, 0));
        const paidAmount = Math.min(paidAtFolio, total);
        const number = await nextCode("INV", db.invoice, "number");
        const created = await db.invoice.create({
          data: {
            number,
            billingType: folio.type,
            folioId: folio.id,
            guestId: folio.guestId,
            subtotal,
            tax: 0,
            discount: 0,
            total,
            paidAmount,
            status: paidAmount >= total - 0.005 ? "PAID" : paidAmount > 0 ? "PARTIAL" : "UNPAID",
          },
        });
        const items = entries
          .filter((e) => e.type !== "PAYMENT" && e.amount !== 0)
          .map((e) => ({
            invoiceId: created.id,
            description: e.description,
            type: e.category === "ROOM" ? "ROOM" : e.category === "FOOD" ? "FOOD" : "SERVICE",
            quantity: 1,
            unitPrice: money(e.amount),
            amount: money(e.amount),
          }));
        if (items.length) await db.invoiceItem.createMany({ data: items });
        invoice = created;
      }
    }

    // 4) Record any remaining outstanding (e.g. tax) against the invoice
    if (invoice) {
      const outstanding = money(invoice.total - invoice.paidAmount);
      if (outstanding > 0.005) {
        await recordInvoicePayment(invoice.id, {
          amount: outstanding,
          method,
          receivedBy: user.name,
          remarks: "Folio settlement",
        });
      }
    }

    await audit(user, "PAYMENT", "Folio", folio.id, `Folio ${folio.code} settled via ${method}`);

    const [settledFolio, fullInvoice] = await Promise.all([
      db.folio.findUnique({ where: { id: folio.id }, include: { entries: { orderBy: { createdAt: "asc" } } } }),
      invoice
        ? db.invoice.findUnique({ where: { id: invoice.id }, include: { items: true, payments: true } })
        : Promise.resolve(null),
    ]);
    return ok({
      folio: settledFolio ? { ...settledFolio, balance: folioBalanceOf(settledFolio.entries) } : settledFolio,
      invoice: fullInvoice,
    });
  },
  { module: undefined }
);
