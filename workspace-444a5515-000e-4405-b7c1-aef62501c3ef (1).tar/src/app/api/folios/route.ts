import { db } from "@/lib/db";
import { withAuth, ok, fail, ApiError, audit, nextCode, parseBody, money } from "@/lib/api-helpers";
import { folioBalanceOf } from "@/lib/billing";
import { canAccess } from "@/lib/permissions";

const FOLIO_TYPES = ["COMPANY", "INDIVIDUAL", "OTA"];
const ENTRY_TYPES = ["CHARGE", "PAYMENT", "ADJUSTMENT"];

function canFolios(role: string) {
  return canAccess(role, "folio-company") || canAccess(role, "folio-ota");
}

// GET /api/folios?type=&status=&search= (module: folio-company | folio-ota)
export const GET = withAuth(
  async (req, { user }) => {
    if (!canFolios(user.role)) return fail("Forbidden: module not allowed for your role", 403);

    const url = new URL(req.url);
    const type = url.searchParams.get("type") ?? undefined;
    const status = url.searchParams.get("status") ?? undefined;
    const search = url.searchParams.get("search")?.trim() ?? "";

    const where: Record<string, unknown> = {
      ...(type ? { type } : {}),
      ...(status ? { status } : {}),
    };
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { contact: { contains: search } },
        { phone: { contains: search } },
        { gstin: { contains: search } },
      ];
    }

    const folios = await db.folio.findMany({
      where,
      include: {
        company: true,
        reservation: { include: { roomType: true, room: true, guest: true } },
      },
      orderBy: { createdAt: "desc" },
    });

    const ids = folios.map((f) => f.id);
    const entries = ids.length ? await db.folioEntry.findMany({ where: { folioId: { in: ids } } }) : [];
    const byFolio = new Map<string, { type: string; amount: number }[]>();
    for (const e of entries) {
      const list = byFolio.get(e.folioId) ?? [];
      list.push({ type: e.type, amount: e.amount });
      byFolio.set(e.folioId, list);
    }

    return ok({
      items: folios.map((f) => ({ ...f, balance: folioBalanceOf(byFolio.get(f.id) ?? []) })),
    });
  },
  { module: undefined }
);

// POST /api/folios (module: folio-company | folio-ota)
export const POST = withAuth(
  async (req, { user }) => {
    if (!canFolios(user.role)) return fail("Forbidden: module not allowed for your role", 403);

    const b = await parseBody<Record<string, unknown>>(req);
    const type = typeof b.type === "string" ? b.type : "";
    if (!FOLIO_TYPES.includes(type)) throw new ApiError("Invalid folio type", 400);
    const name = typeof b.name === "string" ? b.name.trim() : "";
    if (!name) throw new ApiError("Folio name is required", 400);

    const rawEntries = Array.isArray(b.entries) ? b.entries : [];
    const entryData = rawEntries.map((e) => {
      const o = e as Record<string, unknown>;
      const etype = typeof o.type === "string" ? o.type : "";
      const description = typeof o.description === "string" ? o.description.trim() : "";
      const amount = Number(o.amount);
      if (!ENTRY_TYPES.includes(etype)) throw new ApiError("Invalid folio entry type", 400);
      if (!description) throw new ApiError("Folio entry description is required", 400);
      if (!Number.isFinite(amount) || amount === 0) throw new ApiError("Folio entry amount must be non-zero", 400);
      return {
        type: etype,
        description,
        amount: etype === "PAYMENT" ? -Math.abs(amount) : etype === "CHARGE" ? Math.abs(amount) : amount,
        category: typeof o.category === "string" ? o.category : null,
        createdBy: user.name,
      };
    });

    const code = await nextCode("FOL", db.folio);
    const folio = await db.folio.create({
      data: {
        code,
        type,
        name,
        contact: typeof b.contact === "string" ? b.contact : null,
        phone: typeof b.phone === "string" ? b.phone : null,
        gstin: typeof b.gstin === "string" ? b.gstin : null,
        otaName: typeof b.otaName === "string" ? b.otaName : null,
        guestId: typeof b.guestId === "string" && b.guestId ? b.guestId : null,
        companyId: typeof b.companyId === "string" && b.companyId ? b.companyId : null,
        reservationId: typeof b.reservationId === "string" && b.reservationId ? b.reservationId : null,
        dueDate: typeof b.dueDate === "string" && b.dueDate ? new Date(b.dueDate) : null,
        notes: typeof b.notes === "string" ? b.notes : null,
        entries: entryData.length ? { create: entryData } : undefined,
      },
      include: { entries: true, company: true },
    });
    await audit(user, "CREATE", "Folio", folio.id, `Created ${type} folio ${code} (${name})`);
    return ok({ ...folio, balance: folioBalanceOf(folio.entries) });
  },
  { module: undefined }
);
