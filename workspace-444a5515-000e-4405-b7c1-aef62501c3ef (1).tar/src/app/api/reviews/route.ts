import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit, parseBody, addDays } from "@/lib/api-helpers";

const CHANNELS = ["DIRECT", "BOOKING_COM", "GOOGLE", "TRIPADVISOR", "AIRBNB", "MAKE_MY_TRIP"];

// GET /api/reviews?period=30|90|365&channel= (module: reviews)
export const GET = withAuth(
  async (req) => {
    const url = new URL(req.url);
    const periodParam = Number(url.searchParams.get("period") ?? 90) || 90;
    const period = [30, 90, 365].includes(periodParam) ? periodParam : 90;
    const channel = url.searchParams.get("channel") ?? undefined;
    const cutoff = addDays(new Date(), -period);

    const items = await db.review.findMany({
      where: {
        createdAt: { gte: cutoff },
        ...(channel ? { channel } : {}),
      },
      include: { guest: true },
      orderBy: { createdAt: "desc" },
    });

    const distribution: Record<string, number> = { "1": 0, "2": 0, "3": 0, "4": 0, "5": 0 };
    const channelMap = new Map<string, { channel: string; count: number; sum: number }>();
    let sum = 0;
    let needsReply = 0;
    for (const r of items) {
      distribution[String(r.rating)] = (distribution[String(r.rating)] ?? 0) + 1;
      sum += r.rating;
      if (!r.reply) needsReply += 1;
      const c = channelMap.get(r.channel) ?? { channel: r.channel, count: 0, sum: 0 };
      c.count += 1;
      c.sum += r.rating;
      channelMap.set(r.channel, c);
    }

    return ok({
      items,
      insights: {
        avgRating: items.length ? Math.round((sum / items.length) * 100) / 100 : 0,
        count: items.length,
        distribution,
        byChannel: [...channelMap.values()].map((c) => ({
          channel: c.channel,
          count: c.count,
          avg: Math.round((c.sum / c.count) * 100) / 100,
        })),
        needsReply,
      },
    });
  },
  { module: "reviews" }
);

// POST /api/reviews (module: reviews)
export const POST = withAuth(
  async (req, { user }) => {
    const b = await parseBody<Record<string, unknown>>(req);
    const rating = Number(b.rating);
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new ApiError("Rating must be 1-5", 400);
    const comment = typeof b.comment === "string" ? b.comment.trim() : "";
    if (!comment) throw new ApiError("Comment is required", 400);
    const channel = typeof b.channel === "string" && b.channel ? b.channel : "DIRECT";
    if (!CHANNELS.includes(channel)) throw new ApiError("Invalid channel", 400);

    const guestId = typeof b.guestId === "string" && b.guestId ? b.guestId : null;
    if (guestId) {
      const guest = await db.guest.findUnique({ where: { id: guestId } });
      if (!guest) throw new ApiError("Guest not found", 400);
    }
    const reservationId = typeof b.reservationId === "string" && b.reservationId ? b.reservationId : null;
    if (reservationId) {
      const reservation = await db.reservation.findUnique({ where: { id: reservationId } });
      if (!reservation) throw new ApiError("Reservation not found", 400);
      const existing = await db.review.findUnique({ where: { reservationId } });
      if (existing) throw new ApiError("Review already exists for this reservation", 409);
    }

    const review = await db.review.create({
      data: {
        rating,
        comment,
        title: typeof b.title === "string" ? b.title : null,
        channel,
        guestId,
        reservationId,
      },
      include: { guest: true },
    });
    await audit(user, "CREATE", "Review", review.id, `Review ${rating}★ via ${channel}`);
    return ok(review);
  },
  { module: "reviews" }
);
