import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit, parseBody } from "@/lib/api-helpers";

// PUT /api/reviews/[id] { reply?, status? } (module: reviews)
export const PUT = withAuth(
  async (req, { user, params }) => {
    const b = await parseBody<Record<string, unknown>>(req);
    const existing = await db.review.findUnique({ where: { id: params.id } });
    if (!existing) throw new ApiError("Review not found", 404);

    const data: Record<string, unknown> = {};
    if (typeof b.reply === "string" || b.reply === null) data.reply = b.reply;
    if (typeof b.status === "string") {
      if (!["PUBLISHED", "PENDING"].includes(b.status)) throw new ApiError("Invalid status", 400);
      data.status = b.status;
    }

    const review = await db.review.update({ where: { id: params.id }, data, include: { guest: true } });
    await audit(
      user,
      "UPDATE",
      "Review",
      review.id,
      typeof data.reply === "string" ? `Replied to review ${review.id}` : `Updated review ${review.id}`
    );
    return ok(review);
  },
  { module: "reviews" }
);

// DELETE /api/reviews/[id] (module: reviews)
export const DELETE = withAuth(
  async (req, { user, params }) => {
    const existing = await db.review.findUnique({ where: { id: params.id } });
    if (!existing) throw new ApiError("Review not found", 404);
    await db.review.delete({ where: { id: params.id } });
    await audit(user, "DELETE", "Review", params.id, "Deleted review");
    return ok({ ok: true });
  },
  { module: "reviews" }
);
