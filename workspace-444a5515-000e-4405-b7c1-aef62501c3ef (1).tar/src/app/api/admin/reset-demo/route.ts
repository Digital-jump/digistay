import { execSync } from "child_process";
import { ok, withAuth } from "@/lib/api-helpers";

/**
 * POST /api/admin/reset-demo (ADMIN only)
 * Re-seeds the demo dataset by running prisma/seed.ts (sandbox/demo convenience).
 * All sessions are wiped by the seed, so clients are signed out afterwards.
 */
export const POST = withAuth(
  async () => {
    execSync("bun prisma/seed.ts", {
      cwd: "/home/z/my-project",
      stdio: "pipe",
      timeout: 60_000,
    });
    return ok({ ok: true, message: "Demo data re-seeded" });
  },
  { roles: ["ADMIN"] }
);
