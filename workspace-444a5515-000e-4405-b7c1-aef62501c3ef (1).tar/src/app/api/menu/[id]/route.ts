import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit, parseBody } from "@/lib/api-helpers";

const MENU_CATEGORIES = ["STARTER", "MAIN_COURSE", "BREADS_RICE", "DESSERTS", "BEVERAGES", "BAR"];

// PUT /api/menu/[id] — update menu item
export const PUT = withAuth(
  async (req, { user, params }) => {
    const b = await parseBody<Record<string, unknown>>(req);
    const existing = await db.menuItem.findUnique({ where: { id: params.id } });
    if (!existing) throw new ApiError("Menu item not found", 404);

    const data: Record<string, unknown> = {};
    if (typeof b.name === "string" && b.name.trim()) data.name = b.name.trim();
    if (typeof b.category === "string") {
      if (!MENU_CATEGORIES.includes(b.category)) throw new ApiError("Invalid category", 400);
      data.category = b.category;
    }
    if (b.price !== undefined) {
      const price = Number(b.price);
      if (!Number.isFinite(price) || price <= 0) throw new ApiError("Price must be greater than zero", 400);
      data.price = price;
    }
    if (typeof b.description === "string" || b.description === null) data.description = b.description;
    if (typeof b.isVeg === "boolean") data.isVeg = b.isVeg;
    if (typeof b.available === "boolean") data.available = b.available;

    const item = await db.menuItem.update({ where: { id: params.id }, data });
    await audit(user, "UPDATE", "MenuItem", item.id, `Updated menu item ${item.name}`);
    return ok(item);
  },
  { module: "food-menu" }
);

// DELETE /api/menu/[id] — 409 if used in orders
export const DELETE = withAuth(
  async (req, { user, params }) => {
    const existing = await db.menuItem.findUnique({ where: { id: params.id } });
    if (!existing) throw new ApiError("Menu item not found", 404);
    const used = await db.orderItem.count({ where: { menuItemId: params.id } });
    if (used > 0) throw new ApiError("Menu item is used in orders", 409);
    await db.menuItem.delete({ where: { id: params.id } });
    await audit(user, "DELETE", "MenuItem", params.id, `Deleted menu item ${existing.name}`);
    return ok({ ok: true });
  },
  { module: "food-menu" }
);
