import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit, parseBody } from "@/lib/api-helpers";

const MENU_CATEGORIES = ["STARTER", "MAIN_COURSE", "BREADS_RICE", "DESSERTS", "BEVERAGES", "BAR"];

// GET /api/menu?category=&available= (module: food-menu)
export const GET = withAuth(
  async (req) => {
    const url = new URL(req.url);
    const category = url.searchParams.get("category") ?? undefined;
    const available = url.searchParams.get("available");
    const items = await db.menuItem.findMany({
      where: {
        ...(category ? { category } : {}),
        ...(available === "true" || available === "false" ? { available: available === "true" } : {}),
      },
      orderBy: [{ category: "asc" }, { name: "asc" }],
    });
    return ok(items);
  },
  { module: "food-menu" }
);

// POST /api/menu — create menu item
export const POST = withAuth(
  async (req, { user }) => {
    const b = await parseBody<Record<string, unknown>>(req);
    const name = typeof b.name === "string" ? b.name.trim() : "";
    const category = typeof b.category === "string" ? b.category : "";
    const price = Number(b.price);
    if (!name) throw new ApiError("Name is required", 400);
    if (!MENU_CATEGORIES.includes(category)) throw new ApiError("Invalid category", 400);
    if (!Number.isFinite(price) || price <= 0) throw new ApiError("Price must be greater than zero", 400);

    const item = await db.menuItem.create({
      data: {
        name,
        category,
        price,
        description: typeof b.description === "string" ? b.description : null,
        isVeg: typeof b.isVeg === "boolean" ? b.isVeg : true,
        available: typeof b.available === "boolean" ? b.available : true,
      },
    });
    await audit(user, "CREATE", "MenuItem", item.id, `Added menu item ${item.name}`);
    return ok(item);
  },
  { module: "food-menu" }
);
