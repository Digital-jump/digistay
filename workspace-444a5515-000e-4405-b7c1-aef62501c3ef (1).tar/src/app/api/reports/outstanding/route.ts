import { db } from "@/lib/db";
import { withAuth, ok, money, startOfDay, endOfDay } from "@/lib/api-helpers";
import { reportsGuard, ymd } from "../_shared";

// GET /api/reports/outstanding?from=&to= (module: reports-standard)
export const GET = withAuth(
  async (req, { user }) => {
    const guard = reportsGuard(user);
    if (guard) return guard;

    const url = new URL(req.url);
    const fromStr = url.searchParams.get("from");
    const toStr = url.searchParams.get("to");
    const invoices = await db.invoice.findMany({
      where: {
        status: { not: "VOID" },
        ...(fromStr && /^\d{4}-\d{2}-\d{2}$/.test(fromStr)
          ? { issuedAt: { gte: startOfDay(new Date(`${fromStr}T00:00:00`)) } }
          : {}),
        ...(toStr && /^\d{4}-\d{2}-\d{2}$/.test(toStr) ? { issuedAt: { lte: endOfDay(new Date(`${toStr}T00:00:00`)) } } : {}),
      },
      include: { guest: true, folio: true },
      orderBy: { issuedAt: "asc" },
    });

    const now = new Date();
    const rows = invoices
      .filter((inv) => inv.total - inv.paidAmount > 0.005)
      .map((inv) => {
        const guestName = inv.guest
          ? `${inv.guest.firstName} ${inv.guest.lastName}`
          : (inv.folio?.name ?? "—");
        return {
          invoiceNumber: inv.number,
          number: inv.number,
          billingType: inv.billingType,
          guestName,
          folioName: inv.folio?.name ?? null,
          issuedAt: inv.issuedAt,
          total: money(inv.total),
          paidAmount: money(inv.paidAmount),
          balance: money(inv.total - inv.paidAmount),
          daysDue: Math.max(0, Math.floor((now.getTime() - new Date(inv.issuedAt).getTime()) / 86400000)),
        };
      });

    const totals = {
      total: money(rows.reduce((s, r) => s + r.total, 0)),
      collected: money(rows.reduce((s, r) => s + r.paidAmount, 0)),
      outstanding: money(rows.reduce((s, r) => s + r.balance, 0)),
    };
    return ok({ rows, totals, generatedAt: ymd(now) });
  },
  { module: undefined }
);
