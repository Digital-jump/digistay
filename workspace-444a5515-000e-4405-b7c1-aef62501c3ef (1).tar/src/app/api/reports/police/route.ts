import { db } from "@/lib/db";
import { withAuth, ok, startOfDay, endOfDay } from "@/lib/api-helpers";
import { reportsGuard, ymd } from "../_shared";

// GET /api/reports/police?date=YYYY-MM-DD (module: reports-standard)
export const GET = withAuth(
  async (req, { user }) => {
    const guard = reportsGuard(user);
    if (guard) return guard;

    const url = new URL(req.url);
    const dateParam = url.searchParams.get("date");
    const dateStr = dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam) ? dateParam : ymd(new Date());
    const dayStart = startOfDay(new Date(`${dateStr}T00:00:00`));
    const dayEnd = endOfDay(new Date(`${dateStr}T00:00:00`));

    const reservations = await db.reservation.findMany({
      where: {
        OR: [
          { status: "CHECKED_IN" },
          {
            checkIn: { gte: dayStart, lte: dayEnd },
            status: { in: ["PENDING", "CONFIRMED", "CHECKED_IN"] },
          },
        ],
      },
      include: { guest: true, room: true },
      orderBy: { checkIn: "asc" },
    });

    const rows = reservations.map((r) => ({
      guestName: `${r.guest.firstName} ${r.guest.lastName}`,
      nationality: r.guest.nationality,
      idType: r.guest.idType,
      idNumber: r.guest.idNumber,
      phone: r.guest.phone,
      roomNumber: r.room?.number ?? null,
      checkIn: r.checkIn,
      checkOut: r.checkOut,
    }));
    rows.sort((a, b) => (a.roomNumber ?? "zzz").localeCompare(b.roomNumber ?? "zzz"));

    return ok({ rows, date: dateStr });
  },
  { module: undefined }
);
