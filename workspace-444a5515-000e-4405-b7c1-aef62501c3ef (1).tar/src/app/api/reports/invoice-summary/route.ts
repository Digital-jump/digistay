import { db } from "@/lib/db";
import { withAuth, ok, money } from "@/lib/api-helpers";
import { reportsGuard, parseRange, ymd } from "../_shared";

// GET /api/reports/invoice-summary?from=&to= (module: reports-standard)
export const GET = withAuth(
  async (req, { user }) => {
    const guard = reportsGuard(user);
    if (guard) return guard;

    const url = new URL(req.url);
    const { from, to } = parseRange(url, "month");
    const invoices = await db.invoice.findMany({
      where: { issuedAt: { gte: from, lte: to } },
      include: { guest: true, folio: true },
      orderBy: { issuedAt: "asc" },
    });

    const rows = invoices.map((inv) => ({
      number: inv.number,
      issuedAt: inv.issuedAt,
      billingType: inv.billingType,
      guestName: inv.guest ? `${inv.guest.firstName} ${inv.guest.lastName}` : (inv.folio?.name ?? "—"),
      subtotal: money(inv.subtotal),
      tax: money(inv.tax),
      discount: money(inv.discount),
      total: money(inv.total),
      paidAmount: money(inv.paidAmount),
      status: inv.status,
    }));

    const totals = {
      count: rows.length,
      subtotal: money(rows.reduce((s, r) => s + r.subtotal, 0)),
      tax: money(rows.reduce((s, r) => s + r.tax, 0)),
      discount: money(rows.reduce((s, r) => s + r.discount, 0)),
      total: money(rows.reduce((s, r) => s + r.total, 0)),
      paidAmount: money(rows.reduce((s, r) => s + r.paidAmount, 0)),
    };
    return ok({ from: ymd(from), to: ymd(to), rows, totals });
  },
  { module: undefined }
);
