import { db } from "@/lib/db";
import { withAuth, ok, money } from "@/lib/api-helpers";
import { reportsGuard, parseRange, ymd } from "../_shared";

// GET /api/reports/revenue?from=&to= (module: reports-standard)
export const GET = withAuth(
  async (req, { user }) => {
    const guard = reportsGuard(user);
    if (guard) return guard;

    const url = new URL(req.url);
    const { from, to } = parseRange(url, "month");
    const invoices = await db.invoice.findMany({
      where: { status: { not: "VOID" }, issuedAt: { gte: from, lte: to } },
      include: { items: true },
      orderBy: { issuedAt: "asc" },
    });

    const rowsMap = new Map<string, { date: string; roomRevenue: number; fbRevenue: number; other: number; total: number }>();
    let taxRoom = 0;
    let taxFb = 0;

    for (const inv of invoices) {
      const date = ymd(inv.issuedAt);
      const room = inv.items.filter((i) => i.type === "ROOM").reduce((s, i) => s + i.amount, 0);
      const fb = inv.items.filter((i) => i.type === "FOOD").reduce((s, i) => s + i.amount, 0);
      const other = inv.items
        .filter((i) => i.type === "SERVICE" || i.type === "ADJUSTMENT")
        .reduce((s, i) => s + i.amount, 0);
      const tax = inv.items.filter((i) => i.type === "TAX").reduce((s, i) => s + i.amount, 0);
      const base = room + fb;
      const roomTax = base > 0 ? tax * (room / base) : 0;
      taxRoom += roomTax;
      taxFb += tax - roomTax;

      const row = rowsMap.get(date) ?? { date, roomRevenue: 0, fbRevenue: 0, other: 0, total: 0 };
      row.roomRevenue = money(row.roomRevenue + room);
      row.fbRevenue = money(row.fbRevenue + fb);
      row.other = money(row.other + other);
      row.total = money(row.roomRevenue + row.fbRevenue + row.other);
      rowsMap.set(date, row);
    }

    const rows = [...rowsMap.values()].sort((a, b) => a.date.localeCompare(b.date));
    const totals = {
      room: money(rows.reduce((s, r) => s + r.roomRevenue, 0)),
      fb: money(rows.reduce((s, r) => s + r.fbRevenue, 0)),
      other: money(rows.reduce((s, r) => s + r.other, 0)),
      total: money(rows.reduce((s, r) => s + r.total, 0)),
    };
    return ok({
      from: ymd(from),
      to: ymd(to),
      rows,
      totals: { ...totals, total: money(totals.room + totals.fb + totals.other) },
      taxTotals: { room: money(taxRoom), fb: money(taxFb) },
    });
  },
  { module: undefined }
);
