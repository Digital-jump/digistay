import { db } from "@/lib/db";
import { withAuth, ok, fail, money, startOfDay, endOfDay } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

function reportsAccess(role: string) {
  return (
    canAccess(role, "reports-standard") || canAccess(role, "reports-custom") || canAccess(role, "reports-bi")
  );
}

export function reportsGuard(user: { role: string }) {
  if (!reportsAccess(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  return null;
}

export function parseRange(url: URL, defaultStart: "month" | "today" | "last30" = "month") {
  const now = new Date();
  const fromStr = url.searchParams.get("from");
  const toStr = url.searchParams.get("to");
  let from: Date;
  if (fromStr && /^\d{4}-\d{2}-\d{2}$/.test(fromStr)) {
    from = startOfDay(new Date(`${fromStr}T00:00:00`));
  } else if (defaultStart === "today") {
    from = startOfDay(now);
  } else if (defaultStart === "last30") {
    from = startOfDay(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 29));
  } else {
    from = startOfDay(new Date(now.getFullYear(), now.getMonth(), 1));
  }
  const to = toStr && /^\d{4}-\d{2}-\d{2}$/.test(toStr) ? endOfDay(new Date(`${toStr}T00:00:00`)) : endOfDay(now);
  return { from, to };
}

export function ymd(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

export { db, money };
