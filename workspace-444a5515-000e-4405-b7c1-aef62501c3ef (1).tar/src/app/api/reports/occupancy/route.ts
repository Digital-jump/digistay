import { db } from "@/lib/db";
import { withAuth, ok, money, startOfDay, endOfDay, nightsBetween } from "@/lib/api-helpers";
import { reportsGuard, parseRange, ymd, round1 } from "../_shared";

const STAY_STATUSES = ["PENDING", "CONFIRMED", "CHECKED_IN", "CHECKED_OUT"];

// GET /api/reports/occupancy?from=&to= (module: reports-bi | reports-custom)
export const GET = withAuth(
  async (req, { user }) => {
    const guard = reportsGuard(user);
    if (guard) return guard;

    const url = new URL(req.url);
    const { from, to } = parseRange(url, "last30");
    const totalRooms = await db.room.count();

    // Payments received per day (direction IN)
    const payments = await db.payment.findMany({
      where: { paidAt: { gte: from, lte: to }, direction: "IN" },
      select: { amount: true, paidAt: true },
    });
    const revenueByDay = new Map<string, number>();
    for (const p of payments) {
      const key = ymd(p.paidAt);
      revenueByDay.set(key, (revenueByDay.get(key) ?? 0) + p.amount);
    }

    // Stays overlapping the window (for per-night occupancy)
    const stays = await db.reservation.findMany({
      where: {
        status: { in: STAY_STATUSES },
        checkIn: { lte: to },
        checkOut: { gt: from },
      },
      select: { checkIn: true, checkOut: true, roomId: true },
    });

    const occupancyTrend: { date: string; occupancy: number; revenue: number; sold: number }[] = [];
    for (let day = startOfDay(from); day <= to; day = nextDay(day)) {
      if (occupancyTrend.length > 400) break;
      const key = ymd(day);
      const occupiedRoomIds = new Set<string>();
      for (const s of stays) {
        if (startOfDay(s.checkIn) <= day && startOfDay(s.checkOut) > day && s.roomId) {
          occupiedRoomIds.add(s.roomId);
        }
      }
      const sold = occupiedRoomIds.size;
      occupancyTrend.push({
        date: key,
        occupancy: totalRooms ? round1((sold / totalRooms) * 100) : 0,
        revenue: money(revenueByDay.get(key) ?? 0),
        sold,
      });
    }

    const soldRoomNights = occupancyTrend.reduce((s, r) => s + r.sold, 0);
    const availableRoomNights = totalRooms * occupancyTrend.length;
    const revenueTotal = money(occupancyTrend.reduce((s, r) => s + r.revenue, 0));

    const checkedOut = await db.reservation.findMany({
      where: {
        status: "CHECKED_OUT",
        OR: [
          { actualCheckOut: { gte: from, lte: to } },
          { AND: [{ actualCheckOut: null }, { checkOut: { gte: from, lte: to } }] },
        ],
      },
      select: { checkIn: true, checkOut: true },
    });
    const stayNights = checkedOut.map((r) => Math.max(1, nightsBetween(r.checkIn, r.checkOut)));
    const avgStayNights = stayNights.length
      ? round1(stayNights.reduce((s, n) => s + n, 0) / stayNights.length)
      : 0;

    return ok({
      from: ymd(from),
      to: ymd(to),
      occupancyTrend: occupancyTrend.map(({ sold: _sold, ...rest }) => rest),
      totals: {
        availableRoomNights,
        soldRoomNights,
        occupancyRate: availableRoomNights ? round1((soldRoomNights / availableRoomNights) * 100) : 0,
        avgStayNights,
        avgRate: soldRoomNights ? money(revenueTotal / soldRoomNights) : 0,
      },
    });
  },
  { module: undefined }
);

function nextDay(d: Date): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + 1);
  return x;
}
