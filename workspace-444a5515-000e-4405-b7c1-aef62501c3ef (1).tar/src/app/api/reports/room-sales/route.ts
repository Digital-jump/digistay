import { db } from "@/lib/db";
import { withAuth, ok, money, nightsBetween } from "@/lib/api-helpers";
import { reportsGuard, parseRange, ymd } from "../_shared";

// GET /api/reports/room-sales?from=&to= (module: reports-standard)
export const GET = withAuth(
  async (req, { user }) => {
    const guard = reportsGuard(user);
    if (guard) return guard;

    const url = new URL(req.url);
    const { from, to } = parseRange(url, "month");
    const reservations = await db.reservation.findMany({
      where: {
        status: "CHECKED_OUT",
        OR: [
          { actualCheckOut: { gte: from, lte: to } },
          { AND: [{ actualCheckOut: null }, { checkOut: { gte: from, lte: to } }] },
        ],
      },
      include: { room: true, roomType: true },
      orderBy: { checkOut: "asc" },
    });

    const byRoom = new Map<string, { roomNumber: string; roomTypeName: string; nights: number; revenue: number; reservations: number }>();
    for (const r of reservations) {
      const key = r.roomId ?? `type-${r.roomTypeId}`;
      const nights = Math.max(1, nightsBetween(r.checkIn, r.actualCheckOut ?? r.checkOut));
      const row =
        byRoom.get(key) ??
        {
          roomNumber: r.room?.number ?? "—",
          roomTypeName: r.roomType.name,
          nights: 0,
          revenue: 0,
          reservations: 0,
        };
      row.nights += nights;
      row.revenue = money(row.revenue + r.totalAmount);
      row.reservations += 1;
      byRoom.set(key, row);
    }

    const rows = [...byRoom.values()].sort((a, b) => a.roomNumber.localeCompare(b.roomNumber));
    const totals = {
      nights: rows.reduce((s, r) => s + r.nights, 0),
      revenue: money(rows.reduce((s, r) => s + r.revenue, 0)),
    };
    return ok({ from: ymd(from), to: ymd(to), rows, totals });
  },
  { module: undefined }
);
