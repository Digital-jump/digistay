import { db } from "@/lib/db";
import { withAuth, ok, money } from "@/lib/api-helpers";
import { reportsGuard, parseRange, ymd } from "../_shared";

const METHODS = ["CASH", "UPI", "DEBIT_CARD", "CREDIT_CARD", "BANK_TRANSFER", "RAZORPAY", "OTHER"];

// GET /api/reports/payments?from=&to= (module: reports-standard)
export const GET = withAuth(
  async (req, { user }) => {
    const guard = reportsGuard(user);
    if (guard) return guard;

    const url = new URL(req.url);
    const { from, to } = parseRange(url, "month");
    const payments = await db.payment.findMany({
      where: { paidAt: { gte: from, lte: to } },
      select: { direction: true, amount: true, method: true, paidAt: true },
    });

    const rowsMap = new Map<string, Record<string, number>>();
    let outTotal = 0;
    for (const p of payments) {
      if (p.direction === "OUT") {
        outTotal += p.amount;
        continue;
      }
      const date = ymd(p.paidAt);
      const row = rowsMap.get(date) ?? Object.fromEntries(METHODS.map((m) => [m, 0]));
      row[p.method] = money((row[p.method] ?? 0) + p.amount);
      rowsMap.set(date, row);
    }

    const rows = [...rowsMap.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, methods]) => ({
        date,
        ...methods,
        total: money(METHODS.reduce((s, m) => s + (methods[m] ?? 0), 0)),
      }));

    const totals: Record<string, number> = Object.fromEntries(METHODS.map((m) => [m, 0]));
    for (const r of rows) for (const m of METHODS) totals[m] = money(totals[m] + (r[m] ?? 0));
    totals.total = money(METHODS.reduce((s, m) => s + totals[m], 0));

    return ok({ from: ymd(from), to: ymd(to), rows, totals, outTotal: money(outTotal) });
  },
  { module: undefined }
);
