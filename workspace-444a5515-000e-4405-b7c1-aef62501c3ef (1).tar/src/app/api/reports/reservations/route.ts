import { db } from "@/lib/db";
import { withAuth, ok } from "@/lib/api-helpers";
import { reportsGuard, parseRange, ymd } from "../_shared";

const STATUSES = ["PENDING", "CONFIRMED", "CHECKED_IN", "CHECKED_OUT", "CANCELLED", "NO_SHOW"];

// GET /api/reports/reservations?from=&to=&status=&source= (module: reports-custom | reports-standard)
export const GET = withAuth(
  async (req, { user }) => {
    const guard = reportsGuard(user);
    if (guard) return guard;

    const url = new URL(req.url);
    const { from, to } = parseRange(url, "month");
    const status = url.searchParams.get("status") ?? undefined;
    const source = url.searchParams.get("source") ?? undefined;

    const rows = await db.reservation.findMany({
      where: {
        checkIn: { gte: from, lte: to },
        ...(status ? { status } : {}),
        ...(source ? { source } : {}),
      },
      include: { guest: true, roomType: true, room: true },
      orderBy: { checkIn: "asc" },
    });

    const byStatus: Record<string, number> = Object.fromEntries(STATUSES.map((s) => [s, 0]));
    const sourceMap = new Map<string, number>();
    for (const r of rows) {
      if (r.status in byStatus) byStatus[r.status] += 1;
      sourceMap.set(r.source, (sourceMap.get(r.source) ?? 0) + 1);
    }
    const bySource = [...sourceMap.entries()].map(([src, count]) => ({ source: src, count }));

    return ok({
      from: ymd(from),
      to: ymd(to),
      rows,
      summary: { total: rows.length, byStatus, bySource },
    });
  },
  { module: undefined }
);
