import { db } from "@/lib/db";
import { withAuth, ok, money, startOfDay, endOfDay } from "@/lib/api-helpers";
import { reportsGuard, ymd, round1 } from "../_shared";

const METHODS = ["CASH", "UPI", "DEBIT_CARD", "CREDIT_CARD", "BANK_TRANSFER", "RAZORPAY", "OTHER"];

function sameDay(d: Date | null | undefined, dateStr: string): boolean {
  return !!d && ymd(new Date(d)) === dateStr;
}

// GET /api/reports/night-audit?date=YYYY-MM-DD (module: reports-standard)
export const GET = withAuth(
  async (req, { user }) => {
    const guard = reportsGuard(user);
    if (guard) return guard;

    const url = new URL(req.url);
    const dateParam = url.searchParams.get("date");
    const dateStr = dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam) ? dateParam : ymd(new Date());
    const dayStart = startOfDay(new Date(`${dateStr}T00:00:00`));
    const dayEnd = endOfDay(new Date(`${dateStr}T00:00:00`));
    const dayRange = { gte: dayStart, lte: dayEnd };

    // ── Revenue (invoices issued that day, non-VOID) ─────────
    const invoices = await db.invoice.findMany({
      where: { issuedAt: dayRange, status: { not: "VOID" } },
      include: { items: true },
    });
    let roomRevenue = 0;
    let fbRoomService = 0;
    let fbRestaurant = 0;
    let roomDiscount = 0;
    let foodDiscount = 0;
    let roomTaxes = 0;
    let fbTaxes = 0;
    for (const inv of invoices) {
      const room = inv.items.filter((i) => i.type === "ROOM").reduce((s, i) => s + i.amount, 0);
      const fb = inv.items.filter((i) => i.type === "FOOD").reduce((s, i) => s + i.amount, 0);
      const tax = inv.items.filter((i) => i.type === "TAX").reduce((s, i) => s + i.amount, 0);
      const base = room + fb;
      const roomTax = base > 0 ? tax * (room / base) : 0;
      roomTaxes += roomTax;
      fbTaxes += tax - roomTax;
      roomRevenue += room;
      if (inv.reservationId || inv.folioId) fbRoomService += fb;
      else fbRestaurant += fb;
      if (inv.reservationId) roomDiscount += inv.discount;
      if (inv.orderId) foodDiscount += inv.discount;
    }

    // ── Payments that day (direction IN) ─────────────────────
    const payments = await db.payment.findMany({
      where: { paidAt: dayRange, direction: "IN" },
      select: { method: true, amount: true },
    });
    const paymentsMap: Record<string, number> = Object.fromEntries(METHODS.map((m) => [m, 0]));
    for (const p of payments) paymentsMap[p.method] = money((paymentsMap[p.method] ?? 0) + p.amount);
    const paymentsTotal = money(METHODS.reduce((s, m) => s + paymentsMap[m], 0));

    // ── Reservation activity ─────────────────────────────────
    const reservations = await db.reservation.findMany({
      where: {
        OR: [
          { createdAt: dayRange },
          { checkIn: dayRange },
          { checkOut: dayRange },
          { updatedAt: dayRange },
          { actualCheckIn: dayRange },
          { actualCheckOut: dayRange },
        ],
      },
      include: { guest: true, room: true },
    });

    type Activity = { code: string; guestName: string; roomNumber: string | null; action: string; time: Date };
    const seen = new Set<string>();
    const activity: Activity[] = [];
    const checkinActivity: { code: string; guestName: string; roomNumber: string | null; time: Date }[] = [];
    let arrivals = 0;
    let departures = 0;

    for (const r of reservations) {
      const guestName = `${r.guest.firstName} ${r.guest.lastName}`;
      const roomNumber = r.room?.number ?? null;
      const push = (action: string, time: Date) => {
        const key = `${r.code}:${action}`;
        if (seen.has(key)) return;
        seen.add(key);
        activity.push({ code: r.code, guestName, roomNumber, action, time });
      };
      if (sameDay(r.createdAt, dateStr)) push("CREATED", r.createdAt);
      if (sameDay(r.checkIn, dateStr) && ["PENDING", "CONFIRMED", "CHECKED_IN"].includes(r.status)) {
        arrivals += 1;
        push("ARRIVAL", r.checkIn);
      }
      if ((sameDay(r.checkOut, dateStr) && r.status === "CHECKED_IN") || sameDay(r.actualCheckOut, dateStr)) {
        departures += 1;
        push("DEPARTURE", r.actualCheckOut ?? r.checkOut);
      }
      if (r.status === "CANCELLED" && sameDay(r.updatedAt, dateStr)) push("CANCELLED", r.updatedAt);
      if (sameDay(r.actualCheckIn, dateStr)) {
        checkinActivity.push({ code: r.code, guestName, roomNumber, time: r.actualCheckIn as Date });
      }
    }
    activity.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());
    checkinActivity.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());

    // ── Occupancy tonight ────────────────────────────────────
    const totalRooms = await db.room.count();
    const inHouseTonight = await db.reservation.findMany({
      where: {
        status: "CHECKED_IN",
        checkIn: { lte: dayEnd },
        checkOut: { gt: dayStart },
      },
      select: { roomId: true },
    });
    const occupiedRooms = new Set(inHouseTonight.map((r) => r.roomId).filter((id): id is string => !!id));
    const occupiedTonight = occupiedRooms.size;
    const inHouse = inHouseTonight.length;

    return ok({
      date: dateStr,
      revenue: {
        roomRevenue: money(roomRevenue),
        fbRoomService: money(fbRoomService),
        fbRestaurant: money(fbRestaurant),
        roomDiscount: money(roomDiscount),
        foodDiscount: money(foodDiscount),
        total: money(roomRevenue + fbRoomService + fbRestaurant),
      },
      tax: { roomTaxes: money(roomTaxes), fbTaxes: money(fbTaxes), total: money(roomTaxes + fbTaxes) },
      payments: { ...paymentsMap, total: paymentsTotal },
      reservationsActivity: activity.map((a) => ({ ...a, time: a.time })),
      checkinActivity: checkinActivity.map((c) => ({ ...c, time: c.time })),
      occupancy: {
        totalRooms,
        occupiedTonight,
        occupancyRate: totalRooms ? round1((occupiedTonight / totalRooms) * 100) : 0,
        arrivals,
        departures,
        inHouse,
      },
    });
  },
  { module: undefined }
);
