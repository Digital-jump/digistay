import { db } from "@/lib/db";
import { withAuth, ok, money, nightsBetween } from "@/lib/api-helpers";
import { getSettings } from "@/lib/billing";
import { reportsGuard, parseRange, ymd } from "../_shared";

const COMMISSION: Record<string, number> = {
  BOOKING_COM: 15,
  MAKE_MY_TRIP: 18,
  AIRBNB: 12,
  EXPEDIA: 15,
  GOIBIBO: 16,
};

// GET /api/reports/ota?from=&to= (module: reports-standard | reports-custom)
export const GET = withAuth(
  async (req, { user }) => {
    const guard = reportsGuard(user);
    if (guard) return guard;

    const url = new URL(req.url);
    const { from, to } = parseRange(url, "month");
    const settings = await getSettings();
    const reservations = await db.reservation.findMany({
      where: {
        source: { startsWith: "OTA_" },
        status: { not: "CANCELLED" },
        createdAt: { gte: from, lte: to },
      },
      orderBy: { createdAt: "asc" },
    });

    const bySource = new Map<string, { source: string; bookings: number; nights: number; revenue: number }>();
    for (const r of reservations) {
      const row = bySource.get(r.source) ?? { source: r.source, bookings: 0, nights: 0, revenue: 0 };
      row.bookings += 1;
      row.nights += Math.max(1, nightsBetween(r.checkIn, r.checkOut));
      row.revenue = money(row.revenue + r.totalAmount);
      bySource.set(r.source, row);
    }

    const rows = [...bySource.values()].map((row) => {
      const suffix = row.source.replace(/^OTA_/, "");
      const commissionRate = COMMISSION[suffix] ?? (settings.otaCommission ?? 15);
      return {
        ...row,
        revenue: money(row.revenue),
        commissionRate,
        commission: money((row.revenue * commissionRate) / 100),
      };
    });

    const totals = {
      bookings: rows.reduce((s, r) => s + r.bookings, 0),
      nights: rows.reduce((s, r) => s + r.nights, 0),
      revenue: money(rows.reduce((s, r) => s + r.revenue, 0)),
      commission: money(rows.reduce((s, r) => s + r.commission, 0)),
    };
    return ok({ from: ymd(from), to: ymd(to), rows, totals });
  },
  { module: undefined }
);
