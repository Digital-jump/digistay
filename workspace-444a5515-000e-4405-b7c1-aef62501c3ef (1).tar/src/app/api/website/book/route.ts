import { db } from "@/lib/db";
import { ok, fail, ApiError, audit, nextCode, nightsBetween, money } from "@/lib/api-helpers";

const ACTIVE_STATUSES = ["PENDING", "CONFIRMED", "CHECKED_IN"];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const SOURCE_RE = /^(WEBSITE|OTA_[A-Z_]+)$/;

function parseYmd(s: unknown, time: "14:00:00" | "11:00:00"): Date | null {
  if (typeof s !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const d = new Date(`${s}T${time}`);
  return isNaN(d.getTime()) ? null : d;
}

function handleError(e: unknown) {
  if (e instanceof ApiError) return fail(e.message, e.status);
  console.error("[website/book]", e);
  return fail("Internal server error", 500);
}

// POST /api/website/book — PUBLIC booking engine
export async function POST(req: Request) {
  try {
    const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const guest = (b.guest ?? {}) as Record<string, unknown>;
    const firstName = typeof guest.firstName === "string" ? guest.firstName.trim() : "";
    const lastName = typeof guest.lastName === "string" ? guest.lastName.trim() : "";
    const email = typeof guest.email === "string" ? guest.email.trim() : "";
    const phone = typeof guest.phone === "string" ? guest.phone.trim() : "";
    if (!firstName || !lastName || !email || !phone) {
      throw new ApiError("guest.firstName, guest.lastName, guest.email and guest.phone are required", 400);
    }
    if (!EMAIL_RE.test(email)) throw new ApiError("Invalid email address", 400);

    const roomTypeId = typeof b.roomTypeId === "string" ? b.roomTypeId : "";
    const roomType = roomTypeId ? await db.roomType.findUnique({ where: { id: roomTypeId } }) : null;
    if (!roomType) throw new ApiError("Invalid room type", 400);

    const checkIn = parseYmd(b.checkIn, "14:00:00");
    const checkOut = parseYmd(b.checkOut, "11:00:00");
    if (!checkIn || !checkOut) throw new ApiError("Valid checkIn and checkOut (YYYY-MM-DD) are required", 400);
    const nights = nightsBetween(checkIn, checkOut);
    if (nights < 1) throw new ApiError("checkOut must be after checkIn", 400);
    const adults = Math.floor(Number(b.adults ?? 1) || 0);
    if (adults < 1) throw new ApiError("adults must be at least 1", 400);
    const children = Math.max(0, Math.floor(Number(b.children ?? 0) || 0));

    // Find-or-create guest by email (case-insensitive)
    let existingGuest = await db.guest.findFirst({ where: { email } });
    if (!existingGuest) {
      const candidates = await db.guest.findMany({ where: { email: { not: null } }, select: { id: true, email: true } });
      const match = candidates.find((g) => g.email?.toLowerCase() === email.toLowerCase());
      if (match) existingGuest = await db.guest.findUnique({ where: { id: match.id } });
    }
    const guestRow =
      existingGuest ??
      (await db.guest.create({ data: { firstName, lastName, email, phone } }));

    // Availability check for the room type
    const overlapping = await db.reservation.findMany({
      where: {
        status: { in: ACTIVE_STATUSES },
        checkIn: { lt: checkOut },
        checkOut: { gt: checkIn },
      },
      select: { roomId: true },
    });
    const blockedRoomIds = new Set(overlapping.map((r) => r.roomId).filter((id): id is string => !!id));
    const rooms = await db.room.findMany({ where: { roomTypeId: roomType.id } });
    const availableRooms = rooms.filter(
      (r) => r.status !== "MAINTENANCE" && r.status !== "RESERVED" && !blockedRoomIds.has(r.id)
    );
    if (availableRooms.length === 0) {
      throw new ApiError("Selected room type is sold out for these dates", 409);
    }
    const room = availableRooms[0];

    const source = typeof b.source === "string" && SOURCE_RE.test(b.source) ? b.source : "WEBSITE";
    const extraAdults = Math.max(0, adults - roomType.capacity);
    const rate = money(roomType.baseRate + roomType.extraAdultCharge * extraAdults);
    const totalAmount = money(rate * nights);
    const code = await nextCode("RSV", db.reservation);

    const reservation = await db.reservation.create({
      data: {
        code,
        guestId: guestRow.id,
        roomTypeId: roomType.id,
        roomId: room.id,
        checkIn,
        checkOut,
        adults,
        children,
        status: "CONFIRMED",
        source,
        rate,
        totalAmount,
        specialRequests: typeof b.specialRequests === "string" ? b.specialRequests : null,
      },
    });
    await db.room.update({ where: { id: room.id }, data: { status: "RESERVED" } });

    await audit(null, "CREATE", "Reservation", reservation.id, `Website booking ${code}`);

    return ok({
      reservation: {
        code,
        checkIn: typeof b.checkIn === "string" ? b.checkIn : checkIn.toISOString(),
        checkOut: typeof b.checkOut === "string" ? b.checkOut : checkOut.toISOString(),
        roomTypeName: roomType.name,
        nights,
        totalAmount,
        guestName: `${guestRow.firstName} ${guestRow.lastName}`,
      },
    });
  } catch (e) {
    return handleError(e);
  }
}
