import { db } from "@/lib/db";
import { ok, fail } from "@/lib/api-helpers";
import { getSettings } from "@/lib/billing";

function parseAmenities(raw: string | null | undefined): string[] {
  try {
    const arr = JSON.parse(raw ?? "[]");
    return Array.isArray(arr) ? arr.map(String) : [];
  } catch {
    return [];
  }
}

function handleError(e: unknown) {
  console.error("[website/config]", e);
  return fail("Internal server error", 500);
}

// GET /api/website/config — PUBLIC
export async function GET() {
  try {
    const settings = await getSettings();
    const roomTypes = await db.roomType.findMany({
      include: { _count: { select: { rooms: true } } },
      orderBy: { baseRate: "asc" },
    });
    return ok({
      name: settings.name,
      tagline: settings.tagline,
      address: settings.address,
      phone: settings.phone,
      currency: settings.currency,
      bookingEngineEnabled: settings.bookingEngineEnabled,
      paymentMode: settings.paymentMode,
      checkInTime: settings.checkInTime,
      checkOutTime: settings.checkOutTime,
      roomTypes: roomTypes.map((rt) => ({
        id: rt.id,
        name: rt.name,
        description: rt.description,
        baseRate: rt.baseRate,
        capacity: rt.capacity,
        amenities: parseAmenities(rt.amenities),
        roomCount: rt._count.rooms,
      })),
    });
  } catch (e) {
    return handleError(e);
  }
}
