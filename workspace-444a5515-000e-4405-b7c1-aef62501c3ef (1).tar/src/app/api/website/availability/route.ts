import { db } from "@/lib/db";
import { ok, fail, nightsBetween, money } from "@/lib/api-helpers";

const ACTIVE_STATUSES = ["PENDING", "CONFIRMED", "CHECKED_IN"];

function parseYmd(s: string | null, time: "14:00:00" | "11:00:00"): Date | null {
  if (!s || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const d = new Date(`${s}T${time}`);
  return isNaN(d.getTime()) ? null : d;
}

function parseAmenities(raw: string | null | undefined): string[] {
  try {
    const arr = JSON.parse(raw ?? "[]");
    return Array.isArray(arr) ? arr.map(String) : [];
  } catch {
    return [];
  }
}

function handleError(e: unknown) {
  console.error("[website/availability]", e);
  return fail("Internal server error", 500);
}

// GET /api/website/availability?checkIn=YYYY-MM-DD&checkOut=YYYY-MM-DD&adults=1 — PUBLIC
export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const checkInStr = url.searchParams.get("checkIn");
    const checkOutStr = url.searchParams.get("checkOut");
    const adults = Math.max(1, Math.floor(Number(url.searchParams.get("adults") ?? 1) || 1));
    if (!checkInStr || !checkOutStr) return fail("checkIn and checkOut are required", 400);

    const checkIn = parseYmd(checkInStr, "14:00:00");
    const checkOut = parseYmd(checkOutStr, "11:00:00");
    if (!checkIn || !checkOut) return fail("Invalid dates", 400);
    const nights = nightsBetween(checkIn, checkOut);
    if (nights < 1) return fail("checkOut must be after checkIn", 400);

    // Rooms blocked by room-level overlapping ACTIVE reservations
    const overlapping = await db.reservation.findMany({
      where: {
        status: { in: ACTIVE_STATUSES },
        checkIn: { lt: checkOut },
        checkOut: { gt: checkIn },
      },
      select: { roomId: true },
    });
    const blockedRoomIds = new Set(overlapping.map((r) => r.roomId).filter((id): id is string => !!id));

    const [rooms, roomTypes] = await Promise.all([
      db.room.findMany({ select: { id: true, status: true, roomTypeId: true } }),
      db.roomType.findMany({ orderBy: { baseRate: "asc" } }),
    ]);

    const out = roomTypes.map((rt) => {
      const typeRooms = rooms.filter((r) => r.roomTypeId === rt.id);
      const available = typeRooms.filter(
        (r) => r.status !== "MAINTENANCE" && r.status !== "RESERVED" && !blockedRoomIds.has(r.id)
      ).length;
      const extraAdults = Math.max(0, adults - rt.capacity);
      const nightlyRate = rt.baseRate + rt.extraAdultCharge * extraAdults;
      return {
        id: rt.id,
        name: rt.name,
        description: rt.description,
        baseRate: rt.baseRate,
        capacity: rt.capacity,
        amenities: parseAmenities(rt.amenities),
        available,
        total: typeRooms.length,
        nights,
        totalForStay: money(nightlyRate * nights),
      };
    });

    return ok({ roomTypes: out, checkIn: checkInStr, checkOut: checkOutStr, nights });
  } catch (e) {
    return handleError(e);
  }
}
