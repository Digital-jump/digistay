import { db } from "@/lib/db";
import { nightsBetween, ok, withAuth } from "@/lib/api-helpers";

// GET /api/website/my-bookings — GUEST portal: bookings linked to the signed-in guest account
export const GET = withAuth(async (req, { user }) => {
  // Match the guest profile by email (same rule the website booking engine uses)
  let guest = await db.guest.findFirst({ where: { email: user.email } });
  if (!guest) {
    const candidates = await db.guest.findMany({
      where: { email: { not: null } },
      select: { id: true, email: true },
    });
    const match = candidates.find((g) => g.email?.toLowerCase() === user.email.toLowerCase());
    if (match) guest = await db.guest.findUnique({ where: { id: match.id } });
  }

  const reservations = guest
    ? await db.reservation.findMany({
        where: { guestId: guest.id },
        include: {
          roomType: { select: { name: true } },
          room: { select: { number: true } },
        },
        orderBy: { checkIn: "desc" },
        take: 50,
      })
    : [];

  const now = new Date();

  return ok({
    guestProfileFound: !!guest,
    bookings: reservations.map((r) => ({
      id: r.id,
      code: r.code,
      roomTypeName: r.roomType.name,
      roomNumber: r.room?.number ?? null,
      checkIn: r.checkIn.toISOString(),
      checkOut: r.checkOut.toISOString(),
      nights: nightsBetween(r.checkIn, r.checkOut),
      adults: r.adults,
      children: r.children,
      status: r.status,
      source: r.source,
      rate: r.rate,
      totalAmount: r.totalAmount,
      paidAmount: r.paidAmount,
      specialRequests: r.specialRequests,
      canCancel:
        ["PENDING", "CONFIRMED"].includes(r.status) && r.checkIn.getTime() > now.getTime(),
    })),
  });
}, { roles: ["GUEST"] });
