import { db } from "@/lib/db";
import { ApiError, audit, ok, withAuth } from "@/lib/api-helpers";

// POST /api/website/my-bookings/[id]/cancel — GUEST portal: cancel own upcoming booking
export const POST = withAuth(async (req, { user, params }) => {
  const reservation = await db.reservation.findUnique({
    where: { id: params.id },
    include: { guest: true, room: true },
  });
  if (!reservation) throw new ApiError("Booking not found", 404);

  // Ownership check: the booking's guest profile must match the signed-in guest account
  if (
    !reservation.guest.email ||
    reservation.guest.email.toLowerCase() !== user.email.toLowerCase()
  ) {
    throw new ApiError("This booking does not belong to your account", 403);
  }

  if (!["PENDING", "CONFIRMED"].includes(reservation.status)) {
    throw new ApiError(
      `This booking can no longer be cancelled (current status: ${reservation.status})`,
      400
    );
  }
  if (reservation.checkIn.getTime() <= Date.now()) {
    throw new ApiError("Bookings can only be cancelled before the check-in date", 400);
  }

  const updated = await db.reservation.update({
    where: { id: reservation.id },
    data: { status: "CANCELLED" },
  });

  // Release the held room back to available (same rule as staff-side cancellation)
  if (reservation.roomId && reservation.room?.status === "RESERVED") {
    await db.room.update({
      where: { id: reservation.roomId },
      data: { status: "AVAILABLE" },
    });
  }

  await audit(user, "CANCEL", "Reservation", reservation.id, `Guest cancelled website booking ${reservation.code}`);

  return ok({ ok: true, booking: { id: updated.id, code: updated.code, status: updated.status } });
}, { roles: ["GUEST"] });
