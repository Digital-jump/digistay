import { db } from "@/lib/db";
import { fail, ok } from "@/lib/api-helpers";

function handleError(e: unknown) {
  console.error("[website/reviews]", e);
  return fail("Internal server error", 500);
}

// GET /api/website/reviews — PUBLIC: latest published 4-5★ reviews for the website
export async function GET() {
  try {
    const [featured, all] = await Promise.all([
      db.review.findMany({
        where: { status: "PUBLISHED", rating: { gte: 4 } },
        include: { guest: { select: { firstName: true, lastName: true, city: true } } },
        orderBy: { createdAt: "desc" },
        take: 6,
      }),
      db.review.findMany({
        where: { status: "PUBLISHED" },
        select: { rating: true },
      }),
    ]);

    const averageRating = all.length
      ? Math.round((all.reduce((sum, r) => sum + r.rating, 0) / all.length) * 10) / 10
      : 0;

    return ok({
      averageRating,
      totalReviews: all.length,
      reviews: featured.map((r) => ({
        id: r.id,
        rating: r.rating,
        title: r.title,
        comment: r.comment,
        reply: r.reply,
        channel: r.channel,
        createdAt: r.createdAt.toISOString(),
        guestName: r.guest ? `${r.guest.firstName} ${r.guest.lastName}` : "Verified guest",
        guestCity: r.guest?.city ?? null,
      })),
    });
  } catch (e: unknown) {
    return handleError(e);
  }
}
