import { db } from "@/lib/db";
import { ApiError, audit, ok, withAuth } from "@/lib/api-helpers";

export const PUT = withAuth(async (req, { user, params }) => {
  const existing = await db.company.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Company not found", 404);

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const str = (v: unknown) => (typeof v === "string" && v.trim() ? v.trim() : null);
  if (body.name !== undefined && (typeof body.name !== "string" || !body.name.trim())) {
    throw new ApiError("Company name is required", 400);
  }

  const company = await db.company.update({
    where: { id: params.id },
    data: {
      ...(body.name !== undefined ? { name: String(body.name).trim() } : {}),
      ...(body.contactPerson !== undefined ? { contactPerson: str(body.contactPerson) } : {}),
      ...(body.email !== undefined ? { email: str(body.email) } : {}),
      ...(body.phone !== undefined ? { phone: str(body.phone) } : {}),
      ...(body.address !== undefined ? { address: str(body.address) } : {}),
      ...(body.gstin !== undefined ? { gstin: str(body.gstin) } : {}),
      ...(body.creditLimit !== undefined && typeof body.creditLimit === "number"
        ? { creditLimit: body.creditLimit }
        : {}),
    },
  });
  await audit(user, "UPDATE", "Company", company.id, company.name);
  return ok(company);
});

export const DELETE = withAuth(async (_req, { user, params }) => {
  const existing = await db.company.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Company not found", 404);

  const openFolios = await db.folio.count({ where: { companyId: params.id, status: "OPEN" } });
  if (openFolios > 0) throw new ApiError("Company has open folios", 409);

  await db.company.delete({ where: { id: params.id } });
  await audit(user, "DELETE", "Company", params.id, existing.name);
  return ok({ ok: true });
});
