import { db } from "@/lib/db";
import { ApiError, audit, ok, withAuth } from "@/lib/api-helpers";

export const GET = withAuth(async (req) => {
  const url = new URL(req.url);
  const search = (url.searchParams.get("search") ?? "").trim().toLowerCase();

  const companies = await db.company.findMany({ orderBy: { createdAt: "desc" } });
  const openFolios = await db.folio.findMany({ where: { status: "OPEN" }, include: { entries: true } });

  const folioSums = new Map<string, number>();
  for (const f of openFolios) {
    if (!f.companyId) continue;
    folioSums.set(f.companyId, (folioSums.get(f.companyId) ?? 0) + f.entries.reduce((s, e) => s + e.amount, 0));
  }

  const items = companies
    .filter((c) => !search || c.name.toLowerCase().includes(search))
    .map((c) => ({ ...c, openFolioAmount: Math.round((folioSums.get(c.id) ?? 0) * 100) / 100 }));

  return ok(items);
});

export const POST = withAuth(async (req, { user }) => {
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const name = typeof body.name === "string" ? body.name.trim() : "";
  if (!name) throw new ApiError("Company name is required", 400);

  const str = (v: unknown) => (typeof v === "string" && v.trim() ? v.trim() : null);
  const company = await db.company.create({
    data: {
      name,
      contactPerson: str(body.contactPerson),
      email: str(body.email),
      phone: str(body.phone),
      address: str(body.address),
      gstin: str(body.gstin),
      creditLimit: typeof body.creditLimit === "number" ? body.creditLimit : 0,
    },
  });
  await audit(user, "CREATE", "Company", company.id, company.name);
  return ok(company);
});
