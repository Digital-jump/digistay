import { db } from "@/lib/db";
import {
  ACTIVE_RESERVATION_STATUSES,
  addDays,
  ok,
  startOfDay,
  withAuth,
} from "@/lib/api-helpers";

function dayKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export const GET = withAuth(
  async (req) => {
    const url = new URL(req.url);
    const startParam = url.searchParams.get("start");
    const daysParam = parseInt(url.searchParams.get("days") ?? "14", 10);
    const days = Math.min(60, Math.max(1, Number.isFinite(daysParam) ? daysParam : 14));
    const start = startOfDay(startParam ? new Date(`${startParam}T00:00:00`) : new Date());
    const windowEnd = addDays(start, days);

    const [rooms, reservations] = await Promise.all([
      db.room.findMany({ include: { roomType: { select: { id: true, name: true } } }, orderBy: { number: "asc" } }),
      db.reservation.findMany({
        where: {
          status: { in: ACTIVE_RESERVATION_STATUSES },
          checkIn: { lt: windowEnd },
          checkOut: { gt: start },
        },
        include: { guest: { select: { firstName: true, lastName: true } }, roomType: { select: { name: true } } },
      }),
    ]);

    const dayKeys: string[] = [];
    for (let i = 0; i < days; i++) dayKeys.push(dayKey(addDays(start, i)));

    const cells: Record<string, Record<string, unknown>> = {};
    for (const room of rooms) {
      const roomCells: Record<string, unknown> = {};
      for (const dk of dayKeys) {
        const dayCellDate = new Date(`${dk}T00:00:00`);
        const res = reservations.find(
          (r) =>
            r.roomId === room.id &&
            startOfDay(r.checkIn).getTime() <= dayCellDate.getTime() &&
            startOfDay(r.checkOut).getTime() > dayCellDate.getTime()
        );
        if (res) {
          roomCells[dk] = {
            status: res.status === "CHECKED_IN" ? "OCCUPIED" : "RESERVED",
            reservationId: res.id,
            guestName: `${res.guest.firstName} ${res.guest.lastName}`.trim(),
            code: res.code,
            checkOut: dayKey(res.checkOut),
          };
        } else {
          roomCells[dk] = { status: "AVAILABLE" };
        }
      }
      cells[room.id] = roomCells;
    }

    const unassigned = reservations
      .filter((r) => !r.roomId)
      .map((r) => ({
        reservationId: r.id,
        code: r.code,
        guestName: `${r.guest.firstName} ${r.guest.lastName}`.trim(),
        roomTypeName: r.roomType.name,
        checkIn: r.checkIn,
        checkOut: r.checkOut,
      }));

    // Stats for "today"
    const today = startOfDay(new Date());
    const occupiedSet = new Set<string>();
    const checkoutDueSet = new Set<string>();
    for (const r of reservations) {
      if (!r.roomId) continue;
      const coversToday =
        startOfDay(r.checkIn).getTime() <= today.getTime() && startOfDay(r.checkOut).getTime() > today.getTime();
      const dueToday = startOfDay(r.checkOut).getTime() === today.getTime();
      if (r.status === "CHECKED_IN" && coversToday) occupiedSet.add(r.roomId);
      if (dueToday) checkoutDueSet.add(r.roomId);
    }
    const dirtySet = new Set(rooms.filter((r) => r.status === "DIRTY").map((r) => r.id));
    const busyOrDirty = new Set<string>([...occupiedSet, ...checkoutDueSet, ...dirtySet]);
    const availableCount = rooms.filter((r) => !busyOrDirty.has(r.id)).length;

    return ok({
      rooms: rooms.map((r) => ({
        id: r.id,
        number: r.number,
        floor: r.floor,
        roomType: { id: r.roomType.id, name: r.roomType.name },
      })),
      days: dayKeys,
      cells,
      unassigned,
      stats: {
        AVAILABLE: availableCount,
        OCCUPIED: occupiedSet.size,
        CHECKOUT_DUE: checkoutDueSet.size,
        HOUSEKEEPING: dirtySet.size,
      },
    });
  },
  { module: "stay-view" }
);
