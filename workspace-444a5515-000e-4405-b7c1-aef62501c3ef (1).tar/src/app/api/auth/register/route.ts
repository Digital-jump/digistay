import { db } from "@/lib/db";
import { ApiError, audit, fail, ok } from "@/lib/api-helpers";
import { createSession, hashPassword } from "@/lib/auth";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function handleError(e: unknown) {
  if (e instanceof ApiError) return fail(e.message, e.status);
  console.error("[auth/register]", e);
  return fail("Internal server error", 500);
}

// POST /api/auth/register — PUBLIC: create a guest account for website booking
export async function POST(req: Request) {
  try {
    const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const name = typeof b.name === "string" ? b.name.trim().replace(/\s+/g, " ") : "";
    const email = typeof b.email === "string" ? b.email.trim().toLowerCase() : "";
    const phone = typeof b.phone === "string" ? b.phone.trim() : "";
    const password = typeof b.password === "string" ? b.password : "";

    const parts = name.split(" ").filter(Boolean);
    if (parts.length < 2) {
      throw new ApiError("Please enter your full name (first and last name)", 400);
    }
    if (!EMAIL_RE.test(email)) throw new ApiError("Please enter a valid email address", 400);
    if (phone && !/^[+\d][\d\s\-()]{5,19}$/.test(phone)) {
      throw new ApiError("Please enter a valid phone number", 400);
    }
    if (password.length < 6) throw new ApiError("Password must be at least 6 characters", 400);
    if (password.length > 100) throw new ApiError("Password is too long", 400);

    const existing = await db.user.findUnique({ where: { email } });
    if (existing) {
      throw new ApiError("An account with this email already exists. Please sign in instead.", 409);
    }

    const user = await db.user.create({
      data: {
        name,
        email,
        passwordHash: hashPassword(password),
        role: "GUEST",
        phone: phone || null,
      },
    });

    // Link or create a matching guest profile so bookings made with this
    // email appear in the guest's "My bookings" portal automatically.
    let guestProfile = await db.guest.findFirst({ where: { email } });
    if (!guestProfile) {
      const candidates = await db.guest.findMany({
        where: { email: { not: null } },
        select: { id: true, email: true },
      });
      const match = candidates.find((g) => g.email?.toLowerCase() === email.toLowerCase());
      if (match) guestProfile = await db.guest.findUnique({ where: { id: match.id } });
    }
    if (!guestProfile) {
      await db.guest.create({
        data: {
          firstName: parts[0],
          lastName: parts.slice(1).join(" "),
          email,
          phone: phone || null,
        },
      });
    }

    const { token } = await createSession(user.id);
    const safe = { id: user.id, name: user.name, email: user.email, role: user.role, phone: user.phone };
    await audit(safe, "CREATE", "User", user.id, `${user.name} registered a guest booking account`);

    return ok({ token, user: safe }, 201);
  } catch (e: unknown) {
    return handleError(e);
  }
}
