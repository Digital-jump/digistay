import { db } from "@/lib/db";
import { ApiError, audit, fail, ok } from "@/lib/api-helpers";
import { createSession, verifyPassword } from "@/lib/auth";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Portal sign-in: restrict which roles may enter through each portal
const PORTAL_ROLES: Record<string, string[]> = {
  admin: ["ADMIN"],
  staff: ["RECEPTIONIST", "ACCOUNTANT", "STAFF"],
  guest: ["GUEST"],
};
const PORTAL_LABELS: Record<string, string> = {
  admin: "Hotel Owner / Admin",
  staff: "Staff",
  guest: "Guest booking",
};

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as {
      email?: unknown;
      password?: unknown;
      portal?: unknown;
    };
    const portal = typeof body.portal === "string" ? body.portal.toLowerCase() : "";
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body.password === "string" ? body.password : "";

    if (!email || !EMAIL_RE.test(email)) throw new ApiError("A valid email is required", 400);
    if (!password) throw new ApiError("Password is required", 400);

    const u = await db.user.findUnique({ where: { email } });
    if (!u || !u.active || !verifyPassword(password, u.passwordHash)) {
      throw new ApiError("Invalid email or password", 401);
    }

    if (portal && PORTAL_ROLES[portal] && !PORTAL_ROLES[portal].includes(u.role)) {
      throw new ApiError(
        `This account doesn't have access to the ${PORTAL_LABELS[portal] ?? portal} portal. Please use the correct sign-in option.`,
        403
      );
    }

    const { token } = await createSession(u.id);
    const user = { id: u.id, name: u.name, email: u.email, role: u.role, phone: u.phone };
    await audit(user, "LOGIN", "User", u.id, `${u.name} signed in`);
    return ok({ token, user });
  } catch (e: unknown) {
    if (e instanceof ApiError) return fail(e.message, e.status);
    console.error("[auth/login]", e);
    return fail("Internal server error", 500);
  }
}
