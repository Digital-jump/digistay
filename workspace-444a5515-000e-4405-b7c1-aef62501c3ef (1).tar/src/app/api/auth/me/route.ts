import { ok, withAuth } from "@/lib/api-helpers";

export const GET = withAuth(async (_req, { user }) => {
  return ok({ user });
});
