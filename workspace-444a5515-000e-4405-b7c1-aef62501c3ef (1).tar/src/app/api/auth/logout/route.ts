import { ok, withAuth } from "@/lib/api-helpers";
import { destroySession, extractToken } from "@/lib/auth";

export const POST = withAuth(async (req) => {
  const token = extractToken(req);
  if (token) await destroySession(token);
  return ok({ ok: true });
});
