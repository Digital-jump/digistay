import { z } from "zod";
import { db } from "@/lib/db";
import {
  ApiError,
  nightsBetween,
  ok,
  overlappingReservationsFilter,
  parseBody,
  withAuth,
} from "@/lib/api-helpers";
import { callLLM, extractJson, ymd } from "@/lib/ai";

const Body = z.object({ reservationId: z.string().min(1, "reservationId is required") });

const isRecord = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);

type Candidate = {
  room: { id: string; number: string; floor: number; housekeeping: string; roomTypeId: string };
  typeName: string;
  isUpgrade: boolean;
  score: number;
  signals: string[];
};

function roomNumKey(n: string): number {
  const x = parseInt(n, 10);
  return isNaN(x) ? Number.MAX_SAFE_INTEGER : x;
}

// POST /api/ai/smart-assign { reservationId } (ADMIN | RECEPTIONIST) — rank available rooms (NO DB writes)
export const POST = withAuth(
  async (req) => {
    const parsed = Body.safeParse(await parseBody(req));
    if (!parsed.success) throw new ApiError("reservationId is required", 400);

    const reservation = await db.reservation.findUnique({
      where: { id: parsed.data.reservationId },
      include: { guest: true, roomType: true },
    });
    if (!reservation) throw new ApiError("Reservation not found", 404);
    if (nightsBetween(reservation.checkIn, reservation.checkOut) < 1) {
      throw new ApiError("Reservation has invalid dates", 409);
    }

    const guests = Math.max(1, reservation.adults + reservation.children);
    const guestName = `${reservation.guest.firstName} ${reservation.guest.lastName}`;

    // Rooms this guest previously stayed in (for the repeat-guest bonus).
    const pastStays = await db.reservation.findMany({
      where: { guestId: reservation.guestId, roomId: { not: null }, id: { not: reservation.id } },
      select: { roomId: true },
    });
    const stayedRoomIds = new Set(pastStays.map((p) => p.roomId).filter((id): id is string => !!id));

    // Candidate pool: same room type first; upgrade to higher-rate types if none available.
    const [sameTypeRooms, higherTypes] = await Promise.all([
      db.room.findMany({ where: { roomTypeId: reservation.roomTypeId }, orderBy: { number: "asc" } }),
      db.roomType.findMany({
        where: { baseRate: { gt: reservation.roomType.baseRate } },
        orderBy: { baseRate: "asc" },
      }),
    ]);
    const higherRooms = higherTypes.length
      ? await db.room.findMany({ where: { roomTypeId: { in: higherTypes.map((t) => t.id) } }, orderBy: { number: "asc" } })
      : [];
    const typeById = new Map([reservation.roomType, ...higherTypes].map((t) => [t.id, t]));

    const isFree = async (rooms: typeof sameTypeRooms) => {
      const free: typeof sameTypeRooms = [];
      for (const room of rooms) {
        const clash = await db.reservation.findFirst({
          where: overlappingReservationsFilter({
            roomId: room.id,
            checkIn: reservation.checkIn,
            checkOut: reservation.checkOut,
            excludeId: reservation.id,
          }),
        });
        if (!clash) free.push(room);
      }
      return free;
    };

    const availableSame = await isFree(sameTypeRooms);
    // Capacity filter first (capacity lives on RoomType); relax if it would empty the pool.
    const capacityOk = (roomTypeId: string) => (typeById.get(roomTypeId)?.capacity ?? 0) >= guests;
    let pool = availableSame.filter((r) => capacityOk(r.roomTypeId));
    if (!pool.length) pool = availableSame;
    if (!pool.length) {
      const availableUpgrade = await isFree(higherRooms);
      pool = availableUpgrade.filter((r) => capacityOk(r.roomTypeId));
      if (!pool.length) pool = availableUpgrade;
    }

    // Deterministic scoring.
    const sr = (reservation.specialRequests ?? "").toLowerCase();
    const wantsHighFloor = /high floor|higher floor|top floor/.test(sr);
    const wantsLowFloor = /low floor|ground floor/.test(sr);
    const wantsQuiet = /quiet/.test(sr);
    const wantsView = /view/.test(sr);
    const wantsAccessible = /accessible|wheelchair/.test(sr);
    const maxFloor = pool.reduce((m, r) => Math.max(m, r.floor), 1);
    const highEnough = Math.min(3, maxFloor);

    const scored: Candidate[] = pool.map((room) => {
      const type = typeById.get(room.roomTypeId);
      const signals: string[] = [];
      let score = 0;
      if (stayedRoomIds.has(room.id)) {
        score += 3;
        signals.push("guest stayed in this room before");
      }
      if (wantsHighFloor && room.floor >= highEnough) {
        score += 2;
        signals.push("matches high-floor request");
      }
      if (wantsLowFloor && room.floor <= 2) {
        score += 2;
        signals.push("matches low-floor request");
      }
      if (wantsQuiet && room.floor >= highEnough) {
        score += 2;
        signals.push("quiet higher-floor setting");
      }
      if (wantsView && room.floor >= highEnough) {
        score += 2;
        signals.push("good view from a higher floor");
      }
      if (wantsAccessible && room.floor === 1) {
        score += 2;
        signals.push("ground-floor accessible");
      }
      if ((type?.capacity ?? 0) >= guests) {
        score += 1;
        signals.push("fits the party size");
      }
      if (room.housekeeping === "CLEAN" || room.housekeeping === "INSPECTED") {
        score += 1;
        signals.push("housekeeping-ready");
      }
      const isUpgrade = room.roomTypeId !== reservation.roomTypeId;
      if (isUpgrade && type) signals.push(`complimentary upgrade to ${type.name}`);
      return {
        room: {
          id: room.id,
          number: room.number,
          floor: room.floor,
          housekeeping: room.housekeeping,
          roomTypeId: room.roomTypeId,
        },
        typeName: type?.name ?? reservation.roomType.name,
        isUpgrade,
        score,
        signals,
      };
    });

    scored.sort(
      (a, b) =>
        b.score - a.score ||
        a.room.floor - b.room.floor ||
        roomNumKey(a.room.number) - roomNumKey(b.room.number) ||
        a.room.number.localeCompare(b.room.number)
    );
    const top = scored.slice(0, 5);

    const ruleReasons = (c: Candidate): string[] => {
      const reasons = [...c.signals];
      if (!reasons.some((r) => r.includes("Available") || r.includes("free"))) {
        reasons.push(`Room ${c.room.number} is free for ${ymd(reservation.checkIn)} → ${ymd(reservation.checkOut)}`);
      }
      return reasons.slice(0, 3);
    };

    const suggestions = top.map((c) => ({
      roomId: c.room.id,
      roomNumber: c.room.number,
      typeName: c.typeName,
      score: c.score,
      reasons: ruleReasons(c),
    }));
    let bestRoomId: string | null = suggestions[0]?.roomId ?? null;

    // One LLM call writes short reasons for each candidate (scores/order stay ours).
    try {
      const payload = {
        reservation: {
          code: reservation.code,
          guestName,
          requestedType: reservation.roomType.name,
          checkIn: ymd(reservation.checkIn),
          checkOut: ymd(reservation.checkOut),
          nights: nightsBetween(reservation.checkIn, reservation.checkOut),
          guests,
          specialRequests: reservation.specialRequests,
        },
        candidates: top.map((c) => ({
          roomId: c.room.id,
          roomNumber: c.room.number,
          floor: c.room.floor,
          housekeeping: c.room.housekeeping,
          typeName: c.typeName,
          isUpgrade: c.isUpgrade,
          ourScore: c.score,
          signals: c.signals,
        })),
      };
      const text = await callLLM([
        {
          role: "system",
          content:
            "You are a hotel front-desk AI helping assign the best available room to a reservation. " +
            "For EACH candidate room in the given order, write 2-3 very short reasons (each max 70 chars) why it is a good assignment. " +
            "Reference the guest's special requests, prior stays, floor/housekeeping facts — stay factual, never invent amenities. " +
            'Return STRICT JSON only: [{"roomId":"...","reasons":["..."]}] in the SAME order as the candidates. No markdown, no fences.',
        },
        { role: "user", content: JSON.stringify(payload) },
      ]);
      const arr = extractJson<unknown[]>(text);
      const byId = new Map<string, string[]>();
      if (Array.isArray(arr)) {
        for (const e of arr) {
          if (!isRecord(e) || typeof e.roomId !== "string" || !Array.isArray(e.reasons)) continue;
          const reasons = e.reasons
            .filter((r): r is string => typeof r === "string" && !!r.trim())
            .map((r) => r.trim().slice(0, 90))
            .slice(0, 3);
          if (reasons.length >= 2) byId.set(e.roomId, reasons);
        }
      }
      if (byId.size) {
        for (const s of suggestions) {
          const llmReasons = byId.get(s.roomId);
          if (llmReasons) s.reasons = llmReasons;
        }
      }
    } catch (e) {
      console.error("[ai/smart-assign] LLM reason call failed:", e);
    }

    if (!bestRoomId) {
      // No free room of the requested (or higher) type — surface empty result.
      return ok({ suggestions: [], bestRoomId: null });
    }

    return ok({ suggestions, bestRoomId });
  },
  { roles: ["ADMIN", "RECEPTIONIST"] }
);
