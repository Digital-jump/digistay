import { db } from "@/lib/db";
import { addDays, startOfDay, withAuth, ok } from "@/lib/api-helpers";
import { callLLM, extractJson, inr, pct, round1 } from "@/lib/ai";

// ─── Deterministic rate suggestion ────────────────────────────────────────

type TypeDemand = {
  roomTypeId: string;
  name: string;
  baseRate: number;
  occupancy14d: number; // 0..1 rooms-nights sold / available over past 14d
  next14dBookedRatio: number; // 0..1 rooms-nights committed / available next 14d
  weekdayNights: number;
  weekendNights: number;
  currentPressure: number; // 0..1 committed tonight
};

/**
 * Defensible band-based suggestion: ±5-20% by demand/occupancy bands,
 * rounded to nearest ₹100, never below 0.8× base and never above +20%.
 */
function suggestRate(base: number, d: TypeDemand): number {
  let delta = 0;
  if (d.next14dBookedRatio >= 0.8) delta += 20;
  else if (d.next14dBookedRatio >= 0.65) delta += 12;
  else if (d.next14dBookedRatio >= 0.45) delta += 6;
  else if (d.next14dBookedRatio <= 0.15) delta -= 12;
  else if (d.next14dBookedRatio <= 0.3) delta -= 6;

  if (d.occupancy14d >= 0.85) delta += 4;
  else if (d.occupancy14d <= 0.25) delta -= 4;

  const weekendSkew = d.weekendNights > d.weekdayNights * 1.25;
  if (weekendSkew) delta += 3;

  delta = Math.max(-15, Math.min(20, delta));
  let suggested = Math.round((base * (100 + delta)) / 100 / 100) * 100;
  const minRate = Math.ceil((base * 0.8) / 100) * 100;
  if (suggested < minRate) suggested = minRate;
  if (Math.abs(suggested - base) / base < 0.03) suggested = base;
  return suggested;
}

function fallbackReason(d: TypeDemand, suggested: number, deltaPercent: number): string {
  const demand = pct(d.next14dBookedRatio);
  const occ = pct(d.occupancy14d);
  if (deltaPercent > 0) {
    return `Next-14-day demand is at ${demand}% of capacity (past-14-day occupancy ${occ}%) — the rate can move up to ${inr(suggested)}.`;
  }
  if (deltaPercent < 0) {
    return `Only ${demand}% of the next 14 days is booked (${occ}% occupancy over the past 14 days) — ease the rate to ${inr(suggested)} to stimulate demand.`;
  }
  return `Demand is steady (${demand}% booked for the next 14 days, ${occ}% past occupancy) — hold the current rate of ${inr(d.baseRate)}.`;
}

// GET /api/ai/pricing (ADMIN) — dynamic rate suggestions per room type (NO DB writes)
export const GET = withAuth(async () => {
  const today = startOfDay(new Date());
  const windowStart = addDays(today, -14);
  const windowEnd = addDays(today, 14);

  const [types, stays] = await Promise.all([
    db.roomType.findMany({ include: { rooms: { select: { id: true, roomTypeId: true } } }, orderBy: { baseRate: "asc" } }),
    db.reservation.findMany({
      where: { status: { notIn: ["CANCELLED", "NO_SHOW"] }, checkIn: { lt: windowEnd }, checkOut: { gt: windowStart } },
      select: { roomTypeId: true, roomId: true, checkIn: true, checkOut: true },
    }),
  ]);
  const roomsAll = types.flatMap((t) => t.rooms);
  const roomTypeByRoomId = new Map(roomsAll.map((r) => [r.id, r.roomTypeId]));

  // Pre-compute committed rooms per type per day across the whole window.
  const dayList: Date[] = [];
  for (let d = startOfDay(windowStart); d.getTime() < windowEnd.getTime(); d = addDays(d, 1)) {
    dayList.push(startOfDay(d));
  }
  const committed = new Map<string, number[]>(); // roomTypeId → per-day counts (index 0 = windowStart)
  for (let di = 0; di < dayList.length; di++) {
    const dayMs = dayList[di].getTime();
    for (const s of stays) {
      if (startOfDay(s.checkIn).getTime() > dayMs || startOfDay(s.checkOut).getTime() <= dayMs) continue;
      const typeId = s.roomId ? roomTypeByRoomId.get(s.roomId) : s.roomTypeId;
      if (!typeId) continue;
      let arr = committed.get(typeId);
      if (!arr) {
        arr = new Array<number>(dayList.length).fill(0);
        committed.set(typeId, arr);
      }
      arr[di] += 1;
    }
  }
  const todayIdx = dayList.findIndex((d) => d.getTime() === today.getTime());

  const demand: TypeDemand[] = types.map((t) => {
    const total = t.rooms.length || 1;
    const days = committed.get(t.id) ?? new Array<number>(dayList.length).fill(0);
    let pastNights = 0;
    let nextNights = 0;
    let weekday = 0;
    let weekend = 0;
    for (let di = 0; di < dayList.length; di++) {
      const isPast = dayList[di].getTime() < today.getTime();
      const isWeekend = dayList[di].getDay() === 5 || dayList[di].getDay() === 6; // Fri & Sat nights
      if (isPast) {
        pastNights += days[di];
      } else {
        nextNights += days[di];
        if (isWeekend) weekend += days[di];
        else weekday += days[di];
      }
    }
    return {
      roomTypeId: t.id,
      name: t.name,
      baseRate: t.baseRate,
      occupancy14d: pastNights / (total * 14),
      next14dBookedRatio: nextNights / (total * 14),
      weekdayNights: weekday,
      weekendNights: weekend,
      currentPressure: todayIdx >= 0 ? (days[todayIdx] ?? 0) / total : 0,
    };
  });

  const suggestions = demand.map((d) => {
    const suggested = suggestRate(d.baseRate, d);
    const deltaPercent = d.baseRate ? round1(((suggested - d.baseRate) / d.baseRate) * 100) : 0;
    return {
      roomTypeId: d.roomTypeId,
      roomTypeName: d.name,
      currentRate: d.baseRate,
      suggestedRate: suggested,
      deltaPercent,
      occupancy14d: Math.round(d.occupancy14d * 1000) / 1000,
      next14dBookedRatio: Math.round(d.next14dBookedRatio * 1000) / 1000,
      _demand: d,
    };
  });

  // One LLM call writes the human reason for every type.
  const reasons = new Map<string, string>();
  try {
    const payload = suggestions.map((s) => ({
      roomTypeId: s.roomTypeId,
      name: s.roomTypeName,
      currentRate: s.currentRate,
      suggestedRate: s.suggestedRate,
      deltaPercent: s.deltaPercent,
      occupancy14dPct: pct(s._demand.occupancy14d),
      next14dBookedPct: pct(s._demand.next14dBookedRatio),
      weekdayNights: s._demand.weekdayNights,
      weekendNights: s._demand.weekendNights,
      currentPressurePct: pct(s._demand.currentPressure),
    }));
    const text = await callLLM([
      {
        role: "system",
        content:
          "You are a hotel pricing analyst. For EACH room type in the JSON array, write ONE reason sentence (max 140 chars) " +
          "justifying the suggested rate vs the current rate, citing the concrete demand/occupancy numbers given. " +
          'Return STRICT JSON only: an array [{"roomTypeId":"...","reason":"..."}] with one entry per type, same order. ' +
          "No markdown, no fences, no commentary.",
      },
      { role: "user", content: JSON.stringify(payload) },
    ]);
    const arr = extractJson<unknown[]>(text);
    if (Array.isArray(arr)) {
      for (const e of arr) {
        if (!e || typeof e !== "object" || Array.isArray(e)) continue;
        const o = e as Record<string, unknown>;
        if (typeof o.roomTypeId === "string" && typeof o.reason === "string" && o.reason.trim()) {
          reasons.set(o.roomTypeId, o.reason.trim().slice(0, 200));
        }
      }
    }
  } catch (e) {
    console.error("[ai/pricing] LLM reason call failed:", e);
  }

  const out = suggestions.map(({ _demand, ...s }) => ({
    ...s,
    reason: reasons.get(s.roomTypeId) ?? fallbackReason(_demand, s.suggestedRate, s.deltaPercent),
  }));

  return ok({ suggestions: out, generatedAt: new Date().toISOString() });
}, { roles: ["ADMIN"] });
