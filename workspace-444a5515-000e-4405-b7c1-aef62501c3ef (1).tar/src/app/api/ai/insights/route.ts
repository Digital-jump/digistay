import { z } from "zod";
import { db } from "@/lib/db";
import { ACTIVE_RESERVATION_STATUSES, addDays, money, startOfDay, withAuth, ok } from "@/lib/api-helpers";
import {
  callLLM,
  extractJson,
  getHotelSnapshot,
  getOccupancyTrend,
  getStayRevenueStats,
  inr,
  pct,
  round1,
  ymd,
} from "@/lib/ai";

// ─── Types & in-memory cache (5 min TTL, concurrent-computation guard) ────

type Insight = {
  title: string;
  detail: string;
  severity: "positive" | "warning" | "critical" | "info";
  action: string;
};

const TTL = 5 * 60 * 1000;

let cache: { at: number; data: Insight[] } | null = null;
let inflight: Promise<Insight[]> | null = null;

// ─── Metrics ──────────────────────────────────────────────────────────────

type Metrics = {
  today: { date: string; occupancyPct: number; occupied: number; totalRooms: number; outOfService: number };
  occupancyTrend14d: { date: string; occupancyPct: number }[];
  adr14d: number;
  revpar14d: number;
  roomNightsSold14d: number;
  roomRevenue14d: number;
  outstandingInvoiced: number;
  pendingFnBOrders: number;
  arrivalsNext7d: number;
  roomTypePressureNext7d: { type: string; total: number; peakBooked: number; pressurePct: number }[];
  reviews: { avg: number; count: number; buckets: Record<string, number> };
  topChannel30d: { source: string; bookings: number } | null;
  cancellationsNoShows30d: number;
};

async function computeMetrics(): Promise<Metrics> {
  const now = new Date();
  const today = startOfDay(now);
  const weekEnd = addDays(today, 7);

  const snapshot = await getHotelSnapshot();
  const [trend, stayStats, typePressure, reviewAgg, reviewBuckets, recentRes, cancelledCount, arrivalsNext7d] =
    await Promise.all([
      getOccupancyTrend(14),
      getStayRevenueStats(addDays(today, -13), addDays(today, 1), snapshot.totalRooms),
      (async () => {
        const [rooms, types, upcoming] = await Promise.all([
          db.room.findMany({ select: { id: true, roomTypeId: true } }),
          db.roomType.findMany({ select: { id: true, name: true } }),
          db.reservation.findMany({
            where: {
              status: { in: ACTIVE_RESERVATION_STATUSES },
              checkIn: { lt: weekEnd },
              checkOut: { gt: today },
            },
            select: { roomTypeId: true, roomId: true, checkIn: true, checkOut: true },
          }),
        ]);
        const roomTypeByRoomId = new Map(rooms.map((r) => [r.id, r.roomTypeId]));
        const totals = new Map<string, number>();
        for (const r of rooms) totals.set(r.roomTypeId, (totals.get(r.roomTypeId) ?? 0) + 1);
        return types.map((t) => {
          let peak = 0;
          for (let d = 0; d < 7; d++) {
            const day = addDays(today, d).getTime();
            const committed = upcoming.filter((u) => {
              if (startOfDay(u.checkIn).getTime() > day || startOfDay(u.checkOut).getTime() <= day) return false;
              return u.roomId ? roomTypeByRoomId.get(u.roomId) === t.id : u.roomTypeId === t.id;
            }).length;
            peak = Math.max(peak, committed);
          }
          const total = totals.get(t.id) ?? 0;
          return { type: t.name, total, peakBooked: peak, pressurePct: total ? pct(peak / total) : 0 };
        });
      })(),
      db.review.aggregate({ _avg: { rating: true }, _count: true }),
      db.review.groupBy({ by: ["rating"], _count: true }),
      db.reservation.findMany({
        where: { createdAt: { gte: addDays(now, -30) }, status: { not: "CANCELLED" } },
        select: { source: true },
      }),
      db.reservation.count({
        where: { status: { in: ["CANCELLED", "NO_SHOW"] }, updatedAt: { gte: addDays(now, -30) } },
      }),
      db.reservation.count({
        where: { checkIn: { gte: today, lt: weekEnd }, status: { in: ACTIVE_RESERVATION_STATUSES } },
      }),
    ]);

  const buckets: Record<string, number> = { "1": 0, "2": 0, "3": 0, "4": 0, "5": 0 };
  for (const b of reviewBuckets) buckets[String(b.rating)] = b._count;

  const channelMap = new Map<string, number>();
  for (const r of recentRes) channelMap.set(r.source, (channelMap.get(r.source) ?? 0) + 1);
  const topChannel = [...channelMap.entries()].sort((a, b) => b[1] - a[1])[0];

  return {
    today: {
      date: snapshot.date,
      occupancyPct: snapshot.occupancyPct,
      occupied: snapshot.occupiedRooms,
      totalRooms: snapshot.totalRooms,
      outOfService: snapshot.outOfServiceRooms,
    },
    occupancyTrend14d: trend,
    adr14d: stayStats.roomNightsSold ? money(stayStats.roomRevenue / stayStats.roomNightsSold) : 0,
    revpar14d: stayStats.availableRoomNights ? money(stayStats.roomRevenue / stayStats.availableRoomNights) : 0,
    roomNightsSold14d: stayStats.roomNightsSold,
    roomRevenue14d: stayStats.roomRevenue,
    outstandingInvoiced: snapshot.outstandingTotal,
    pendingFnBOrders: snapshot.pendingFoodOrders,
    arrivalsNext7d,
    roomTypePressureNext7d: typePressure,
    reviews: {
      avg: reviewAgg._avg.rating ? round1(reviewAgg._avg.rating) : 0,
      count: reviewAgg._count,
      buckets,
    },
    topChannel30d: topChannel ? { source: topChannel[0], bookings: topChannel[1] } : null,
    cancellationsNoShows30d: cancelledCount,
  };
}

// ─── LLM insights (strict JSON, zod-validated) ────────────────────────────

const InsightSchema = z.object({
  title: z.string().min(3).max(60),
  detail: z.string().min(5).max(220),
  severity: z.enum(["positive", "warning", "critical", "info"]),
  action: z.string().min(3).max(100),
});

const isRecord = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);

const trunc = (v: unknown, n: number): unknown => (typeof v === "string" ? v.trim().slice(0, n) : v);

function coerceInsight(raw: unknown): unknown {
  if (!isRecord(raw)) return raw;
  return {
    title: trunc(raw.title, 60),
    detail: trunc(raw.detail, 220),
    severity: typeof raw.severity === "string" ? raw.severity.trim().toLowerCase() : raw.severity,
    action: trunc(raw.action, 100),
  };
}

async function llmInsights(m: Metrics): Promise<Insight[] | null> {
  const text = await callLLM([
    {
      role: "system",
      content:
        "You are a senior hotel revenue & operations analyst for DigiStay Grand Hotel (Mumbai). " +
        "Analyze the JSON metrics provided and return STRICT JSON only: an array of 4-6 insight objects, each with keys " +
        '"title" (max 60 chars), "detail" (max 220 chars, MUST cite the actual numbers from the metrics), ' +
        '"severity" (one of "positive"|"warning"|"critical"|"info"), "action" (max 100 chars, a concrete next step for staff). ' +
        "Focus on what matters most: occupancy, revenue, receivables, sell-out risk, guest satisfaction. " +
        "Output ONLY the JSON array — no markdown, no code fences, no commentary.",
    },
    { role: "user", content: JSON.stringify(m) },
  ]);
  const arr = extractJson<unknown[]>(text);
  if (!Array.isArray(arr)) return null;
  const insights: Insight[] = [];
  for (const raw of arr.slice(0, 6)) {
    const v = InsightSchema.safeParse(coerceInsight(raw));
    if (v.success) insights.push(v.data);
  }
  return insights.length ? insights : null;
}

// ─── Deterministic fallback insights ──────────────────────────────────────

function ruleBasedInsights(m: Metrics): Insight[] {
  const out: Insight[] = [];
  const t = m.today;

  if (t.occupancyPct < 55) {
    out.push({
      title: "Occupancy is running low",
      detail: `Only ${t.occupied}/${t.totalRooms} rooms (${t.occupancyPct}%) are occupied tonight and ${t.outOfService} are out of service.`,
      severity: "warning",
      action: "Run a flash sale on the booking engine and push OTA promos for the next 7 days.",
    });
  } else {
    out.push({
      title: "Healthy occupancy tonight",
      detail: `${t.occupied}/${t.totalRooms} rooms are occupied (${t.occupancyPct}%), with ${m.arrivalsNext7d} arrivals expected over the next 7 days.`,
      severity: "positive",
      action: "Hold current rate cards and focus on suite upsells at check-in.",
    });
  }

  if (m.outstandingInvoiced > 50000) {
    out.push({
      title: "Outstanding receivables are high",
      detail: `${inr(m.outstandingInvoiced)} is invoiced but unpaid — vs ${inr(m.roomRevenue14d)} room revenue in the last 14 days.`,
      severity: m.outstandingInvoiced > 150000 ? "critical" : "warning",
      action: "Chase the oldest unpaid invoices and send folio reminders today.",
    });
  } else if (m.outstandingInvoiced > 0) {
    out.push({
      title: "Receivables under control",
      detail: `Outstanding invoiced balance is ${inr(m.outstandingInvoiced)} against ${inr(m.roomRevenue14d)} room revenue in 14 days.`,
      severity: "info",
      action: "Watch invoice aging and remind folio holders before month-end.",
    });
  }

  const hot = [...m.roomTypePressureNext7d].sort((a, b) => b.pressurePct - a.pressurePct)[0];
  if (hot && hot.pressurePct >= 70) {
    out.push({
      title: `${hot.type} may sell out`,
      detail: `${hot.peakBooked}/${hot.total} ${hot.type} rooms are committed on the peak day within the next 7 days (${hot.pressurePct}%).`,
      severity: "critical",
      action: `Stop discounts on ${hot.type} and upsell to higher categories.`,
    });
  } else if (hot) {
    out.push({
      title: "Availability is comfortable",
      detail: `Peak next-7-day commitment is ${hot.peakBooked}/${hot.total} rooms (${hot.pressurePct}%) for ${hot.type}.`,
      severity: "info",
      action: "Keep promotions running to lift midweek occupancy.",
    });
  }

  if (m.reviews.count > 0 && m.reviews.avg < 3.5) {
    const low = (m.reviews.buckets["1"] ?? 0) + (m.reviews.buckets["2"] ?? 0);
    out.push({
      title: "Guest review scores are dipping",
      detail: `Average rating is ${m.reviews.avg}/5 across ${m.reviews.count} reviews (${low} of them 2★ or lower).`,
      severity: "warning",
      action: "Reply to unanswered reviews and brief the team on repeat complaints.",
    });
  } else if (m.reviews.count > 0) {
    out.push({
      title: "Reviews remain strong",
      detail: `Average rating is ${m.reviews.avg}/5 across ${m.reviews.count} reviews.`,
      severity: "positive",
      action: "Share top reviews with the team and ask happy guests for more.",
    });
  }

  if (m.pendingFnBOrders > 2) {
    out.push({
      title: "F&B queue is building",
      detail: `${m.pendingFnBOrders} food orders are still pending or preparing.`,
      severity: "info",
      action: "Check the Food Orders board and expedite the oldest tickets.",
    });
  }

  if (m.cancellationsNoShows30d >= 3) {
    out.push({
      title: "Cancellations trending up",
      detail: `${m.cancellationsNoShows30d} cancellations/no-shows in the last 30 days${m.topChannel30d ? `; top channel is ${m.topChannel30d.source} (${m.topChannel30d.bookings} bookings)` : ""}.`,
      severity: "info",
      action: "Confirm upcoming bookings by phone and enforce the no-show policy.",
    });
  }

  if (out.length < 4) {
    out.push({
      title: "Revenue snapshot",
      detail: `Last 14 days: ${inr(m.roomRevenue14d)} room revenue, ADR ${inr(m.adr14d)}, RevPAR ${inr(m.revpar14d)}.`,
      severity: "info",
      action: "Review AI pricing suggestions to optimise the next 14 days.",
    });
  }
  return out.slice(0, 6);
}

async function computeInsights(): Promise<Insight[]> {
  if (inflight) return inflight;
  inflight = (async () => {
    const metrics = await computeMetrics();
    let insights = (await llmInsights(metrics)) ?? [];
    if (insights.length < 4) {
      const rb = ruleBasedInsights(metrics).filter((r) => !insights.some((i) => i.title === r.title));
      insights = [...insights, ...rb].slice(0, Math.max(4, insights.length));
    }
    cache = { at: Date.now(), data: insights };
    return insights;
  })().finally(() => {
    inflight = null;
  });
  return inflight;
}

// GET /api/ai/insights (ADMIN) — AI operational insights with 5-min cache
export const GET = withAuth(
  async (req) => {
    const url = new URL(req.url);
    const refresh = url.searchParams.get("refresh") === "1";
    if (!refresh && cache && Date.now() - cache.at < TTL) {
      return ok({ insights: cache.data, generatedAt: new Date(cache.at).toISOString(), cached: true });
    }
    const data = await computeInsights();
    return ok({
      insights: data,
      generatedAt: new Date(cache?.at ?? Date.now()).toISOString(),
      cached: false,
    });
  },
  { roles: ["ADMIN"] }
);
