import { z } from "zod";
import { db } from "@/lib/db";
import { ApiError, ok, parseBody, withAuth } from "@/lib/api-helpers";
import { callLLM, extractJson } from "@/lib/ai";

const Body = z.object({ reviewId: z.string().min(1, "reviewId is required") });

const ReplySchema = z.object({
  reply: z.string().min(20).max(1200),
  sentiment: z.enum(["positive", "neutral", "negative"]),
  themes: z.array(z.string().min(1).max(40)).min(1).max(6),
});

// ─── Fallback helpers (template reply by rating band) ─────────────────────

function sentimentByRating(rating: number): "positive" | "neutral" | "negative" {
  if (rating >= 4) return "positive";
  if (rating === 3) return "neutral";
  return "negative";
}

const THEME_KEYWORDS: Array<[RegExp, string]> = [
  [/clean|housekeep|immaculate|tidy|spotless/, "Cleanliness"],
  [/staff|team|front desk|reception|concierge/, "Staff service"],
  [/food|breakfast|restaurant|dining|room service|bar/, "Food & dining"],
  [/wifi|internet/, "Wi-Fi"],
  [/nois|loud|street/, "Noise levels"],
  [/room|suite|bed|space|bathroom/, "Room comfort"],
  [/location|marine drive|walk|view/, "Location"],
  [/value|price|expensive|worth/, "Value for money"],
  [/slow|delay|wait|late|never came/, "Service speed"],
  [/ac|air.?condition|maintenance|repair|broken/, "Maintenance"],
];

function keywordThemes(comment: string, rating: number): string[] {
  const c = comment.toLowerCase();
  const found = THEME_KEYWORDS.filter(([re]) => re.test(c)).map(([, label]) => label);
  const fallback =
    rating >= 4 ? ["Overall experience", "Staff service"] : rating === 3 ? ["Mixed experience", "Service quality"] : ["Service recovery", "Guest experience"];
  return [...new Set([...found, ...fallback])].slice(0, 4);
}

function templateReply(rating: number, guestName: string, comment: string): string {
  const name = guestName || "Guest";
  const specifics = comment.trim().slice(0, 90);
  if (rating >= 5) {
    return `Thank you so much for the wonderful 5-star review, ${name}! We're thrilled that your stay hit the mark${
      specifics ? ` — especially your kind words about ${specifics}` : ""
    }. Your appreciation means a lot to our team, and we look forward to welcoming you back to DigiStay Grand Hotel soon. — Team DigiStay`;
  }
  if (rating === 4) {
    return `Thank you for the lovely feedback, ${name}! We're glad you enjoyed your stay${
      specifics ? ` and appreciated ${specifics}` : ""
    }. We've noted your suggestions as we keep polishing every detail of the experience. We hope to welcome you back for an even better visit. — Team DigiStay`;
  }
  if (rating === 3) {
    return `Thank you for the balanced feedback, ${name}. We're glad parts of your stay worked well, and we're sorry other aspects fell short${
      specifics ? ` — including ${specifics}` : ""
    }. Your comments have been shared with our team and we're acting on them. We'd love the chance to make your next stay a five-star one. — Team DigiStay`;
  }
  return `We sincerely apologise, ${name}, for falling short of your expectations during your stay. Your feedback${
    specifics ? ` about ${specifics}` : ""
  } has been shared with our management team and we're addressing these issues directly. Please reach out to frontdesk@digistay.example so we can make things right on your next visit. — Team DigiStay`;
}

const isRecord = (v: unknown): v is Record<string, unknown> => !!v && typeof v === "object" && !Array.isArray(v);

// POST /api/ai/review-reply { reviewId } (ADMIN | RECEPTIONIST) — draft a hotelier reply (NO DB writes)
export const POST = withAuth(
  async (req) => {
    const parsed = Body.safeParse(await parseBody(req));
    if (!parsed.success) throw new ApiError("reviewId is required", 400);

    const review = await db.review.findUnique({
      where: { id: parsed.data.reviewId },
      include: { guest: true, reservation: { include: { room: true, roomType: true } } },
    });
    if (!review) throw new ApiError("Review not found", 404);

    const guestName = review.guest ? `${review.guest.firstName} ${review.guest.lastName}` : "Guest";
    const roomLabel = review.reservation
      ? [review.reservation.room?.number, review.reservation.roomType?.name].filter(Boolean).join(" · ") || null
      : null;

    let reply: string | null = null;
    let sentiment: string | null = null;
    let themes: string[] = [];

    try {
      const text = await callLLM([
        {
          role: "system",
          content:
            "You are the guest-experience AI for DigiStay Grand Hotel (Mumbai). Write a warm, professional hotelier reply to the guest review. " +
            "Rules: maximum 120 words; acknowledge at least one specific point from the comment; never promise refunds, compensation or anything monetary; " +
            'no bullet points; sign off as "— Team DigiStay". Also classify the review sentiment ("positive"|"neutral"|"negative") and extract 2-4 short themes (1-3 words each). ' +
            'Return STRICT JSON only: {"reply":"...","sentiment":"...","themes":["..."]} — no markdown, no fences, no commentary.',
        },
        {
          role: "user",
          content: JSON.stringify({
            rating: review.rating,
            title: review.title,
            comment: review.comment,
            channel: review.channel,
            guestName,
            room: roomLabel,
          }),
        },
      ]);
      const parsedJson = extractJson(text);
      if (isRecord(parsedJson)) {
        const v = ReplySchema.safeParse(parsedJson);
        if (v.success && v.data.reply.split(/\s+/).length <= 130) {
          reply = v.data.reply.trim();
          sentiment = v.data.sentiment;
          themes = [...new Set(v.data.themes.map((t) => t.trim()).filter(Boolean))].slice(0, 4);
          for (const t of keywordThemes(review.comment, review.rating)) {
            if (themes.length >= 2) break;
            if (!themes.includes(t)) themes.push(t);
          }
        }
      }
    } catch (e) {
      console.error("[ai/review-reply] LLM call failed:", e);
    }

    if (!reply) {
      reply = templateReply(review.rating, guestName, review.comment);
      sentiment = sentimentByRating(review.rating);
      themes = keywordThemes(review.comment, review.rating);
    }

    return ok({ reply, sentiment, themes });
  },
  { roles: ["ADMIN", "RECEPTIONIST"] }
);
