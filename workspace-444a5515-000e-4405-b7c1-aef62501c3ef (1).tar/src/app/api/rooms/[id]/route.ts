import { db } from "@/lib/db";
import { ApiError, audit, fail, ok, withAuth } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

const SETTABLE_STATUSES = ["AVAILABLE", "RESERVED", "DIRTY", "MAINTENANCE"];

function roomsAllowed(role: string): boolean {
  return canAccess(role, "room-view") || canAccess(role, "stay-view");
}

export const PUT = withAuth(async (req, { user, params }) => {
  if (!roomsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const existing = await db.room.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Room not found", 404);

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

  if (body.number !== undefined) {
    const number = typeof body.number === "string" ? body.number.trim() : "";
    if (!number) throw new ApiError("Room number is required", 400);
    if (number !== existing.number) {
      const dup = await db.room.findUnique({ where: { number } });
      if (dup) throw new ApiError("Room number already exists", 409);
    }
  }

  if (body.roomTypeId !== undefined) {
    const roomType = await db.roomType.findUnique({ where: { id: String(body.roomTypeId) } });
    if (!roomType) throw new ApiError("Room type not found", 404);
  }

  if (body.status !== undefined) {
    const status = String(body.status);
    if (status === "OCCUPIED") throw new ApiError("Use check-in to occupy a room", 400);
    if (!SETTABLE_STATUSES.includes(status)) throw new ApiError("Invalid room status", 400);
  }

  const room = await db.room.update({
    where: { id: params.id },
    data: {
      ...(body.number !== undefined ? { number: String(body.number).trim() } : {}),
      ...(body.floor !== undefined && typeof body.floor === "number" ? { floor: body.floor } : {}),
      ...(body.roomTypeId !== undefined ? { roomTypeId: String(body.roomTypeId) } : {}),
      ...(body.notes !== undefined
        ? { notes: typeof body.notes === "string" && body.notes.trim() ? body.notes.trim() : null }
        : {}),
      ...(body.status !== undefined ? { status: String(body.status) } : {}),
    },
    include: { roomType: true },
  });
  await audit(user, "UPDATE", "Room", room.id, `Room ${room.number} updated`);
  return ok(room);
});

export const DELETE = withAuth(async (_req, { user, params }) => {
  if (!roomsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const existing = await db.room.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Room not found", 404);

  const activeReservation = await db.reservation.findFirst({
    where: { roomId: params.id, status: { in: ["PENDING", "CONFIRMED", "CHECKED_IN"] } },
  });
  if (activeReservation) throw new ApiError("Room has active reservations", 409);

  await db.room.delete({ where: { id: params.id } });
  await audit(user, "DELETE", "Room", params.id, `Room ${existing.number}`);
  return ok({ ok: true });
});
