import { db } from "@/lib/db";
import { ApiError, audit, fail, ok, withAuth } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

const HOUSEKEEPING_STATUSES = ["AVAILABLE", "DIRTY", "MAINTENANCE", "RESERVED"];

function roomsAllowed(role: string): boolean {
  return canAccess(role, "room-view") || canAccess(role, "stay-view");
}

export const POST = withAuth(async (req, { user, params }) => {
  if (!roomsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const existing = await db.room.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Room not found", 404);

  const body = (await req.json().catch(() => ({}))) as { status?: unknown };
  const status = typeof body.status === "string" ? body.status : "";
  if (!HOUSEKEEPING_STATUSES.includes(status)) {
    throw new ApiError("Invalid status. Allowed: AVAILABLE, DIRTY, MAINTENANCE, RESERVED", 400);
  }

  const room = await db.room.update({
    where: { id: params.id },
    data: {
      status,
      ...(status === "DIRTY" ? { housekeeping: "DIRTY" } : {}),
      ...(status === "AVAILABLE" ? { housekeeping: "CLEAN" } : {}),
    },
    include: { roomType: true },
  });
  await audit(user, "UPDATE", "Room", room.id, `Room ${room.number} status → ${status}`);
  return ok(room);
});
