import { db } from "@/lib/db";
import { ApiError, audit, fail, ok, withAuth } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

const ROOM_STATUSES = ["AVAILABLE", "OCCUPIED", "RESERVED", "DIRTY", "MAINTENANCE"];

function roomsAllowed(role: string): boolean {
  return canAccess(role, "room-view") || canAccess(role, "stay-view");
}

export const GET = withAuth(async (req, { user }) => {
  if (!roomsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const url = new URL(req.url);
  const status = url.searchParams.get("status") ?? "";
  const search = (url.searchParams.get("search") ?? "").trim().toLowerCase();
  const roomTypeId = url.searchParams.get("roomTypeId") ?? "";

  const rooms = await db.room.findMany({ include: { roomType: true }, orderBy: { number: "asc" } });

  const items = rooms.filter(
    (r) =>
      (!status || r.status === status) &&
      (!roomTypeId || r.roomTypeId === roomTypeId) &&
      (!search || r.number.toLowerCase().includes(search))
  );

  const stats: Record<string, number> = {};
  for (const s of ROOM_STATUSES) stats[s] = 0;
  for (const r of rooms) stats[r.status] = (stats[r.status] ?? 0) + 1;

  return ok({ items, stats });
});

export const POST = withAuth(async (req, { user }) => {
  if (!roomsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const number = typeof body.number === "string" ? body.number.trim() : "";
  if (!number) throw new ApiError("Room number is required", 400);
  const roomTypeId = typeof body.roomTypeId === "string" ? body.roomTypeId : "";
  if (!roomTypeId) throw new ApiError("Room type is required", 400);

  const roomType = await db.roomType.findUnique({ where: { id: roomTypeId } });
  if (!roomType) throw new ApiError("Room type not found", 404);

  const dup = await db.room.findUnique({ where: { number } });
  if (dup) throw new ApiError("Room number already exists", 409);

  const room = await db.room.create({
    data: {
      number,
      floor: typeof body.floor === "number" ? body.floor : 1,
      roomTypeId,
      notes: typeof body.notes === "string" && body.notes.trim() ? body.notes.trim() : null,
    },
    include: { roomType: true },
  });
  await audit(user, "CREATE", "Room", room.id, `Room ${room.number}`);
  return ok(room);
});
