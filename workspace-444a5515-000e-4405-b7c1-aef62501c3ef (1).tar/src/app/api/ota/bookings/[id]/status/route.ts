import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit, parseBody } from "@/lib/api-helpers";

// PUT /api/ota/bookings/[id]/status { status: CONFIRMED | CANCELLED } (module: channel-manager)
export const PUT = withAuth(
  async (req, { user, params }) => {
    const b = await parseBody<Record<string, unknown>>(req);
    const status = typeof b.status === "string" ? b.status : "";
    if (!["CONFIRMED", "CANCELLED"].includes(status)) {
      throw new ApiError("Status must be CONFIRMED or CANCELLED", 400);
    }

    const reservation = await db.reservation.findUnique({
      where: { id: params.id },
      include: { room: true },
    });
    if (!reservation) throw new ApiError("Reservation not found", 404);
    if (!reservation.source.startsWith("OTA_")) throw new ApiError("Not an OTA booking", 400);

    if (status === "CANCELLED" && reservation.roomId && reservation.room?.status === "RESERVED") {
      await db.room.update({ where: { id: reservation.roomId }, data: { status: "AVAILABLE" } });
    }

    const updated = await db.reservation.update({
      where: { id: params.id },
      data: { status },
      include: { guest: true, roomType: true, room: true },
    });
    await audit(user, "UPDATE", "Reservation", params.id, `OTA booking ${reservation.code} → ${status}`);
    return ok(updated);
  },
  { module: "channel-manager" }
);
