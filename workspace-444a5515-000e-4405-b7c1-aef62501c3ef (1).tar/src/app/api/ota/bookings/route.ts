import { db } from "@/lib/db";
import { withAuth, ok, fail } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

// GET /api/ota/bookings?source=&status=&search= (module: channel-manager)
export const GET = withAuth(
  async (req, { user }) => {
    if (!canAccess(user.role, "channel-manager")) {
      return fail("Forbidden: module not allowed for your role", 403);
    }
    const url = new URL(req.url);
    const source = url.searchParams.get("source") ?? undefined;
    const status = url.searchParams.get("status") ?? undefined;
    const search = url.searchParams.get("search")?.trim() ?? "";

    const where: Record<string, unknown> = {
      source: { startsWith: "OTA_" },
      ...(source ? { source } : {}),
      ...(status ? { status } : {}),
    };
    if (search) {
      where.OR = [
        { code: { contains: search } },
        { guest: { OR: [{ firstName: { contains: search } }, { lastName: { contains: search } }] } },
      ];
    }

    const [items, groups] = await Promise.all([
      db.reservation.findMany({
        where,
        include: { guest: true, roomType: true, room: true },
        orderBy: { createdAt: "desc" },
      }),
      db.reservation.groupBy({ by: ["source"], where: { source: { startsWith: "OTA_" } }, _count: true }),
    ]);

    const counts: Record<string, number> = {};
    for (const g of groups) {
      if (g.source) counts[g.source] = g._count;
    }

    return ok({ items, counts });
  },
  { module: "channel-manager" }
);
