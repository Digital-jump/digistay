import { db } from "@/lib/db";
import {
  ACTIVE_RESERVATION_STATUSES,
  addDays,
  endOfDay,
  money,
  ok,
  startOfDay,
  withAuth,
} from "@/lib/api-helpers";

function dayKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

const MONTH_LABELS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export const GET = withAuth(async () => {
  const now = new Date();
  const today = startOfDay(now);
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const trendStart = addDays(today, -13);
  const paymentsSince = monthStart < trendStart ? monthStart : trendStart;
  const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1);

  const [rooms, reservations, payments, invoices, pendingOrders, outstanding, activity] = await Promise.all([
    db.room.findMany(),
    db.reservation.findMany({ include: { guest: true, roomType: true, room: true } }),
    db.payment.findMany({ where: { direction: "IN", paidAt: { gte: paymentsSince } } }),
    db.invoice.findMany({
      where: { status: { not: "VOID" }, issuedAt: { gte: sixMonthsAgo } },
      include: { items: true },
    }),
    db.restaurantOrder.count({ where: { status: "PENDING" } }),
    db.invoice.aggregate({
      where: { status: { not: "VOID" } },
      _sum: { total: true, paidAmount: true },
    }),
    db.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 12 }),
  ]);

  const countByStatus = (status: string) => rooms.filter((r) => r.status === status).length;
  const totalRooms = rooms.length;
  const occupiedRooms = countByStatus("OCCUPIED");
  const isActive = (s: string) => ACTIVE_RESERVATION_STATUSES.includes(s);
  const sameDay = (d: Date | string, day: Date) => startOfDay(d).getTime() === day.getTime();
  const coversNight = (r: { checkIn: Date | string; checkOut: Date | string }, day: Date) =>
    startOfDay(r.checkIn).getTime() <= day.getTime() && startOfDay(r.checkOut).getTime() > day.getTime();

  const arrivalsToday = reservations.filter(
    (r) => isActive(r.status) && sameDay(r.checkIn, today)
  );
  const departuresToday = reservations.filter(
    (r) => r.status === "CHECKED_IN" && sameDay(r.checkOut, today)
  );
  const inHouse = reservations.filter((r) => r.status === "CHECKED_IN");
  const inHouseGuests = inHouse.reduce((sum, r) => sum + (r.adults ?? 0) + (r.children ?? 0), 0);

  const sumPayments = (predicate: (p: (typeof payments)[number]) => boolean) =>
    money(payments.filter(predicate).reduce((s, p) => s + p.amount, 0));

  const stats = {
    totalRooms,
    availableRooms: countByStatus("AVAILABLE"),
    occupiedRooms,
    reservedRooms: countByStatus("RESERVED"),
    dirtyRooms: countByStatus("DIRTY"),
    maintenanceRooms: countByStatus("MAINTENANCE"),
    occupancyRate: totalRooms ? money((occupiedRooms / totalRooms) * 100) : 0,
    arrivalsToday: arrivalsToday.length,
    departuresToday: departuresToday.length,
    inHouseGuests,
    todayRevenue: sumPayments((p) => sameDay(p.paidAt, today)),
    monthRevenue: sumPayments((p) => p.paidAt >= monthStart),
    outstandingBalance: money((outstanding._sum.total ?? 0) - (outstanding._sum.paidAmount ?? 0)),
    pendingOrders,
  };

  const occupancyTrend: { date: string; occupancy: number; revenue: number }[] = [];
  for (let i = 13; i >= 0; i--) {
    const day = addDays(today, -i);
    const occupiedThatNight = reservations.filter((r) => isActive(r.status) && coversNight(r, day)).length;
    occupancyTrend.push({
      date: dayKey(day),
      occupancy: totalRooms ? money((occupiedThatNight / totalRooms) * 100) : 0,
      revenue: sumPayments((p) => sameDay(p.paidAt, day)),
    });
  }

  const revenueByMonth: { month: string; room: number; fb: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const mDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = monthKey(mDate);
    const monthInvoices = invoices.filter((inv) => monthKey(inv.issuedAt) === key);
    revenueByMonth.push({
      month: MONTH_LABELS[mDate.getMonth()],
      room: money(
        monthInvoices.reduce(
          (s, inv) => s + inv.items.filter((it) => it.type === "ROOM").reduce((x, it) => x + it.amount, 0),
          0
        )
      ),
      fb: money(
        monthInvoices.reduce(
          (s, inv) => s + inv.items.filter((it) => it.type === "FOOD").reduce((x, it) => x + it.amount, 0),
          0
        )
      ),
    });
  }

  const sourceMap = new Map<string, number>();
  for (const r of reservations) {
    if (r.status === "CANCELLED") continue;
    sourceMap.set(r.source, (sourceMap.get(r.source) ?? 0) + 1);
  }
  const sourceBreakdown = [...sourceMap.entries()]
    .map(([source, count]) => ({ source, count }))
    .sort((a, b) => b.count - a.count);

  const roomStatusBreakdown = ["AVAILABLE", "OCCUPIED", "RESERVED", "DIRTY", "MAINTENANCE"].map(
    (status) => ({ status, count: countByStatus(status) })
  );

  const recentActivity = activity.map((a) => ({
    id: a.id,
    action: a.action,
    userName: a.userName,
    entity: a.entity,
    details: a.details,
    createdAt: a.createdAt,
  }));

  return ok({
    stats,
    occupancyTrend,
    revenueByMonth,
    sourceBreakdown,
    roomStatusBreakdown,
    recentActivity,
    arrivalsTodayList: arrivalsToday,
    departuresTodayList: departuresToday,
  });
});
