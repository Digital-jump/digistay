import { db } from "@/lib/db";
import { endOfDay, fail, money, ok, startOfDay, withAuth } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

function guestsAllowed(role: string): boolean {
  return canAccess(role, "guests") || canAccess(role, "checkins");
}

function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export const GET = withAuth(async (_req, { user }) => {
  if (!guestsAllowed(user.role)) {
    return fail("Forbidden: module not allowed for your role", 403);
  }

  const guests = await db.guest.findMany({ include: { reservations: true } });
  const now = new Date();
  const todayEnd = endOfDay(now);
  const allReservations = guests.flatMap((g) => g.reservations);

  const totalGuests = guests.length;

  const repeatGuests = guests.filter(
    (g) => g.reservations.filter((r) => r.status === "CHECKED_OUT").length >= 2
  ).length;

  const checkedOutStays = allReservations.filter((r) => r.status === "CHECKED_OUT");
  const avgStayNights = checkedOutStays.length
    ? Math.round(
        (checkedOutStays.reduce(
          (s, r) => s + Math.round((startOfDay(r.checkOut).getTime() - startOfDay(r.checkIn).getTime()) / 86400000),
          0
        ) /
          checkedOutStays.length) *
          10
      ) / 10
    : 0;

  const totalArrivals = allReservations.filter(
    (r) => r.status !== "CANCELLED" && startOfDay(r.checkIn) <= todayEnd
  );
  const noShows = allReservations.filter((r) => r.status === "NO_SHOW");
  const noShowRate = totalArrivals.length ? money((noShows.length / totalArrivals.length) * 100) : 0;

  const newByMonth: { month: string; count: number }[] = [];
  for (let i = 11; i >= 0; i--) {
    const mDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = monthKey(mDate);
    const nextMonth = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
    newByMonth.push({
      month: key,
      count: guests.filter((g) => g.createdAt >= mDate && g.createdAt < nextMonth).length,
    });
  }

  const hasIdNumber = (v: string | null | undefined) => !!v && v.trim().length > 0;
  const idDocsRecorded = guests.filter((g) => hasIdNumber(g.idNumber)).length;
  const missingId = guests.filter(
    (g) => !hasIdNumber(g.idNumber) && g.reservations.some((r) => ["PENDING", "CONFIRMED", "CHECKED_IN"].includes(r.status))
  ).length;
  const missingContact = guests.filter((g) => !hasIdNumber(g.phone) && !hasIdNumber(g.email)).length;

  const phoneGroups = new Map<string, number>();
  const idGroups = new Map<string, number>();
  for (const g of guests) {
    if (hasIdNumber(g.phone)) phoneGroups.set(g.phone!, (phoneGroups.get(g.phone!) ?? 0) + 1);
    if (hasIdNumber(g.idNumber)) idGroups.set(g.idNumber!, (idGroups.get(g.idNumber!) ?? 0) + 1);
  }
  const duplicates = guests.filter(
    (g) =>
      (hasIdNumber(g.phone) && (phoneGroups.get(g.phone!) ?? 0) > 1) ||
      (hasIdNumber(g.idNumber) && (idGroups.get(g.idNumber!) ?? 0) > 1)
  ).length;

  const natMap = new Map<string, number>();
  for (const g of guests) {
    const key = g.nationality?.trim() || "Unknown";
    natMap.set(key, (natMap.get(key) ?? 0) + 1);
  }
  const nationalityBreakdown = [...natMap.entries()]
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);

  const srcMap = new Map<string, number>();
  for (const r of allReservations) {
    if (r.status !== "CHECKED_IN" && r.status !== "CHECKED_OUT") continue;
    srcMap.set(r.source, (srcMap.get(r.source) ?? 0) + 1);
  }
  const sourceBreakdown = [...srcMap.entries()]
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);

  return ok({
    totalGuests,
    repeatGuests,
    avgStayNights,
    noShowRate,
    newByMonth,
    idDocsRecorded,
    missingId,
    missingContact,
    duplicates,
    nationalityBreakdown,
    sourceBreakdown,
  });
});
