import { db } from "@/lib/db";
import { ApiError, audit, fail, ok, withAuth } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function guestsAllowed(role: string): boolean {
  return canAccess(role, "guests") || canAccess(role, "checkins");
}

type GuestBody = {
  firstName?: unknown;
  lastName?: unknown;
  email?: unknown;
  phone?: unknown;
  idType?: unknown;
  idNumber?: unknown;
  nationality?: unknown;
  address?: unknown;
  city?: unknown;
  company?: unknown;
  vip?: unknown;
  notes?: unknown;
};

function validateGuest(body: GuestBody) {
  const firstName = typeof body.firstName === "string" ? body.firstName.trim() : "";
  const lastName = typeof body.lastName === "string" ? body.lastName.trim() : "";
  if (!firstName) throw new ApiError("First name is required", 400);
  if (!lastName) throw new ApiError("Last name is required", 400);
  const email = typeof body.email === "string" ? body.email.trim() : "";
  if (email && !EMAIL_RE.test(email)) throw new ApiError("Invalid email address", 400);
  const phone = typeof body.phone === "string" ? body.phone.trim() : "";
  if (phone && phone.length < 7) throw new ApiError("Phone number must be at least 7 characters", 400);
}

function guestData(body: GuestBody) {
  const str = (v: unknown) => (typeof v === "string" && v.trim() ? v.trim() : null);
  return {
    firstName: String(body.firstName).trim(),
    lastName: String(body.lastName).trim(),
    email: str(body.email),
    phone: str(body.phone),
    idType: str(body.idType),
    idNumber: str(body.idNumber),
    nationality: str(body.nationality),
    address: str(body.address),
    city: str(body.city),
    company: str(body.company),
    vip: body.vip === true,
    notes: str(body.notes),
  };
}

export const GET = withAuth(async (_req, { user, params }) => {
  if (!guestsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const guest = await db.guest.findUnique({
    where: { id: params.id },
    include: {
      reservations: { include: { roomType: true, room: true }, orderBy: { checkIn: "desc" } },
      orders: { include: { items: { include: { menuItem: true } } }, orderBy: { createdAt: "desc" } },
      reviews: { orderBy: { createdAt: "desc" } },
    },
  });
  if (!guest) throw new ApiError("Guest not found", 404);

  const invoices = await db.invoice.findMany({ where: { guestId: guest.id, status: { not: "VOID" } } });
  const spend = invoices.reduce((s, i) => s + i.total, 0);
  const stats = {
    stays: guest.reservations.filter((r) => r.status === "CHECKED_OUT").length,
    spend: Math.round(spend * 100) / 100,
  };

  return ok({ guest, reservations: guest.reservations, orders: guest.orders, reviews: guest.reviews, stats });
});

export const PUT = withAuth(async (req, { user, params }) => {
  if (!guestsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const existing = await db.guest.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Guest not found", 404);

  const body = (await req.json().catch(() => ({}))) as GuestBody;
  validateGuest(body);

  const phone = typeof body.phone === "string" ? body.phone.trim() : "";
  const idNumber = typeof body.idNumber === "string" ? body.idNumber.trim() : "";
  if (phone && idNumber) {
    const dup = await db.guest.findFirst({ where: { phone, idNumber, id: { not: params.id } } });
    if (dup) throw new ApiError("Guest with same phone and ID already exists", 409);
  }

  const guest = await db.guest.update({ where: { id: params.id }, data: guestData(body) });
  await audit(user, "UPDATE", "Guest", guest.id, `${guest.firstName} ${guest.lastName}`);
  return ok(guest);
});

export const DELETE = withAuth(async (_req, { user, params }) => {
  if (!guestsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const existing = await db.guest.findUnique({
    where: { id: params.id },
    include: { reservations: { select: { status: true } } },
  });
  if (!existing) throw new ApiError("Guest not found", 404);

  const hasActive = existing.reservations.some((r) => ["PENDING", "CONFIRMED", "CHECKED_IN"].includes(r.status));
  if (hasActive) throw new ApiError("Guest has active reservations", 409);

  const guestId = params.id;
  // Cascade cleanup in a transaction: remove stay history + financial links for this guest
  await db.$transaction(async (tx) => {
    const reservationIds = (await tx.reservation.findMany({ where: { guestId: guestId }, select: { id: true } })).map((r) => r.id);
    const invoiceIds = (await tx.invoice.findMany({ where: { guestId: guestId }, select: { id: true } })).map((i) => i.id);
    const folioIds = (await tx.folio.findMany({ where: { OR: [{ guestId: guestId }, { reservationId: { in: reservationIds } }] }, select: { id: true } })).map((f) => f.id);
    const orderIds = (await tx.restaurantOrder.findMany({ where: { guestId: guestId }, select: { id: true } })).map((o) => o.id);

    await tx.review.deleteMany({ where: { guestId: guestId } });
    await tx.orderItem.deleteMany({ where: { orderId: { in: orderIds } } });
    await tx.restaurantOrder.deleteMany({ where: { id: { in: orderIds } } });
    await tx.payment.deleteMany({ where: { invoiceId: { in: invoiceIds } } });
    await tx.invoiceItem.deleteMany({ where: { invoiceId: { in: invoiceIds } } });
    await tx.invoice.deleteMany({ where: { id: { in: invoiceIds } } });
    await tx.folioEntry.deleteMany({ where: { folioId: { in: folioIds } } });
    await tx.folio.deleteMany({ where: { id: { in: folioIds } } });
    await tx.reservation.deleteMany({ where: { id: { in: reservationIds } } });
    await tx.guest.delete({ where: { id: guestId } });
  });
  await audit(user, "DELETE", "Guest", params.id, `${existing.firstName} ${existing.lastName}`);
  return ok({ ok: true });
});
