import { db } from "@/lib/db";
import { ApiError, audit, fail, ok, withAuth } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function guestsAllowed(role: string): boolean {
  return canAccess(role, "guests") || canAccess(role, "checkins");
}

type GuestBody = {
  firstName?: unknown;
  lastName?: unknown;
  email?: unknown;
  phone?: unknown;
  idType?: unknown;
  idNumber?: unknown;
  nationality?: unknown;
  address?: unknown;
  city?: unknown;
  company?: unknown;
  vip?: unknown;
  notes?: unknown;
};

function validateGuest(body: GuestBody) {
  const firstName = typeof body.firstName === "string" ? body.firstName.trim() : "";
  const lastName = typeof body.lastName === "string" ? body.lastName.trim() : "";
  if (!firstName) throw new ApiError("First name is required", 400);
  if (!lastName) throw new ApiError("Last name is required", 400);
  const email = typeof body.email === "string" ? body.email.trim() : "";
  if (email && !EMAIL_RE.test(email)) throw new ApiError("Invalid email address", 400);
  const phone = typeof body.phone === "string" ? body.phone.trim() : "";
  if (phone && phone.length < 7) throw new ApiError("Phone number must be at least 7 characters", 400);
}

function guestData(body: GuestBody) {
  const str = (v: unknown) => (typeof v === "string" && v.trim() ? v.trim() : null);
  return {
    firstName: String(body.firstName).trim(),
    lastName: String(body.lastName).trim(),
    email: str(body.email),
    phone: str(body.phone),
    idType: str(body.idType),
    idNumber: str(body.idNumber),
    nationality: str(body.nationality),
    address: str(body.address),
    city: str(body.city),
    company: str(body.company),
    vip: body.vip === true,
    notes: str(body.notes),
  };
}

export const GET = withAuth(async (req, { user }) => {
  if (!guestsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const url = new URL(req.url);
  const search = (url.searchParams.get("search") ?? "").trim().toLowerCase();
  const page = Math.max(1, parseInt(url.searchParams.get("page") ?? "1", 10) || 1);
  const pageSize = Math.min(200, Math.max(1, parseInt(url.searchParams.get("pageSize") ?? "20", 10) || 20));

  const guests = await db.guest.findMany({
    include: { reservations: { select: { checkOut: true } } },
    orderBy: { createdAt: "desc" },
  });

  const filtered = search
    ? guests.filter((g) =>
        [g.firstName, g.lastName, g.email, g.phone, g.idNumber].some(
          (v) => v && String(v).toLowerCase().includes(search)
        )
      )
    : guests;

  const total = filtered.length;
  const items = filtered.slice((page - 1) * pageSize, page * pageSize).map((g) => {
    const { reservations, ...rest } = g;
    const lastStay = reservations.reduce<Date | null>(
      (acc, r) => (!acc || new Date(r.checkOut) > acc ? new Date(r.checkOut) : acc),
      null
    );
    return { ...rest, reservationCount: reservations.length, lastStay };
  });

  return ok({ items, total, page, pageSize });
});

export const POST = withAuth(async (req, { user }) => {
  if (!guestsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const body = (await req.json().catch(() => ({}))) as GuestBody;
  validateGuest(body);

  const phone = typeof body.phone === "string" ? body.phone.trim() : "";
  const idNumber = typeof body.idNumber === "string" ? body.idNumber.trim() : "";
  if (phone && idNumber) {
    const dup = await db.guest.findFirst({ where: { phone, idNumber } });
    if (dup) throw new ApiError("Guest with same phone and ID already exists", 409);
  }

  const guest = await db.guest.create({ data: guestData(body) });
  await audit(user, "CREATE", "Guest", guest.id, `${guest.firstName} ${guest.lastName}`);
  return ok(guest);
});
