import { db } from "@/lib/db";
import { ApiError, audit, fail, ok, withAuth } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

function roomsAllowed(role: string): boolean {
  return canAccess(role, "room-view") || canAccess(role, "stay-view");
}

function parseAmenities(raw: string): string[] {
  try {
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.map(String) : [];
  } catch {
    return [];
  }
}

export const PUT = withAuth(async (req, { user, params }) => {
  if (!roomsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const existing = await db.roomType.findUnique({ where: { id: params.id } });
  if (!existing) throw new ApiError("Room type not found", 404);

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  if (body.name !== undefined && (typeof body.name !== "string" || !body.name.trim())) {
    throw new ApiError("Room type name is required", 400);
  }
  if (body.baseRate !== undefined && !(typeof body.baseRate === "number" && body.baseRate > 0)) {
    throw new ApiError("Base rate must be greater than 0", 400);
  }
  if (body.capacity !== undefined && !(typeof body.capacity === "number" && body.capacity >= 1)) {
    throw new ApiError("Capacity must be at least 1", 400);
  }

  const roomType = await db.roomType.update({
    where: { id: params.id },
    data: {
      ...(body.name !== undefined ? { name: String(body.name).trim() } : {}),
      ...(body.description !== undefined
        ? { description: typeof body.description === "string" && body.description.trim() ? body.description.trim() : null }
        : {}),
      ...(body.baseRate !== undefined && typeof body.baseRate === "number" ? { baseRate: body.baseRate } : {}),
      ...(body.capacity !== undefined && typeof body.capacity === "number" ? { capacity: body.capacity } : {}),
      ...(body.extraAdultCharge !== undefined && typeof body.extraAdultCharge === "number"
        ? { extraAdultCharge: body.extraAdultCharge }
        : {}),
      ...(body.extraChildCharge !== undefined && typeof body.extraChildCharge === "number"
        ? { extraChildCharge: body.extraChildCharge }
        : {}),
      ...(body.amenities !== undefined && Array.isArray(body.amenities)
        ? { amenities: JSON.stringify(body.amenities.map(String)) }
        : {}),
    },
  });
  await audit(user, "UPDATE", "RoomType", roomType.id, roomType.name);
  return ok({ ...roomType, amenities: parseAmenities(roomType.amenities) });
});

export const DELETE = withAuth(async (_req, { user, params }) => {
  if (!roomsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const existing = await db.roomType.findUnique({
    where: { id: params.id },
    include: { _count: { select: { rooms: true } } },
  });
  if (!existing) throw new ApiError("Room type not found", 404);
  if (existing._count.rooms > 0) throw new ApiError("Room type has rooms", 409);

  await db.roomType.delete({ where: { id: params.id } });
  await audit(user, "DELETE", "RoomType", params.id, existing.name);
  return ok({ ok: true });
});
