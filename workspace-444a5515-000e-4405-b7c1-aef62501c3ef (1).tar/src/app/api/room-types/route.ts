import { db } from "@/lib/db";
import { ApiError, audit, fail, ok, withAuth } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

function roomsAllowed(role: string): boolean {
  return canAccess(role, "room-view") || canAccess(role, "stay-view");
}

function parseAmenities(raw: string): string[] {
  try {
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.map(String) : [];
  } catch {
    return [];
  }
}

export const GET = withAuth(async (_req, { user }) => {
  if (!roomsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const roomTypes = await db.roomType.findMany({
    include: {
      _count: {
        select: {
          rooms: true,
          reservations: { where: { status: { in: ["PENDING", "CONFIRMED", "CHECKED_IN"] } } },
        },
      },
    },
    orderBy: { baseRate: "asc" },
  });
  return ok(
    roomTypes.map((rt) => ({
      ...rt,
      amenities: parseAmenities(rt.amenities),
      roomCount: rt._count.rooms,
      activeReservations: rt._count.reservations,
      _count: undefined,
    }))
  );
});

export const POST = withAuth(async (req, { user }) => {
  if (!roomsAllowed(user.role)) return fail("Forbidden: module not allowed for your role", 403);
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const name = typeof body.name === "string" ? body.name.trim() : "";
  if (!name) throw new ApiError("Room type name is required", 400);
  const baseRate = typeof body.baseRate === "number" ? body.baseRate : NaN;
  if (!(baseRate > 0)) throw new ApiError("Base rate must be greater than 0", 400);
  const capacity = typeof body.capacity === "number" ? body.capacity : NaN;
  if (!(capacity >= 1)) throw new ApiError("Capacity must be at least 1", 400);

  const roomType = await db.roomType.create({
    data: {
      name,
      description: typeof body.description === "string" && body.description.trim() ? body.description.trim() : null,
      baseRate,
      capacity,
      extraAdultCharge: typeof body.extraAdultCharge === "number" ? body.extraAdultCharge : 0,
      extraChildCharge: typeof body.extraChildCharge === "number" ? body.extraChildCharge : 0,
      amenities: JSON.stringify(Array.isArray(body.amenities) ? body.amenities.map(String) : []),
    },
  });
  await audit(user, "CREATE", "RoomType", roomType.id, roomType.name);
  return ok({ ...roomType, amenities: parseAmenities(roomType.amenities) });
});
