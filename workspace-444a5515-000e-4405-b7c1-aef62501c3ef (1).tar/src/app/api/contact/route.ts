import { db } from "@/lib/db";
import { ApiError, fail, ok, withAuth } from "@/lib/api-helpers";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function handleError(e: unknown) {
  if (e instanceof ApiError) return fail(e.message, e.status);
  console.error("[contact]", e);
  return fail("Internal server error", 500);
}

// POST /api/contact — PUBLIC: save a contact-us message from the website
export async function POST(req: Request) {
  try {
    const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const name = typeof b.name === "string" ? b.name.trim() : "";
    const email = typeof b.email === "string" ? b.email.trim() : "";
    const phone = typeof b.phone === "string" ? b.phone.trim() : "";
    const subject = typeof b.subject === "string" ? b.subject.trim() : "";
    const message = typeof b.message === "string" ? b.message.trim() : "";

    if (name.length < 2) throw new ApiError("Please enter your full name", 400);
    if (!EMAIL_RE.test(email)) throw new ApiError("Please enter a valid email address", 400);
    if (phone && !/^[+\d][\d\s\-()]{5,19}$/.test(phone)) {
      throw new ApiError("Please enter a valid phone number", 400);
    }
    if (message.length < 10) throw new ApiError("Message must be at least 10 characters", 400);
    if (message.length > 2000) throw new ApiError("Message is too long (max 2000 characters)", 400);

    const saved = await db.contactMessage.create({
      data: {
        name,
        email,
        phone: phone || null,
        subject: subject || null,
        message,
      },
    });

    return ok({ ok: true, id: saved.id }, 201);
  } catch (e: unknown) {
    return handleError(e);
  }
}

// GET /api/contact — ADMIN: list contact messages (newest first)
export const GET = withAuth(async () => {
  const messages = await db.contactMessage.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  return ok({ messages });
}, { roles: ["ADMIN"] });
