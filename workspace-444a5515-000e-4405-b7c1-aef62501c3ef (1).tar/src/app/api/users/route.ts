import { db } from "@/lib/db";
import { ApiError, audit, ok, withAuth } from "@/lib/api-helpers";
import { hashPassword } from "@/lib/auth";

const ROLES = ["ADMIN", "RECEPTIONIST", "ACCOUNTANT", "STAFF"];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function publicUser(u: { id: string; name: string; email: string; role: string; phone: string | null; active: boolean; createdAt: Date; updatedAt: Date; _count?: { sessions: number } }) {
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    phone: u.phone,
    active: u.active,
    createdAt: u.createdAt,
    updatedAt: u.updatedAt,
    ...(u._count ? { sessionCount: u._count.sessions } : {}),
  };
}

export const GET = withAuth(
  async () => {
    const users = await db.user.findMany({
      include: { _count: { select: { sessions: true } } },
      orderBy: { createdAt: "asc" },
    });
    return ok(users.map(publicUser));
  },
  { roles: ["ADMIN"] }
);

export const POST = withAuth(
  async (req, { user }) => {
    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const password = typeof body.password === "string" ? body.password : "";
    const role = typeof body.role === "string" ? body.role : "";
    const phone = typeof body.phone === "string" && body.phone.trim() ? body.phone.trim() : null;

    if (!name) throw new ApiError("Name is required", 400);
    if (!EMAIL_RE.test(email)) throw new ApiError("A valid email is required", 400);
    if (password.length < 6) throw new ApiError("Password must be at least 6 characters", 400);
    if (!ROLES.includes(role)) throw new ApiError("Invalid role", 400);

    const dup = await db.user.findUnique({ where: { email } });
    if (dup) throw new ApiError("Email already registered", 409);

    const created = await db.user.create({
      data: { name, email, passwordHash: hashPassword(password), role, phone },
      include: { _count: { select: { sessions: true } } },
    });
    await audit(user, "CREATE", "User", created.id, `${created.name} (${created.role})`);
    return ok(publicUser(created));
  },
  { roles: ["ADMIN"] }
);
