import { db } from "@/lib/db";
import { ApiError, audit, ok, withAuth } from "@/lib/api-helpers";
import { hashPassword } from "@/lib/auth";

const ROLES = ["ADMIN", "RECEPTIONIST", "ACCOUNTANT", "STAFF"];

export const PUT = withAuth(
  async (req, { user, params }) => {
    const target = await db.user.findUnique({ where: { id: params.id } });
    if (!target) throw new ApiError("User not found", 404);

    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

    if (body.role !== undefined && !ROLES.includes(String(body.role))) {
      throw new ApiError("Invalid role", 400);
    }
    if (body.password !== undefined && (typeof body.password !== "string" || body.password.length < 6)) {
      throw new ApiError("Password must be at least 6 characters", 400);
    }

    // Protect the last active ADMIN from demotion / deactivation
    const willBeAffected =
      target.role === "ADMIN" &&
      target.active &&
      ((body.role !== undefined && body.role !== "ADMIN") || body.active === false);
    if (willBeAffected) {
      const activeAdmins = await db.user.count({ where: { role: "ADMIN", active: true } });
      if (activeAdmins <= 1) {
        throw new ApiError("Cannot demote or deactivate the last active administrator", 400);
      }
    }

    const updated = await db.user.update({
      where: { id: params.id },
      data: {
        ...(body.name !== undefined && typeof body.name === "string" && body.name.trim() ? { name: body.name.trim() } : {}),
        ...(body.role !== undefined ? { role: String(body.role) } : {}),
        ...(body.phone !== undefined
          ? { phone: typeof body.phone === "string" && body.phone.trim() ? body.phone.trim() : null }
          : {}),
        ...(body.active !== undefined ? { active: body.active === true } : {}),
        ...(body.password !== undefined && typeof body.password === "string" ? { passwordHash: hashPassword(body.password) } : {}),
      },
    });

    await audit(user, "UPDATE", "User", updated.id, `${updated.name} updated`);
    return ok({ id: updated.id, name: updated.name, email: updated.email, role: updated.role, phone: updated.phone, active: updated.active, createdAt: updated.createdAt, updatedAt: updated.updatedAt });
  },
  { roles: ["ADMIN"] }
);

export const DELETE = withAuth(
  async (_req, { user, params }) => {
    const target = await db.user.findUnique({ where: { id: params.id } });
    if (!target) throw new ApiError("User not found", 404);

    if (target.role === "ADMIN" && target.active) {
      const activeAdmins = await db.user.count({ where: { role: "ADMIN", active: true } });
      if (activeAdmins <= 1) {
        throw new ApiError("Cannot delete the last active administrator", 400);
      }
    }

    await db.session.deleteMany({ where: { userId: params.id } });
    await db.user.delete({ where: { id: params.id } });
    await audit(user, "DELETE", "User", params.id, `${target.name} deleted`);
    return ok({ ok: true });
  },
  { roles: ["ADMIN"] }
);
