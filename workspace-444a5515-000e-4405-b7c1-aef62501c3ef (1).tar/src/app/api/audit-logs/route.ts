import { db } from "@/lib/db";
import { ok, withAuth } from "@/lib/api-helpers";

export const GET = withAuth(
  async (req) => {
    const url = new URL(req.url);
    const search = (url.searchParams.get("search") ?? "").trim().toLowerCase();
    const limitParam = parseInt(url.searchParams.get("limit") ?? "100", 10);
    const limit = Math.min(500, Math.max(1, Number.isFinite(limitParam) ? limitParam : 100));

    const logs = await db.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 1000 });
    const filtered = search
      ? logs.filter((l) =>
          [l.action, l.entity, l.userName, l.details].some((v) => v && String(v).toLowerCase().includes(search))
        )
      : logs;

    return ok(filtered.slice(0, limit));
  },
  { roles: ["ADMIN"] }
);
