import { db } from "@/lib/db";
import { withAuth, ok, fail, startOfDay, endOfDay } from "@/lib/api-helpers";
import { canAccess } from "@/lib/permissions";

// GET /api/payments?from=&to=&method=&category= (module: invoices | ledger)
export const GET = withAuth(
  async (req, { user }) => {
    const allowed = canAccess(user.role, "invoices") || canAccess(user.role, "ledger");
    if (!allowed) return fail("Forbidden: module not allowed for your role", 403);

    const url = new URL(req.url);
    const fromStr = url.searchParams.get("from");
    const toStr = url.searchParams.get("to");
    const from = fromStr && /^\d{4}-\d{2}-\d{2}$/.test(fromStr) ? startOfDay(new Date(`${fromStr}T00:00:00`)) : undefined;
    const to = toStr && /^\d{4}-\d{2}-\d{2}$/.test(toStr) ? endOfDay(new Date(`${toStr}T00:00:00`)) : undefined;
    const method = url.searchParams.get("method") ?? undefined;
    const category = url.searchParams.get("category") ?? undefined;

    const payments = await db.payment.findMany({
      where: {
        ...(from || to ? { paidAt: { ...(from ? { gte: from } : {}), ...(to ? { lte: to } : {}) } } : {}),
        ...(method ? { method } : {}),
        ...(category ? { category } : {}),
      },
      include: { invoice: { select: { number: true } } },
      orderBy: { paidAt: "desc" },
      take: 500,
    });
    return ok(payments);
  },
  { module: undefined }
);
