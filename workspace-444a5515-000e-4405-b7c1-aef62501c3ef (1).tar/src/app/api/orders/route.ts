import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit, nextCode, money, parseBody } from "@/lib/api-helpers";
import { getSettings } from "@/lib/billing";

const ORDER_STATUSES = ["PENDING", "ACCEPTED", "DELIVERED", "PARTIALLY_DELIVERED", "CANCELLED"];

// GET /api/orders?status=&type=&search=&scope=all|checkins|restaurant|bar (module: food-orders)
export const GET = withAuth(
  async (req) => {
    const url = new URL(req.url);
    const status = url.searchParams.get("status") ?? undefined;
    const type = url.searchParams.get("type") ?? undefined;
    const scope = url.searchParams.get("scope") ?? undefined;
    const search = url.searchParams.get("search")?.trim() ?? "";

    const scopeType =
      scope === "checkins" ? "ROOM_SERVICE" : scope === "restaurant" ? "RESTAURANT" : scope === "bar" ? "BAR" : undefined;
    const effectiveType = scopeType ?? type;

    const where: Record<string, unknown> = {
      ...(status ? { status } : {}),
      ...(effectiveType ? { type: effectiveType } : {}),
    };
    if (search) {
      where.OR = [
        { orderNumber: { contains: search } },
        { tableNumber: { contains: search } },
        { guest: { OR: [{ firstName: { contains: search } }, { lastName: { contains: search } }] } },
        { reservation: { room: { number: { contains: search } } } },
      ];
    }

    const [items, groups] = await Promise.all([
      db.restaurantOrder.findMany({
        where,
        include: {
          items: { include: { menuItem: true } },
          guest: true,
          reservation: { include: { room: true } },
        },
        orderBy: { createdAt: "desc" },
      }),
      db.restaurantOrder.groupBy({ by: ["status"], _count: true }),
    ]);

    const counts: Record<string, number> = {
      PENDING: 0,
      ACCEPTED: 0,
      DELIVERED: 0,
      PARTIALLY_DELIVERED: 0,
      CANCELLED: 0,
    };
    for (const g of groups) {
      if (g.status && g.status in counts) counts[g.status] = g._count;
    }
    return ok({ items, counts });
  },
  { module: "food-orders" }
);

// POST /api/orders — create F&B order
export const POST = withAuth(
  async (req, { user }) => {
    const b = await parseBody<Record<string, unknown>>(req);
    const type = typeof b.type === "string" && b.type ? b.type : "RESTAURANT";
    if (!["ROOM_SERVICE", "RESTAURANT", "BAR"].includes(type)) throw new ApiError("Invalid order type", 400);

    const rawItems = Array.isArray(b.items) ? b.items : [];
    if (rawItems.length === 0) throw new ApiError("Order must contain at least one item", 400);

    const parsed = rawItems.map((it) => {
      const o = it as Record<string, unknown>;
      return { menuItemId: String(o.menuItemId ?? ""), quantity: Math.max(1, Math.floor(Number(o.quantity ?? 1) || 1)) };
    });
    const menuIds = [...new Set(parsed.map((p) => p.menuItemId))];
    const menuItems = await db.menuItem.findMany({ where: { id: { in: menuIds } } });
    const menuMap = new Map(menuItems.map((m) => [m.id, m]));
    for (const p of parsed) {
      const m = menuMap.get(p.menuItemId);
      if (!m) throw new ApiError("Invalid menu item in order", 400);
      if (!m.available) throw new ApiError(`Menu item ${m.name} is not available`, 400);
    }

    const reservationId = typeof b.reservationId === "string" && b.reservationId ? b.reservationId : null;
    let reservation: { id: string; guestId: string; roomId: string | null } | null = null;
    let folioId: string | null = null;
    if (reservationId) {
      const r = await db.reservation.findUnique({ where: { id: reservationId } });
      if (!r) throw new ApiError("Reservation not found", 404);
      reservation = { id: r.id, guestId: r.guestId, roomId: r.roomId };
      if (type === "ROOM_SERVICE") {
        const folio = await db.folio.findFirst({ where: { reservationId } });
        folioId = folio?.id ?? null;
      }
    }

    const subtotal = money(parsed.reduce((sum, p) => sum + (menuMap.get(p.menuItemId)?.price ?? 0) * p.quantity, 0));
    const settings = await getSettings();
    const tax = money((subtotal * (settings.fbTaxRate ?? 5)) / 100);
    const totalAmount = money(subtotal + tax);

    const guestId =
      typeof b.guestId === "string" && b.guestId ? b.guestId : reservation ? reservation.guestId : null;
    const roomId = typeof b.roomId === "string" && b.roomId ? b.roomId : reservation ? reservation.roomId : null;
    const tableNumber = typeof b.tableNumber === "string" ? b.tableNumber : null;
    const notes = typeof b.notes === "string" ? b.notes : null;

    const orderNumber = await nextCode("ORD", db.restaurantOrder, "orderNumber");
    const order = await db.restaurantOrder.create({
      data: {
        orderNumber,
        type,
        guestId,
        reservationId,
        roomId,
        tableNumber,
        notes,
        status: "PENDING",
        subtotal,
        tax,
        totalAmount,
        chargedToRoom: !!folioId,
        items: {
          create: parsed.map((p) => ({
            menuItemId: p.menuItemId,
            quantity: p.quantity,
            unitPrice: menuMap.get(p.menuItemId)?.price ?? 0,
          })),
        },
      },
    });

    if (folioId) {
      await db.folioEntry.create({
        data: {
          folioId,
          type: "CHARGE",
          description: `In-room dining ${orderNumber}`,
          amount: totalAmount,
          category: "FOOD",
          createdBy: user.name,
        },
      });
    }

    await audit(user, "CREATE", "RestaurantOrder", order.id, `Order ${orderNumber} (${type})`);
    const full = await db.restaurantOrder.findUnique({
      where: { id: order.id },
      include: { items: { include: { menuItem: true } }, guest: true, reservation: { include: { room: true } } },
    });
    return ok(full);
  },
  { module: "food-orders" }
);
