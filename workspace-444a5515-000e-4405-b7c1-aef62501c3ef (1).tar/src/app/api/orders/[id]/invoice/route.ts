import { withAuth, ok, audit } from "@/lib/api-helpers";
import { ensureInvoiceForOrder } from "@/lib/billing";

// POST /api/orders/[id]/invoice (module: invoices) — create invoice for an order
export const POST = withAuth(
  async (req, { user, params }) => {
    const invoice = await ensureInvoiceForOrder(params.id);
    await audit(user, "CREATE", "Invoice", invoice?.id, `Invoice generated for order ${params.id}`);
    return ok({ invoice });
  },
  { module: "invoices" }
);
