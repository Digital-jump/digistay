import { db } from "@/lib/db";
import { withAuth, ok, ApiError, audit, money, parseBody } from "@/lib/api-helpers";
import { getSettings } from "@/lib/billing";

const ALLOWED_TRANSITIONS: Record<string, string[]> = {
  PENDING: ["ACCEPTED", "DELIVERED", "PARTIALLY_DELIVERED", "CANCELLED"],
  ACCEPTED: ["DELIVERED", "PARTIALLY_DELIVERED", "CANCELLED"],
  DELIVERED: [],
  PARTIALLY_DELIVERED: ["DELIVERED"],
  CANCELLED: [],
};

function orderInclude() {
  return {
    items: { include: { menuItem: true } },
    guest: true,
    reservation: { include: { room: true } },
  } as const;
}

// GET /api/orders/[id]
export const GET = withAuth(
  async (req, { params }) => {
    const order = await db.restaurantOrder.findUnique({ where: { id: params.id }, include: orderInclude() });
    if (!order) throw new ApiError("Order not found", 404);
    return ok(order);
  },
  { module: "food-orders" }
);

// PUT /api/orders/[id] — status transitions / items replacement / notes
export const PUT = withAuth(
  async (req, { user, params }) => {
    const b = await parseBody<Record<string, unknown>>(req);
    const order = await db.restaurantOrder.findUnique({ where: { id: params.id }, include: orderInclude() });
    if (!order) throw new ApiError("Order not found", 404);

    const data: Record<string, unknown> = {};
    if (typeof b.notes === "string") data.notes = b.notes;

    // ── Items replacement ───────────────────────────────────
    if (b.items !== undefined) {
      const rawItems = Array.isArray(b.items) ? b.items : [];
      if (rawItems.length === 0) throw new ApiError("Order must contain at least one item", 400);
      const parsed = rawItems.map((it) => {
        const o = it as Record<string, unknown>;
        return {
          menuItemId: String(o.menuItemId ?? ""),
          quantity: Math.max(1, Math.floor(Number(o.quantity ?? 1) || 1)),
        };
      });
      const menuItems = await db.menuItem.findMany({
        where: { id: { in: [...new Set(parsed.map((p) => p.menuItemId))] } },
      });
      const menuMap = new Map(menuItems.map((m) => [m.id, m]));
      for (const p of parsed) {
        const m = menuMap.get(p.menuItemId);
        if (!m) throw new ApiError("Invalid menu item in order", 400);
        if (!m.available) throw new ApiError(`Menu item ${m.name} is not available`, 400);
      }

      const subtotal = money(parsed.reduce((sum, p) => sum + (menuMap.get(p.menuItemId)?.price ?? 0) * p.quantity, 0));
      const settings = await getSettings();
      const tax = money((subtotal * (settings.fbTaxRate ?? 5)) / 100);
      const totalAmount = money(subtotal + tax);
      const delta = money(totalAmount - order.totalAmount);

      await db.orderItem.deleteMany({ where: { orderId: order.id } });
      await db.orderItem.createMany({
        data: parsed.map((p) => ({
          orderId: order.id,
          menuItemId: p.menuItemId,
          quantity: p.quantity,
          unitPrice: menuMap.get(p.menuItemId)?.price ?? 0,
        })),
      });
      data.subtotal = subtotal;
      data.tax = tax;
      data.totalAmount = totalAmount;

      // Folio adjustment when the order was charged to a room folio
      if (order.chargedToRoom && Math.abs(delta) > 0.005 && order.reservationId) {
        const folio = await db.folio.findFirst({ where: { reservationId: order.reservationId } });
        if (folio) {
          await db.folioEntry.create({
            data: {
              folioId: folio.id,
              type: "ADJUSTMENT",
              description: `Order ${order.orderNumber} modification`,
              amount: delta,
              category: "FOOD",
              createdBy: user.name,
            },
          });
        }
      }
    }

    // ── Status transition ───────────────────────────────────
    if (typeof b.status === "string" && b.status) {
      const next = b.status;
      const allowed = ALLOWED_TRANSITIONS[order.status] ?? [];
      if (!allowed.includes(next)) {
        throw new ApiError(`Invalid status transition from ${order.status} to ${next}`, 400);
      }
      if (next === "CANCELLED") {
        const invoiced = await db.invoice.findFirst({
          where: { orderId: order.orderNumber, status: { not: "VOID" } },
        });
        if (order.chargedToRoom && invoiced) {
          throw new ApiError("Order already charged to room folio", 400);
        }
        if (order.chargedToRoom && order.reservationId) {
          const folio = await db.folio.findFirst({ where: { reservationId: order.reservationId } });
          if (folio) {
            await db.folioEntry.create({
              data: {
                folioId: folio.id,
                type: "ADJUSTMENT",
                description: `Cancellation of ${order.orderNumber}`,
                amount: -order.totalAmount,
                category: "FOOD",
                createdBy: user.name,
              },
            });
          }
          data.chargedToRoom = false;
        }
      }
      if (next === "DELIVERED") data.deliveredAt = new Date();
      data.status = next;
    }

    const updated = await db.restaurantOrder.update({ where: { id: order.id }, data, include: orderInclude() });
    await audit(
      user,
      "UPDATE",
      "RestaurantOrder",
      order.id,
      `Updated order ${order.orderNumber}${data.status ? ` → ${String(data.status)}` : ""}`
    );
    return ok(updated);
  },
  { module: "food-orders" }
);
