import { db } from "@/lib/db";
import { audit, ok, withAuth } from "@/lib/api-helpers";

const WHITELIST_STRING = ["name", "tagline", "address", "phone", "email", "gstin", "currency", "checkInTime", "checkOutTime", "paymentMode", "themeColor"] as const;
const WHITELIST_NUMBER = ["taxRate", "fbTaxRate", "otaCommission"] as const;

async function getOrCreateSettings() {
  const s = await db.hotelSetting.findUnique({ where: { id: "main" } });
  if (s) return s;
  return db.hotelSetting.create({ data: { id: "main" } });
}

export const GET = withAuth(async () => {
  const settings = await getOrCreateSettings();
  return ok(settings);
});

export const PUT = withAuth(
  async (req, { user }) => {
    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

    const data: Record<string, unknown> = {};
    for (const key of WHITELIST_STRING) {
      if (body[key] !== undefined && typeof body[key] === "string") data[key] = body[key];
    }
    for (const key of WHITELIST_NUMBER) {
      if (body[key] !== undefined && typeof body[key] === "number" && Number.isFinite(body[key])) data[key] = body[key];
    }
    if (body.bookingEngineEnabled !== undefined) data.bookingEngineEnabled = body.bookingEngineEnabled === true;

    await getOrCreateSettings();
    const settings = await db.hotelSetting.update({ where: { id: "main" }, data });

    await audit(user, "UPDATE", "Settings", settings.id, "Hotel settings updated");
    return ok(settings);
  },
  { roles: ["ADMIN"] }
);
