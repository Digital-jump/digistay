"use client";

import * as React from "react";
import dynamic from "next/dynamic";
import { useAppStore, type AppUser } from "@/store/app-store";

const PublicSite = dynamic(() => import("@/components/site/public-site"), { ssr: false });
const AppShell = dynamic(() => import("@/components/app/app-shell"), { ssr: false });

const SITE_VIEWS = new Set(["home", "about", "contact", "booking", "login", "portal"]);

function readInitialView(): string {
  if (typeof window === "undefined") return "home";
  const h = window.location.hash.replace(/^#\/?/, "").toLowerCase();
  return SITE_VIEWS.has(h) ? h : "home";
}

export default function Home() {
  const [mounted, setMounted] = React.useState(false);
  const [initialView, setInitialView] = React.useState("home");
  const user = useAppStore((s) => s.user);
  const token = useAppStore((s) => s.token);
  const setAuth = useAppStore((s) => s.setAuth);
  const logout = useAppStore((s) => s.logout);

  React.useEffect(() => {
    setMounted(true);
    setInitialView(readInitialView());
  }, []);

  // Public site login/logout flows (guest stays on the site, staff enters the app shell)
  const onAuthChange = React.useCallback(
    (nextToken: string | null, nextUser: AppUser | null) => {
      if (nextToken && nextUser) setAuth(nextToken, nextUser);
      else logout();
    },
    [setAuth, logout]
  );

  // Avoid hydration mismatch: the persisted zustand store is only readable on the client.
  if (!mounted) return null;

  const isStaffSession = !!user && !!token && user.role !== "GUEST";
  if (isStaffSession) return <AppShell />;

  return (
    <PublicSite
      user={user}
      onAuthChange={onAuthChange}
      initialView={user?.role === "GUEST" ? "portal" : initialView}
    />
  );
}
