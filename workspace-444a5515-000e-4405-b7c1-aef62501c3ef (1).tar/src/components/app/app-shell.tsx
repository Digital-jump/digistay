"use client";

import * as React from "react";
import { ComponentType, useMemo, useState } from "react";
import { Bot, BedDouble, ChevronDown, LogOut, Menu, Plus, Search, Settings } from "lucide-react";
import { toast } from "sonner";
import { apiPost } from "@/lib/api-client";
import { canAccess, type ModuleId } from "@/lib/permissions";
import { ROLE_LABELS, type Role } from "@/lib/permissions";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/store/app-store";
import { NAV, moduleCrumbs, type NavItem } from "@/components/app/nav-config";
import DigiAIChat from "@/components/app/digiai-chat";
import DashboardView from "@/components/views/dashboard-view";
import AiHubView from "@/components/views/ai-hub-view";
import SettingsView from "@/components/views/settings-view";
import GuidesView from "@/components/views/guides-view";
import RoomsView from "@/components/views/rooms-view";
import StayView from "@/components/views/stay-view";
import ReservationsView from "@/components/views/reservations-view";
import CheckinsView from "@/components/views/checkins-view";
import GuestsView from "@/components/views/guests-view";
import FoodOrdersView from "@/components/views/food-orders-view";
import FoodMenuView from "@/components/views/food-menu-view";
import LedgerView from "@/components/views/ledger-view";
import InvoicesView from "@/components/views/invoices-view";
import FolioCompanyView from "@/components/views/folio-company-view";
import FolioOtaView from "@/components/views/folio-ota-view";
import ReportsStandardView from "@/components/views/reports-standard-view";
import ReportsCustomView from "@/components/views/reports-custom-view";
import ReportsBiView from "@/components/views/reports-bi-view";
import ChannelManagerView from "@/components/views/channel-manager-view";
import BookingEngineView from "@/components/views/booking-engine-view";
import ChatsView from "@/components/views/chats-view";
import ReviewsView from "@/components/views/reviews-view";
import type { ViewProps } from "@/components/views/shared";
import { EmptyState } from "@/components/views/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";

// ─── View registry (single place to rewire real views later) ──

const VIEW_REGISTRY: Record<ModuleId, ComponentType<ViewProps>> = {
  dashboard: DashboardView,
  "ai-hub": AiHubView,
  settings: SettingsView,
  guides: GuidesView,
  "room-view": RoomsView,
  "stay-view": StayView,
  reservations: ReservationsView,
  checkins: CheckinsView,
  guests: GuestsView,
  "food-orders": FoodOrdersView,
  "food-menu": FoodMenuView,
  ledger: LedgerView,
  invoices: InvoicesView,
  "folio-company": FolioCompanyView,
  "folio-ota": FolioOtaView,
  "reports-standard": ReportsStandardView,
  "reports-custom": ReportsCustomView,
  "reports-bi": ReportsBiView,
  "channel-manager": ChannelManagerView,
  "booking-engine": BookingEngineView,
  chats: ChatsView,
  reviews: ReviewsView,
};

// ─── Sidebar nav (shared by desktop + mobile sheet) ───────────

function SidebarNav({
  role,
  activeModule,
  onNavigate,
}: {
  role: string;
  activeModule: ModuleId;
  onNavigate: (m: ModuleId) => void;
}) {
  const [navSearch, setNavSearch] = useState("");
  const [toggled, setToggled] = useState<Set<string>>(new Set());

  const visibleItems = useMemo(() => {
    return NAV.filter((item) => {
      const selfAllowed = canAccess(role, item.id);
      const childrenAllowed = item.children?.filter((c) => canAccess(role, c.id)) ?? [];
      if (!selfAllowed && childrenAllowed.length === 0) return false;
      if (navSearch.trim()) {
        const q = navSearch.trim().toLowerCase();
        const match = item.label.toLowerCase().includes(q) ||
          childrenAllowed.some((c) => c.label.toLowerCase().includes(q));
        if (!match) return false;
      }
      return true;
    }).map((item) => ({
      ...item,
      children: item.children?.filter((c) => canAccess(role, c.id)),
    }));
  }, [role, navSearch]);

  const toggleGroup = (id: string) => {
    setToggled((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const renderButton = (item: NavItem) => {
    const Icon = item.icon;
    const isActive = activeModule === item.id;
    return (
      <button
        type="button"
        onClick={() => {
          if (item.children && item.children.length > 0) toggleGroup(item.id);
          else onNavigate(item.id);
        }}
        className={cn(
          "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
          isActive && (!item.children || item.children.length === 0)
            ? "bg-amber-100 text-amber-700"
            : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        )}
      >
        <Icon className={cn("h-4 w-4 shrink-0", isActive ? "text-amber-700" : "text-gray-400")} />
        <span className="flex-1 truncate text-left">{item.label}</span>
        {item.children && item.children.length > 0 && (
          <ChevronDown
            className={cn(
              "h-4 w-4 shrink-0 text-gray-400 transition-transform",
              (toggled.has(item.id) || item.children.some((c) => c.id === activeModule)) && "rotate-180"
            )}
          />
        )}
      </button>
    );
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="px-3 pb-2">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <Input
            value={navSearch}
            onChange={(e) => setNavSearch(e.target.value)}
            placeholder="Search modules..."
            className="h-9 bg-gray-50 pl-9 text-sm"
          />
        </div>
      </div>

      <nav className="min-h-0 flex-1 space-y-0.5 overflow-y-auto px-3 pb-4">
        {visibleItems.map((item) => {
          const hasChildren = !!item.children && item.children.length > 0;
          const childActive = item.children?.some((c) => c.id === activeModule) ?? false;
          const expanded = hasChildren && (navSearch.trim() ? true : toggled.has(item.id) || childActive);
          return (
            <div key={`${item.id}-${item.label}`}>
              {renderButton(item)}
              {hasChildren && expanded && (
                <div className="mb-1 ml-4 mt-0.5 space-y-0.5 border-l border-gray-100 pl-3">
                  {item.children!.map((child) => {
                    const isActive = activeModule === child.id;
                    return (
                      <button
                        key={child.id}
                        type="button"
                        onClick={() => onNavigate(child.id)}
                        className={cn(
                          "block w-full truncate rounded-lg px-3 py-1.5 text-left text-sm transition-colors",
                          isActive
                            ? "bg-amber-100 font-medium text-amber-700"
                            : "text-gray-500 hover:bg-gray-50 hover:text-gray-900"
                        )}
                      >
                        {child.label}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
        {visibleItems.length === 0 && (
          <div className="px-3 py-6 text-center text-xs text-gray-400">No modules match your search</div>
        )}
      </nav>
    </div>
  );
}

function SidebarUserFooter() {
  const user = useAppStore((s) => s.user);
  const setModule = useAppStore((s) => s.setModule);
  const logout = useAppStore((s) => s.logout);

  if (!user) return null;
  const initials = user.name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  async function handleLogout() {
    try {
      await apiPost("/api/auth/logout");
    } catch {
      // session may already be gone — log out locally regardless
    }
    logout();
    toast.success("Signed out");
  }

  return (
    <div className="flex items-center gap-2.5 border-t border-gray-100 p-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-600 text-xs font-semibold text-white">
        {initials}
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-medium text-gray-900">{user.name}</div>
        <div className="truncate text-xs text-gray-400">
          {ROLE_LABELS[user.role as Role] ?? user.role}
        </div>
      </div>
      <button
        type="button"
        title="Settings"
        onClick={() => setModule("settings")}
        className="rounded-lg p-2 text-gray-400 transition-colors hover:bg-gray-50 hover:text-amber-700"
      >
        <Settings className="h-4 w-4" />
      </button>
      <button
        type="button"
        title="Sign out"
        onClick={() => void handleLogout()}
        className="rounded-lg p-2 text-gray-400 transition-colors hover:bg-rose-50 hover:text-rose-600"
      >
        <LogOut className="h-4 w-4" />
      </button>
    </div>
  );
}

// ─── App shell ────────────────────────────────────────────────

export default function AppShell() {
  const user = useAppStore((s) => s.user);
  const activeModule = useAppStore((s) => s.activeModule);
  const setModule = useAppStore((s) => s.setModule);
  const mobileNavOpen = useAppStore((s) => s.mobileNavOpen);
  const setMobileNavOpen = useAppStore((s) => s.setMobileNavOpen);
  const [chatOpen, setChatOpen] = useState(false);

  const crumbs = moduleCrumbs(activeModule);
  const View = VIEW_REGISTRY[activeModule] ?? null;
  const hasAccess = user ? canAccess(user.role, activeModule) : false;

  const handleNavigate = (m: ModuleId) => setModule(m);

  function handleCreateReservation() {
    setModule("reservations");
    window.dispatchEvent(new CustomEvent("digistay:new-reservation"));
  }

  if (!user) return null;

  const sidebarInner = (
    <>
      <div className="flex items-center gap-2.5 px-4 py-4">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-600 text-white">
          <BedDouble className="h-5 w-5" />
        </div>
        <div>
          <div className="text-base font-bold leading-tight text-gray-900">DigiStay</div>
          <div className="text-[11px] leading-tight text-gray-400">Hotel Management</div>
        </div>
      </div>
      <SidebarNav role={user.role} activeModule={activeModule} onNavigate={handleNavigate} />
      <SidebarUserFooter />
    </>
  );

  return (
    <div className="min-h-screen bg-white">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-gray-100 bg-white md:flex">
        {sidebarInner}
      </aside>

      {/* Mobile sheet */}
      <Sheet open={mobileNavOpen} onOpenChange={setMobileNavOpen}>
        <SheetContent side="left" className="w-72 p-0">
          <SheetHeader className="sr-only">
            <SheetTitle>Navigation</SheetTitle>
          </SheetHeader>
          <div className="flex h-full flex-col">{sidebarInner}</div>
        </SheetContent>
      </Sheet>

      {/* Main column */}
      <div className="flex min-h-screen flex-col md:pl-64">
        {/* Topbar */}
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between gap-3 border-b border-gray-100 bg-white/95 px-4 backdrop-blur md:px-6">
          <div className="flex min-w-0 items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileNavOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <div className="min-w-0 truncate text-sm text-gray-400">
              <span>Dashboard</span>
              {crumbs.map((c, i) => (
                <span key={i}>
                  <span className="mx-1.5 text-gray-300">/</span>
                  <span className={i === crumbs.length - 1 ? "font-medium text-gray-700" : ""}>{c}</span>
                </span>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setChatOpen(true)}
              className="ml-2 hidden items-center gap-1.5 rounded-full border border-amber-200 px-3 py-1 text-xs font-medium text-amber-700 transition-colors hover:bg-amber-50 sm:inline-flex"
            >
              <Bot className="h-3.5 w-3.5" />
              Ask DigiAI
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setChatOpen(true)}
              className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-amber-200 text-amber-700 sm:hidden"
            >
              <Bot className="h-4 w-4" />
            </button>
            <Button
              onClick={handleCreateReservation}
              className="rounded-lg bg-amber-600 text-white hover:bg-amber-700"
              size="sm"
            >
              <Plus className="mr-1 h-4 w-4" />
              Create Reservation
            </Button>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 md:p-6">
          {!hasAccess || !View ? (
            <EmptyState
              title="No access"
              description="Your role does not have permission to view this module."
            />
          ) : (
            <View key={activeModule} user={user} />
          )}
        </main>
      </div>

      <DigiAIChat open={chatOpen} onOpenChange={setChatOpen} user={user} />
    </div>
  );
}
