"use client";

import * as React from "react";
import { BedDouble, Loader2, Lock, Mail } from "lucide-react";
import { toast } from "sonner";
import { apiPost } from "@/lib/api-client";
import { useAppStore, type AppUser } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const ROLE_PRESETS: { label: string; email: string; password: string }[] = [
  { label: "Admin", email: "admin@digistay.com", password: "admin123" },
  { label: "Reception", email: "reception@digistay.com", password: "reception123" },
  { label: "Accountant", email: "accounts@digistay.com", password: "accounts123" },
  { label: "Staff", email: "staff@digistay.com", password: "staff123" },
];

export default function LoginScreen() {
  const setAuth = useAppStore((s) => s.setAuth);
  const [email, setEmail] = React.useState("admin@digistay.com");
  const [password, setPassword] = React.useState("admin123");
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  async function signIn(e?: React.FormEvent) {
    e?.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await apiPost<{ token: string; user: AppUser }>("/api/auth/login", { email, password });
      setAuth(res.token, res.user);
      toast.success(`Welcome back, ${res.user.name}`);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Sign in failed";
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-amber-600 to-orange-800 p-4">
      <div className="w-full max-w-md">
        <div className="rounded-2xl bg-white p-8 shadow-xl">
          {/* Logo */}
          <div className="mb-6 flex flex-col items-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-amber-600 text-white shadow-md shadow-amber-200">
              <BedDouble className="h-6 w-6" />
            </div>
            <div className="text-xl font-bold text-gray-900">DigiStay</div>
            <div className="mt-0.5 text-sm text-gray-500">Hotel Management System</div>
          </div>

          <form onSubmit={signIn} className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-sm font-medium text-gray-700">Email</label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@hotel.com"
                  className="pl-9"
                  autoComplete="email"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-sm font-medium text-gray-700">Password</label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="pl-9"
                  autoComplete="current-password"
                />
              </div>
            </div>

            {error && (
              <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700">
                {error}
              </div>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full rounded-lg bg-amber-600 text-white hover:bg-amber-700"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Signing in...
                </>
              ) : (
                "Sign In"
              )}
            </Button>
          </form>

          <div className="mt-4 text-center text-xs text-gray-400">
            Demo: admin@digistay.com / admin123
          </div>

          <div className="mt-5 border-t border-gray-100 pt-4">
            <div className="mb-2 text-center text-xs font-medium uppercase tracking-wide text-gray-400">
              Quick sign in
            </div>
            <div className="grid grid-cols-2 gap-2">
              {ROLE_PRESETS.map((r) => (
                <button
                  key={r.label}
                  type="button"
                  onClick={() => {
                    setEmail(r.email);
                    setPassword(r.password);
                    setError(null);
                  }}
                  className={`rounded-lg border px-3 py-2 text-sm font-medium transition-colors ${
                    email === r.email
                      ? "border-amber-600 bg-amber-50 text-amber-700"
                      : "border-gray-200 text-gray-600 hover:border-amber-300 hover:text-amber-700"
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-4 text-center text-xs text-amber-100/80">
          DigiStay PMS · Demo environment · v1.0
        </div>
      </div>
    </div>
  );
}
