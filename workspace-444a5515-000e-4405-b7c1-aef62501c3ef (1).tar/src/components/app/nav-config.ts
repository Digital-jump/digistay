import type { LucideIcon } from "lucide-react";
import {
  BedDouble,
  BookOpen,
  CalendarCheck,
  CalendarRange,
  ClipboardCheck,
  ClipboardList,
  FileBarChart,
  FileSearch,
  FileText,
  FolderOpen,
  Globe,
  GraduationCap,
  IndianRupee,
  LayoutDashboard,
  MessageSquare,
  Network,
  Send,
  Settings,
  Sparkles,
  Star,
  TrendingUp,
  Users,
} from "lucide-react";
import type { ModuleId } from "@/lib/permissions";

export type NavChild = { id: ModuleId; label: string };

export type NavItem = {
  id: ModuleId;
  label: string;
  icon: LucideIcon;
  children?: NavChild[];
};

export const NAV: NavItem[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "ai-hub", label: "AI Automation", icon: Sparkles },
  { id: "room-view", label: "Room view", icon: BedDouble },
  { id: "stay-view", label: "Stay view", icon: CalendarRange },
  { id: "reservations", label: "Reservations", icon: CalendarCheck },
  {
    id: "checkins",
    label: "Check-ins & Guests",
    icon: ClipboardCheck,
    children: [
      { id: "checkins", label: "All Checkins" },
      { id: "guests", label: "Guests" },
    ],
  },
  {
    id: "food-orders",
    label: "Food",
    icon: ClipboardList,
    children: [
      { id: "food-orders", label: "Orders" },
      { id: "food-menu", label: "Menu" },
    ],
  },
  {
    id: "ledger",
    label: "Finance",
    icon: IndianRupee,
    children: [
      { id: "ledger", label: "Ledger" },
      { id: "invoices", label: "Invoices" },
      { id: "folio-company", label: "Company/Individual Folio" },
      { id: "folio-ota", label: "OTA Folio" },
    ],
  },
  {
    id: "reports-standard",
    label: "Reports",
    icon: FileBarChart,
    children: [
      { id: "reports-standard", label: "Standard Reports" },
      { id: "reports-custom", label: "Custom Reports" },
      { id: "reports-bi", label: "Business Intelligence" },
    ],
  },
  {
    id: "channel-manager",
    label: "OTAs & Website",
    icon: Network,
    children: [
      { id: "channel-manager", label: "Channel Manager" },
      { id: "booking-engine", label: "Booking Engine" },
      { id: "chats", label: "Chats" },
      { id: "reviews", label: "Reviews" },
    ],
  },
  { id: "guides", label: "Guides & Tutorials", icon: GraduationCap },
  { id: "settings", label: "Settings", icon: Settings },
];

// Child-only modules referenced inside groups (icons used by breadcrumb/registry consumers).
export const MODULE_ICONS: Partial<Record<ModuleId, LucideIcon>> = {
  dashboard: LayoutDashboard,
  "ai-hub": Sparkles,
  "room-view": BedDouble,
  "stay-view": CalendarRange,
  reservations: CalendarCheck,
  checkins: ClipboardCheck,
  guests: Users,
  "food-orders": ClipboardList,
  "food-menu": BookOpen,
  ledger: IndianRupee,
  invoices: FileText,
  "folio-company": FolderOpen,
  "folio-ota": Send,
  "reports-standard": FileBarChart,
  "reports-custom": FileSearch,
  "reports-bi": TrendingUp,
  "channel-manager": Network,
  "booking-engine": Globe,
  chats: MessageSquare,
  reviews: Star,
  guides: GraduationCap,
  settings: Settings,
};

/** Flat label lookup across groups + children (used by search filtering & breadcrumbs). */
export function moduleLabel(id: ModuleId): string {
  for (const item of NAV) {
    if (item.id === id) return item.label;
    if (item.children) {
      for (const child of item.children) {
        if (child.id === id) return child.label;
      }
    }
  }
  return id;
}

/** Breadcrumb path for a module, e.g. ["Finance", "Invoices"]. */
export function moduleCrumbs(id: ModuleId): string[] {
  for (const item of NAV) {
    if (item.id === id) return [item.label];
    if (item.children?.some((c) => c.id === id)) {
      return [item.label, item.children.find((c) => c.id === id)?.label ?? id];
    }
  }
  return [id];
}
