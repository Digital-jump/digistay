"use client";

import * as React from "react";
import { Bot, Loader2, Send, Sparkles, Zap } from "lucide-react";
import { apiGet, apiPost } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import type { ViewProps } from "@/components/views/shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";

type ChatMessage = {
  id: string;
  sessionId: string;
  role: string;
  content: string;
  createdAt: string;
};

type ChatAction = { tool: string; summary: string };

const ROLE_CHIPS: Record<string, string[]> = {
  ADMIN: [
    "Occupancy now",
    "Arrivals today",
    "Outstanding balance",
    "Pending food orders",
    "Availability next weekend",
  ],
  RECEPTIONIST: [
    "Occupancy now",
    "Arrivals today",
    "Pending food orders",
    "Availability next weekend",
  ],
  ACCOUNTANT: ["Revenue summary", "Outstanding balance", "Occupancy now"],
  STAFF: ["Occupancy now", "Pending food orders", "Arrivals today"],
};

export default function DigiAIChat({
  open,
  onOpenChange,
  user,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: ViewProps["user"];
}) {
  const sessionId = `user-${user.id}`;
  const [messages, setMessages] = React.useState<ChatMessage[]>([]);
  const [actionsById, setActionsById] = React.useState<Record<string, ChatAction[]>>({});
  const [input, setInput] = React.useState("");
  const [loadingHistory, setLoadingHistory] = React.useState(false);
  const [sending, setSending] = React.useState(false);
  const bottomRef = React.useRef<HTMLDivElement | null>(null);

  React.useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setLoadingHistory(true);
    apiGet<ChatMessage[]>(`/api/support/messages?sessionId=${encodeURIComponent(sessionId)}`)
      .then((items) => {
        if (!cancelled) setMessages(Array.isArray(items) ? items : []);
      })
      .catch(() => {
        if (!cancelled) setMessages([]);
      })
      .finally(() => {
        if (!cancelled) setLoadingHistory(false);
      });
    return () => {
      cancelled = true;
    };
  }, [open, sessionId]);

  React.useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, sending]);

  async function send(text?: string) {
    const body = (text ?? input).trim();
    if (!body || sending) return;
    setInput("");
    setSending(true);
    const optimistic: ChatMessage = {
      id: `tmp-${Date.now()}`,
      sessionId,
      role: "USER",
      content: body,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimistic]);
    try {
      const res = await apiPost<{ reply: string; messages?: ChatMessage[]; actions?: ChatAction[] }>(
        "/api/support/chat",
        { sessionId, message: body }
      );
      setMessages((prev) => {
        const withoutOptimistic = prev.filter((m) => m.id !== optimistic.id);
        let next: ChatMessage[];
        if (res.messages && Array.isArray(res.messages) && res.messages.length > 0) {
          next = res.messages;
        } else {
          next = [
            ...withoutOptimistic,
            {
              id: `assistant-${Date.now()}`,
              sessionId,
              role: "ASSISTANT",
              content: res.reply ?? "",
              createdAt: new Date().toISOString(),
            },
          ];
        }
        const actions = Array.isArray(res.actions) ? res.actions : [];
        if (actions.length > 0) {
          const lastAssistant = [...next].reverse().find((m) => m.role === "ASSISTANT");
          if (lastAssistant) {
            setActionsById((prevActions) => ({ ...prevActions, [lastAssistant.id]: actions }));
          }
        }
        return next;
      });
    } catch (e) {
      const message = e instanceof Error ? e.message : "DigiAI is unavailable right now.";
      setMessages((prev) => [
        ...prev,
        {
          id: `error-${Date.now()}`,
          sessionId,
          role: "ASSISTANT",
          content: message,
          createdAt: new Date().toISOString(),
        },
      ]);
    } finally {
      setSending(false);
    }
  }

  const quickChips = ROLE_CHIPS[user.role] ?? ROLE_CHIPS.STAFF;
  const showChips = !loadingHistory && messages.length <= 2;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex h-[560px] max-w-lg flex-col gap-0 p-0 sm:h-[600px]">
        <DialogHeader className="border-b border-gray-100 px-4 py-3">
          <DialogTitle className="flex items-center gap-2 text-base font-semibold text-gray-900">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-100 text-amber-600">
              <Bot className="h-4 w-4" />
            </span>
            DigiAI 2.0
            <span className="inline-flex items-center gap-1 rounded-full border border-amber-200 bg-amber-50 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-amber-700">
              <Sparkles className="h-3 w-3" />
              Agentic
            </span>
          </DialogTitle>
          <DialogDescription className="text-xs">
            Agentic assistant — checks live hotel data before answering
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 px-4">
          <div className="space-y-3 py-4">
            {loadingHistory ? (
              <div className="flex justify-center py-10">
                <Loader2 className="h-5 w-5 animate-spin text-amber-600" />
              </div>
            ) : messages.length === 0 ? (
              <div className="py-10 text-center">
                <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-amber-50 text-amber-400">
                  <Sparkles className="h-5 w-5" />
                </div>
                <div className="text-sm font-medium text-gray-700">Hi {user.name.split(" ")[0]}! I&apos;m DigiAI.</div>
                <div className="mt-1 text-xs text-gray-400">
                  Ask me about today&apos;s occupancy, arrivals, outstanding balances or how to do anything in DigiStay.
                </div>
              </div>
            ) : (
              messages.map((m) => {
                const isUser = m.role === "USER";
                const actions = !isUser ? actionsById[m.id] : undefined;
                return (
                  <div key={m.id} className={cn("flex", isUser ? "justify-end" : "justify-start")}>
                    <div className="max-w-[80%]">
                      {actions && actions.length > 0 && (
                        <div className="mb-1 pl-1">
                          <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[11px] font-medium text-amber-700">
                            <Zap className="h-3 w-3" />
                            {actions.length} tool check{actions.length === 1 ? "" : "s"}
                          </span>
                          {actions.map((a, i) => (
                            <div key={i} className="mt-0.5 pl-1 text-[10px] leading-snug text-gray-400">
                              {a.summary}
                            </div>
                          ))}
                        </div>
                      )}
                      <div
                        className={cn(
                          "whitespace-pre-wrap rounded-2xl px-3.5 py-2 text-sm",
                          isUser
                            ? "rounded-br-md bg-amber-600 text-white"
                            : "rounded-bl-md bg-gray-100 text-gray-800"
                        )}
                      >
                        {m.content}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            {sending && (
              <div className="flex justify-start">
                <div className="flex items-center gap-1.5 rounded-2xl rounded-bl-md bg-gray-100 px-3.5 py-2.5">
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-gray-400 [animation-delay:0ms]" />
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-gray-400 [animation-delay:150ms]" />
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-gray-400 [animation-delay:300ms]" />
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
        </ScrollArea>

        <div className="border-t border-gray-100 p-3">
          {showChips && quickChips.length > 0 && (
            <div className="mb-2 flex flex-wrap gap-1.5" aria-label="Quick questions">
              {quickChips.map((chip) => (
                <button
                  key={chip}
                  type="button"
                  disabled={sending}
                  onClick={() => void send(chip)}
                  className="rounded-full border border-amber-200 bg-white px-2.5 py-1 text-xs font-medium text-amber-700 transition-colors hover:bg-amber-50 disabled:opacity-50"
                >
                  {chip}
                </button>
              ))}
            </div>
          )}
          <form
            className="flex items-center gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              void send();
            }}
          >
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask anything about your hotel..."
              disabled={sending}
            />
            <Button
              type="submit"
              size="icon"
              disabled={sending || !input.trim()}
              className="shrink-0 rounded-lg bg-amber-600 text-white hover:bg-amber-700"
            >
              {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
