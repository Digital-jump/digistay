// Shared types + helpers for the DigiStay public website (src/components/site).

// ─── API payload types ───────────────────────────────────────

export type SiteRoomType = {
  id: string;
  name: string;
  description: string;
  baseRate: number;
  capacity: number;
  amenities: string[];
  roomCount: number;
};

export type SiteConfig = {
  name: string;
  tagline: string;
  address: string;
  phone: string;
  email?: string;
  currency: string;
  bookingEngineEnabled: boolean;
  paymentMode: string;
  checkInTime: string;
  checkOutTime: string;
  roomTypes: SiteRoomType[];
};

export type SiteReview = {
  id: string;
  rating: number;
  title: string;
  comment: string;
  reply: string | null;
  channel: string;
  createdAt: string;
  guestName: string;
  guestCity: string | null;
};

export type ReviewsData = {
  averageRating: number;
  totalReviews: number;
  reviews: SiteReview[];
};

export type AvailabilityRoomType = Omit<SiteRoomType, "roomCount"> & {
  available: number;
  total: number;
  nights: number;
  totalForStay: number;
};

export type AvailabilityData = {
  roomTypes: AvailabilityRoomType[];
  checkIn: string;
  checkOut: string;
  nights: number;
};

export type BookedReservation = {
  code: string;
  checkIn: string;
  checkOut: string;
  roomTypeName: string;
  nights: number;
  totalAmount: number;
  guestName: string;
};

export type MyBooking = {
  id: string;
  code: string;
  roomTypeName: string;
  roomNumber: string | null;
  checkIn: string;
  checkOut: string;
  nights: number;
  adults: number;
  children: number;
  status: string;
  source: string;
  rate: number;
  totalAmount: number;
  paidAmount: number;
  specialRequests: string | null;
  canCancel: boolean;
};

export type MyBookingsData = {
  guestProfileFound: boolean;
  bookings: MyBooking[];
};

export type SiteView = "home" | "about" | "contact" | "booking" | "login" | "portal";

// ─── Fallback config (used only while loading / if API fails) ──

export const DEFAULT_CONFIG: SiteConfig = {
  name: "DigiStay Grand Hotel",
  tagline: "A premium stay experience by the sea",
  address: "12 Marine Drive, Mumbai",
  phone: "+91 98200 12345",
  email: "frontdesk@digistay.example",
  currency: "INR",
  bookingEngineEnabled: true,
  paymentMode: "UNPAID",
  checkInTime: "14:00",
  checkOutTime: "11:00",
  roomTypes: [],
};

// ─── Money & dates ───────────────────────────────────────────

const inr = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export function formatInr(n: number | null | undefined): string {
  return inr.format(typeof n === "number" && Number.isFinite(n) ? n : 0);
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export function formatDateShort(d: string | Date | null | undefined): string {
  if (!d) return "—";
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return "—";
  return `${dt.getDate()} ${MONTHS[dt.getMonth()]} ${dt.getFullYear()}`;
}

export function ymdLocal(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function addDays(dateStr: string, days: number): string {
  const d = new Date(`${dateStr}T00:00:00`);
  d.setDate(d.getDate() + days);
  return ymdLocal(d);
}

export function nightsBetween(checkIn: string, checkOut: string): number {
  const a = new Date(`${checkIn}T00:00:00`).getTime();
  const b = new Date(`${checkOut}T00:00:00`).getTime();
  if (isNaN(a) || isNaN(b)) return 0;
  return Math.max(0, Math.round((b - a) / 86400000));
}

// ─── Room type images ────────────────────────────────────────

const ROOM_IMAGES: { key: string; url: string }[] = [
  { key: "standard", url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/28ef20fb6321.jpg" },
  { key: "deluxe", url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/aac55facb215.jpg" },
  { key: "family", url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/d077d6c171cb.jpg" },
  { key: "executive", url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/cdaa7f2b83ec.jpg" },
  { key: "presidential", url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/e825c3f84357.jpg" },
];

const FALLBACK_ORDER = [1, 4, 2, 3, 0];

export function roomImage(name: string, index: number): string {
  const lower = name.toLowerCase();
  for (const img of ROOM_IMAGES) {
    if (lower.includes(img.key)) return img.url;
  }
  return ROOM_IMAGES[FALLBACK_ORDER[index % FALLBACK_ORDER.length] ?? 0].url;
}

// ─── Misc display helpers ────────────────────────────────────

const CHANNEL_LABELS: Record<string, string> = {
  BOOKING_COM: "Booking.com",
  GOOGLE: "Google",
  TRIPADVISOR: "TripAdvisor",
  MAKE_MY_TRIP: "MakeMyTrip",
  AIRBNB: "Airbnb",
  DIRECT: "Direct",
  GOIBIBO: "Goibibo",
};

export function channelLabel(channel: string): string {
  return CHANNEL_LABELS[channel] ?? channel.replace(/_/g, " ");
}

export function paymentNote(paymentMode: string): string {
  if (paymentMode === "PREPAID") return "Pay online — a secure payment link will follow your confirmation.";
  if (paymentMode === "BOTH") return "Pay now or at the hotel — your choice.";
  return "No advance needed — pay at the hotel.";
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function pluralize(n: number, word: string, plural?: string): string {
  return `${n} ${n === 1 ? word : (plural ?? `${word}s`)}`;
}
