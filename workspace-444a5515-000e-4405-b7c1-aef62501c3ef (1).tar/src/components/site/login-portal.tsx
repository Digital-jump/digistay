"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  ConciergeBell,
  KeyRound,
  Loader2,
  ShieldCheck,
  UserRound,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiPost } from "@/lib/api-client";
import type { AppUser } from "@/store/app-store";
import { cn } from "@/lib/utils";
import type { SiteView } from "./site-helpers";

type LoginPortalProps = {
  onAuthChange: (token: string | null, user: AppUser | null) => void;
  navigate: (v: SiteView) => void;
};

type PortalId = "admin" | "staff" | "guest";

const PORTALS: {
  id: PortalId;
  Icon: React.ComponentType<{ className?: string; "aria-hidden"?: boolean | "true" | "false" }>;
  title: string;
  copy: string;
  badge: string;
  loginLabel: string;
  demo: { label: string; email: string; password: string }[];
}[] = [
  {
    id: "admin",
    Icon: ShieldCheck,
    title: "Hotel Owner / Admin",
    copy: "Full control of your property: rooms, staff, finance & reports.",
    badge: "Management",
    loginLabel: "Admin",
    demo: [{ label: "Admin", email: "admin@digistay.com", password: "admin123" }],
  },
  {
    id: "staff",
    Icon: ConciergeBell,
    title: "Staff",
    copy: "Reception, accounts & operations workspaces.",
    badge: "Team",
    loginLabel: "Staff",
    demo: [
      { label: "Reception", email: "reception@digistay.com", password: "reception123" },
      { label: "Accounts", email: "accounts@digistay.com", password: "accounts123" },
      { label: "Staff", email: "staff@digistay.com", password: "staff123" },
    ],
  },
  {
    id: "guest",
    Icon: UserRound,
    title: "Guest",
    copy: "Book rooms with your account and manage your stays.",
    badge: "Booking",
    loginLabel: "Guest",
    demo: [{ label: "Guest", email: "guest@digistay.com", password: "guest123" }],
  },
];

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function LoginPortal({ onAuthChange, navigate }: LoginPortalProps) {
  const [portal, setPortal] = React.useState<PortalId | null>(null);

  const active = PORTALS.find((p) => p.id === portal) ?? null;

  return (
    <div className="mx-auto max-w-5xl px-4 py-14 sm:py-20">
      {!active ? (
        <motion.div
          key="picker"
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        >
          <div className="mx-auto max-w-2xl text-center">
            <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-600 shadow-sm">
              <KeyRound className="h-6 w-6 text-white" aria-hidden="true" />
            </span>
            <h1 className="mt-4 text-3xl font-bold tracking-tight text-zinc-900 sm:text-4xl">
              Welcome to DigiStay
            </h1>
            <p className="mt-2 text-sm text-zinc-500 sm:text-base">
              Sign in to manage the hotel or to book your stay.
            </p>
          </div>

          <div className="mt-10 grid gap-5 md:grid-cols-3" role="list" aria-label="Portals">
            {PORTALS.map(({ id, Icon, title, copy, badge }, i) => (
              <motion.button
                key={id}
                type="button"
                role="listitem"
                onClick={() => setPortal(id)}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.06 * i, ease: "easeOut" }}
                className="group flex min-h-[44px] flex-col rounded-2xl border border-zinc-200 bg-white p-6 text-left shadow-sm outline-none transition-all hover:border-amber-600 hover:shadow-md focus-visible:ring-2 focus-visible:ring-amber-500"
              >
                <div className="flex items-center justify-between">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-50 transition-colors group-hover:bg-amber-600">
                    <Icon className="h-5.5 w-5.5 text-amber-600 transition-colors group-hover:text-white" aria-hidden="true" />
                  </span>
                  <Badge variant="outline" className="border-amber-200 text-[10px] font-semibold uppercase tracking-wide text-amber-600">
                    {badge}
                  </Badge>
                </div>
                <h2 className="mt-4 text-base font-semibold text-zinc-900">{title}</h2>
                <p className="mt-1.5 text-sm leading-relaxed text-zinc-500">{copy}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-amber-600">
                  Continue
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                </span>
              </motion.button>
            ))}
          </div>

          <div className="mt-8 text-center">
            <button
              type="button"
              onClick={() => navigate("booking")}
              className="text-sm font-medium text-zinc-500 underline-offset-4 transition-colors hover:text-amber-600 hover:underline"
            >
              Just want to book? No account needed — check availability →
            </button>
          </div>
        </motion.div>
      ) : (
        <LoginForm
          key={active.id}
          portal={active}
          onBack={() => {
            setPortal(null);
          }}
          onAuthChange={onAuthChange}
        />
      )}
    </div>
  );
}

// ─── Stage B: portal login / guest register ──────────────────

type ActivePortal = (typeof PORTALS)[number];

function LoginForm({
  portal,
  onBack,
  onAuthChange,
}: {
  portal: ActivePortal;
  onBack: () => void;
  onAuthChange: (token: string, user: AppUser) => void;
}) {
  const { Icon } = portal;
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [error, setError] = React.useState<string | null>(null);
  const [submitting, setSubmitting] = React.useState(false);

  // Guest registration fields
  const [name, setName] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [confirm, setConfirm] = React.useState("");

  const fill = (e: string, p: string) => {
    setEmail(e);
    setPassword(p);
    setError(null);
  };

  const doLogin = async (event?: React.FormEvent) => {
    event?.preventDefault();
    setError(null);
    if (!EMAIL_RE.test(email.trim())) {
      setError("Please enter a valid email address.");
      return;
    }
    if (password.length < 1) {
      setError("Please enter your password.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await apiPost<{ token: string; user: AppUser }>("/api/auth/login", {
        email: email.trim(),
        password,
        portal: portal.id,
      });
      toast.success(`Welcome back, ${res.user.name}`);
      onAuthChange(res.token, res.user);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Sign in failed. Please try again.";
      setError(msg);
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const doRegister = async (event?: React.FormEvent) => {
    event?.preventDefault();
    setError(null);
    if (name.trim().length < 2) {
      setError("Please enter your full name (first and last name).");
      return;
    }
    if (!EMAIL_RE.test(email.trim())) {
      setError("Please enter a valid email address.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    if (password !== confirm) {
      setError("Passwords do not match.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await apiPost<{ token: string; user: AppUser }>("/api/auth/register", {
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim() || undefined,
        password,
      });
      toast.success(`Welcome, ${res.user.name}`);
      onAuthChange(res.token, res.user);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Could not create your account. Please try again.";
      setError(msg);
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const errorBox = error && (
    <div className="rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-700" role="alert">
      {error}
    </div>
  );

  const demoBox = (
    <div className="rounded-lg border border-zinc-200 bg-zinc-100/70 p-3.5">
      <div className="text-xs font-semibold uppercase tracking-wide text-zinc-500">
        Demo accounts — tap to fill
      </div>
      <div className="mt-2.5 flex flex-wrap gap-2">
        {portal.demo.map((d) => (
          <button
            key={d.email}
            type="button"
            onClick={() => fill(d.email, d.password)}
            className="rounded-full border border-zinc-300 bg-white px-3 py-1.5 text-xs font-medium text-zinc-700 transition-colors hover:border-amber-600 hover:text-amber-700"
            title={`${d.email} / ${d.password}`}
          >
            {d.label}
          </button>
        ))}
      </div>
      <div className="mt-2.5 text-[11px] text-zinc-400">
        Demo environment — data resets available in Settings.
      </div>
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className="mx-auto max-w-md"
    >
      <button
        type="button"
        onClick={onBack}
        className="mb-4 inline-flex min-h-[44px] items-center gap-1.5 text-sm font-medium text-zinc-500 transition-colors hover:text-amber-600"
      >
        <ArrowLeft className="h-4 w-4" aria-hidden="true" />
        All portals
      </button>

      <Card className="border-zinc-200 shadow-sm">
        <CardContent className="p-6 sm:p-7">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-600">
              <Icon className="h-5.5 w-5.5 text-white" aria-hidden="true" />
            </span>
            <div>
              <h1 className="text-lg font-semibold text-zinc-900">{portal.title}</h1>
              <p className="text-xs text-zinc-500">{portal.copy}</p>
            </div>
          </div>

          {portal.id === "guest" ? (
            <Tabs defaultValue="signin" className="mt-5">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="signin" className="min-h-[40px]">Sign in</TabsTrigger>
                <TabsTrigger value="register" className="min-h-[40px]">Create account</TabsTrigger>
              </TabsList>

              <TabsContent value="signin" className="mt-5">
                <form onSubmit={doLogin} className="space-y-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="l-email">Email</Label>
                    <Input
                      id="l-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      autoComplete="email"
                      disabled={submitting}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="l-password">Password</Label>
                    <Input
                      id="l-password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      autoComplete="current-password"
                      disabled={submitting}
                    />
                  </div>
                  {errorBox}
                  <Button
                    type="submit"
                    disabled={submitting}
                    className={cn("min-h-[44px] w-full bg-amber-600 text-white hover:bg-amber-700")}
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                        Signing in…
                      </>
                    ) : (
                      `Sign in as ${portal.loginLabel}`
                    )}
                  </Button>
                </form>
                <div className="mt-4">{demoBox}</div>
              </TabsContent>

              <TabsContent value="register" className="mt-5">
                <form onSubmit={doRegister} className="space-y-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="r-name">
                      Full name<span className="ml-0.5 text-rose-500">*</span>
                    </Label>
                    <Input
                      id="r-name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Aisha Kapoor"
                      autoComplete="name"
                      disabled={submitting}
                    />
                    <p className="text-xs text-zinc-400">First and last name, please.</p>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="r-email">
                      Email<span className="ml-0.5 text-rose-500">*</span>
                    </Label>
                    <Input
                      id="r-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      autoComplete="email"
                      disabled={submitting}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="r-phone">Phone (optional)</Label>
                    <Input
                      id="r-phone"
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 ..."
                      autoComplete="tel"
                      disabled={submitting}
                    />
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label htmlFor="r-password">
                        Password<span className="ml-0.5 text-rose-500">*</span>
                      </Label>
                      <Input
                        id="r-password"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Min. 6 characters"
                        autoComplete="new-password"
                        disabled={submitting}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="r-confirm">
                        Confirm password<span className="ml-0.5 text-rose-500">*</span>
                      </Label>
                      <Input
                        id="r-confirm"
                        type="password"
                        value={confirm}
                        onChange={(e) => setConfirm(e.target.value)}
                        placeholder="Repeat password"
                        autoComplete="new-password"
                        disabled={submitting}
                      />
                    </div>
                  </div>
                  {errorBox}
                  <Button
                    type="submit"
                    disabled={submitting}
                    className="min-h-[44px] w-full bg-amber-600 text-white hover:bg-amber-700"
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                        Creating account…
                      </>
                    ) : (
                      "Create account"
                    )}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          ) : (
            <form onSubmit={doLogin} className="mt-5 space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="l-email">Email</Label>
                <Input
                  id="l-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@hotel.com"
                  autoComplete="email"
                  disabled={submitting}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="l-password">Password</Label>
                <Input
                  id="l-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  disabled={submitting}
                />
              </div>
              {errorBox}
              <Button
                type="submit"
                disabled={submitting}
                className="min-h-[44px] w-full bg-amber-600 text-white hover:bg-amber-700"
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                    Signing in…
                  </>
                ) : (
                  `Sign in as ${portal.loginLabel}`
                )}
              </Button>
              <div>{demoBox}</div>
            </form>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
