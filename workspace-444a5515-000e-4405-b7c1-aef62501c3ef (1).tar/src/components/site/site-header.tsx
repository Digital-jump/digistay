"use client";

import * as React from "react";
import { BedDouble, ChevronDown, LogOut, Menu } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import type { AppUser } from "@/store/app-store";
import { initials, type SiteView } from "./site-helpers";

type SiteHeaderProps = {
  view: SiteView;
  navigate: (v: SiteView) => void;
  user: AppUser | null;
  onSignOut: () => void;
  siteName: string;
};

const NAV_LINKS: { id: SiteView; label: string }[] = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "contact", label: "Contact" },
];

export default function SiteHeader({ view, navigate, user, onSignOut, siteName }: SiteHeaderProps) {
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const goRooms = React.useCallback(() => {
    setMobileOpen(false);
    const scroll = () =>
      document.getElementById("rooms")?.scrollIntoView({ behavior: "smooth", block: "start" });
    if (view !== "home") {
      navigate("home");
      window.setTimeout(scroll, 350);
    } else {
      scroll();
    }
  }, [view, navigate]);

  const goto = (v: SiteView) => {
    setMobileOpen(false);
    navigate(v);
  };

  const linkClass = (active: boolean) =>
    `relative text-sm font-medium transition-colors ${
      active ? "text-amber-600" : "text-zinc-600 hover:text-zinc-900"
    }`;

  const nav = (
    <>
      {NAV_LINKS.map((l) => (
        <button
          key={l.id}
          type="button"
          onClick={() => goto(l.id)}
          className={`${linkClass(view === l.id)} min-h-[44px] px-1`}
          aria-current={view === l.id ? "page" : undefined}
        >
          {l.label}
          {view === l.id && (
            <span className="absolute inset-x-0 -bottom-[5px] h-0.5 rounded-full bg-amber-600" />
          )}
        </button>
      ))}
      <button
        type="button"
        onClick={goRooms}
        className="min-h-[44px] px-1 text-sm font-medium text-zinc-600 transition-colors hover:text-zinc-900"
      >
        Rooms &amp; Rates
      </button>
    </>
  );

  return (
    <header className="sticky top-0 z-50 border-b border-zinc-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
        {/* Brand */}
        <button
          type="button"
          onClick={() => goto("home")}
          className="flex min-h-[44px] items-center gap-2.5"
          aria-label={`${siteName} — go to home`}
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-600 shadow-sm">
            <BedDouble className="h-5 w-5 text-white" aria-hidden="true" />
          </span>
          <span className="flex flex-col items-start leading-none">
            <span className="text-lg font-bold tracking-tight text-zinc-900">DigiStay</span>
            <span className="mt-0.5 text-[10px] font-semibold tracking-[0.28em] text-zinc-400">
              GRAND HOTEL
            </span>
          </span>
        </button>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-7 md:flex" aria-label="Main navigation">
          {nav}
        </nav>

        {/* Right side */}
        <div className="flex items-center gap-2">
          {!user && (
            <>
              <Button
                variant="ghost"
                onClick={() => goto("login")}
                className="hidden min-h-[40px] text-zinc-700 hover:text-amber-700 sm:inline-flex"
              >
                Sign in
              </Button>
              <Button
                onClick={() => goto("booking")}
                className="min-h-[40px] bg-amber-600 text-white hover:bg-amber-700"
              >
                Book Now
              </Button>
            </>
          )}

          {user?.role === "GUEST" && (
            <>
              <Button
                onClick={() => goto("booking")}
                className="min-h-[40px] bg-amber-600 text-white hover:bg-amber-700"
              >
                Book Now
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    type="button"
                    className="flex min-h-[44px] items-center gap-2 rounded-full outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
                    aria-label="Account menu"
                  >
                    <Avatar className="h-9 w-9 border border-amber-200">
                      <AvatarFallback className="bg-amber-600 text-xs font-semibold text-white">
                        {initials(user.name)}
                      </AvatarFallback>
                    </Avatar>
                    <ChevronDown className="hidden h-4 w-4 text-zinc-400 sm:block" aria-hidden="true" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="truncate text-sm font-semibold text-zinc-900">{user.name}</div>
                    <div className="truncate text-xs font-normal text-zinc-500">{user.email}</div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate("portal")} className="cursor-pointer">
                    My Bookings
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={onSignOut}
                    className="cursor-pointer text-rose-600 focus:text-rose-600"
                  >
                    <LogOut className="h-4 w-4" aria-hidden="true" />
                    Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          )}

          {/* Mobile hamburger */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                aria-label="Open menu"
              >
                <Menu className="h-5 w-5" aria-hidden="true" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 p-0">
              <SheetTitle className="sr-only">Navigation menu</SheetTitle>
              <div className="flex h-full flex-col">
                <div className="flex items-center gap-2.5 border-b border-zinc-100 px-5 py-4">
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-600">
                    <BedDouble className="h-5 w-5 text-white" aria-hidden="true" />
                  </span>
                  <div>
                    <div className="text-base font-bold tracking-tight text-zinc-900">DigiStay</div>
                    <div className="text-[10px] font-semibold tracking-[0.28em] text-zinc-400">
                      GRAND HOTEL
                    </div>
                  </div>
                </div>
                <nav className="flex flex-col gap-1 px-3 py-4" aria-label="Mobile navigation">
                  {NAV_LINKS.map((l) => (
                    <button
                      key={l.id}
                      type="button"
                      onClick={() => goto(l.id)}
                      className={`rounded-lg px-3 py-3 text-left text-sm font-medium transition-colors ${
                        view === l.id
                          ? "bg-amber-50 text-amber-700"
                          : "text-zinc-700 hover:bg-zinc-50"
                      }`}
                    >
                      {l.label}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={goRooms}
                    className="rounded-lg px-3 py-3 text-left text-sm font-medium text-zinc-700 transition-colors hover:bg-zinc-50"
                  >
                    Rooms &amp; Rates
                  </button>
                </nav>
                <div className="mt-auto flex flex-col gap-2 border-t border-zinc-100 p-4">
                  {!user && (
                    <>
                      <Button
                        variant="outline"
                        onClick={() => goto("login")}
                        className="min-h-[44px]"
                      >
                        Sign in
                      </Button>
                      <Button
                        onClick={() => goto("booking")}
                        className="min-h-[44px] bg-amber-600 text-white hover:bg-amber-700"
                      >
                        Book Now
                      </Button>
                    </>
                  )}
                  {user?.role === "GUEST" && (
                    <>
                      <div className="flex items-center gap-2.5 px-1 py-1">
                        <Avatar className="h-9 w-9 border border-amber-200">
                          <AvatarFallback className="bg-amber-600 text-xs font-semibold text-white">
                            {initials(user.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <div className="truncate text-sm font-semibold text-zinc-900">{user.name}</div>
                          <div className="truncate text-xs text-zinc-500">{user.email}</div>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => goto("portal")}
                        className="min-h-[44px]"
                      >
                        My Bookings
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setMobileOpen(false);
                          onSignOut();
                        }}
                        className="min-h-[44px] border-rose-200 text-rose-600 hover:bg-rose-50 hover:text-rose-700"
                      >
                        <LogOut className="h-4 w-4" aria-hidden="true" />
                        Sign out
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
