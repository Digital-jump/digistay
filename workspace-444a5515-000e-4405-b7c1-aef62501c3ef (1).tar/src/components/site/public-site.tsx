"use client";

import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";
import { apiGet, apiPost } from "@/lib/api-client";
import type { AppUser } from "@/store/app-store";
import SiteHeader from "./site-header";
import SiteFooter from "./site-footer";
import HomeView from "./home-view";
import AboutView from "./about-view";
import ContactView from "./contact-view";
import BookingView from "./booking-view";
import LoginPortal from "./login-portal";
import GuestPortal from "./guest-portal";
import {
  DEFAULT_CONFIG,
  type ReviewsData,
  type SiteConfig,
  type SiteView,
} from "./site-helpers";

export type PublicSiteProps = {
  user: AppUser | null;
  onAuthChange: (token: string | null, user: AppUser | null) => void;
  initialView: string;
};

const VIEW_SET = new Set<string>(["home", "about", "contact", "booking", "login", "portal"]);

function normalizeView(v: string): SiteView {
  return VIEW_SET.has(v) ? (v as SiteView) : "home";
}

export default function PublicSite({ user, onAuthChange, initialView }: PublicSiteProps) {
  const [view, setView] = React.useState<SiteView>(() => normalizeView(initialView));
  const [config, setConfig] = React.useState<SiteConfig | null>(null);
  const [configLoading, setConfigLoading] = React.useState(true);
  const [reviews, setReviews] = React.useState<ReviewsData | null>(null);
  const [reviewsLoading, setReviewsLoading] = React.useState(true);

  const navigate = React.useCallback((v: SiteView) => {
    if (typeof window !== "undefined" && window.location.hash.replace(/^#\/?/, "") === v) {
      setView(v);
      window.scrollTo(0, 0);
      return;
    }
    if (typeof window !== "undefined") window.location.hash = v;
  }, []);

  // Initialize from the hash once mounted + listen for hash changes.
  // NOTE: only a valid hash overrides the view — guests arriving with an empty
  // hash keep the orchestrator-provided initialView ("portal").
  React.useEffect(() => {
    const applyHash = () => {
      const h = window.location.hash.replace(/^#\/?/, "").toLowerCase();
      if (VIEW_SET.has(h)) {
        setView(h as SiteView);
        window.scrollTo(0, 0);
      }
    };
    applyHash();
    window.addEventListener("hashchange", applyHash);
    return () => window.removeEventListener("hashchange", applyHash);
  }, [initialView]);

  // Public hotel config + published reviews (single fetch each, passed down).
  React.useEffect(() => {
    let cancelled = false;
    apiGet<SiteConfig>("/api/website/config")
      .then((c) => {
        if (!cancelled) setConfig(c);
      })
      .catch(() => {
        if (!cancelled) setConfig(null);
      })
      .finally(() => {
        if (!cancelled) setConfigLoading(false);
      });
    apiGet<ReviewsData>("/api/website/reviews")
      .then((r) => {
        if (!cancelled) setReviews(r);
      })
      .catch(() => {
        if (!cancelled) setReviews(null);
      })
      .finally(() => {
        if (!cancelled) setReviewsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Auth reactions: guests land on the portal, portal requires a guest session.
  React.useEffect(() => {
    if (user?.role === "GUEST" && view === "login") navigate("portal");
    if (!user && view === "portal") navigate("login");
  }, [user, view, navigate]);

  const handleSignOut = React.useCallback(() => {
    apiPost("/api/auth/logout").catch(() => undefined);
    onAuthChange(null, null);
    navigate("home");
    toast.success("Signed out");
  }, [onAuthChange, navigate]);

  const effectiveConfig: SiteConfig = config ?? DEFAULT_CONFIG;
  const siteName = effectiveConfig.name || DEFAULT_CONFIG.name;

  const renderView = () => {
    switch (view) {
      case "about":
        return <AboutView config={effectiveConfig} reviews={reviews} navigate={navigate} />;
      case "contact":
        return <ContactView config={effectiveConfig} />;
      case "booking":
        return (
          <BookingView
            config={effectiveConfig}
            configLoading={configLoading}
            user={user}
            navigate={navigate}
          />
        );
      case "login":
        return <LoginPortal onAuthChange={onAuthChange} navigate={navigate} />;
      case "portal":
        return <GuestPortal user={user} navigate={navigate} />;
      case "home":
      default:
        return (
          <HomeView
            config={effectiveConfig}
            configLoading={configLoading}
            reviews={reviews}
            reviewsLoading={reviewsLoading}
            navigate={navigate}
          />
        );
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-white">
      <SiteHeader
        view={view}
        navigate={navigate}
        user={user}
        onSignOut={handleSignOut}
        siteName={siteName}
      />
      <main className="flex-1">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.28, ease: "easeOut" }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>
      <SiteFooter
        view={view}
        navigate={navigate}
        config={effectiveConfig}
        siteName={siteName}
      />
    </div>
  );
}
