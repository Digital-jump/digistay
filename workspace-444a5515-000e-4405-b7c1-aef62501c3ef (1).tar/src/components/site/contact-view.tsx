"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { CheckCircle2, Clock, Loader2, Mail, MapPin, Phone, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { apiPost } from "@/lib/api-client";
import { DEFAULT_CONFIG, type SiteConfig } from "./site-helpers";

const SUBJECTS = [
  "Reservation enquiry",
  "Feedback",
  "Events & banquets",
  "Corporate rates",
  "Other",
] as const;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type ContactViewProps = {
  config: SiteConfig;
};

export default function ContactView({ config }: ContactViewProps) {
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [subject, setSubject] = React.useState<string>(SUBJECTS[0]);
  const [message, setMessage] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [successName, setSuccessName] = React.useState<string | null>(null);

  const validate = (): string | null => {
    if (name.trim().length < 2) return "Please enter your full name (at least 2 characters).";
    if (!EMAIL_RE.test(email.trim())) return "Please enter a valid email address.";
    const msg = message.trim();
    if (msg.length < 10) return "Message must be at least 10 characters.";
    if (msg.length > 2000) return "Message must be 2000 characters or fewer.";
    return null;
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const problem = validate();
    if (problem) {
      setError(problem);
      toast.error(problem);
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      await apiPost("/api/contact", {
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim() || undefined,
        subject,
        message: message.trim(),
      });
      setSuccessName(name.trim());
      toast.success("Message sent — we'll be in touch soon");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Could not send your message. Please try again.";
      setError(msg);
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  const reset = () => {
    setName("");
    setEmail("");
    setPhone("");
    setSubject(SUBJECTS[0]);
    setMessage("");
    setError(null);
    setSuccessName(null);
  };

  const infoCards = [
    {
      Icon: MapPin,
      title: "Address",
      main: config.address,
      sub: "Seafront landmark on the Queen's Necklace",
    },
    {
      Icon: Phone,
      title: "Phone",
      main: config.phone,
      sub: "24×7 front desk",
      href: `tel:${config.phone.replace(/\s+/g, "")}`,
    },
    {
      Icon: Mail,
      title: "Email",
      main: config.email ?? DEFAULT_CONFIG.email,
      sub: "We reply within 24 hours",
      href: `mailto:${config.email ?? DEFAULT_CONFIG.email}`,
    },
    {
      Icon: Clock,
      title: "Check-in / Check-out",
      main: `${config.checkInTime} / ${config.checkOutTime}`,
      sub: "Early check-in on request, subject to availability",
    },
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:py-16">
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
      >
        <h1 className="text-3xl font-bold tracking-tight text-zinc-900 sm:text-4xl">Contact Us</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-zinc-500 sm:text-base">
          Questions about a stay, an event or anything else? Send us a message — a real person from
          our team will get back to you.
        </p>
      </motion.div>

      <div className="mt-10 grid gap-8 lg:grid-cols-5">
        {/* LEFT — info cards */}
        <div className="space-y-4 lg:col-span-2">
          {infoCards.map(({ Icon, title, main, sub, href }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.05 * i, ease: "easeOut" }}
            >
              <Card className="border-zinc-200 shadow-sm">
                <CardContent className="flex items-start gap-3.5 p-4">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-amber-50">
                    <Icon className="h-5 w-5 text-amber-600" aria-hidden="true" />
                  </span>
                  <div className="min-w-0">
                    <div className="text-xs font-semibold uppercase tracking-wide text-zinc-400">{title}</div>
                    {href ? (
                      <a
                        href={href}
                        className="mt-0.5 block break-words text-sm font-semibold text-zinc-900 hover:text-amber-700"
                      >
                        {main}
                      </a>
                    ) : (
                      <div className="mt-0.5 text-sm font-semibold text-zinc-900">{main}</div>
                    )}
                    <div className="mt-0.5 text-xs text-zinc-500">{sub}</div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.22, ease: "easeOut" }}
            className="rounded-xl bg-amber-50 p-4 text-sm leading-relaxed text-amber-700"
          >
            <span className="font-semibold">Tip:</span> for immediate bookings call the front desk or
            use <span className="font-semibold">Book Now</span> — rooms are confirmed instantly, and
            you only pay at the hotel.
          </motion.div>
        </div>

        {/* RIGHT — form */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.32, delay: 0.1, ease: "easeOut" }}
          className="lg:col-span-3"
        >
          <Card className="border-zinc-200 shadow-sm">
            <CardContent className="p-6">
              {successName !== null ? (
                <div className="flex flex-col items-center py-10 text-center" role="status">
                  <CheckCircle2 className="h-12 w-12 text-emerald-500" aria-hidden="true" />
                  <h2 className="mt-4 text-lg font-semibold text-zinc-900">
                    Thanks {successName}!
                  </h2>
                  <p className="mt-1.5 max-w-sm text-sm text-zinc-500">
                    Our team will reach out within 24 hours. For anything urgent, call{" "}
                    <a href={`tel:${config.phone.replace(/\s+/g, "")}`} className="font-medium text-amber-600">
                      {config.phone}
                    </a>
                    .
                  </p>
                  <Button variant="ghost" onClick={reset} className="mt-6 min-h-[44px] text-amber-600 hover:bg-amber-50 hover:text-amber-700">
                    Send another message
                  </Button>
                </div>
              ) : (
                <form onSubmit={submit} noValidate className="space-y-5">
                  <div className="grid gap-5 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label htmlFor="c-name">
                        Full name<span className="ml-0.5 text-rose-500">*</span>
                      </Label>
                      <Input
                        id="c-name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Your name"
                        disabled={submitting}
                        maxLength={120}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="c-email">
                        Email<span className="ml-0.5 text-rose-500">*</span>
                      </Label>
                      <Input
                        id="c-email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="you@example.com"
                        disabled={submitting}
                      />
                    </div>
                  </div>

                  <div className="grid gap-5 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label htmlFor="c-phone">Phone (optional)</Label>
                      <Input
                        id="c-phone"
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+91 ..."
                        disabled={submitting}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="c-subject">Subject</Label>
                      <Select value={subject} onValueChange={setSubject} disabled={submitting}>
                        <SelectTrigger id="c-subject" className="w-full">
                          <SelectValue placeholder="Choose a subject" />
                        </SelectTrigger>
                        <SelectContent>
                          {SUBJECTS.map((s) => (
                            <SelectItem key={s} value={s}>
                              {s}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-baseline justify-between">
                      <Label htmlFor="c-message">
                        Message<span className="ml-0.5 text-rose-500">*</span>
                      </Label>
                      <span className="text-xs text-zinc-400">{message.length}/2000</span>
                    </div>
                    <Textarea
                      id="c-message"
                      value={message}
                      onChange={(e) => setMessage(e.target.value.slice(0, 2000))}
                      placeholder="Tell us about your plans — dates, number of guests, anything we should know..."
                      rows={6}
                      disabled={submitting}
                    />
                  </div>

                  {error && (
                    <div className="rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-700" role="alert">
                      {error}
                    </div>
                  )}

                  <Button
                    type="submit"
                    disabled={submitting}
                    className="min-h-[44px] w-full bg-amber-600 text-white hover:bg-amber-700 sm:w-auto sm:px-8"
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                        Sending…
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4" aria-hidden="true" />
                        Send message
                      </>
                    )}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
