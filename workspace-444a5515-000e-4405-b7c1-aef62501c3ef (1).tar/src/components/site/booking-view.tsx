"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  BedDouble,
  CalendarDays,
  CheckCircle2,
  Loader2,
  Moon,
  Phone,
  RotateCcw,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { apiGet, apiPost } from "@/lib/api-client";
import type { AppUser } from "@/store/app-store";
import { cn } from "@/lib/utils";
import {
  addDays,
  formatDateShort,
  formatInr,
  nightsBetween,
  paymentNote,
  roomImage,
  ymdLocal,
  type AvailabilityData,
  type AvailabilityRoomType,
  type BookedReservation,
  type SiteConfig,
  type SiteView,
} from "./site-helpers";

type BookingViewProps = {
  config: SiteConfig;
  configLoading: boolean;
  user: AppUser | null;
  navigate: (v: SiteView) => void;
};

type Stage = "search" | "details" | "confirmation";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function BookingView({ config, configLoading, user, navigate }: BookingViewProps) {
  const today = ymdLocal(new Date());
  const [stage, setStage] = React.useState<Stage>("search");

  // Search form
  const [checkIn, setCheckIn] = React.useState<string>(addDays(today, 1));
  const [checkOut, setCheckOut] = React.useState<string>(addDays(today, 3));
  const [adults, setAdults] = React.useState<string>("2");
  const [children, setChildren] = React.useState<string>("0");

  // Results
  const [searching, setSearching] = React.useState(false);
  const [availability, setAvailability] = React.useState<AvailabilityData | null>(null);
  const [searchError, setSearchError] = React.useState<string | null>(null);

  // Details dialog
  const [selected, setSelected] = React.useState<AvailabilityRoomType | null>(null);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [firstName, setFirstName] = React.useState("");
  const [lastName, setLastName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [dAdults, setDAdults] = React.useState("2");
  const [dChildren, setDChildren] = React.useState("0");
  const [specialRequests, setSpecialRequests] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  // Confirmation
  const [confirmation, setConfirmation] = React.useState<BookedReservation | null>(null);

  // Prefill guest identity from a signed-in guest user.
  React.useEffect(() => {
    if (user?.role === "GUEST") {
      const parts = user.name.trim().split(/\s+/);
      setFirstName((prev) => prev || parts[0] || "");
      setLastName((prev) => prev || parts.slice(1).join(" ") || "");
      setEmail((prev) => prev || user.email);
      setPhone((prev) => prev || user.phone || "");
    }
  }, [user]);

  const validateDates = (): boolean => {
    if (!checkIn || !checkOut) {
      toast.error("Please choose both check-in and check-out dates.");
      return false;
    }
    if (checkIn < today) {
      toast.error("Check-in date cannot be in the past.");
      return false;
    }
    if (nightsBetween(checkIn, checkOut) < 1) {
      toast.error("Check-out must be after check-in.");
      return false;
    }
    return true;
  };

  const runSearch = async () => {
    if (!validateDates()) return;
    setSearching(true);
    setSearchError(null);
    try {
      const data = await apiGet<AvailabilityData>(
        `/api/website/availability?checkIn=${checkIn}&checkOut=${checkOut}&adults=${adults}`
      );
      setAvailability(data);
    } catch (err) {
      setAvailability(null);
      setSearchError(err instanceof Error ? err.message : "Could not load availability. Please try again.");
    } finally {
      setSearching(false);
    }
  };

  const openDetails = (rt: AvailabilityRoomType) => {
    setSelected(rt);
    setDAdults(adults);
    setDChildren(children);
    setDialogOpen(true);
    setStage("details");
  };

  const confirmBooking = async () => {
    if (!selected) return;
    const problem = validateDetails();
    if (problem) {
      toast.error(problem);
      return;
    }
    setSubmitting(true);
    try {
      const res = await apiPost<{ reservation: BookedReservation }>("/api/website/book", {
        guest: {
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          email: email.trim(),
          phone: phone.trim(),
        },
        roomTypeId: selected.id,
        checkIn,
        checkOut,
        adults: Number(dAdults),
        children: Number(dChildren),
        specialRequests: specialRequests.trim() || undefined,
        source: "WEBSITE",
      });
      setConfirmation(res.reservation);
      setDialogOpen(false);
      setStage("confirmation");
      toast.success(`Booking ${res.reservation.code} confirmed`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Booking failed. Please try again.";
      toast.error(msg);
      if (msg.toLowerCase().includes("sold out")) {
        setDialogOpen(false);
        setStage("search");
        void runSearch();
      }
    } finally {
      setSubmitting(false);
    }
  };

  const validateDetails = (): string | null => {
    if (firstName.trim().length < 1) return "First name is required.";
    if (lastName.trim().length < 1) return "Last name is required.";
    if (!EMAIL_RE.test(email.trim())) return "Please enter a valid email address.";
    if (phone.trim().length < 5) return "Please enter a contact phone number.";
    return null;
  };

  const resetAll = () => {
    setConfirmation(null);
    setSelected(null);
    setSpecialRequests("");
    setStage("search");
  };

  // ── Offline booking engine ──────────────────────────────
  if (!configLoading && !config.bookingEngineEnabled) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20">
        <Card className="border-zinc-200 shadow-sm">
          <CardContent className="flex flex-col items-center p-8 text-center">
            <BedDouble className="h-10 w-10 text-amber-600" aria-hidden="true" />
            <h1 className="mt-4 text-xl font-semibold text-zinc-900">Online booking is currently unavailable</h1>
            <p className="mt-2 text-sm text-zinc-500">
              Our booking engine is temporarily switched off. Please call us at{" "}
              <a
                href={`tel:${config.phone.replace(/\s+/g, "")}`}
                className="inline-flex items-center gap-1 font-semibold text-amber-600"
              >
                <Phone className="h-3.5 w-3.5" aria-hidden="true" />
                {config.phone}
              </a>{" "}
              and we&apos;ll be happy to reserve your room.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // ── Confirmation ────────────────────────────────────────
  if (stage === "confirmation" && confirmation) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-14 sm:py-20">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        >
          <Card className="border-emerald-200 shadow-sm">
            <CardContent className="p-8 text-center">
              <CheckCircle2 className="mx-auto h-14 w-14 text-emerald-500" aria-hidden="true" />
              <h1 className="mt-4 text-2xl font-bold tracking-tight text-zinc-900">Booking confirmed!</h1>
              <p className="mt-1 text-sm text-zinc-500">
                A confirmation has been saved to your reservation. Show this code at the front desk.
              </p>
              <div className="mt-5 inline-block rounded-xl bg-amber-50 px-6 py-3 font-mono text-2xl font-bold tracking-wider text-amber-700">
                {confirmation.code}
              </div>

              <div className="mt-7 space-y-3 text-left">
                <ConfirmRow label="Guest" value={confirmation.guestName} />
                <ConfirmRow label="Room type" value={confirmation.roomTypeName} />
                <ConfirmRow
                  label="Dates"
                  value={`${formatDateShort(confirmation.checkIn)} → ${formatDateShort(confirmation.checkOut)}`}
                />
                <ConfirmRow label="Nights" value={String(confirmation.nights)} />
                <ConfirmRow label="Total" value={formatInr(confirmation.totalAmount)} strong />
                <ConfirmRow label="Payment" value={paymentNote(config.paymentMode)} />
                <div className="rounded-lg bg-zinc-50 px-4 py-2.5 text-xs text-zinc-500">
                  Taxes as applicable are added at check-out. Check-in {config.checkInTime} · Check-out{" "}
                  {config.checkOutTime}.
                </div>
              </div>

              <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
                <Button
                  onClick={() => navigate(user ? "portal" : "login")}
                  className="min-h-[44px] bg-amber-600 text-white hover:bg-amber-700"
                >
                  View my bookings
                </Button>
                <Button
                  variant="outline"
                  onClick={resetAll}
                  className="min-h-[44px]"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Book another stay
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  // ── Search + results ────────────────────────────────────
  const nights = nightsBetween(checkIn, checkOut);

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:py-16">
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
      >
        <h1 className="text-3xl font-bold tracking-tight text-zinc-900 sm:text-4xl">Book your stay</h1>
        <p className="mt-2 max-w-2xl text-sm text-zinc-500 sm:text-base">
          Real-time availability — reserve instantly, {paymentNote(config.paymentMode).toLowerCase()}
        </p>
      </motion.div>

      {/* Search card */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.06, ease: "easeOut" }}
        className="mt-8"
      >
        <Card className="border-amber-200 bg-amber-50/60 shadow-sm">
          <CardContent className="p-5 sm:p-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="space-y-1.5">
                <Label htmlFor="b-checkin">
                  <CalendarDays className="mr-1 inline h-3.5 w-3.5 text-amber-600" aria-hidden="true" />
                  Check-in
                </Label>
                <Input
                  id="b-checkin"
                  type="date"
                  value={checkIn}
                  min={today}
                  onChange={(e) => {
                    const v = e.target.value;
                    setCheckIn(v);
                    if (v && nightsBetween(v, checkOut) < 1) setCheckOut(addDays(v, 1));
                  }}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="b-checkout">
                  <Moon className="mr-1 inline h-3.5 w-3.5 text-amber-600" aria-hidden="true" />
                  Check-out
                </Label>
                <Input
                  id="b-checkout"
                  type="date"
                  value={checkOut}
                  min={addDays(checkIn, 1)}
                  onChange={(e) => setCheckOut(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Adults</Label>
                <Select value={adults} onValueChange={setAdults}>
                  <SelectTrigger className="w-full" aria-label="Adults">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {["1", "2", "3", "4"].map((n) => (
                      <SelectItem key={n} value={n}>
                        {n} {n === "1" ? "adult" : "adults"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Children</Label>
                <Select value={children} onValueChange={setChildren}>
                  <SelectTrigger className="w-full" aria-label="Children">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {["0", "1", "2", "3"].map((n) => (
                      <SelectItem key={n} value={n}>
                        {n} {n === "1" ? "child" : "children"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button
              onClick={runSearch}
              disabled={searching}
              className="mt-5 min-h-[44px] w-full bg-amber-600 text-white hover:bg-amber-700 sm:w-auto sm:px-8"
            >
              {searching ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                  Checking availability…
                </>
              ) : (
                "Check availability"
              )}
            </Button>
          </CardContent>
        </Card>
      </motion.div>

      {/* Results */}
      <div className="mt-10" aria-live="polite">
        {searching ? (
          <div className="grid gap-6 lg:grid-cols-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex gap-4 rounded-xl border border-zinc-200 bg-white p-4">
                <Skeleton className="h-32 w-40 shrink-0 rounded-lg" />
                <div className="flex-1 space-y-2.5">
                  <Skeleton className="h-5 w-1/2" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                  <Skeleton className="h-8 w-full" />
                </div>
              </div>
            ))}
          </div>
        ) : searchError ? (
          <div className="rounded-xl border border-rose-200 bg-rose-50 px-5 py-4 text-sm text-rose-700">
            {searchError}
            <Button variant="outline" size="sm" onClick={runSearch} className="ml-3 border-rose-300 text-rose-700 hover:bg-rose-100">
              Retry
            </Button>
          </div>
        ) : availability ? (
          <>
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="text-lg font-semibold text-zinc-900">
                Available rooms
              </h2>
              <div className="text-sm text-zinc-500">
                {availability.nights} nights · {formatDateShort(availability.checkIn)} →{" "}
                {formatDateShort(availability.checkOut)}
              </div>
            </div>
            <div className="mt-5 grid gap-6 lg:grid-cols-2">
              {availability.roomTypes.map((rt) => (
                <RoomResultCard
                  key={rt.id}
                  rt={rt}
                  nights={rt.nights}
                  onReserve={() => openDetails(rt)}
                />
              ))}
            </div>
          </>
        ) : (
          <div className="rounded-xl border border-dashed border-zinc-300 bg-zinc-50 py-14 text-center">
            <BedDouble className="mx-auto h-9 w-9 text-zinc-300" aria-hidden="true" />
            <p className="mt-3 text-sm text-zinc-500">
              Choose your dates and tap <span className="font-medium text-zinc-700">Check availability</span> to see
              live rates.
            </p>
            {nights > 0 && (
              <p className="mt-1 text-xs text-zinc-400">
                {nights} night{nights === 1 ? "" : "s"} selected · {formatDateShort(checkIn)} → {formatDateShort(checkOut)}
              </p>
            )}
          </div>
        )}
      </div>

      {/* Details dialog */}
      <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) setStage("search"); }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>Reserve {selected?.name}</DialogTitle>
            <DialogDescription>
              {selected && (
                <>
                  {formatDateShort(checkIn)} → {formatDateShort(checkOut)} · {selected.nights}{" "}
                  {selected.nights === 1 ? "night" : "nights"} · {formatInr(selected.baseRate)}/night
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          {user?.role === "GUEST" && (
            <div className="inline-flex w-fit items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-xs font-medium text-amber-700">
              <Users className="h-3.5 w-3.5" aria-hidden="true" />
              Booking as {user.name}
            </div>
          )}

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="r-first">
                First name<span className="ml-0.5 text-rose-500">*</span>
              </Label>
              <Input id="r-first" value={firstName} onChange={(e) => setFirstName(e.target.value)} disabled={submitting} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="r-last">
                Last name<span className="ml-0.5 text-rose-500">*</span>
              </Label>
              <Input id="r-last" value={lastName} onChange={(e) => setLastName(e.target.value)} disabled={submitting} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="r-email">
                Email<span className="ml-0.5 text-rose-500">*</span>
              </Label>
              <Input id="r-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} disabled={submitting} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="r-phone">
                Phone<span className="ml-0.5 text-rose-500">*</span>
              </Label>
              <Input id="r-phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} disabled={submitting} />
            </div>
            <div className="space-y-1.5">
              <Label>Adults</Label>
              <Select value={dAdults} onValueChange={setDAdults} disabled={submitting}>
                <SelectTrigger aria-label="Adults">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {["1", "2", "3", "4"].map((n) => (
                    <SelectItem key={n} value={n}>
                      {n} {n === "1" ? "adult" : "adults"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Children</Label>
              <Select value={dChildren} onValueChange={setDChildren} disabled={submitting}>
                <SelectTrigger aria-label="Children">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {["0", "1", "2", "3"].map((n) => (
                    <SelectItem key={n} value={n}>
                      {n} {n === "1" ? "child" : "children"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="r-requests">Special requests (optional)</Label>
              <Textarea
                id="r-requests"
                rows={3}
                value={specialRequests}
                onChange={(e) => setSpecialRequests(e.target.value.slice(0, 500))}
                placeholder="Sea-facing floor, late check-in, celebrations…"
                disabled={submitting}
              />
            </div>
          </div>

          {/* Summary */}
          {selected && (
            <div className="rounded-xl border border-amber-100 bg-amber-50/60 p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-zinc-600">
                  {selected.name} · {selected.nights} {selected.nights === 1 ? "night" : "nights"} ×{" "}
                  {formatInr(selected.baseRate)}
                </span>
                <span className="font-medium text-zinc-900">
                  {formatInr(selected.baseRate * selected.nights)}
                </span>
              </div>
              <Separator className="my-3 bg-amber-100" />
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-zinc-700">Total (before taxes)</span>
                <span className="text-lg font-bold text-amber-700">
                  {formatInr(selected.totalForStay)}
                </span>
              </div>
              <div className="mt-2 text-xs text-amber-600/80">
                {paymentNote(config.paymentMode)} · Taxes as applicable added at check-out.
              </div>
            </div>
          )}

          <Button
            onClick={confirmBooking}
            disabled={submitting}
            className="min-h-[44px] w-full bg-amber-600 text-white hover:bg-amber-700"
          >
            {submitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                Confirming…
              </>
            ) : (
              "Confirm booking"
            )}
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Result card ─────────────────────────────────────────────

function RoomResultCard({
  rt,
  nights,
  onReserve,
}: {
  rt: AvailabilityRoomType;
  nights: number;
  onReserve: () => void;
}) {
  const soldOut = rt.available <= 0;
  const scarce = rt.available > 0 && rt.available <= 2;

  return (
    <article className="flex flex-col overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-sm sm:flex-row">
      <img
        src={roomImage(rt.name, 0)}
        alt={rt.name}
        loading="lazy"
        className="h-48 w-full object-cover sm:h-auto sm:w-48 sm:shrink-0"
      />
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-start justify-between gap-3">
          <h3 className="text-base font-semibold text-zinc-900">{rt.name}</h3>
          {soldOut ? (
            <Badge className="shrink-0 bg-rose-100 text-rose-700 hover:bg-rose-100">Sold out</Badge>
          ) : scarce ? (
            <Badge className="shrink-0 bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
              Only {rt.available} left
            </Badge>
          ) : (
            <Badge variant="outline" className="shrink-0 border-emerald-200 text-emerald-700">
              {rt.available}/{rt.total} available
            </Badge>
          )}
        </div>
        <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-zinc-500">
          <span className="inline-flex items-center gap-1">
            <Users className="h-3.5 w-3.5 text-amber-600" aria-hidden="true" />
            Sleeps {rt.capacity}
          </span>
          {rt.amenities.slice(0, 4).map((a) => (
            <span key={a} className="rounded-full bg-zinc-100 px-2 py-0.5 font-medium text-zinc-600">
              {a}
            </span>
          ))}
        </div>
        <div className="mt-3 flex flex-auto flex-wrap items-end justify-between gap-3">
          <div>
            <span className="text-lg font-bold text-amber-600">{formatInr(rt.baseRate)}</span>
            <span className="text-xs text-zinc-400"> /night</span>
            <div className="text-xs text-zinc-500">
              {formatInr(rt.totalForStay)} total for {nights === 1 ? "1 night" : `${nights} nights`}
            </div>
          </div>
          <Button
            onClick={onReserve}
            disabled={soldOut}
            className={cn(
              "min-h-[44px] px-6 text-sm font-semibold",
              !soldOut && "bg-amber-600 text-white hover:bg-amber-700"
            )}
          >
            {soldOut ? "Sold out" : "Reserve"}
          </Button>
        </div>
      </div>
    </article>
  );
}

// ─── Confirmation row ────────────────────────────────────────

function ConfirmRow({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-zinc-100 pb-2.5 text-sm last:border-b-0">
      <span className="shrink-0 text-zinc-500">{label}</span>
      <span className={cn("text-right", strong ? "text-base font-bold text-amber-700" : "font-medium text-zinc-900")}>
        {value}
      </span>
    </div>
  );
}
