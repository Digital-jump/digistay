"use client";

import * as React from "react";
import { HeartHandshake, ShieldCheck, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  channelLabel,
  initials,
  type ReviewsData,
  type SiteConfig,
  type SiteReview,
  type SiteView,
} from "./site-helpers";
import { Reveal, Stars } from "./site-ui";

type AboutViewProps = {
  config: SiteConfig;
  reviews: ReviewsData | null;
  navigate: (v: SiteView) => void;
};

const HERO_IMAGE = "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/e0caf268c9b8.webp";
const CONCIERGE_IMAGE = "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/6c47cc734d36.png";

const VALUES = [
  {
    Icon: HeartHandshake,
    title: "Genuine hospitality",
    copy: "A team that remembers your name, your coffee order and how you like your pillows — service with heart, not a script.",
  },
  {
    Icon: ShieldCheck,
    title: "Trust & safety",
    copy: "Discreet security, verified staff and clear, honest pricing. What we quote is what you pay — no surprises at check-out.",
  },
  {
    Icon: Sparkles,
    title: "Refined comfort",
    copy: "Crisp linen, blackout curtains, quiet air-conditioning and a mattress worth travelling with. Comfort, engineered.",
  },
];

export default function AboutView({ config, reviews, navigate }: AboutViewProps) {
  const roomTypes = config.roomTypes ?? [];
  const totalRooms = roomTypes.reduce((sum, r) => sum + (r.roomCount || 0), 0);
  const showRating = !!reviews && reviews.totalReviews > 0;

  const topReviews: SiteReview[] = React.useMemo(() => {
    if (!reviews) return [];
    return [...reviews.reviews].sort((a, b) => b.rating - a.rating).slice(0, 2);
  }, [reviews]);

  return (
    <div>
      {/* ── HERO BAND ────────────────────────────────────── */}
      <section className="relative h-[42vh] min-h-[320px] w-full" aria-label="About the hotel">
        <img
          src={HERO_IMAGE}
          alt="Elegant hotel exterior"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/40 to-black/70" aria-hidden="true" />
        <div className="absolute inset-0 flex items-center justify-center px-4">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.32, ease: "easeOut" }}
            className="text-center"
          >
            <h1 className="text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl">
              About {config.name || "DigiStay Grand Hotel"}
            </h1>
            <p className="mt-3 max-w-xl text-sm text-amber-200 sm:text-base">
              {config.tagline || "A premium stay experience by the sea"}
            </p>
          </motion.div>
        </div>
      </section>

      {/* ── OUR STORY ────────────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-4 py-16 sm:py-20" aria-label="Our story">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <Reveal>
            <div className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-amber-600">
              Our story
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-zinc-900 sm:text-3xl">
              A seafront landmark, reimagined
            </h2>
            <div className="mt-5 space-y-4 text-sm leading-relaxed text-zinc-600 sm:text-base">
              <p>
                DigiStay began life as a seafront heritage property on Marine Drive — the kind of
                address Mumbaikars pointed out to visitors. In recent years it has been thoughtfully
                rebuilt around one idea: that modern luxury should feel effortless, not ornate.
              </p>
              <p>
                Today the hotel pairs quiet, contemporary rooms with the warmth of classic Indian
                hospitality. Mornings start with the Arabian Sea at your window; evenings end on the
                rooftop, with the Queen&apos;s Necklace glittering across the bay.
              </p>
              <p>
                Whether you&apos;re in Mumbai for a boardroom, a wedding or a weekend of doing
                absolutely nothing, our team — many of them with us for over a decade — makes sure it
                feels like coming home.
              </p>
            </div>
          </Reveal>
          <Reveal delay={0.08}>
            <img
              src={CONCIERGE_IMAGE}
              alt="Concierge welcoming a guest at the front desk"
              loading="lazy"
              className="aspect-[4/3] w-full rounded-2xl object-cover shadow-md"
            />
          </Reveal>
        </div>

        {/* Stats strip */}
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { value: `${totalRooms || "—"}`, label: "Rooms & Suites" },
            { value: `${roomTypes.length || "—"}`, label: "Room Categories" },
            {
              value: `${config.checkInTime} / ${config.checkOutTime}`,
              label: "Check-in / Check-out",
            },
            ...(showRating
              ? [
                  {
                    value: `★ ${reviews?.averageRating.toFixed(1)}`,
                    label: `Guest rating (${reviews?.totalReviews} reviews)`,
                  },
                ]
              : []),
          ].map((s, i) => (
            <Reveal key={s.label} delay={i * 0.05}>
              <div className="rounded-xl border border-amber-100 bg-amber-50/60 p-5 text-center">
                <div className="text-2xl font-bold tracking-tight text-amber-700">{s.value}</div>
                <div className="mt-1 text-xs font-medium text-amber-600/80">{s.label}</div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ── VALUES ───────────────────────────────────────── */}
      <section className="bg-zinc-50/70 py-16 sm:py-20" aria-label="Our values">
        <div className="mx-auto max-w-6xl px-4">
          <div className="mx-auto max-w-2xl text-center">
            <div className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-amber-600">
              What we stand for
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-zinc-900 sm:text-3xl">
              Three promises we never break
            </h2>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {VALUES.map(({ Icon, title, copy }, i) => (
              <Reveal key={title} delay={i * 0.06}>
                <div className="h-full rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-amber-50">
                    <Icon className="h-5.5 w-5.5 text-amber-600" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-base font-semibold text-zinc-900">{title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-zinc-500">{copy}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ── GUEST WORDS ──────────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-4 py-16 sm:py-20" aria-label="Guest words">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-amber-600">
            In their words
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-zinc-900 sm:text-3xl">
            Guests say it best
          </h2>
        </div>
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {!reviews ? (
            Array.from({ length: 2 }).map((_, i) => (
              <div key={i} className="rounded-2xl border border-zinc-200 bg-white p-6">
                <Skeleton className="h-4 w-28" />
                <Skeleton className="mt-4 h-4 w-full" />
                <Skeleton className="mt-2 h-4 w-3/4" />
                <Skeleton className="mt-5 h-9 w-44" />
              </div>
            ))
          ) : topReviews.length === 0 ? (
            <div className="md:col-span-2 rounded-xl border border-dashed border-zinc-300 bg-zinc-50 py-10 text-center text-sm text-zinc-500">
              Be our first reviewed guest — we can&apos;t wait to welcome you.
            </div>
          ) : (
            topReviews.map((r, i) => (
              <Reveal key={r.id} delay={i * 0.07}>
                <figure className="flex h-full flex-col rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm">
                  <Stars rating={r.rating} />
                  <blockquote className="mt-3 flex-1 text-sm leading-relaxed text-zinc-600">
                    “{r.comment}”
                  </blockquote>
                  <figcaption className="mt-4 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-amber-600 text-[11px] font-semibold text-white">
                          {initials(r.guestName)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="text-sm font-medium text-zinc-900">{r.guestName}</div>
                        {r.guestCity && <div className="text-xs text-zinc-400">{r.guestCity}</div>}
                      </div>
                    </div>
                    <Badge variant="outline" className="shrink-0 border-zinc-200 text-[10px] font-semibold uppercase tracking-wide text-zinc-500">
                      {channelLabel(r.channel)}
                    </Badge>
                  </figcaption>
                </figure>
              </Reveal>
            ))
          )}
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-4 pb-16">
        <Reveal>
          <div className="rounded-3xl bg-gradient-to-r from-amber-600 to-orange-700 px-6 py-10 text-center sm:px-12">
            <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              Experience DigiStay hospitality
            </h2>
            <p className="mx-auto mt-2 max-w-xl text-sm text-amber-100">
              Rooms from {roomTypes.length > 0 ? `₹${Math.round(Math.min(...roomTypes.map((r) => r.baseRate))).toLocaleString("en-IN")}` : "₹4,500"} a night.
            </p>
            <Button
              onClick={() => navigate("booking")}
              className="mt-6 min-h-[44px] border border-white/70 bg-transparent px-6 text-sm font-semibold text-white hover:bg-white hover:text-amber-700"
            >
              Book Now
            </Button>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
