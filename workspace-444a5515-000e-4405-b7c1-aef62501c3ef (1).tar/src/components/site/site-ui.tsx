"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// ─── Section reveal wrapper (subtle whileInView) ─────────────

export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.32, ease: "easeOut", delay }}
    >
      {children}
    </motion.div>
  );
}

// ─── Section heading ─────────────────────────────────────────

export function SectionHeading({
  eyebrow,
  title,
  subcopy,
  center,
}: {
  eyebrow?: string;
  title: string;
  subcopy?: string;
  center?: boolean;
}) {
  return (
    <Reveal className={cn("max-w-2xl", center && "mx-auto text-center")}>
      {eyebrow && (
        <div className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-amber-600">
          {eyebrow}
        </div>
      )}
      <h2 className="text-2xl font-bold tracking-tight text-zinc-900 sm:text-3xl">{title}</h2>
      {subcopy && <p className="mt-3 text-sm leading-relaxed text-zinc-500 sm:text-base">{subcopy}</p>}
    </Reveal>
  );
}

// ─── Star row ────────────────────────────────────────────────

export function Stars({ rating, className }: { rating: number; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-0.5", className)} role="img" aria-label={`${rating} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          className={cn(
            "h-4 w-4",
            i <= Math.round(rating) ? "fill-amber-400 text-amber-400" : "fill-zinc-200 text-zinc-200"
          )}
          aria-hidden="true"
        />
      ))}
    </span>
  );
}

// ─── CTA band ────────────────────────────────────────────────

export function CtaBand({
  title,
  buttonLabel,
  onBook,
}: {
  title: string;
  buttonLabel: string;
  onBook: () => void;
}) {
  return (
    <section className="mx-auto max-w-6xl px-4 pb-16">
      <Reveal>
        <div className="rounded-3xl bg-gradient-to-r from-amber-600 to-orange-700 px-6 py-12 text-center sm:px-12 sm:py-14">
          <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">{title}</h2>
          <p className="mx-auto mt-2 max-w-xl text-sm text-amber-100 sm:text-base">
            Reserve in minutes — no advance payment needed for direct website bookings.
          </p>
          <Button
            onClick={onBook}
            className="mt-6 min-h-[44px] border border-white/70 bg-transparent px-6 text-sm font-semibold text-white hover:bg-white hover:text-amber-700"
          >
            {buttonLabel}
          </Button>
        </div>
      </Reveal>
    </section>
  );
}
