"use client";

import * as React from "react";
import { BedDouble, Facebook, Instagram, Mail, MapPin, Phone, Twitter } from "lucide-react";
import { toast } from "sonner";
import type { SiteConfig, SiteView } from "./site-helpers";

type SiteFooterProps = {
  view: SiteView;
  navigate: (v: SiteView) => void;
  config: SiteConfig;
  siteName: string;
};

const SOCIALS = [
  { id: "facebook", label: "Facebook", Icon: Facebook },
  { id: "instagram", label: "Instagram", Icon: Instagram },
  { id: "twitter", label: "Twitter", Icon: Twitter },
];

export default function SiteFooter({ view, navigate, config, siteName }: SiteFooterProps) {
  const isGuest = view === "portal";

  const socialClick = (e: React.MouseEvent<HTMLAnchorElement>, label: string) => {
    e.preventDefault();
    toast.info(`Follow us on ${label.toLowerCase()} — social links coming soon`);
  };

  const quickLinks: { label: string; action: () => void }[] = [
    { label: "Home", action: () => navigate("home") },
    { label: "About", action: () => navigate("about") },
    { label: "Contact", action: () => navigate("contact") },
    { label: "Book Now", action: () => navigate("booking") },
    isGuest
      ? { label: "My Bookings", action: () => navigate("portal") }
      : { label: "Sign in", action: () => navigate("login") },
  ];

  return (
    <footer className="mt-auto bg-zinc-950 text-zinc-400">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-2 md:grid-cols-4">
        {/* Brand */}
        <div>
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-600">
              <BedDouble className="h-5 w-5 text-white" aria-hidden="true" />
            </span>
            <span className="flex flex-col leading-none">
              <span className="text-lg font-bold tracking-tight text-white">DigiStay</span>
              <span className="mt-0.5 text-[10px] font-semibold tracking-[0.28em] text-zinc-500">
                GRAND HOTEL
              </span>
            </span>
          </div>
          <p className="mt-4 text-sm leading-relaxed text-zinc-400">{config.tagline}</p>
          <div className="mt-4 flex items-center gap-2">
            {SOCIALS.map(({ id, label, Icon }) => (
              <a
                key={id}
                href="#"
                aria-label={label}
                onClick={(e) => socialClick(e, label)}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-zinc-800 text-zinc-400 transition-colors hover:border-amber-600 hover:text-amber-400"
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
              </a>
            ))}
          </div>
        </div>

        {/* Quick links */}
        <nav aria-label="Footer navigation">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-white">Quick Links</h3>
          <ul className="mt-4 space-y-2.5">
            {quickLinks.map((l) => (
              <li key={l.label}>
                <button
                  type="button"
                  onClick={l.action}
                  className="text-sm text-zinc-400 transition-colors hover:text-amber-400"
                >
                  {l.label}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Contact */}
        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-white">Contact</h3>
          <ul className="mt-4 space-y-3 text-sm">
            <li className="flex items-start gap-2.5">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" aria-hidden="true" />
              <span>{config.address}</span>
            </li>
            <li className="flex items-start gap-2.5">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" aria-hidden="true" />
              <a href={`tel:${config.phone.replace(/\s+/g, "")}`} className="transition-colors hover:text-amber-400">
                {config.phone}
              </a>
            </li>
            <li className="flex items-start gap-2.5">
              <Mail className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" aria-hidden="true" />
              <a href={`mailto:${config.email ?? "frontdesk@digistay.example"}`} className="break-all transition-colors hover:text-amber-400">
                {config.email ?? "frontdesk@digistay.example"}
              </a>
            </li>
          </ul>
        </div>

        {/* Good to know */}
        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-white">Good to know</h3>
          <ul className="mt-4 space-y-3 text-sm">
            <li>
              Check-in <span className="font-medium text-white">{config.checkInTime}</span> · Check-out{" "}
              <span className="font-medium text-white">{config.checkOutTime}</span>
            </li>
            <li>Pay at hotel — no advance needed for direct bookings.</li>
            <li>On Marine Drive, minutes from Mumbai&apos;s business district and the sea promenade.</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-zinc-800">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-zinc-500 sm:flex-row">
          <div>
            © {new Date().getFullYear()} {siteName} · Marine Drive, Mumbai
          </div>
          <div>Powered by DigiStay PMS · Demo environment</div>
        </div>
      </div>
    </footer>
  );
}
