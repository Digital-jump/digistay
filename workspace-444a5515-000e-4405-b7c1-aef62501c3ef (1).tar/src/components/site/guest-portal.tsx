"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  BedDouble,
  CalendarDays,
  CheckCircle2,
  Loader2,
  Moon,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { apiGet, apiPost } from "@/lib/api-client";
import type { AppUser } from "@/store/app-store";
import { cn } from "@/lib/utils";
import {
  formatDateShort,
  formatInr,
  type MyBookingsData,
  type MyBooking,
  type SiteView,
} from "./site-helpers";

type GuestPortalProps = {
  user: AppUser | null;
  navigate: (v: SiteView) => void;
};

const STATUS_STYLES: Record<string, string> = {
  CONFIRMED: "bg-emerald-100 text-emerald-700",
  PENDING: "bg-amber-100 text-amber-700",
  CHECKED_IN: "bg-amber-100 text-amber-700",
  CHECKED_OUT: "bg-zinc-100 text-zinc-600",
  CANCELLED: "bg-rose-100 text-rose-700",
  NO_SHOW: "bg-zinc-100 text-zinc-600",
};

function GuestStatusBadge({ status }: { status: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium",
        STATUS_STYLES[status] ?? "bg-zinc-100 text-zinc-600"
      )}
    >
      {status.replace(/_/g, " ")}
    </span>
  );
}

export default function GuestPortal({ user, navigate }: GuestPortalProps) {
  const [data, setData] = React.useState<MyBookingsData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [cancellingId, setCancellingId] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiGet<MyBookingsData>("/api/website/my-bookings");
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load your bookings. Please try again.");
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    if (user) void load();
  }, [user, load]);

  const cancelBooking = async (b: MyBooking) => {
    setCancellingId(b.id);
    try {
      await apiPost(`/api/website/my-bookings/${b.id}/cancel`);
      toast.success(`Booking ${b.code} cancelled`);
      await load();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Could not cancel this booking.";
      toast.error(msg);
    } finally {
      setCancellingId(null);
    }
  };

  if (!user) return null;

  const bookings = data?.bookings ?? [];
  const upcoming = bookings.filter((b) => ["PENDING", "CONFIRMED", "CHECKED_IN"].includes(b.status));
  const past = bookings.filter((b) => ["CHECKED_OUT", "CANCELLED", "NO_SHOW"].includes(b.status));
  const firstName = user.name.trim().split(/\s+/)[0] ?? user.name;

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:py-16">
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"
      >
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-zinc-900 sm:text-4xl">My Bookings</h1>
          <p className="mt-1.5 text-sm text-zinc-500 sm:text-base">
            Hello, {firstName} — here are your stays with us.
          </p>
        </div>
        <Button
          onClick={() => navigate("booking")}
          className="min-h-[44px] bg-amber-600 text-white hover:bg-amber-700"
        >
          Book another stay
        </Button>
      </motion.div>

      {/* Summary chips */}
      {!loading && !error && (
        <div className="mt-6 flex flex-wrap gap-2.5" aria-label="Booking summary">
          <span className="rounded-full bg-amber-50 px-4 py-2 text-sm font-medium text-amber-700">
            {upcoming.length} upcoming {upcoming.length === 1 ? "stay" : "stays"}
          </span>
          <span className="rounded-full bg-zinc-100 px-4 py-2 text-sm font-medium text-zinc-700">
            {bookings.length} total {bookings.length === 1 ? "booking" : "bookings"}
          </span>
          <span className="rounded-full bg-zinc-100 px-4 py-2 text-sm font-medium text-zinc-700">
            {past.length} past {past.length === 1 ? "stay" : "stays"}
          </span>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="rounded-xl border border-zinc-200 bg-white p-5">
              <Skeleton className="h-5 w-36" />
              <Skeleton className="mt-3 h-4 w-48" />
              <Skeleton className="mt-2 h-4 w-64" />
              <Skeleton className="mt-2 h-4 w-40" />
              <Skeleton className="mt-4 h-9 w-full" />
            </div>
          ))}
        </div>
      )}

      {/* Error */}
      {!loading && error && (
        <div className="mt-8 rounded-xl border border-rose-200 bg-rose-50 px-5 py-4 text-sm text-rose-700">
          {error}
          <Button
            variant="outline"
            size="sm"
            onClick={() => void load()}
            className="ml-3 border-rose-300 text-rose-700 hover:bg-rose-100"
          >
            Retry
          </Button>
        </div>
      )}

      {/* Empty */}
      {!loading && !error && bookings.length === 0 && (
        <Card className="mt-8 border-dashed shadow-none">
          <CardContent className="flex flex-col items-center py-12 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-amber-50">
              <BedDouble className="h-7 w-7 text-amber-400" aria-hidden="true" />
            </span>
            <h2 className="mt-4 text-lg font-semibold text-zinc-900">No bookings yet</h2>
            <p className="mt-1 max-w-sm text-sm text-zinc-500">
              Your sea view is waiting. Pick your dates and we&apos;ll have the room ready.
            </p>
            <Button
              onClick={() => navigate("booking")}
              className="mt-5 min-h-[44px] bg-amber-600 text-white hover:bg-amber-700"
            >
              Book your first stay
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Upcoming */}
      {!loading && !error && upcoming.length > 0 && (
        <section className="mt-10" aria-label="Upcoming stays">
          <h2 className="text-lg font-semibold text-zinc-900">Upcoming stays</h2>
          <div className="mt-4 grid gap-6 md:grid-cols-2">
            {upcoming.map((b, i) => (
              <BookingCard
                key={b.id}
                booking={b}
                delay={i * 0.05}
                cancelling={cancellingId === b.id}
                onCancel={() => cancelBooking(b)}
              />
            ))}
          </div>
        </section>
      )}

      {/* Past */}
      {!loading && !error && past.length > 0 && (
        <section className="mt-10" aria-label="Past stays">
          <h2 className="text-lg font-semibold text-zinc-900">Past stays</h2>
          <div className="mt-4 grid gap-6 md:grid-cols-2">
            {past.map((b, i) => (
              <BookingCard key={b.id} booking={b} delay={i * 0.05} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

// ─── Booking card ────────────────────────────────────────────

function BookingCard({
  booking,
  delay = 0,
  cancelling = false,
  onCancel,
}: {
  booking: MyBooking;
  delay?: number;
  cancelling?: boolean;
  onCancel?: () => Promise<void> | void;
}) {
  const [confirmOpen, setConfirmOpen] = React.useState(false);

  return (
    <motion.article
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.28, delay, ease: "easeOut" }}
      className="flex h-full flex-col rounded-xl border border-zinc-200 bg-white p-5 shadow-sm"
    >
      <div className="flex items-center justify-between gap-3">
        <span className="font-mono text-sm font-bold tracking-wide text-amber-700">{booking.code}</span>
        <GuestStatusBadge status={booking.status} />
      </div>
      <h3 className="mt-2 text-base font-semibold text-zinc-900">
        {booking.roomTypeName}
        {booking.roomNumber && <span className="font-normal text-zinc-500"> · Room {booking.roomNumber}</span>}
      </h3>
      <div className="mt-2 space-y-1.5 text-sm text-zinc-600">
        <div className="flex items-center gap-1.5">
          <CalendarDays className="h-3.5 w-3.5 shrink-0 text-amber-600" aria-hidden="true" />
          {formatDateShort(booking.checkIn)} → {formatDateShort(booking.checkOut)} ·{" "}
          {booking.nights} {booking.nights === 1 ? "night" : "nights"}
        </div>
        <div className="flex items-center gap-1.5">
          <Users className="h-3.5 w-3.5 shrink-0 text-amber-600" aria-hidden="true" />
          {booking.adults} {booking.adults === 1 ? "adult" : "adults"}
          {booking.children > 0 && `, ${booking.children} ${booking.children === 1 ? "child" : "children"}`}
        </div>
        <div className="flex items-center gap-1.5">
          <Moon className="h-3.5 w-3.5 shrink-0 text-amber-600" aria-hidden="true" />
          {booking.source === "WEBSITE" ? "Booked on the website" : booking.source.replace(/_/g, " ")}
        </div>
      </div>
      {booking.specialRequests && (
        <p className="mt-3 text-sm italic text-zinc-500">“{booking.specialRequests}”</p>
      )}
      <div className="mt-4 flex flex-auto flex-wrap items-end justify-between gap-3 pt-1">
        <div className="text-base font-bold text-zinc-900">{formatInr(booking.totalAmount)} total</div>
        {onCancel && (
          <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                disabled={cancelling}
                className="min-h-[40px] border-rose-200 text-rose-600 hover:bg-rose-50 hover:text-rose-700"
              >
                {cancelling ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                    Cancelling…
                  </>
                ) : (
                  "Cancel booking"
                )}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Cancel booking {booking.code}?</AlertDialogTitle>
                <AlertDialogDescription>
                  The room will be released immediately and other guests will be able to book it. This
                  cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel disabled={cancelling}>Keep booking</AlertDialogCancel>
                <AlertDialogAction
                  disabled={cancelling}
                  onClick={(e) => {
                    e.preventDefault();
                    void (async () => {
                      await onCancel();
                      setConfirmOpen(false);
                    })();
                  }}
                  className="bg-rose-600 text-white hover:bg-rose-700"
                >
                  {cancelling ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                      Cancelling…
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                      Yes, cancel it
                    </>
                  )}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>
    </motion.article>
  );
}
