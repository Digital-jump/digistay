"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  Car,
  Coffee,
  Dumbbell,
  MapPin,
  Sparkles,
  Star,
  Users,
  Waves,
  Wifi,
} from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import {
  channelLabel,
  formatInr,
  initials,
  roomImage as roomImageSrc,
  type ReviewsData,
  type SiteConfig,
  type SiteReview,
  type SiteView,
} from "./site-helpers";
import { CtaBand, Reveal, SectionHeading, Stars } from "./site-ui";

type HomeViewProps = {
  config: SiteConfig;
  configLoading: boolean;
  reviews: ReviewsData | null;
  reviewsLoading: boolean;
  navigate: (v: SiteView) => void;
};

const HERO_IMAGE = "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/5b034ecc1276.jpg";

const EXPERIENCE = [
  {
    label: "Fine Dining",
    sub: "Coastal flavours, global craft",
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/b468dea6c1f7.jpg",
    Icon: null,
  },
  {
    label: "Rooftop Infinity Pool",
    sub: "Sunsets over the bay",
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/2073758ca55d.jpg",
    Icon: null,
  },
  {
    label: "24×7 Concierge",
    sub: "Whatever you need, whenever",
    url: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/6c47cc734d36.png",
    Icon: null,
  },
];

const FEATURES = [
  { Icon: Wifi, title: "High-speed Wi-Fi", copy: "Fibre internet in every room and public space." },
  { Icon: Waves, title: "Sea-facing balconies", copy: "Most rooms open onto the Arabian Sea skyline." },
  { Icon: Sparkles, title: "Spa & wellness", copy: "Ayurvedic treatments, sauna and steam rooms." },
  { Icon: Car, title: "Airport transfer", copy: "Chauffeured pickups from Mumbai airport." },
  { Icon: Coffee, title: "All-day dining", copy: "Multi-cuisine restaurant, café and rooftop bar." },
  { Icon: Dumbbell, title: "Fitness studio", copy: "Open 24 hours with modern equipment." },
];

export default function HomeView({ config, configLoading, reviews, reviewsLoading, navigate }: HomeViewProps) {
  const roomTypes = config.roomTypes ?? [];
  const totalRooms = roomTypes.reduce((sum, r) => sum + (r.roomCount || 0), 0);
  const showRatingChip = !!reviews && reviews.totalReviews > 0;
  const averageRating = reviews?.averageRating ?? 0;
  const totalReviews = reviews?.totalReviews ?? 0;

  const goRooms = () =>
    document.getElementById("rooms")?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <div>
      {/* ── HERO ─────────────────────────────────────────── */}
      <section className="relative h-[68vh] min-h-[480px] w-full" aria-label="Welcome">
        <img
          src={HERO_IMAGE}
          alt="Seafront view of the hotel at dusk"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/40 to-black/70" aria-hidden="true" />
        <div className="absolute inset-0">
          <div className="mx-auto flex h-full max-w-6xl items-end px-4 pb-12 sm:pb-16">
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              className="max-w-3xl"
            >
              <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm">
                <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
                Marine Drive, Mumbai
              </span>
              <h1 className="mt-4 text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
                {config.name || "DigiStay Grand Hotel"}
              </h1>
              <p className="mt-2 text-base font-medium text-amber-200 sm:text-lg">
                {config.tagline || "A premium stay experience by the sea"}
              </p>
              <p className="mt-3 max-w-xl text-sm leading-relaxed text-zinc-200 sm:text-base">
                Wake up to the Arabian Sea, dine under the city lights, and let our team take care of
                every detail of your stay.
              </p>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                <Button
                  onClick={() => navigate("booking")}
                  className="min-h-[44px] bg-amber-600 px-6 text-sm font-semibold text-white hover:bg-amber-700"
                >
                  Book Your Stay
                </Button>
                <Button
                  variant="outline"
                  onClick={goRooms}
                  className="min-h-[44px] border-white/60 bg-transparent px-6 text-sm font-semibold text-white hover:bg-white hover:text-zinc-900"
                >
                  Explore Rooms
                </Button>
              </div>

              {/* Stat chips */}
              {!configLoading && (
                <div className="mt-7 flex flex-wrap gap-2.5">
                  <span className="rounded-xl bg-white/10 px-4 py-2 text-xs font-medium text-white backdrop-blur sm:text-sm">
                    {roomTypes.length} room categories
                  </span>
                  <span className="rounded-xl bg-white/10 px-4 py-2 text-xs font-medium text-white backdrop-blur sm:text-sm">
                    {totalRooms} rooms
                  </span>
                  {showRatingChip && (
                    <span className="inline-flex items-center gap-1.5 rounded-xl bg-white/10 px-4 py-2 text-xs font-medium text-white backdrop-blur sm:text-sm">
                      <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" aria-hidden="true" />
                      {averageRating.toFixed(1)} guest rating ({totalReviews} reviews)
                    </span>
                  )}
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── ROOMS & RATES ────────────────────────────────── */}
      <section id="rooms" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-16 sm:py-20" aria-label="Rooms and rates">
        <SectionHeading
          eyebrow="Stay"
          title="Rooms & Rates"
          subcopy="Thoughtfully designed rooms and suites, all with sea breeze, deep beds and everything you need for a restful night."
        />
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {configLoading
            ? Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="overflow-hidden rounded-xl border border-zinc-200 bg-white">
                  <Skeleton className="aspect-[4/3] w-full rounded-none" />
                  <div className="space-y-2.5 p-5">
                    <Skeleton className="h-5 w-2/3" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-8 w-full" />
                  </div>
                </div>
              ))
            : roomTypes.map((rt, idx) => (
                <Reveal key={rt.id} delay={idx * 0.05}>
                  <article className="flex h-full flex-col overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-sm transition-shadow hover:shadow-md">
                    <img
                      src={roomImageSrc(rt.name, idx)}
                      alt={rt.name}
                      loading="lazy"
                      className="aspect-[4/3] w-full object-cover"
                    />
                    <div className="flex flex-1 flex-col p-5">
                      <h3 className="text-base font-semibold text-zinc-900">{rt.name}</h3>
                      <p className="mt-1 line-clamp-2 text-sm text-zinc-500">{rt.description}</p>
                      <div className="mt-3 flex items-center gap-1.5 text-xs text-zinc-600">
                        <Users className="h-3.5 w-3.5 text-amber-600" aria-hidden="true" />
                        Sleeps {rt.capacity}
                      </div>
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {rt.amenities.slice(0, 3).map((a) => (
                          <span
                            key={a}
                            className="rounded-full bg-zinc-100 px-2.5 py-0.5 text-[11px] font-medium text-zinc-600"
                          >
                            {a}
                          </span>
                        ))}
                        {rt.amenities.length > 3 && (
                          <span className="rounded-full bg-zinc-100 px-2.5 py-0.5 text-[11px] font-medium text-zinc-600">
                            +{rt.amenities.length - 3} more
                          </span>
                        )}
                      </div>
                      <div className="mt-4 flex flex-auto items-end justify-between gap-3 pt-2">
                        <div>
                          <span className="text-lg font-bold text-amber-600">{formatInr(rt.baseRate)}</span>
                          <span className="text-xs text-zinc-400"> /night</span>
                        </div>
                        <Button
                          variant="ghost"
                          onClick={() => navigate("booking")}
                          className="min-h-[40px] text-sm font-semibold text-amber-600 hover:bg-amber-50 hover:text-amber-700"
                        >
                          Check availability
                        </Button>
                      </div>
                    </div>
                  </article>
                </Reveal>
              ))}
        </div>
      </section>

      {/* ── EXPERIENCE ───────────────────────────────────── */}
      <section className="bg-zinc-50/70 py-16 sm:py-20" aria-label="Experience">
        <div className="mx-auto max-w-6xl px-4">
          <SectionHeading
            eyebrow="Experience"
            title="More than a room"
            subcopy="From sunrise swims to midnight desserts — the stay is the destination."
          />
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {EXPERIENCE.map((x, i) => (
              <Reveal key={x.label} delay={i * 0.06}>
                <div className="relative overflow-hidden rounded-2xl">
                  <img
                    src={x.url}
                    alt={x.label}
                    loading="lazy"
                    className="aspect-[4/5] w-full object-cover transition-transform duration-500 hover:scale-105 sm:aspect-[3/4]"
                  />
                  <div
                    className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent"
                    aria-hidden="true"
                  />
                  <div className="absolute bottom-0 left-0 p-5">
                    <div className="text-lg font-semibold text-white">{x.label}</div>
                    <div className="mt-0.5 text-xs text-zinc-200">{x.sub}</div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3">
            {FEATURES.map(({ Icon, title, copy }, i) => (
              <Reveal key={title} delay={i * 0.04}>
                <div className="flex h-full items-start gap-3 rounded-xl border border-zinc-200 bg-white p-4">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-amber-50">
                    <Icon className="h-5 w-5 text-amber-600" aria-hidden="true" />
                  </span>
                  <div>
                    <div className="text-sm font-semibold text-zinc-900">{title}</div>
                    <div className="mt-0.5 text-xs leading-relaxed text-zinc-500">{copy}</div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ── GUEST REVIEWS ────────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-4 py-16 sm:py-20" aria-label="Guest reviews">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <SectionHeading
            eyebrow="Guest reviews"
            title="Loved by our guests"
            subcopy="Real words from travellers who stayed with us, collected across booking platforms."
          />
          {!reviewsLoading && reviews && reviews.totalReviews > 0 && (
            <Reveal className="shrink-0 rounded-2xl border border-zinc-200 bg-white px-6 py-4 text-center shadow-sm">
              <div className="flex items-center justify-center gap-1.5">
                <Star className="h-6 w-6 fill-amber-400 text-amber-400" aria-hidden="true" />
                <span className="text-3xl font-bold tracking-tight text-zinc-900">
                  {reviews.averageRating.toFixed(1)}
                </span>
              </div>
              <div className="mt-1 text-xs text-zinc-500">
                {totalReviews} verified guest {totalReviews === 1 ? "review" : "reviews"}
              </div>
            </Reveal>
          )}
        </div>

        <div className="mt-8">
          {reviewsLoading ? (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="rounded-xl border border-zinc-200 bg-white p-5">
                  <Skeleton className="h-4 w-28" />
                  <Skeleton className="mt-3 h-5 w-3/4" />
                  <Skeleton className="mt-3 h-4 w-full" />
                  <Skeleton className="mt-2 h-4 w-full" />
                  <Skeleton className="mt-2 h-4 w-2/3" />
                  <Skeleton className="mt-4 h-9 w-40" />
                </div>
              ))}
            </div>
          ) : !reviews || reviews.reviews.length === 0 ? (
            <div className="rounded-xl border border-dashed border-zinc-300 bg-zinc-50 py-10 text-center text-sm text-zinc-500">
              Be our first reviewed guest — we can&apos;t wait to welcome you.
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {reviews.reviews.map((r, i) => (
                <ReviewCard key={r.id} review={r} delay={i * 0.05} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ── CTA BAND ─────────────────────────────────────── */}
      <CtaBand
        title="Ready for a memorable stay by the sea?"
        buttonLabel="Book now — pay at hotel"
        onBook={() => navigate("booking")}
      />
    </div>
  );
}

// ─── Review card ─────────────────────────────────────────────

function ReviewCard({ review, delay }: { review: SiteReview; delay: number }) {
  return (
    <Reveal delay={delay} className="h-full">
      <article className="flex h-full flex-col rounded-xl border border-zinc-200 bg-white p-5 shadow-sm">
        <Stars rating={review.rating} />
        <h3 className="mt-3 text-sm font-semibold text-zinc-900">{review.title}</h3>
        <p className="mt-1.5 line-clamp-4 text-sm leading-relaxed text-zinc-600">{review.comment}</p>
        {review.reply && (
          <div className="mt-3 rounded-lg bg-amber-50 px-3 py-2.5 text-xs leading-relaxed text-amber-700">
            <span className="font-semibold">Response from hotel</span> — {review.reply}
          </div>
        )}
        <div className="mt-4 flex flex-auto items-center justify-between gap-3 pt-1">
          <div className="flex min-w-0 items-center gap-2.5">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="bg-amber-600 text-[11px] font-semibold text-white">
                {initials(review.guestName)}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <div className="truncate text-sm font-medium text-zinc-900">{review.guestName}</div>
              {review.guestCity && <div className="truncate text-xs text-zinc-400">{review.guestCity}</div>}
            </div>
          </div>
          <Badge
            variant="outline"
            className={cn("shrink-0 border-zinc-200 text-[10px] font-semibold uppercase tracking-wide text-zinc-500")}
          >
            {channelLabel(review.channel)}
          </Badge>
        </div>
      </article>
    </Reveal>
  );
}


