"use client";

import * as React from "react";
import { Clock, GraduationCap, PlayCircle } from "lucide-react";
import {
  EmptyState,
  PageHeader,
  SearchInput,
  Spinner,
  useApi,
  type ViewProps,
} from "@/components/views/shared";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type Tutorial = {
  id: string;
  title: string;
  category: string;
  duration: string;
  description: string;
  steps: string[];
  languages: number;
};

export default function GuidesView({ user: _user }: ViewProps) {
  const { data, loading, error } = useApi<Tutorial[]>("/api/support/tutorials");
  const [search, setSearch] = React.useState("");
  const [category, setCategory] = React.useState("All");
  const [selected, setSelected] = React.useState<Tutorial | null>(null);

  const categories = React.useMemo(() => {
    const set = new Set<string>();
    for (const t of data ?? []) set.add(t.category);
    return ["All", ...[...set].sort()];
  }, [data]);

  const filtered = React.useMemo(() => {
    const q = search.trim().toLowerCase();
    return (data ?? []).filter((t) => {
      if (category !== "All" && t.category !== category) return false;
      if (!q) return true;
      return (
        t.title.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.steps.some((s) => s.toLowerCase().includes(q))
      );
    });
  }, [data, search, category]);

  return (
    <div className="space-y-4">
      <PageHeader title="Learn DigiStay" crumbs={["Guides & Tutorials"]}>
        <div className="w-full sm:w-64">
          <SearchInput value={search} onChange={setSearch} placeholder="Search tutorials..." />
        </div>
      </PageHeader>

      {/* Category chips */}
      <div className="flex flex-wrap gap-2">
        {categories.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setCategory(c)}
            className={cn(
              "rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors",
              category === c
                ? "border-amber-600 bg-white text-amber-700 shadow-sm"
                : "border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:text-gray-900"
            )}
          >
            {c}
          </button>
        ))}
      </div>

      {loading ? (
        <Spinner />
      ) : error ? (
        <EmptyState title="Couldn't load tutorials" description={error} />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<GraduationCap className="h-7 w-7" />}
          title="No tutorials found"
          description="Try a different search term or category."
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((t) => (
            <Card
              key={t.id}
              className="cursor-pointer transition-shadow hover:shadow-md"
              onClick={() => setSelected(t)}
            >
              <CardContent className="p-4">
                <div className="mb-3 flex items-start justify-between gap-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-50 text-amber-600">
                    <PlayCircle className="h-5 w-5" />
                  </div>
                  <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-0.5 text-xs font-medium text-amber-700">
                    <Clock className="h-3 w-3" /> {t.duration}
                  </span>
                </div>
                <div className="text-sm font-semibold text-gray-900">{t.title}</div>
                <div className="mt-1 line-clamp-2 text-xs text-gray-500">{t.description}</div>
                <div className="mt-3 flex flex-wrap items-center gap-1.5 border-t border-gray-50 pt-3 text-[11px] text-gray-500">
                  <span className="rounded-full bg-gray-100 px-2 py-0.5 font-medium text-gray-600">{t.category}</span>
                  <span>·</span>
                  <span>{t.languages} languages</span>
                  <span>·</span>
                  <span className="rounded-full bg-gray-100 px-2 py-0.5 font-medium text-gray-600">CC</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Tutorial detail dialog */}
      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 pr-6">
              {selected?.title}
              {selected && (
                <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-amber-50 px-2.5 py-0.5 text-xs font-medium text-amber-700">
                  <Clock className="h-3 w-3" /> {selected.duration}
                </span>
              )}
            </DialogTitle>
            {selected && (
              <DialogDescription>
                {selected.description}
              </DialogDescription>
            )}
          </DialogHeader>
          {selected && (
            <div className="max-h-[50vh] overflow-y-auto pr-2">
              <ol className="list-decimal space-y-2 pl-5 text-sm text-gray-700">
                {selected.steps.map((step, i) => (
                  <li key={i}>{step}</li>
                ))}
              </ol>
            </div>
          )}
          <div className="flex items-center justify-between border-t border-gray-100 pt-3 text-xs text-gray-400">
            <span>
              {selected?.category} · {selected?.languages} languages · CC
            </span>
            <Button
              variant="outline"
              size="sm"
              className="h-8 rounded-lg"
              onClick={() => setSelected(null)}
            >
              Done
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
