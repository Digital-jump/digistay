"use client";

import * as React from "react";
import {
  BedDouble,
  Brush,
  Hammer,
  Pencil,
  Plus,
  ReceiptText,
  Sparkles,
  Trash2,
  Wrench,
} from "lucide-react";
import { toast } from "sonner";
import { apiDelete, apiPost, apiPut } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/store/app-store";
import {
  ConfirmButton,
  EmptyState,
  Field,
  PageHeader,
  SearchInput,
  Spinner,
  StatusBadge,
  formatMoney,
  formatDate,
  ymd,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

// ─── Types ────────────────────────────────────────────────────

type RoomType = {
  id: string;
  name: string;
  description?: string | null;
  baseRate: number;
  capacity: number;
  extraAdultCharge?: number | null;
  amenities: string | string[] | null;
  roomCount?: number;
  activeReservations?: number;
};

type Room = {
  id: string;
  number: string;
  floor: number;
  status: string;
  housekeeping: string;
  notes: string | null;
  roomType: RoomType | null;
};

type RoomsData = {
  items: Room[];
  stats: { AVAILABLE: number; OCCUPIED: number; RESERVED: number; DIRTY: number; MAINTENANCE: number };
};

type CheckedInReservation = {
  id: string;
  code: string;
  status: string;
  checkOut: string;
  guest: { firstName: string; lastName: string } | null;
  room: { id: string; number: string } | null;
};

// ─── Helpers ──────────────────────────────────────────────────

function parseAmenities(a: string | string[] | null | undefined): string[] {
  if (!a) return [];
  if (Array.isArray(a)) return a;
  try {
    const parsed = JSON.parse(a);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return a.split(",").map((s) => s.trim()).filter(Boolean);
  }
}

const STATUS_BAR: Record<string, string> = {
  AVAILABLE: "bg-emerald-500",
  OCCUPIED: "bg-rose-500",
  RESERVED: "bg-amber-500",
  DIRTY: "bg-amber-500",
  MAINTENANCE: "bg-gray-400",
};

const FILTER_DOTS: Record<string, string> = {
  all: "bg-amber-500",
  AVAILABLE: "bg-emerald-500",
  OCCUPIED: "bg-rose-500",
  CHECKOUT_DUE: "bg-amber-500",
  RESERVED: "bg-amber-500",
  MAINTENANCE: "bg-gray-400",
  HOUSEKEEPING: "bg-orange-500",
};

function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}

// ─── View ─────────────────────────────────────────────────────

export default function RoomsView({ user }: ViewProps) {
  const setModule = useAppStore((s) => s.setModule);
  const canManage = user.role === "ADMIN" || user.role === "RECEPTIONIST";

  const { data, loading, error, refetch } = useApi<RoomsData>("/api/rooms");
  const { data: checkedin, refetch: refetchCheckedin } = useApi<{ items: CheckedInReservation[] }>(
    "/api/reservations?tab=checkedin"
  );
  const { data: roomTypesData, refetch: refetchTypes } = useApi<RoomType[]>("/api/room-types");

  const [filter, setFilter] = React.useState("all");
  const [search, setSearch] = React.useState("");
  const [detailsRoom, setDetailsRoom] = React.useState<Room | null>(null);
  const [busy, setBusy] = React.useState(false);

  // Add room dialog
  const [addOpen, setAddOpen] = React.useState(false);
  // Edit room dialog
  const [editRoom, setEditRoom] = React.useState<Room | null>(null);
  // Room types manager dialog
  const [typesOpen, setTypesOpen] = React.useState(false);
  const [typeForm, setTypeForm] = React.useState<RoomType | "new" | null>(null);

  const today = ymd(new Date());

  // roomId → active CHECKED_IN reservation (for checkout-due + guest name)
  const activeByRoom = React.useMemo(() => {
    const map = new Map<string, CheckedInReservation>();
    for (const r of checkedin?.items ?? []) {
      if (r.room?.id) map.set(r.room.id, r);
    }
    return map;
  }, [checkedin]);

  const rooms = data?.items ?? [];

  const counts = React.useMemo(() => {
    const c: Record<string, number> = {
      all: rooms.length,
      AVAILABLE: 0,
      OCCUPIED: 0,
      CHECKOUT_DUE: 0,
      RESERVED: 0,
      MAINTENANCE: 0,
      HOUSEKEEPING: 0,
    };
    for (const r of rooms) {
      if (r.status === "OCCUPIED") {
        const res = activeByRoom.get(r.id);
        if (res && ymd(res.checkOut) === today) c.CHECKOUT_DUE += 1;
        else c.OCCUPIED += 1;
      } else if (r.status === "AVAILABLE") c.AVAILABLE += 1;
      else if (r.status === "RESERVED") c.RESERVED += 1;
      else if (r.status === "MAINTENANCE") c.MAINTENANCE += 1;
      if (r.housekeeping === "DIRTY" || r.status === "DIRTY") c.HOUSEKEEPING += 1;
    }
    return c;
  }, [rooms, activeByRoom, today]);

  const filtered = React.useMemo(() => {
    const q = search.trim().toLowerCase();
    return rooms.filter((r) => {
      if (q) {
        const hay = `${r.number} ${r.roomType?.name ?? ""} ${activeByRoom.get(r.id)?.guest?.firstName ?? ""} ${activeByRoom.get(r.id)?.guest?.lastName ?? ""}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      switch (filter) {
        case "all":
          return true;
        case "AVAILABLE":
          return r.status === "AVAILABLE";
        case "OCCUPIED": {
          const res = activeByRoom.get(r.id);
          return r.status === "OCCUPIED" && !(res && ymd(res.checkOut) === today);
        }
        case "CHECKOUT_DUE": {
          const res = activeByRoom.get(r.id);
          return r.status === "OCCUPIED" && !!res && ymd(res.checkOut) === today;
        }
        case "RESERVED":
          return r.status === "RESERVED";
        case "MAINTENANCE":
          return r.status === "MAINTENANCE";
        case "HOUSEKEEPING":
          return r.housekeeping === "DIRTY" || r.status === "DIRTY";
        default:
          return true;
      }
    });
  }, [rooms, filter, search, activeByRoom]);

  async function setRoomStatus(room: Room, status: string, hk?: string) {
    setBusy(true);
    try {
      await apiPost(`/api/rooms/${room.id}/status`, hk ? { status, housekeeping: hk } : { status });
      toast.success(`Room ${room.number} updated`);
      refetch();
      refetchCheckedin();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to update room");
    } finally {
      setBusy(false);
    }
  }

  async function checkout(room: Room) {
    const res = activeByRoom.get(room.id);
    if (!res) return;
    setBusy(true);
    try {
      await apiPost(`/api/reservations/${res.id}/checkout`);
      toast.success(`${res.code} checked out — room ${room.number} set to dirty`);
      refetch();
      refetchCheckedin();
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Check-out failed";
      toast.error(/unsettled|balance/i.test(msg) ? `${msg}. Settle the folio before checkout.` : msg);
    } finally {
      setBusy(false);
    }
  }

  async function deleteRoom(room: Room) {
    try {
      await apiDelete(`/api/rooms/${room.id}`);
      toast.success(`Room ${room.number} deleted`);
      setDetailsRoom(null);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to delete room");
    }
  }

  const FILTERS: { id: string; label: string }[] = [
    { id: "all", label: "All" },
    { id: "AVAILABLE", label: "Available" },
    { id: "OCCUPIED", label: "Occupied" },
    { id: "CHECKOUT_DUE", label: "Checkout Due" },
    { id: "RESERVED", label: "Reservation" },
    { id: "MAINTENANCE", label: "Maintenance" },
    { id: "HOUSEKEEPING", label: "Housekeeping" },
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Room View" crumbs={["Front Desk", "Room View"]}>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setTypesOpen(true)}
          className="h-9 rounded-lg border-gray-200 text-gray-700 hover:bg-gray-50"
        >
          <BedDouble className="mr-1.5 h-4 w-4" /> Manage Room Types
        </Button>
        {canManage && (
          <Button
            size="sm"
            onClick={() => setAddOpen(true)}
            className="h-9 rounded-lg bg-amber-600 text-white hover:bg-amber-700"
          >
            <Plus className="mr-1.5 h-4 w-4" /> Add Room
          </Button>
        )}
      </PageHeader>

      {/* Filter chips + search */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-sm font-medium transition-colors",
                filter === f.id
                  ? "border-amber-600 bg-white text-amber-700 shadow-sm"
                  : "border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:text-gray-900"
              )}
            >
              <span className={cn("h-2 w-2 rounded-full", FILTER_DOTS[f.id] ?? "bg-gray-300")} />
              {f.label}
              <span className="text-gray-400">({counts[f.id] ?? 0})</span>
            </button>
          ))}
        </div>
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search by Room/Name"
          className="w-full lg:w-72"
        />
      </div>

      {/* Room grid */}
      {loading ? (
        <Spinner />
      ) : error ? (
        <EmptyState title="Couldn't load rooms" description={error} />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<BedDouble className="h-7 w-7" />}
          title="No rooms match"
          description="Try a different filter or search term."
        />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
          {filtered.map((room) => {
            const res = activeByRoom.get(room.id);
            const dueToday = !!res && ymd(res.checkOut) === today;
            const guestName = res ? `${res.guest?.firstName ?? ""} ${res.guest?.lastName ?? ""}`.trim() : "";
            return (
              <button
                key={room.id}
                type="button"
                onClick={() => setDetailsRoom(room)}
                className="group overflow-hidden rounded-xl border border-gray-200 bg-white text-left shadow-sm transition-shadow hover:shadow-md"
              >
                <div className={cn("h-1 w-full", STATUS_BAR[room.status] ?? "bg-gray-300")} />
                <div className="flex flex-col items-center px-3 py-4">
                  <div className="text-lg font-bold text-gray-900">{room.number}</div>
                  <div className="mt-0.5 truncate text-center text-xs text-gray-500">
                    {room.roomType?.name ?? "—"} · Floor {room.floor}
                  </div>
                  <div className="mt-2">
                    <StatusBadge status={dueToday ? "CHECKOUT_DUE" : room.status} />
                  </div>
                  {room.status === "OCCUPIED" && guestName ? (
                    <Popover>
                      <PopoverTrigger asChild>
                        <span
                          onClick={(e) => e.stopPropagation()}
                          className="mt-1.5 cursor-help text-[11px] font-medium text-gray-600 underline decoration-dotted underline-offset-2"
                        >
                          {initials(guestName)} · guest
                        </span>
                      </PopoverTrigger>
                      <PopoverContent className="w-52 p-3" onClick={(e) => e.stopPropagation()}>
                        <div className="text-sm font-semibold text-gray-900">{guestName}</div>
                        <div className="mt-0.5 text-xs text-gray-500">
                          Departs {formatDate(res?.checkOut)}
                        </div>
                        <div className="mt-0.5 text-xs text-gray-400">{res?.code}</div>
                      </PopoverContent>
                    </Popover>
                  ) : room.housekeeping === "DIRTY" ? (
                    <span className="mt-1.5 inline-flex items-center gap-1 text-[11px] text-orange-600">
                      <Brush className="h-3 w-3" /> needs cleaning
                    </span>
                  ) : room.notes ? (
                    <span className="mt-1.5 max-w-full truncate text-[11px] text-gray-400">{room.notes}</span>
                  ) : null}
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* Room details dialog */}
      <Dialog open={!!detailsRoom} onOpenChange={(open) => !open && setDetailsRoom(null)}>
        <DialogContent className="sm:max-w-md">
          {detailsRoom && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  Room {detailsRoom.number}
                  <StatusBadge status={detailsRoom.status} />
                </DialogTitle>
                <DialogDescription>
                  {detailsRoom.roomType?.name ?? "—"} · Floor {detailsRoom.floor} ·{" "}
                  {formatMoney(detailsRoom.roomType?.baseRate ?? 0)}/night
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between rounded-lg bg-gray-50 px-3 py-2">
                  <span className="text-gray-500">Housekeeping</span>
                  <span className="font-medium text-gray-900">
                    {detailsRoom.housekeeping === "CLEAN" ? "Clean" : "Dirty"}
                  </span>
                </div>
                {detailsRoom.notes && (
                  <div className="rounded-lg bg-gray-50 px-3 py-2">
                    <div className="text-xs text-gray-500">Notes</div>
                    <div className="text-gray-800">{detailsRoom.notes}</div>
                  </div>
                )}
                {activeByRoom.get(detailsRoom.id) && (
                  <div className="rounded-lg border border-amber-100 bg-amber-50 px-3 py-2">
                    <div className="font-medium text-gray-900">
                      {activeByRoom.get(detailsRoom.id)!.guest?.firstName}{" "}
                      {activeByRoom.get(detailsRoom.id)!.guest?.lastName} (in-house)
                    </div>
                    <div className="text-xs text-gray-500">
                      {activeByRoom.get(detailsRoom.id)!.code} · departs{" "}
                      {formatDate(activeByRoom.get(detailsRoom.id)!.checkOut)}
                    </div>
                  </div>
                )}
                {parseAmenities(detailsRoom.roomType?.amenities).length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {parseAmenities(detailsRoom.roomType?.amenities).map((a) => (
                      <span key={a} className="rounded-full bg-gray-100 px-2 py-0.5 text-xs text-gray-600">
                        {a}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <DialogFooter className="flex flex-wrap gap-2 sm:justify-start">
                {detailsRoom.housekeeping === "DIRTY" &&
                  detailsRoom.status !== "OCCUPIED" &&
                  detailsRoom.status !== "RESERVED" && (
                  <Button
                    size="sm"
                    disabled={busy}
                    onClick={() => void setRoomStatus(detailsRoom, "AVAILABLE", "CLEAN")}
                    className="h-8 rounded-lg bg-amber-600 text-xs text-white hover:bg-amber-700"
                  >
                    <Sparkles className="mr-1 h-3.5 w-3.5" /> Mark Clean
                  </Button>
                )}
                {detailsRoom.status === "AVAILABLE" && (
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={busy}
                    onClick={() => void setRoomStatus(detailsRoom, "DIRTY")}
                    className="h-8 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                  >
                    <Brush className="mr-1 h-3.5 w-3.5" /> Mark Dirty
                  </Button>
                )}
                {(detailsRoom.status === "AVAILABLE" || detailsRoom.status === "RESERVED") && (
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={busy}
                    onClick={() => void setRoomStatus(detailsRoom, "MAINTENANCE")}
                    className="h-8 rounded-lg border-gray-200 text-xs text-gray-700 hover:bg-gray-50"
                  >
                    <Wrench className="mr-1 h-3.5 w-3.5" /> Start Maintenance
                  </Button>
                )}
                {detailsRoom.status === "MAINTENANCE" && (
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={busy}
                    onClick={() => void setRoomStatus(detailsRoom, "AVAILABLE")}
                    className="h-8 rounded-lg border-emerald-200 text-xs text-emerald-700 hover:bg-emerald-50"
                  >
                    <Hammer className="mr-1 h-3.5 w-3.5" /> End Maintenance
                  </Button>
                )}
                {activeByRoom.get(detailsRoom.id) && (
                  <>
                    <Button
                      size="sm"
                      disabled={busy}
                      onClick={() => void checkout(detailsRoom)}
                      className="h-8 rounded-lg bg-rose-600 text-xs text-white hover:bg-rose-700"
                    >
                      Check-out
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setDetailsRoom(null);
                        setModule("invoices");
                      }}
                      className="h-8 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                    >
                      <ReceiptText className="mr-1 h-3.5 w-3.5" /> View Folio
                    </Button>
                  </>
                )}
                {canManage && (
                  <>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditRoom(detailsRoom);
                        setDetailsRoom(null);
                      }}
                      className="h-8 rounded-lg border-gray-200 text-xs text-gray-700 hover:bg-gray-50"
                    >
                      <Pencil className="mr-1 h-3.5 w-3.5" /> Edit
                    </Button>
                    <ConfirmButton
                      title={`Delete room ${detailsRoom.number}?`}
                      description="Rooms with active reservations cannot be deleted."
                      confirmLabel="Delete"
                      onConfirm={() => deleteRoom(detailsRoom)}
                    >
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 rounded-lg border-rose-200 text-xs text-rose-600 hover:bg-rose-50"
                      >
                        <Trash2 className="mr-1 h-3.5 w-3.5" /> Delete
                      </Button>
                    </ConfirmButton>
                  </>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      <AddRoomDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        roomTypes={roomTypesData ?? []}
        onSaved={() => {
          refetch();
          refetchTypes();
        }}
      />

      <EditRoomDialog
        room={editRoom}
        onClose={() => setEditRoom(null)}
        roomTypes={roomTypesData ?? []}
        onSaved={() => {
          refetch();
          refetchTypes();
        }}
      />

      <RoomTypesDialog
        open={typesOpen}
        onOpenChange={setTypesOpen}
        roomTypes={roomTypesData ?? []}
        loading={!roomTypesData}
        onSaved={() => refetchTypes()}
        editType={typeForm}
        setEditType={setTypeForm}
      />
    </div>
  );
}

// ─── Add room dialog ──────────────────────────────────────────

function AddRoomDialog({
  open,
  onOpenChange,
  roomTypes,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  roomTypes: RoomType[];
  onSaved: () => void;
}) {
  const [number, setNumber] = React.useState("");
  const [floor, setFloor] = React.useState("1");
  const [roomTypeId, setRoomTypeId] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setNumber("");
      setFloor("1");
      setNotes("");
      setRoomTypeId(roomTypes[0]?.id ?? "");
    }
  }, [open, roomTypes]);

  async function save() {
    if (!number.trim() || !roomTypeId) {
      toast.error("Room number and type are required");
      return;
    }
    setBusy(true);
    try {
      await apiPost("/api/rooms", {
        number: number.trim(),
        floor: Number(floor) || 1,
        roomTypeId,
        notes: notes.trim() || undefined,
      });
      toast.success(`Room ${number.trim()} added`);
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to add room");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Add Room</DialogTitle>
          <DialogDescription>Create a new room in the inventory.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Room number" required>
              <Input value={number} onChange={(e) => setNumber(e.target.value)} placeholder="e.g. 305" />
            </Field>
            <Field label="Floor">
              <Input type="number" value={floor} onChange={(e) => setFloor(e.target.value)} />
            </Field>
          </div>
          <Field label="Room type" required>
            <Select value={roomTypeId} onValueChange={setRoomTypeId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                {roomTypes.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.name} — {formatMoney(t.baseRate)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Notes">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="Optional" />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button disabled={busy} onClick={() => void save()} className="bg-amber-600 hover:bg-amber-700">
            {busy ? "Saving..." : "Add Room"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Edit room dialog ─────────────────────────────────────────

function EditRoomDialog({
  room,
  onClose,
  roomTypes,
  onSaved,
}: {
  room: Room | null;
  onClose: () => void;
  roomTypes: RoomType[];
  onSaved: () => void;
}) {
  const [number, setNumber] = React.useState("");
  const [floor, setFloor] = React.useState("1");
  const [roomTypeId, setRoomTypeId] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    if (room) {
      setNumber(room.number);
      setFloor(String(room.floor ?? 1));
      setRoomTypeId(room.roomType?.id ?? "");
      setNotes(room.notes ?? "");
    }
  }, [room]);

  async function save() {
    if (!room) return;
    setBusy(true);
    try {
      await apiPut(`/api/rooms/${room.id}`, {
        number: number.trim(),
        floor: Number(floor) || 1,
        roomTypeId,
        notes: notes.trim() || null,
      });
      toast.success(`Room ${number.trim()} updated`);
      onClose();
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to update room");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={!!room} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Edit Room {room?.number}</DialogTitle>
          <DialogDescription>Status changes are made from the room card actions.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Room number" required>
              <Input value={number} onChange={(e) => setNumber(e.target.value)} />
            </Field>
            <Field label="Floor">
              <Input type="number" value={floor} onChange={(e) => setFloor(e.target.value)} />
            </Field>
          </div>
          <Field label="Room type" required>
            <Select value={roomTypeId} onValueChange={setRoomTypeId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                {roomTypes.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.name} — {formatMoney(t.baseRate)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Notes">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button disabled={busy} onClick={() => void save()} className="bg-amber-600 hover:bg-amber-700">
            {busy ? "Saving..." : "Save changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Room types manager ───────────────────────────────────────

function RoomTypesDialog({
  open,
  onOpenChange,
  roomTypes,
  loading,
  onSaved,
  editType,
  setEditType,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  roomTypes: RoomType[];
  loading: boolean;
  onSaved: () => void;
  editType: RoomType | "new" | null;
  setEditType: (t: RoomType | "new" | null) => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Room Types</DialogTitle>
          <DialogDescription>Rates, capacity and amenities per room category.</DialogDescription>
        </DialogHeader>
        {loading ? (
          <Spinner />
        ) : (
          <div className="max-h-[60vh] space-y-2 overflow-y-auto pr-1">
            {roomTypes.length === 0 && <EmptyState title="No room types yet" />}
            {roomTypes.map((t) => (
              <div key={t.id} className="rounded-xl border border-gray-200 p-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-semibold text-gray-900">{t.name}</div>
                    <div className="mt-0.5 text-xs text-gray-500">
                      {formatMoney(t.baseRate)}/night · {t.capacity} guests
                      {typeof t.extraAdultCharge === "number" && t.extraAdultCharge > 0
                        ? ` · extra adult ${formatMoney(t.extraAdultCharge)}`
                        : ""}
                      {` · ${t.roomCount ?? 0} rooms`}
                      {typeof t.activeReservations === "number" && t.activeReservations > 0
                        ? ` · ${t.activeReservations} active`
                        : ""}
                    </div>
                    {t.description && <div className="mt-1 text-xs text-gray-500">{t.description}</div>}
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {parseAmenities(t.amenities).map((a) => (
                        <span key={a} className="rounded-full bg-amber-50 px-2 py-0.5 text-[11px] text-amber-700">
                          {a}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="flex shrink-0 flex-col gap-1.5">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setEditType(t)}
                      className="h-8 rounded-lg text-xs"
                    >
                      <Pencil className="mr-1 h-3.5 w-3.5" /> Edit
                    </Button>
                    <ConfirmButton
                      title={`Delete ${t.name}?`}
                      description="Room types with rooms cannot be deleted."
                      confirmLabel="Delete"
                      onConfirm={async () => {
                        try {
                          await apiDelete(`/api/room-types/${t.id}`);
                          toast.success(`${t.name} deleted`);
                          onSaved();
                        } catch (e) {
                          toast.error(e instanceof Error ? e.message : "Failed to delete room type");
                        }
                      }}
                    >
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 rounded-lg border-rose-200 text-xs text-rose-600 hover:bg-rose-50"
                      >
                        <Trash2 className="mr-1 h-3.5 w-3.5" /> Delete
                      </Button>
                    </ConfirmButton>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button
            onClick={() => setEditType("new")}
            className="bg-amber-600 hover:bg-amber-700"
          >
            <Plus className="mr-1.5 h-4 w-4" /> Add Room Type
          </Button>
        </DialogFooter>
      </DialogContent>

      {editType !== null && (
        <RoomTypeFormDialog
          existing={editType === "new" ? null : editType}
          onClose={() => setEditType(null)}
          onSaved={() => {
            setEditType(null);
            onSaved();
          }}
        />
      )}
    </Dialog>
  );
}

function RoomTypeFormDialog({
  existing,
  onClose,
  onSaved,
}: {
  existing: RoomType | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = React.useState(existing?.name ?? "");
  const [description, setDescription] = React.useState(existing?.description ?? "");
  const [baseRate, setBaseRate] = React.useState(String(existing?.baseRate ?? ""));
  const [capacity, setCapacity] = React.useState(String(existing?.capacity ?? 2));
  const [extraAdultCharge, setExtraAdultCharge] = React.useState(String(existing?.extraAdultCharge ?? 0));
  const [amenities, setAmenities] = React.useState(
    parseAmenities(existing?.amenities).join(", ")
  );
  const [busy, setBusy] = React.useState(false);

  async function save() {
    if (!name.trim() || !baseRate) {
      toast.error("Name and base rate are required");
      return;
    }
    const body = {
      name: name.trim(),
      description: description.trim() || undefined,
      baseRate: Number(baseRate),
      capacity: Number(capacity) || 2,
      extraAdultCharge: Number(extraAdultCharge) || 0,
      amenities: amenities.split(",").map((s) => s.trim()).filter(Boolean),
    };
    setBusy(true);
    try {
      if (existing) {
        await apiPut(`/api/room-types/${existing.id}`, body);
        toast.success("Room type updated");
      } else {
        await apiPost("/api/room-types", body);
        toast.success("Room type added");
      }
      onClose();
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to save room type");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={true} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{existing ? `Edit ${existing.name}` : "Add Room Type"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <Field label="Name" required>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Deluxe Room" />
          </Field>
          <Field label="Description">
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
          </Field>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Base rate (₹)" required>
              <Input type="number" value={baseRate} onChange={(e) => setBaseRate(e.target.value)} />
            </Field>
            <Field label="Capacity">
              <Input type="number" value={capacity} onChange={(e) => setCapacity(e.target.value)} />
            </Field>
            <Field label="Extra adult (₹)">
              <Input type="number" value={extraAdultCharge} onChange={(e) => setExtraAdultCharge(e.target.value)} />
            </Field>
          </div>
          <Field label="Amenities (comma separated)">
            <Input
              value={amenities}
              onChange={(e) => setAmenities(e.target.value)}
              placeholder="Wi-Fi, AC, TV, Balcony"
            />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button disabled={busy} onClick={() => void save()} className="bg-amber-600 hover:bg-amber-700">
            {busy ? "Saving..." : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
