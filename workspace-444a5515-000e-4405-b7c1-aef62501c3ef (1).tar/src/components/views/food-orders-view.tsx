"use client";

import * as React from "react";
import {
  BedDouble,
  Minus,
  Plus,
  ReceiptText,
  ShoppingBag,
  Trash2,
  UtensilsCrossed,
  Wine,
} from "lucide-react";
import { toast } from "sonner";
import { apiGet, apiPost, apiPut, qs } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import {
  ConfirmButton,
  EmptyState,
  Field,
  PageHeader,
  SearchInput,
  Spinner,
  StatusBadge,
  formatMoney,
  formatDateTime,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// ─── Types ────────────────────────────────────────────────────

type MenuItem = {
  id: string;
  name: string;
  category: string;
  description: string | null;
  price: number;
  available: boolean;
  isVeg: boolean;
};

type OrderItem = { id: string; menuItemId: string; quantity: number; unitPrice: number; menuItem: MenuItem | null };

type Order = {
  id: string;
  orderNumber: string;
  type: string;
  status: string;
  subtotal: number;
  tax: number;
  totalAmount: number;
  chargedToRoom: boolean;
  tableNumber: string | null;
  notes: string | null;
  createdAt: string;
  deliveredAt: string | null;
  items: OrderItem[];
  guest: { firstName: string; lastName: string } | null;
  reservation: {
    id: string;
    code: string;
    room: { id: string; number: string } | null;
    guest: { firstName: string; lastName: string } | null;
  } | null;
};

type OrdersData = {
  items: Order[];
  counts: { PENDING: number; ACCEPTED: number; DELIVERED: number; PARTIALLY_DELIVERED: number; CANCELLED: number };
};

type CheckedInData = {
  items: {
    id: string;
    code: string;
    guest: { firstName: string; lastName: string } | null;
    room: { number: string } | null;
  }[];
};

function timeAgo(d: string): string {
  const then = new Date(d).getTime();
  if (isNaN(then)) return "";
  const secs = Math.max(0, Math.floor((Date.now() - then) / 1000));
  if (secs < 60) return "just now";
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

const TYPE_META: Record<string, { label: string; cls: string; icon: React.ReactNode }> = {
  ROOM_SERVICE: {
    label: "Room Service",
    cls: "bg-amber-100 text-amber-700",
    icon: <BedDouble className="h-3 w-3" />,
  },
  RESTAURANT: {
    label: "Restaurant",
    cls: "bg-teal-100 text-teal-700",
    icon: <UtensilsCrossed className="h-3 w-3" />,
  },
  BAR: { label: "Bar", cls: "bg-amber-100 text-amber-700", icon: <Wine className="h-3 w-3" /> },
};

const CATEGORY_TABS = [
  { id: "STARTER", label: "Starters" },
  { id: "MAIN_COURSE", label: "Main Course" },
  { id: "BREADS_RICE", label: "Breads & Rice" },
  { id: "DESSERTS", label: "Desserts" },
  { id: "BEVERAGES", label: "Beverages" },
  { id: "BAR", label: "Bar" },
];

function orderLocation(o: Order): string {
  if (o.reservation?.room?.number) return `Room ${o.reservation.room.number}`;
  if (o.tableNumber) return `Table ${o.tableNumber}`;
  return "—";
}

// ─── View ─────────────────────────────────────────────────────

export default function FoodOrdersView(_props: ViewProps) {
  const [statusTab, setStatusTab] = React.useState("ALL");
  const [scope, setScope] = React.useState("all");
  const [search, setSearch] = React.useState("");
  const [debounced, setDebounced] = React.useState("");
  React.useEffect(() => {
    const t = window.setTimeout(() => setDebounced(search), 350);
    return () => window.clearTimeout(t);
  }, [search]);

  const url = `/api/orders${qs({
    status: statusTab === "ALL" ? "" : statusTab,
    scope,
    search: debounced,
  })}`;
  const { data, loading, error, refetch } = useApi<OrdersData>(url);
  const { data: menu } = useApi<MenuItem[]>("/api/menu");

  const [addOpen, setAddOpen] = React.useState(false);
  const [busyId, setBusyId] = React.useState<string | null>(null);

  async function setStatus(order: Order, status: string) {
    setBusyId(order.id);
    try {
      await apiPut(`/api/orders/${order.id}`, { status });
      toast.success(`${order.orderNumber} → ${status.replace(/_/g, " ").toLowerCase()}`);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to update order");
    } finally {
      setBusyId(null);
    }
  }

  async function createInvoice(order: Order) {
    setBusyId(order.id);
    try {
      const res = await apiPost<{ invoice: { number: string } }>(`/api/orders/${order.id}/invoice`);
      toast.success(`Invoice ${res.invoice?.number ?? "created"} for ${order.orderNumber}`);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to create invoice");
    } finally {
      setBusyId(null);
    }
  }

  const counts = data?.counts;
  const statusTabs = [
    { id: "PENDING", label: "Pending", count: counts?.PENDING },
    { id: "ACCEPTED", label: "Accepted", count: counts?.ACCEPTED },
    { id: "DELIVERED", label: "Delivered", count: counts?.DELIVERED },
    { id: "PARTIALLY_DELIVERED", label: "Partially delivered", count: counts?.PARTIALLY_DELIVERED },
    { id: "CANCELLED", label: "Cancelled", count: counts?.CANCELLED },
    { id: "ALL", label: "All", count:
      counts
        ? counts.PENDING + counts.ACCEPTED + counts.DELIVERED + counts.PARTIALLY_DELIVERED + counts.CANCELLED
        : undefined
    },
  ];
  const scopeTabs = [
    { id: "all", label: "All" },
    { id: "checkins", label: "Check-ins" },
    { id: "restaurant", label: "Restaurant" },
    { id: "bar", label: "Bar" },
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="F&B Orders" crumbs={["Food", "F&B Orders"]}>
        <Button
          size="sm"
          onClick={() => setAddOpen(true)}
          className="h-9 rounded-lg bg-amber-600 text-white hover:bg-amber-700"
        >
          <Plus className="mr-1.5 h-4 w-4" /> Add Order
        </Button>
      </PageHeader>

      {/* Status tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {statusTabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setStatusTab(t.id)}
            className={cn(
              "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
              statusTab === t.id
                ? "border-amber-600 bg-white text-amber-700 shadow-sm"
                : "border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:text-gray-900"
            )}
          >
            {t.label}
            {typeof t.count === "number" && <span className="ml-1 text-gray-400">({t.count})</span>}
          </button>
        ))}
      </div>

      {/* Scope + search */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          {scopeTabs.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setScope(t.id)}
              className={cn(
                "rounded-full border px-3.5 py-1 text-xs font-medium transition-colors",
                scope === t.id
                  ? "border-amber-600 bg-white text-amber-700"
                  : "border-gray-200 bg-white text-gray-500 hover:border-gray-300 hover:text-gray-700"
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search room / name / order no."
          className="w-full lg:w-72"
        />
      </div>

      {/* Order cards */}
      {loading ? (
        <Spinner />
      ) : error ? (
        <EmptyState title="Couldn't load orders" description={error} />
      ) : (data?.items.length ?? 0) === 0 ? (
        <EmptyState
          icon={<ShoppingBag className="h-7 w-7" />}
          title="No orders here"
          description="F&B orders will show up as guests order from the menu."
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-2 xl:grid-cols-3">
          {data!.items.map((o) => {
            const meta = TYPE_META[o.type] ?? {
              label: o.type,
              cls: "bg-gray-100 text-gray-600",
              icon: <UtensilsCrossed className="h-3 w-3" />,
            };
            const guestLabel =
              o.guest
                ? `${o.guest.firstName} ${o.guest.lastName}`
                : o.reservation?.guest
                  ? `${o.reservation.guest.firstName} ${o.reservation.guest.lastName}`
                  : null;
            return (
              <div key={o.id} className="flex flex-col rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-gray-900">{o.orderNumber}</span>
                      <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium", meta.cls)}>
                        {meta.icon} {meta.label}
                      </span>
                    </div>
                    <div className="mt-0.5 text-xs text-gray-400">
                      {timeAgo(o.createdAt)} · {formatDateTime(o.createdAt)}
                    </div>
                  </div>
                  <StatusBadge status={o.status} />
                </div>

                <div className="mt-3 space-y-1 border-t border-gray-100 pt-3">
                  {o.items.map((it) => (
                    <div key={it.id} className="flex items-baseline justify-between text-sm">
                      <span className="truncate pr-2 text-gray-700">
                        {it.menuItem?.name ?? "Item"}
                        {it.quantity > 1 && <span className="text-gray-400"> × {it.quantity}</span>}
                      </span>
                      <span className="whitespace-nowrap text-gray-600">{formatMoney(it.unitPrice * it.quantity)}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-2 space-y-0.5 border-t border-gray-100 pt-2 text-xs text-gray-500">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>{formatMoney(o.subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>GST 5%</span>
                    <span>{formatMoney(o.tax)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-gray-900">
                    <span>Total</span>
                    <span>{formatMoney(o.totalAmount)}</span>
                  </div>
                </div>

                <div className="mt-2 flex items-center justify-between text-xs text-gray-500">
                  <span>
                    {orderLocation(o)}
                    {guestLabel ? ` · ${guestLabel}` : ""}
                    {o.chargedToRoom ? " · charged to room" : ""}
                  </span>
                  {o.notes && <span className="max-w-[50%] truncate italic text-gray-400">“{o.notes}”</span>}
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5 border-t border-gray-100 pt-3">
                  {o.status === "PENDING" && (
                    <Button
                      size="sm"
                      disabled={busyId === o.id}
                      onClick={() => void setStatus(o, "ACCEPTED")}
                      className="h-8 rounded-lg bg-amber-600 text-xs text-white hover:bg-amber-700"
                    >
                      Accept
                    </Button>
                  )}
                  {(o.status === "PENDING" || o.status === "ACCEPTED") && (
                    <>
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={busyId === o.id}
                        onClick={() => void setStatus(o, "DELIVERED")}
                        className="h-8 rounded-lg border-emerald-200 text-xs text-emerald-700 hover:bg-emerald-50"
                      >
                        Mark Delivered
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={busyId === o.id}
                        onClick={() => void setStatus(o, "PARTIALLY_DELIVERED")}
                        className="h-8 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                      >
                        Partial
                      </Button>
                      <ConfirmButton
                        title={`Cancel ${o.orderNumber}?`}
                        description="Cancelled orders cannot be reopened."
                        confirmLabel="Cancel Order"
                        onConfirm={() => setStatus(o, "CANCELLED")}
                      >
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={busyId === o.id}
                          className="h-8 rounded-lg border-rose-200 text-xs text-rose-600 hover:bg-rose-50"
                        >
                          <Trash2 className="mr-1 h-3.5 w-3.5" /> Cancel
                        </Button>
                      </ConfirmButton>
                    </>
                  )}
                  {o.status === "DELIVERED" && (
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={busyId === o.id}
                      onClick={() => void createInvoice(o)}
                      className="h-8 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                    >
                      <ReceiptText className="mr-1 h-3.5 w-3.5" /> Create Invoice
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <AddOrderDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        menu={menu ?? []}
        onSaved={refetch}
      />
    </div>
  );
}

// ─── Add order dialog ─────────────────────────────────────────

function AddOrderDialog({
  open,
  onOpenChange,
  menu,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  menu: MenuItem[];
  onSaved: () => void;
}) {
  const [type, setType] = React.useState("ROOM_SERVICE");
  const [reservationId, setReservationId] = React.useState("");
  const [tableNumber, setTableNumber] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const [cat, setCat] = React.useState("STARTER");
  const [cart, setCart] = React.useState<Record<string, number>>({});
  const [busy, setBusy] = React.useState(false);

  const { data: checkedin } = useApi<CheckedInData>(open ? "/api/reservations?tab=checkedin" : null);

  React.useEffect(() => {
    if (!open) {
      setType("ROOM_SERVICE");
      setReservationId("");
      setTableNumber("");
      setNotes("");
      setCat("STARTER");
      setCart({});
    }
  }, [open]);

  const cartItems = Object.entries(cart)
    .map(([id, qty]) => ({ item: menu.find((m) => m.id === id), qty }))
    .filter((x): x is { item: MenuItem; qty: number } => !!x.item && x.qty > 0);
  const subtotal = cartItems.reduce((s, x) => s + x.item.price * x.qty, 0);
  const tax = Math.round(subtotal * 0.05 * 100) / 100;

  function bump(id: string, delta: number) {
    setCart((p) => {
      const next = { ...p, [id]: Math.max(0, (p[id] ?? 0) + delta) };
      if (next[id] === 0) delete next[id];
      return next;
    });
  }

  async function save() {
    if (cartItems.length === 0) {
      toast.error("Add at least one menu item");
      return;
    }
    if (type === "ROOM_SERVICE" && !reservationId) {
      toast.error("Pick an in-house reservation for room service");
      return;
    }
    if (type !== "ROOM_SERVICE" && !tableNumber.trim()) {
      toast.error("Table number is required");
      return;
    }
    setBusy(true);
    try {
      await apiPost("/api/orders", {
        type,
        reservationId: type === "ROOM_SERVICE" ? reservationId : undefined,
        tableNumber: type !== "ROOM_SERVICE" ? tableNumber.trim() : undefined,
        notes: notes.trim() || undefined,
        items: cartItems.map((x) => ({ menuItemId: x.item.id, quantity: x.qty })),
      });
      toast.success("Order created");
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to create order");
    } finally {
      setBusy(false);
    }
  }

  const catItems = menu.filter((m) => m.category === cat && m.available);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>New F&amp;B Order</DialogTitle>
          <DialogDescription>Pick items from the menu — totals update live.</DialogDescription>
        </DialogHeader>

        {/* Type radio */}
        <div className="flex gap-2">
          {[
            { id: "ROOM_SERVICE", label: "Room service" },
            { id: "RESTAURANT", label: "Restaurant" },
            { id: "BAR", label: "Bar" },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setType(t.id)}
              className={cn(
                "flex-1 rounded-lg border px-3 py-2 text-sm font-medium transition-colors",
                type === t.id
                  ? "border-amber-600 bg-amber-50 text-amber-700"
                  : "border-gray-200 text-gray-600 hover:border-gray-300"
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        {type === "ROOM_SERVICE" ? (
          <Field label="In-house reservation" required>
            <Select value={reservationId} onValueChange={setReservationId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder={checkedin ? "Select guest — room #" : "Loading check-ins…"} />
              </SelectTrigger>
              <SelectContent>
                {(checkedin?.items ?? []).map((r) => (
                  <SelectItem key={r.id} value={r.id}>
                    {r.guest ? `${r.guest.firstName} ${r.guest.lastName}` : r.code} — Room {r.room?.number ?? "?"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
        ) : (
          <Field label="Table number" required>
            <Input value={tableNumber} onChange={(e) => setTableNumber(e.target.value)} placeholder="e.g. T4" />
          </Field>
        )}

        {/* Menu picker + cart */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <div className="mb-2 flex flex-wrap gap-1.5">
              {CATEGORY_TABS.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setCat(c.id)}
                  className={cn(
                    "rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors",
                    cat === c.id
                      ? "border-amber-600 bg-white text-amber-700"
                      : "border-gray-200 bg-white text-gray-500 hover:border-gray-300"
                  )}
                >
                  {c.label}
                </button>
              ))}
            </div>
            <div className="max-h-56 space-y-1 overflow-y-auto pr-1">
              {catItems.length === 0 && <div className="py-4 text-center text-xs text-gray-400">No items in this category.</div>}
              {catItems.map((m) => (
                <div key={m.id} className="flex items-center justify-between rounded-lg border border-gray-100 px-2.5 py-1.5">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 text-sm text-gray-800">
                      {m.isVeg && <span className="h-2 w-2 shrink-0 rounded-full border border-emerald-600 bg-emerald-500" />}
                      <span className="truncate">{m.name}</span>
                    </div>
                    <div className="text-xs text-gray-400">{formatMoney(m.price)}</div>
                  </div>
                  <Button size="sm" variant="outline" className="h-7 w-7 rounded-lg p-0" onClick={() => bump(m.id, 1)}>
                    <Plus className="h-3.5 w-3.5" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Cart */}
          <div className="rounded-xl border border-gray-200 p-3">
            <div className="text-xs font-medium uppercase tracking-wide text-gray-400">Cart</div>
            {cartItems.length === 0 ? (
              <div className="py-6 text-center text-xs text-gray-400">Tap + on menu items to add them.</div>
            ) : (
              <div className="mt-2 space-y-2">
                {cartItems.map((x) => (
                  <div key={x.item.id} className="flex items-center justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm text-gray-800">{x.item.name}</div>
                      <div className="text-xs text-gray-400">{formatMoney(x.item.price * x.qty)}</div>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => bump(x.item.id, -1)}
                        className="flex h-6 w-6 items-center justify-center rounded-md border border-gray-200 text-gray-500 hover:bg-gray-50"
                      >
                        <Minus className="h-3 w-3" />
                      </button>
                      <span className="w-5 text-center text-sm font-medium">{x.qty}</span>
                      <button
                        type="button"
                        onClick={() => bump(x.item.id, 1)}
                        className="flex h-6 w-6 items-center justify-center rounded-md border border-gray-200 text-gray-500 hover:bg-gray-50"
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                ))}
                <div className="space-y-0.5 border-t border-gray-100 pt-2 text-xs text-gray-500">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>{formatMoney(subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>GST 5%</span>
                    <span>{formatMoney(tax)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-gray-900">
                    <span>Total</span>
                    <span>{formatMoney(subtotal + tax)}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <Field label="Notes">
          <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="Less spicy, no onions…" />
        </Field>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button disabled={busy} onClick={() => void save()} className="bg-amber-600 hover:bg-amber-700">
            {busy ? "Placing..." : "Place Order"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
