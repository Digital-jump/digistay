'use client';

import * as React from "react";
import { Ban, Download, Eye, Printer, Wallet } from "lucide-react";
import { toast } from "sonner";
import { apiGet, apiPost, qs } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import {
  ConfirmButton,
  DataTable,
  downloadCsv,
  EmptyState,
  Field,
  formatDate,
  formatDateTime,
  formatMoney,
  Money,
  PageHeader,
  SearchInput,
  Spinner,
  StatusBadge,
  TabsBar,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// ─── Types ────────────────────────────────────────────────────

type GuestLite = { id: string; firstName: string; lastName: string; phone?: string | null; email?: string | null } | null;
type FolioLite = { id: string; name: string; type: string } | null;
type ReservationLite = { id: string; code: string } | null;

type InvoiceRow = {
  id: string;
  number: string;
  billingType: string;
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  paidAmount: number;
  status: string;
  issuedAt: string;
  notes: string | null;
  guest: GuestLite;
  reservation: ReservationLite;
  folio: FolioLite;
};

type InvoicesData = {
  items: InvoiceRow[];
  counts: { all: number; company: number; individual: number; ota: number; uninvoiced: number };
};

type InvoiceDetail = InvoiceRow & {
  items: { id: string; description: string; type: string; quantity: number; unitPrice: number; amount: number }[];
  payments: {
    id: string;
    amount: number;
    method: string;
    reference: string | null;
    remarks: string | null;
    paidAt: string;
    receivedBy: string | null;
  }[];
};

type CheckedInReservation = {
  id: string;
  code: string;
  checkIn: string;
  checkOut: string;
  totalAmount: number;
  guest: GuestLite;
  roomType: { name: string } | null;
  room: { number: string } | null;
};

const METHOD_LABELS: Record<string, string> = {
  CASH: "Cash",
  UPI: "UPI",
  DEBIT_CARD: "Debit Card",
  CREDIT_CARD: "Credit Card",
  BANK_TRANSFER: "Bank Transfer",
  RAZORPAY: "Razorpay",
  OTHER: "Other",
};
const METHODS = Object.keys(METHOD_LABELS);

const BILLING_BADGE: Record<string, string> = {
  INDIVIDUAL: "bg-sky-100 text-sky-700",
  COMPANY: "bg-amber-100 text-amber-700",
  OTA: "bg-amber-100 text-amber-700",
};

function BillingBadge({ type }: { type: string }) {
  return (
    <span
      className={cn(
        "inline-flex whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium",
        BILLING_BADGE[type] ?? "bg-gray-100 text-gray-600"
      )}
    >
      {type.replace(/_/g, " ")}
    </span>
  );
}

function guestFullName(g: GuestLite): string {
  return g ? `${g.firstName} ${g.lastName}` : "—";
}

// ─── View ─────────────────────────────────────────────────────

export default function InvoicesView({ user: _user }: ViewProps) {
  const [tab, setTab] = React.useState("all");
  const [search, setSearch] = React.useState("");
  const [from, setFrom] = React.useState("");
  const [to, setTo] = React.useState("");

  const billingType = tab === "COMPANY" || tab === "INDIVIDUAL" || tab === "OTA" ? tab : undefined;
  const url = `/api/invoices${qs({ billingType, search, from: from || undefined, to: to || undefined })}`;
  const { data, loading, error, refetch } = useApi<InvoicesData>(url);

  // Uninvoiced tab: checked-in reservations without an invoice
  const uninvoicedEnabled = tab === "uninvoiced";
  const { data: checkedIn } = useApi<{ items: CheckedInReservation[] }>(
    uninvoicedEnabled ? "/api/reservations?tab=checkedin" : null
  );
  const invoicedReservationIds = React.useMemo(() => {
    const ids = new Set<string>();
    (data?.items ?? []).forEach((i) => {
      if (i.reservation?.id) ids.add(i.reservation.id);
    });
    return ids;
  }, [data]);
  const uninvoicedList = React.useMemo(
    () => (checkedIn?.items ?? []).filter((r) => !invoicedReservationIds.has(r.id)),
    [checkedIn, invoicedReservationIds]
  );

  // Detail dialog
  const [detailOpen, setDetailOpen] = React.useState(false);
  const [detail, setDetail] = React.useState<InvoiceDetail | null>(null);
  const [detailLoading, setDetailLoading] = React.useState(false);

  // Record payment dialog
  const [payOpen, setPayOpen] = React.useState(false);
  const [payTarget, setPayTarget] = React.useState<InvoiceRow | null>(null);
  const [payAmount, setPayAmount] = React.useState("");
  const [payMethod, setPayMethod] = React.useState("CASH");
  const [payReference, setPayReference] = React.useState("");
  const [paySaving, setPaySaving] = React.useState(false);

  const balanceDue = payTarget ? Math.max(0, payTarget.total - payTarget.paidAmount) : 0;
  const detailBalanceDue = detail ? Math.max(0, detail.total - detail.paidAmount) : 0;

  async function openDetail(inv: InvoiceRow) {
    setDetailOpen(true);
    setDetailLoading(true);
    setDetail(null);
    try {
      const d = await apiGet<InvoiceDetail>(`/api/invoices/${inv.id}`);
      setDetail(d);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to load invoice");
      setDetailOpen(false);
    } finally {
      setDetailLoading(false);
    }
  }

  async function refreshDetail(id: string) {
    try {
      setDetail(await apiGet<InvoiceDetail>(`/api/invoices/${id}`));
    } catch {
      /* keep old detail on refetch failure */
    }
    refetch();
  }

  function openPayDialog(inv: InvoiceRow) {
    setPayTarget(inv);
    setPayOpen(true);
    setPayAmount(String(Math.max(0, inv.total - inv.paidAmount)));
    setPayMethod("CASH");
    setPayReference("");
  }

  async function submitPayment() {
    if (!payTarget) return;
    const value = Number(payAmount);
    if (!value || value <= 0) {
      toast.error("Enter an amount greater than 0");
      return;
    }
    if (value > balanceDue + 0.001) {
      toast.error(`Amount cannot exceed balance due ${formatMoney(balanceDue)}`);
      return;
    }
    setPaySaving(true);
    try {
      await apiPost(`/api/invoices/${payTarget.id}/payments`, {
        amount: value,
        method: payMethod,
        reference: payReference || undefined,
      });
      toast.success(`Payment of ${formatMoney(value)} recorded`);
      setPayOpen(false);
      if (detailOpen) await refreshDetail(payTarget.id);
      else refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to record payment");
    } finally {
      setPaySaving(false);
    }
  }

  async function voidInvoice(inv: InvoiceRow) {
    try {
      await apiPost(`/api/invoices/${inv.id}/void`);
      toast.success(`${inv.number} voided`);
      refetch();
      if (detail?.id === inv.id) await refreshDetail(inv.id);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to void invoice");
    }
  }

  async function generateInvoice(res: CheckedInReservation) {
    try {
      await apiPost("/api/invoices", { reservationId: res.id });
      toast.success(`Invoice generated for ${res.code}`);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to generate invoice");
    }
  }

  function exportCsv() {
    if (!data) return;
    downloadCsv(
      "invoices",
      [
        { key: "number", header: "Invoice No." },
        { key: "type", header: "Type" },
        { key: "guest", header: "Guest Name" },
        { key: "billedTo", header: "Billed To" },
        { key: "date", header: "Date" },
        { key: "total", header: "Total" },
        { key: "paid", header: "Paid" },
        { key: "balance", header: "Balance" },
        { key: "status", header: "Status" },
      ],
      data.items.map((i) => ({
        number: i.number,
        type: i.billingType,
        guest: guestFullName(i.guest),
        billedTo: i.folio?.name ?? guestFullName(i.guest),
        date: formatDate(i.issuedAt),
        total: i.total,
        paid: i.paidAmount,
        balance: i.total - i.paidAmount,
        status: i.status,
      }))
    );
  }

  const counts = data?.counts;

  return (
    <div className="space-y-4">
      <PageHeader title="Invoices" crumbs={["Dashboard", "Finance", "Invoices"]}>
        <Button variant="outline" onClick={exportCsv}>
          <Download className="mr-1.5 h-4 w-4" /> Export CSV
        </Button>
      </PageHeader>

      <TabsBar
        active={tab}
        onChange={setTab}
        tabs={[
          { id: "all", label: "All Invoices", count: counts?.all ?? 0 },
          { id: "COMPANY", label: "Company", count: counts?.company ?? 0 },
          { id: "INDIVIDUAL", label: "Individual", count: counts?.individual ?? 0 },
          { id: "OTA", label: "OTA", count: counts?.ota ?? 0 },
          { id: "uninvoiced", label: "Uninvoiced", count: counts?.uninvoiced ?? 0 },
        ]}
      />

      <div className="flex flex-wrap items-center gap-2 rounded-xl border border-gray-200 bg-white p-3">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search invoice no., guest, folio..."
          className="w-full sm:w-72"
        />
        <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="w-[150px]" />
        <span className="text-xs text-gray-400">to</span>
        <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="w-[150px]" />
      </div>

      {loading ? (
        <Spinner />
      ) : error ? (
        <EmptyState title="Couldn't load invoices" description={error} />
      ) : uninvoicedEnabled ? (
        <div className="rounded-xl border border-gray-200 bg-white">
          <div className="border-b border-gray-100 px-4 py-3 text-sm font-semibold text-gray-900">
            Checked-in stays without an invoice
          </div>
          <div className="overflow-x-auto">
            <DataTable<CheckedInReservation>
              keyField="id"
              rows={uninvoicedList}
              empty={
                <EmptyState
                  title="Nothing to invoice"
                  description="All checked-in reservations already have an invoice."
                />
              }
              columns={[
                { key: "code", header: "Reservation", render: (r) => <span className="font-medium text-gray-900">{r.code}</span> },
                { key: "guest", header: "Guest", render: (r) => guestFullName(r.guest) },
                { key: "roomType", header: "Room", render: (r) => r.room?.number ?? r.roomType?.name ?? "—" },
                { key: "dates", header: "Stay", render: (r) => `${formatDate(r.checkIn)} → ${formatDate(r.checkOut)}` },
                { key: "totalAmount", header: "Total", className: "text-right", render: (r) => <Money v={r.totalAmount} /> },
                {
                  key: "actions",
                  header: "",
                  className: "text-right",
                  render: (r) => (
                    <Button
                      size="sm"
                      className="h-8 rounded-lg bg-amber-600 text-xs text-white hover:bg-amber-700"
                      onClick={() => void generateInvoice(r)}
                    >
                      Generate Invoice
                    </Button>
                  ),
                },
              ]}
            />
          </div>
        </div>
      ) : (
        <div className="rounded-xl border border-gray-200 bg-white">
          <div className="overflow-x-auto">
            <DataTable<InvoiceRow>
              keyField="id"
              rows={data?.items ?? []}
              empty={<EmptyState title="No invoices found" description="Try changing filters or generate one from a folio." />}
              columns={[
                { key: "number", header: "Invoice No.", render: (r) => <span className="font-medium text-gray-900">{r.number}</span> },
                { key: "billingType", header: "Type", render: (r) => <BillingBadge type={r.billingType} /> },
                { key: "guest", header: "Guest Name", render: (r) => guestFullName(r.guest) },
                { key: "billedTo", header: "Billed To", render: (r) => r.folio?.name ?? guestFullName(r.guest) },
                { key: "issuedAt", header: "Date", render: (r) => formatDate(r.issuedAt) },
                { key: "total", header: "Total", className: "text-right", render: (r) => <Money v={r.total} /> },
                { key: "paidAmount", header: "Paid", className: "text-right", render: (r) => <Money v={r.paidAmount} /> },
                { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
                {
                  key: "actions",
                  header: "Actions",
                  className: "text-right",
                  render: (r) => (
                    <div className="flex items-center justify-end gap-1.5">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 rounded-lg border-gray-200 px-2 text-xs text-gray-600 hover:text-gray-900"
                        onClick={() => void openDetail(r)}
                      >
                        <Eye className="mr-1 h-3.5 w-3.5" /> View
                      </Button>
                      {(r.status === "UNPAID" || r.status === "PARTIAL") && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 rounded-lg border-amber-200 px-2 text-xs text-amber-700 hover:bg-amber-50"
                          onClick={() => openPayDialog(r)}
                        >
                          <Wallet className="mr-1 h-3.5 w-3.5" /> Payment
                        </Button>
                      )}
                      {r.status === "UNPAID" && (
                        <ConfirmButton
                          title={`Void ${r.number}?`}
                          description="Voided invoices cannot be un-voided. Only possible while nothing has been paid."
                          confirmLabel="Void Invoice"
                          onConfirm={() => voidInvoice(r)}
                        >
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 rounded-lg border-rose-200 px-2 text-xs text-rose-600 hover:bg-rose-50"
                          >
                            <Ban className="mr-1 h-3.5 w-3.5" /> Void
                          </Button>
                        </ConfirmButton>
                      )}
                    </div>
                  ),
                },
              ]}
            />
          </div>
        </div>
      )}

      {/* Invoice detail dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
          <style>{`@media print { body * { visibility: hidden !important; } .invoice-print-area, .invoice-print-area * { visibility: visible !important; } .invoice-print-area { position: fixed; inset: 0; background: white; z-index: 9999; } }`}</style>
          {detailLoading || !detail ? (
            <Spinner />
          ) : (
            <div className="invoice-print-area">
              <DialogHeader className="print:static">
                <DialogTitle className="flex items-center gap-2">
                  Invoice {detail.number}
                  <StatusBadge status={detail.status} />
                </DialogTitle>
              </DialogHeader>

              <div className="grid grid-cols-1 gap-3 rounded-lg border border-gray-100 bg-gray-50 p-3 text-sm sm:grid-cols-3">
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Billed To</div>
                  <div className="font-medium text-gray-900">{detail.folio?.name ?? guestFullName(detail.guest)}</div>
                  <div className="text-xs text-gray-500">{detail.guest?.phone ?? "—"}</div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Guest</div>
                  <div className="font-medium text-gray-900">{guestFullName(detail.guest)}</div>
                  <div className="text-xs text-gray-500">{detail.reservation?.code ?? "—"}</div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Issued On</div>
                  <div className="font-medium text-gray-900">{formatDate(detail.issuedAt)}</div>
                  <div className="text-xs text-gray-500">Type: {detail.billingType}</div>
                </div>
              </div>

              <div className="mt-3 overflow-x-auto rounded-lg border border-gray-200">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 text-left text-xs font-medium uppercase tracking-wide text-gray-500">
                      <th className="px-3 py-2">Description</th>
                      <th className="px-3 py-2">Type</th>
                      <th className="px-3 py-2 text-right">Qty</th>
                      <th className="px-3 py-2 text-right">Unit Price</th>
                      <th className="px-3 py-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {detail.items.map((it) => (
                      <tr key={it.id} className="border-t border-gray-100">
                        <td className="px-3 py-2 text-gray-700">{it.description}</td>
                        <td className="px-3 py-2 text-xs text-gray-500">{it.type}</td>
                        <td className="px-3 py-2 text-right text-gray-700">{it.quantity}</td>
                        <td className="px-3 py-2 text-right text-gray-700">
                          <Money v={it.unitPrice} />
                        </td>
                        <td className="px-3 py-2 text-right font-medium text-gray-900">
                          <Money v={it.amount} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="rounded-lg border border-gray-200 p-3 text-sm">
                  <div className="flex justify-between py-0.5 text-gray-600">
                    <span>Subtotal</span>
                    <Money v={detail.subtotal} />
                  </div>
                  <div className="flex justify-between py-0.5 text-gray-600">
                    <span>Tax</span>
                    <Money v={detail.tax} />
                  </div>
                  <div className="flex justify-between py-0.5 text-gray-600">
                    <span>Discount</span>
                    <span>−<Money v={detail.discount} /></span>
                  </div>
                  <div className="mt-1 flex justify-between border-t border-gray-100 pt-1.5 font-semibold text-gray-900">
                    <span>Total</span>
                    <Money v={detail.total} />
                  </div>
                  <div className="flex justify-between py-0.5 text-gray-600">
                    <span>Paid</span>
                    <Money v={detail.paidAmount} />
                  </div>
                  <div
                    className={cn(
                      "mt-1.5 flex justify-between rounded-md px-2 py-1.5 text-sm font-bold",
                      detailBalanceDue > 0 ? "bg-rose-50 text-rose-700" : "bg-emerald-50 text-emerald-700"
                    )}
                  >
                    <span>Balance Due</span>
                    <Money v={detailBalanceDue} />
                  </div>
                </div>
                <div className="rounded-lg border border-gray-200 p-3">
                  <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-500">Payments</div>
                  {detail.payments.length === 0 ? (
                    <div className="text-sm text-gray-400">No payments recorded yet</div>
                  ) : (
                    <div className="space-y-1.5">
                      {detail.payments.map((p) => (
                        <div key={p.id} className="flex items-center justify-between text-sm">
                          <div className="min-w-0">
                            <div className="truncate font-medium text-gray-900">
                              {METHOD_LABELS[p.method] ?? p.method}
                              {p.reference ? <span className="ml-1 text-xs text-gray-400">· {p.reference}</span> : null}
                            </div>
                            <div className="text-xs text-gray-400">{formatDateTime(p.paidAt)}</div>
                          </div>
                          <div className="font-medium text-emerald-600">
                            <Money v={p.amount} />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <DialogFooter className="mt-3 gap-2 print:hidden">
                <Button variant="outline" onClick={() => window.print()}>
                  <Printer className="mr-1.5 h-4 w-4" /> Print / PDF
                </Button>
                {(detail.status === "UNPAID" || detail.status === "PARTIAL") && (
                  <Button
                    className="bg-amber-600 text-white hover:bg-amber-700"
                    onClick={() => openPayDialog(detail)}
                  >
                    <Wallet className="mr-1.5 h-4 w-4" /> Record Payment
                  </Button>
                )}
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Record payment dialog */}
      <Dialog open={payOpen} onOpenChange={setPayOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Record Payment {payTarget ? `— ${payTarget.number}` : ""}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Field label="Amount" required>
              <Input
                type="number"
                min="0"
                step="0.01"
                max={balanceDue || undefined}
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
              />
              <div className="text-xs text-gray-400">Balance due: {formatMoney(balanceDue)}</div>
            </Field>
            <Field label="Method" required>
              <Select value={payMethod} onValueChange={setPayMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {METHODS.map((m) => (
                    <SelectItem key={m} value={m}>
                      {METHOD_LABELS[m]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Reference">
              <Input
                placeholder="Transaction / cheque no."
                value={payReference}
                onChange={(e) => setPayReference(e.target.value)}
              />
            </Field>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPayOpen(false)}>
              Cancel
            </Button>
            <Button className="bg-amber-600 text-white hover:bg-amber-700" disabled={paySaving} onClick={() => void submitPayment()}>
              {paySaving ? "Saving..." : "Save Payment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
