"use client";

import * as React from "react";
import { Pencil, Plus, Trash2, UtensilsCrossed } from "lucide-react";
import { toast } from "sonner";
import { apiDelete, apiPost, apiPut, qs } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import {
  ConfirmButton,
  EmptyState,
  Field,
  PageHeader,
  Spinner,
  formatMoney,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// ─── Types ────────────────────────────────────────────────────

type MenuItem = {
  id: string;
  name: string;
  category: string;
  description: string | null;
  price: number;
  available: boolean;
  isVeg: boolean;
};

const CATEGORY_TABS = [
  { id: "", label: "All" },
  { id: "STARTER", label: "Starters" },
  { id: "MAIN_COURSE", label: "Main Course" },
  { id: "BREADS_RICE", label: "Breads & Rice" },
  { id: "DESSERTS", label: "Desserts" },
  { id: "BEVERAGES", label: "Beverages" },
  { id: "BAR", label: "Bar" },
];

// ─── View ─────────────────────────────────────────────────────

export default function FoodMenuView({ user }: ViewProps) {
  const canManage = user.role === "ADMIN" || user.role === "RECEPTIONIST";

  const [cat, setCat] = React.useState("");
  const { data, loading, error, refetch } = useApi<MenuItem[]>(`/api/menu${qs({ category: cat || undefined })}`);

  const [addOpen, setAddOpen] = React.useState(false);
  const [editItem, setEditItem] = React.useState<MenuItem | null>(null);
  const [busyId, setBusyId] = React.useState<string | null>(null);

  async function toggleAvailable(item: MenuItem, available: boolean) {
    setBusyId(item.id);
    try {
      await apiPut(`/api/menu/${item.id}`, { available });
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to update availability");
    } finally {
      setBusyId(null);
    }
  }

  async function deleteItem(item: MenuItem) {
    try {
      await apiDelete(`/api/menu/${item.id}`);
      toast.success(`${item.name} deleted`);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to delete item");
    }
  }

  const items = data ?? [];

  return (
    <div className="space-y-4">
      <PageHeader title="F&B Menu" crumbs={["Food", "F&B Menu"]}>
        {canManage && (
          <Button
            size="sm"
            onClick={() => setAddOpen(true)}
            className="h-9 rounded-lg bg-amber-600 text-white hover:bg-amber-700"
          >
            <Plus className="mr-1.5 h-4 w-4" /> Add Item
          </Button>
        )}
      </PageHeader>

      {/* Category tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {CATEGORY_TABS.map((c) => (
          <button
            key={c.id || "all"}
            type="button"
            onClick={() => setCat(c.id)}
            className={cn(
              "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
              cat === c.id
                ? "border-amber-600 bg-white text-amber-700 shadow-sm"
                : "border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:text-gray-900"
            )}
          >
            {c.label}
          </button>
        ))}
      </div>

      {/* Menu grid */}
      {loading ? (
        <Spinner />
      ) : error ? (
        <EmptyState title="Couldn't load menu" description={error} />
      ) : items.length === 0 ? (
        <EmptyState
          icon={<UtensilsCrossed className="h-7 w-7" />}
          title="No menu items"
          description={canManage ? "Add your first item to build the menu." : "Check back soon."}
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {items.map((m) => (
            <div
              key={m.id}
              className={cn(
                "flex flex-col rounded-xl border border-gray-200 bg-white p-4 shadow-sm transition-opacity",
                !m.available && "opacity-60"
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2">
                  {m.isVeg && (
                    <span
                      className="mt-1 h-2.5 w-2.5 shrink-0 rounded-full border border-emerald-600 bg-emerald-500"
                      title="Vegetarian"
                    />
                  )}
                  <div className="min-w-0">
                    <div className="font-semibold text-gray-900">{m.name}</div>
                    <div className="text-xs text-gray-400">{m.category.replace(/_/g, " ")}</div>
                  </div>
                </div>
                <div className="whitespace-nowrap font-semibold text-gray-900">{formatMoney(m.price)}</div>
              </div>
              {m.description && <div className="mt-1.5 line-clamp-2 text-xs text-gray-500">{m.description}</div>}

              {canManage && (
                <div className="mt-3 flex items-center justify-between border-t border-gray-100 pt-3">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={m.available}
                      disabled={busyId === m.id}
                      onCheckedChange={(v) => void toggleAvailable(m, v)}
                      id={`avail-${m.id}`}
                    />
                    <label htmlFor={`avail-${m.id}`} className="text-xs text-gray-600">
                      {m.available ? "Available" : "Sold out"}
                    </label>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0"
                      onClick={() => setEditItem(m)}
                    >
                      <Pencil className="h-4 w-4 text-gray-500" />
                    </Button>
                    <ConfirmButton
                      title={`Delete ${m.name}?`}
                      description="Items used in past orders cannot be deleted."
                      confirmLabel="Delete"
                      onConfirm={() => deleteItem(m)}
                    >
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <Trash2 className="h-4 w-4 text-rose-500" />
                      </Button>
                    </ConfirmButton>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <ItemFormDialog
        open={addOpen}
        edit={null}
        onClose={() => setAddOpen(false)}
        onSaved={refetch}
      />
      {editItem && (
        <ItemFormDialog
          open={!!editItem}
          edit={editItem}
          onClose={() => setEditItem(null)}
          onSaved={refetch}
        />
      )}
    </div>
  );
}

// ─── Add / Edit dialog ────────────────────────────────────────

function ItemFormDialog({
  open,
  edit,
  onClose,
  onSaved,
}: {
  open: boolean;
  edit: MenuItem | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = React.useState("");
  const [category, setCategory] = React.useState("STARTER");
  const [price, setPrice] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [isVeg, setIsVeg] = React.useState(true);
  const [available, setAvailable] = React.useState(true);
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    if (!open) return;
    if (edit) {
      setName(edit.name);
      setCategory(edit.category);
      setPrice(String(edit.price));
      setDescription(edit.description ?? "");
      setIsVeg(edit.isVeg);
      setAvailable(edit.available);
    } else {
      setName("");
      setCategory("STARTER");
      setPrice("");
      setDescription("");
      setIsVeg(true);
      setAvailable(true);
    }
  }, [open, edit]);

  async function save() {
    if (!name.trim() || !price) {
      toast.error("Name and price are required");
      return;
    }
    const body = {
      name: name.trim(),
      category,
      price: Number(price),
      description: description.trim() || undefined,
      isVeg,
      available,
    };
    setBusy(true);
    try {
      if (edit) {
        await apiPut(`/api/menu/${edit.id}`, body);
        toast.success(`${body.name} updated`);
      } else {
        await apiPost("/api/menu", body);
        toast.success(`${body.name} added to menu`);
      }
      onClose();
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to save item");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{edit ? `Edit ${edit.name}` : "Add Menu Item"}</DialogTitle>
          <DialogDescription>Menu items are shared with the restaurant, bar and room service.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <Field label="Name" required>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Paneer Tikka" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Category" required>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORY_TABS.filter((c) => c.id).map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Price (₹)" required>
              <Input type="number" value={price} onChange={(e) => setPrice(e.target.value)} />
            </Field>
          </div>
          <Field label="Description">
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
          </Field>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Switch checked={isVeg} onCheckedChange={setIsVeg} id="isveg-switch" />
              <label htmlFor="isveg-switch" className="text-sm text-gray-700">
                Vegetarian
              </label>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={available} onCheckedChange={setAvailable} id="avail-switch" />
              <label htmlFor="avail-switch" className="text-sm text-gray-700">
                Available
              </label>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button disabled={busy} onClick={() => void save()} className="bg-amber-600 hover:bg-amber-700">
            {busy ? "Saving..." : "Save Item"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
