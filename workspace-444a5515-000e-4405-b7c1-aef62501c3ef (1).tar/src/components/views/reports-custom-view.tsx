'use client';

import * as React from "react";
import { Download, PlayCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { qs } from "@/lib/api-client";
import {
  DataTable,
  downloadCsv,
  EmptyState,
  formatDate,
  formatMoney,
  PageHeader,
  Spinner,
  StatusBadge,
  useApi,
  type ViewProps,
  ymd,
} from "./shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// ─── Types ────────────────────────────────────────────────────

type ReportType = "reservations" | "payments" | "revenue";

type ReservationsReport = {
  rows: {
    id: string;
    code: string;
    checkIn: string;
    checkOut: string;
    status: string;
    source: string;
    totalAmount: number;
    guest: { firstName: string; lastName: string } | null;
    roomType: { name: string } | null;
    room: { number: string } | null;
  }[];
  summary: { total: number; byStatus: Record<string, number>; bySource: { source: string; count: number }[] };
};

type PaymentRow = {
  id: string;
  amount: number;
  method: string;
  category: string | null;
  reference: string | null;
  paidAt: string;
  invoice: { number: string } | null;
};

type RevenueReport = {
  rows: { date: string; roomRevenue: number; fbRevenue: number; other: number; total: number }[];
  totals: { room: number; fb: number; other: number; total: number };
};

const SOURCE_LABELS: Record<string, string> = {
  DIRECT: "Direct",
  WEBSITE: "Website",
  OTA_BOOKING_COM: "Booking.com",
  OTA_MAKE_MY_TRIP: "MakeMyTrip",
  OTA_AIRBNB: "Airbnb",
  OTA_EXPEDIA: "Expedia",
  OTA_GOIBIBO: "Goibibo",
  PHONE: "Phone",
  WALK_IN: "Walk-in",
  COMPANY: "Company",
};

const METHOD_LABELS: Record<string, string> = {
  CASH: "Cash",
  UPI: "UPI",
  DEBIT_CARD: "Debit Card",
  CREDIT_CARD: "Credit Card",
  BANK_TRANSFER: "Bank Transfer",
  RAZORPAY: "Razorpay",
  OTHER: "Other",
};

const STATUS_CHIPS: Record<string, string> = {
  PENDING: "bg-amber-50 text-amber-700",
  CONFIRMED: "bg-amber-50 text-amber-700",
  CHECKED_IN: "bg-emerald-50 text-emerald-700",
  CHECKED_OUT: "bg-gray-100 text-gray-600",
  CANCELLED: "bg-rose-50 text-rose-700",
  NO_SHOW: "bg-gray-100 text-gray-600",
};

function monthStart(): string {
  const now = new Date();
  return ymd(new Date(now.getFullYear(), now.getMonth(), 1));
}

// ─── View ─────────────────────────────────────────────────────

export default function ReportsCustomView({ user: _user }: ViewProps) {
  const [reportType, setReportType] = React.useState<ReportType>("reservations");
  const [from, setFrom] = React.useState(monthStart);
  const [to, setTo] = React.useState(ymd(new Date()));
  const [status, setStatus] = React.useState("all");
  const [source, setSource] = React.useState("all");
  const [runUrl, setRunUrl] = React.useState<string | null>(null);

  const { data, loading, error } = useApi<ReservationsReport | PaymentRow[] | RevenueReport>(runUrl);

  function runReport() {
    if (reportType === "reservations") {
      setRunUrl(
        `/api/reports/reservations${qs({
          from,
          to,
          status: status === "all" ? undefined : status,
          source: source === "all" ? undefined : source,
        })}`
      );
    } else if (reportType === "payments") {
      setRunUrl(`/api/payments${qs({ from, to })}`);
    } else {
      setRunUrl(`/api/reports/revenue${qs({ from, to })}`);
    }
  }

  function exportCsv() {
    if (!data) return;
    if (reportType === "reservations") {
      const r = data as ReservationsReport;
      if (!r.rows?.length) return;
      downloadCsv(
        "custom-report-reservations",
        [
          { key: "code", header: "Code" },
          { key: "guest", header: "Guest" },
          { key: "room", header: "Room" },
          { key: "checkIn", header: "Check-in" },
          { key: "checkOut", header: "Check-out" },
          { key: "source", header: "Source" },
          { key: "status", header: "Status" },
          { key: "totalAmount", header: "Total" },
        ],
        r.rows.map((row) => ({
          code: row.code,
          guest: row.guest ? `${row.guest.firstName} ${row.guest.lastName}` : "",
          room: row.room?.number ?? row.roomType?.name ?? "",
          checkIn: row.checkIn?.slice(0, 10),
          checkOut: row.checkOut?.slice(0, 10),
          source: SOURCE_LABELS[row.source] ?? row.source,
          status: row.status,
          totalAmount: row.totalAmount,
        }))
      );
    } else if (reportType === "payments") {
      const rows = data as PaymentRow[];
      if (!rows.length) return;
      downloadCsv(
        "custom-report-payments",
        [
          { key: "paidAt", header: "Date" },
          { key: "invoice", header: "Invoice" },
          { key: "method", header: "Method" },
          { key: "category", header: "Category" },
          { key: "amount", header: "Amount" },
          { key: "reference", header: "Reference" },
        ],
        rows.map((p) => ({
          paidAt: p.paidAt?.slice(0, 16).replace("T", " "),
          invoice: p.invoice?.number ?? "",
          method: METHOD_LABELS[p.method] ?? p.method,
          category: p.category ?? "",
          amount: p.amount,
          reference: p.reference ?? "",
        }))
      );
    } else {
      const r = data as RevenueReport;
      if (!r.rows?.length) return;
      downloadCsv(
        "custom-report-revenue",
        [
          { key: "date", header: "Date" },
          { key: "roomRevenue", header: "Room Revenue" },
          { key: "fbRevenue", header: "F&B Revenue" },
          { key: "other", header: "Other" },
          { key: "total", header: "Total" },
        ],
        r.rows
      );
    }
  }

  const hasData = !!data && !loading && !error;

  return (
    <div className="space-y-4">
      <PageHeader title="Custom Reports" crumbs={["Dashboard", "Reports", "Custom"]}>
        <Button variant="outline" disabled={!hasData} onClick={exportCsv}>
          <Download className="mr-1.5 h-4 w-4" /> Export CSV
        </Button>
      </PageHeader>

      {/* Builder */}
      <div className="flex flex-wrap items-end gap-3 rounded-xl border border-gray-200 bg-white p-4">
        <div className="space-y-1.5">
          <label className="block text-sm font-medium text-gray-700">Report Type</label>
          <Select value={reportType} onValueChange={(v) => setReportType(v as ReportType)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="reservations">Reservations</SelectItem>
              <SelectItem value="payments">Payments</SelectItem>
              <SelectItem value="revenue">Revenue</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <label className="block text-sm font-medium text-gray-700">From</label>
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="w-[150px]" />
        </div>
        <div className="space-y-1.5">
          <label className="block text-sm font-medium text-gray-700">To</label>
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="w-[150px]" />
        </div>
        {reportType === "reservations" && (
          <>
            <div className="space-y-1.5">
              <label className="block text-sm font-medium text-gray-700">Status</label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  {Object.keys(STATUS_CHIPS).map((s) => (
                    <SelectItem key={s} value={s}>
                      {s.replace(/_/g, " ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="block text-sm font-medium text-gray-700">Source</label>
              <Select value={source} onValueChange={setSource}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All sources</SelectItem>
                  {Object.entries(SOURCE_LABELS).map(([k, label]) => (
                    <SelectItem key={k} value={k}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </>
        )}
        <Button className="bg-amber-600 text-white hover:bg-amber-700" onClick={runReport}>
          <PlayCircle className="mr-1.5 h-4 w-4" /> Run Report
        </Button>
      </div>

      {/* Results */}
      {loading ? (
        <Spinner />
      ) : error ? (
        <EmptyState title="Report failed" description={error} />
      ) : !data ? (
        <EmptyState
          title="No report yet"
          description="Pick a report type and range, then hit Run Report to see results."
        />
      ) : reportType === "reservations" ? (
        <ReservationsResult data={data as ReservationsReport} />
      ) : reportType === "payments" ? (
        <PaymentsResult rows={data as PaymentRow[]} />
      ) : (
        <RevenueResult data={data as RevenueReport} />
      )}
    </div>
  );
}

// ─── Result renderers ─────────────────────────────────────────

function ReservationsResult({ data }: { data: ReservationsReport }) {
  const chips = Object.entries(data.summary?.byStatus ?? {}).filter(([, n]) => n > 0);
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-xs font-medium text-amber-700">
          Total reservations
          <span className="font-bold">{data.summary?.total ?? data.rows.length}</span>
        </span>
        {chips.map(([s, n]) => (
          <span
            key={s}
            className={cn("inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium", STATUS_CHIPS[s] ?? "bg-gray-100 text-gray-600")}
          >
            {s.replace(/_/g, " ")}
            <span className="font-bold">{n}</span>
          </span>
        ))}
      </div>
      <div className="rounded-xl border border-gray-200 bg-white">
        <DataTable
          keyField="id"
          rows={data.rows}
          empty={<EmptyState title="No reservations match these filters" />}
          columns={[
            { key: "code", header: "Code", render: (r) => <span className="font-medium text-gray-900">{String(r.code)}</span> },
            { key: "guest", header: "Guest", render: (r) => (r.guest ? `${r.guest.firstName} ${r.guest.lastName}` : "—") },
            { key: "room", header: "Room", render: (r) => r.room?.number ?? r.roomType?.name ?? "—" },
            { key: "checkIn", header: "Check-in", render: (r) => formatDate(String(r.checkIn)) },
            { key: "checkOut", header: "Check-out", render: (r) => formatDate(String(r.checkOut)) },
            { key: "source", header: "Source", render: (r) => SOURCE_LABELS[String(r.source)] ?? String(r.source).replace(/_/g, " ") },
            { key: "status", header: "Status", render: (r) => <StatusBadge status={String(r.status)} /> },
            { key: "totalAmount", header: "Total", className: "text-right font-semibold text-gray-900", render: (r) => formatMoney(Number(r.totalAmount)) },
          ]}
        />
      </div>
    </div>
  );
}

function PaymentsResult({ rows }: { rows: PaymentRow[] }) {
  return (
    <div className="rounded-xl border border-gray-200 bg-white">
      <DataTable
        keyField="id"
        rows={rows}
        empty={<EmptyState title="No payments in this period" />}
        columns={[
          { key: "paidAt", header: "Date", render: (p) => formatDate(p.paidAt) },
          { key: "invoice", header: "Invoice No.", render: (p) => <span className="font-medium text-gray-900">{p.invoice?.number ?? "—"}</span> },
          { key: "method", header: "Method", render: (p) => METHOD_LABELS[p.method] ?? p.method },
          { key: "category", header: "Category", render: (p) => (p.category ? p.category.replace(/_/g, " ") : "—") },
          { key: "amount", header: "Amount", className: "text-right font-semibold text-gray-900", render: (p) => formatMoney(p.amount) },
          { key: "reference", header: "Reference", render: (p) => p.reference ?? "—" },
        ]}
      />
    </div>
  );
}

function RevenueResult({ data }: { data: RevenueReport }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl bg-amber-50 p-4">
          <div className="text-sm font-medium text-gray-600">Room Revenue</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{formatMoney(data.totals?.room)}</div>
        </div>
        <div className="rounded-xl bg-teal-50 p-4">
          <div className="text-sm font-medium text-gray-600">F&amp;B Revenue</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{formatMoney(data.totals?.fb)}</div>
        </div>
        <div className="rounded-xl bg-amber-50 p-4">
          <div className="text-sm font-medium text-gray-600">Other</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{formatMoney(data.totals?.other)}</div>
        </div>
        <div className="rounded-xl bg-sky-50 p-4">
          <div className="text-sm font-medium text-gray-600">Total</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{formatMoney(data.totals?.total)}</div>
        </div>
      </div>
      <div className="rounded-xl border border-gray-200 bg-white">
        <DataTable
          keyField="date"
          rows={data.rows}
          empty={<EmptyState title="No revenue in this period" />}
          columns={[
            { key: "date", header: "Date", render: (r) => <span className="font-medium text-gray-900">{String(r.date)}</span> },
            { key: "roomRevenue", header: "Room Revenue", className: "text-right", render: (r) => formatMoney(Number(r.roomRevenue)) },
            { key: "fbRevenue", header: "F&B Revenue", className: "text-right", render: (r) => formatMoney(Number(r.fbRevenue)) },
            { key: "other", header: "Other", className: "text-right", render: (r) => formatMoney(Number(r.other)) },
            { key: "total", header: "Total", className: "text-right font-semibold text-gray-900", render: (r) => formatMoney(Number(r.total)) },
          ]}
        />
      </div>
    </div>
  );
}
