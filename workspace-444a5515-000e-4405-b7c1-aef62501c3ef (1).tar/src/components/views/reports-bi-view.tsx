'use client';

import * as React from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { qs } from "@/lib/api-client";
import {
  EmptyState,
  formatMoney,
  PageHeader,
  Spinner,
  StatCard,
  TabsBar,
  useApi,
  type ViewProps,
  ymd,
} from "./shared";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

// ─── Types ────────────────────────────────────────────────────

type OccupancyData = {
  occupancyTrend: { date: string; occupancy: number; revenue: number }[];
  totals: {
    availableRoomNights: number;
    soldRoomNights: number;
    occupancyRate: number;
    avgStayNights: number;
    avgRate: number;
  };
};

type DashboardData = {
  stats: {
    occupancyRate: number;
    inHouseGuests: number;
    monthRevenue: number;
    todayRevenue: number;
  };
};

type ReservationsReport = {
  rows: unknown[];
  summary: { total: number; byStatus: Record<string, number>; bySource: { source: string; count: number }[] };
};

type GuestStats = {
  totalGuests: number;
  nationalityBreakdown: { name: string; count: number }[];
};

const PIE_COLORS = ["#D97706", "#14B8A6", "#F59E0B", "#F43F5E", "#0EA5E9", "#B45309", "#10B981", "#6366F1", "#EC4899", "#64748B"];

const MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function shortDayLabel(iso: string): string {
  const d = new Date(`${iso}T00:00:00`);
  if (isNaN(d.getTime())) return iso;
  return `${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}`;
}

function daysAgo(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return ymd(d);
}

function defaultFrom(): string {
  return daysAgo(30);
}

function defaultTo(): string {
  return ymd(new Date());
}

// ─── Shared chart ─────────────────────────────────────────────

function OccupancyRevenueChart({ data }: { data: { date: string; occupancy: number; revenue: number }[] }) {
  const chartData = data.map((p) => ({ ...p, label: shortDayLabel(p.date) }));
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={chartData} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <defs>
          <linearGradient id="biOccFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#D97706" stopOpacity={0.25} />
            <stop offset="100%" stopColor="#D97706" stopOpacity={0.02} />
          </linearGradient>
          <linearGradient id="biRevFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#14B8A6" stopOpacity={0.2} />
            <stop offset="100%" stopColor="#14B8A6" stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
        <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#9CA3AF" }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
        <YAxis yAxisId="occ" tick={{ fontSize: 11, fill: "#9CA3AF" }} tickLine={false} axisLine={false} unit="%" domain={[0, 100]} />
        <YAxis yAxisId="rev" orientation="right" tick={{ fontSize: 11, fill: "#9CA3AF" }} tickLine={false} axisLine={false} tickFormatter={(v: number) => (v >= 1000 ? `${Math.round(v / 1000)}k` : String(v))} />
        <Tooltip
          contentStyle={{ borderRadius: 8, fontSize: 12, borderColor: "#E5E7EB" }}
          formatter={(v: number | string, name: string) =>
            name === "Occupancy %" ? [`${v}%`, name] : [formatMoney(Number(v)), "Revenue"]
          }
        />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Area yAxisId="occ" type="monotone" dataKey="occupancy" name="Occupancy %" stroke="#D97706" strokeWidth={2} fill="url(#biOccFill)" />
        <Area yAxisId="rev" type="monotone" dataKey="revenue" name="Revenue" stroke="#14B8A6" strokeWidth={2} fill="url(#biRevFill)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}

function NationalityPie({ breakdown }: { breakdown: { name: string; count: number }[] }) {
  if (!breakdown.length) {
    return <EmptyState title="No guest nationality data yet" />;
  }
  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie data={breakdown} dataKey="count" nameKey="name" innerRadius={45} outerRadius={80} paddingAngle={2} strokeWidth={0}>
          {breakdown.map((entry, i) => (
            <Cell key={entry.name} fill={PIE_COLORS[i % PIE_COLORS.length]} />
          ))}
        </Pie>
        <Tooltip
          formatter={(v: number | string, name: string) => [`${v} guests`, name]}
          contentStyle={{ borderRadius: 8, fontSize: 12, borderColor: "#E5E7EB" }}
        />
        <Legend wrapperStyle={{ fontSize: 11 }} iconSize={8} />
      </PieChart>
    </ResponsiveContainer>
  );
}

// ─── View ─────────────────────────────────────────────────────

export default function ReportsBiView({ user: _user }: ViewProps) {
  const [tab, setTab] = React.useState("dashboard");
  const [from, setFrom] = React.useState(defaultFrom);
  const [to, setTo] = React.useState(defaultTo);

  const { data: occupancy, loading: occLoading } = useApi<OccupancyData>(
    `/api/reports/occupancy${qs({ from, to })}`
  );
  const { data: dashboard } = useApi<DashboardData>("/api/dashboard");
  const { data: resReport, loading: resLoading } = useApi<ReservationsReport>(
    `/api/reports/reservations${qs({ from, to })}`
  );
  const { data: guestStats, loading: guestLoading } = useApi<GuestStats>("/api/guests/stats");

  const byStatus = resReport?.summary?.byStatus ?? {};

  return (
    <div className="space-y-4">
      <PageHeader title="Business Intelligence" crumbs={["Dashboard", "Reports", "Business Intelligence"]} />
      <p className="-mt-2 text-sm text-gray-500">
        Plain-English insights about your hotel — bookings, guests, food, and feedback.
      </p>

      <div className="flex flex-wrap items-center gap-2 rounded-xl border border-gray-200 bg-white p-3">
        <span className="text-sm font-medium text-gray-600">From</span>
        <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="w-[150px]" />
        <span className="text-xs text-gray-400">to</span>
        <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="w-[150px]" />
      </div>

      <TabsBar
        active={tab}
        onChange={setTab}
        tabs={[
          { id: "dashboard", label: "Dashboard" },
          { id: "occupancy", label: "Occupancy" },
          { id: "checkins", label: "Check-ins" },
          { id: "guests", label: "Guests" },
          { id: "food", label: "Food" },
        ]}
      />

      {occLoading ? (
        <Spinner />
      ) : (
        <>
          {(tab === "dashboard" || tab === "occupancy") && (
            <div className="space-y-4">
              {tab === "dashboard" && (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
                  <StatCard
                    label="Occupancy Rate"
                    value={`${dashboard?.stats.occupancyRate ?? occupancy?.totals.occupancyRate ?? 0}%`}
                    sub="rooms occupied tonight"
                    tone="amber"
                  />
                  <StatCard
                    label="Room Revenue"
                    value={formatMoney(dashboard?.stats.monthRevenue)}
                    sub="this month"
                    tone="teal"
                  />
                  <StatCard label="Checked-in Guests" value={dashboard?.stats.inHouseGuests ?? 0} sub="in-house right now" tone="amber" />
                  <StatCard
                    label="Total Guests"
                    value={guestStats?.totalGuests ?? 0}
                    sub="in your guest database"
                    tone="sky"
                    icon={<Users className="h-4 w-4" />}
                  />
                </div>
              )}

              {tab === "occupancy" && occupancy?.totals && (
                <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
                  <StatCard label="Available Room-Nights" value={occupancy.totals.availableRoomNights} tone="sky" />
                  <StatCard label="Sold Room-Nights" value={occupancy.totals.soldRoomNights} tone="amber" />
                  <StatCard label="Occupancy Rate" value={`${occupancy.totals.occupancyRate}%`} tone="teal" />
                  <StatCard label="Avg Stay" value={`${occupancy.totals.avgStayNights} nights`} tone="amber" />
                  <StatCard label="Avg Rate" value={formatMoney(occupancy.totals.avgRate)} tone="rose" />
                </div>
              )}

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold text-gray-900">Occupancy &amp; revenue trend</CardTitle>
                </CardHeader>
                <CardContent className="h-72">
                  {(occupancy?.occupancyTrend ?? []).length === 0 ? (
                    <EmptyState title="No data for this range" description="Pick a wider date range to see the trend." />
                  ) : (
                    <OccupancyRevenueChart data={occupancy?.occupancyTrend ?? []} />
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {tab === "dashboard" && (
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold text-gray-900">What happened to arrivals</CardTitle>
                </CardHeader>
                <CardContent>
                  {resLoading ? (
                    <Spinner />
                  ) : (
                    <>
                      <div className="mb-3 text-sm text-gray-500">
                        {resReport?.summary?.total ?? 0} reservations in the selected period — here&apos;s how they ended up.
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { key: "NO_SHOW", label: "No-shows", cls: "bg-gray-100 text-gray-600" },
                          { key: "CANCELLED", label: "Cancelled", cls: "bg-rose-50 text-rose-700" },
                          { key: "CHECKED_OUT", label: "Completed", cls: "bg-emerald-50 text-emerald-700" },
                          { key: "CHECKED_IN", label: "In-house", cls: "bg-amber-50 text-amber-700" },
                          { key: "CONFIRMED", label: "Upcoming", cls: "bg-sky-50 text-sky-700" },
                        ].map((c) => (
                          <span
                            key={c.key}
                            className={cn("inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium", c.cls)}
                          >
                            {c.label}
                            <span className="font-bold">{byStatus[c.key] ?? 0}</span>
                          </span>
                        ))}
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold text-gray-900">Who your guests are</CardTitle>
                </CardHeader>
                <CardContent className="h-64">
                  {guestLoading ? (
                    <Spinner />
                  ) : (
                    <NationalityPie breakdown={guestStats?.nationalityBreakdown ?? []} />
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {tab === "occupancy" && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold text-gray-900">Reading the trend</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-gray-500">
                Occupancy tracks the share of rooms sold each night; the teal line shows payments received that day. Spikes usually
                follow weekends or group arrivals — dips are your window for promotions.
              </CardContent>
            </Card>
          )}

          {(tab === "checkins" || tab === "food") && (
            <EmptyState
              title="More intelligence coming soon"
              description={
                tab === "checkins"
                  ? "Check-in pace and front-desk efficiency insights are coming from your data soon."
                  : "Food & beverage insights — top dishes, outlet revenue and order patterns — are coming from your data soon."
              }
            />
          )}

          {tab === "guests" && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold text-gray-900">Who your guests are</CardTitle>
              </CardHeader>
              <CardContent className="h-64">
                {guestLoading ? (
                  <Spinner />
                ) : (
                  <NationalityPie breakdown={guestStats?.nationalityBreakdown ?? []} />
                )}
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
