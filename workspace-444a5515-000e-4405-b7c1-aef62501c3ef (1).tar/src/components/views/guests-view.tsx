"use client";

import * as React from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Eye,
  IdCard,
  Pencil,
  Plus,
  Star,
  Trash2,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { apiDelete, apiGet, apiPost, apiPut, qs } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import {
  DataTable,
  EmptyState,
  Field,
  Money,
  PageHeader,
  SearchInput,
  Spinner,
  StatCard,
  StatusBadge,
  formatDate,
  formatDateTime,
  formatMoney,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

// ─── Types ────────────────────────────────────────────────────

type Guest = {
  id: string;
  firstName: string;
  lastName: string;
  email: string | null;
  phone: string | null;
  idType: string | null;
  idNumber: string | null;
  nationality: string | null;
  address: string | null;
  city: string | null;
  company: string | null;
  vip: boolean;
  notes: string | null;
  reservationCount?: number;
  lastStay?: string | null;
};

type GuestsData = { items: Guest[]; total: number; page: number; pageSize: number };

type StatsData = {
  totalGuests: number;
  repeatGuests: number;
  avgStayNights: number;
  noShowRate: number;
  newByMonth: { month: string; count: number }[];
  idDocsRecorded: number;
  missingId: number;
  missingContact: number;
  duplicates: number;
  nationalityBreakdown: { name: string; count: number }[];
  sourceBreakdown: { name: string; count: number }[];
};

type GuestDetail = {
  guest: Guest;
  reservations: {
    id: string;
    code: string;
    status: string;
    checkIn: string;
    checkOut: string;
    totalAmount: number;
    roomType: { name: string } | null;
    room: { number: string } | null;
  }[];
  orders: { id: string; orderNumber: string; totalAmount: number; status: string; createdAt: string }[];
  reviews: { id: string; rating: number; title: string | null; comment: string; createdAt: string; channel?: string | null }[];
  stats: { stays: number; spend: number };
};

const SOURCE_LABELS: Record<string, string> = {
  DIRECT: "Direct",
  WEBSITE: "Website",
  OTA_BOOKING_COM: "Booking.com",
  OTA_MAKE_MY_TRIP: "MakeMyTrip",
  OTA_AIRBNB: "Airbnb",
  OTA_EXPEDIA: "Expedia",
  OTA_GOIBIBO: "Goibibo",
  PHONE: "Phone",
  WALK_IN: "Walk-in",
  COMPANY: "Company",
};

const PIE_COLORS = ["#D97706", "#14B8A6", "#F59E0B", "#F43F5E", "#0EA5E9", "#B45309", "#10B981", "#6366F1", "#EC4899", "#64748B"];

function fullName(g: Guest): string {
  return `${g.firstName} ${g.lastName}`;
}

// ─── View ─────────────────────────────────────────────────────

export default function GuestsView(_props: ViewProps) {
  const [tab, setTab] = React.useState("insights");

  const stats = useApi<StatsData>("/api/guests/stats");
  const list = useApi<GuestsData>("/api/guests?pageSize=200");

  const [search, setSearch] = React.useState("");
  const [debounced, setDebounced] = React.useState("");
  React.useEffect(() => {
    const t = window.setTimeout(() => setDebounced(search), 350);
    return () => window.clearTimeout(t);
  }, [search]);

  const filtered = React.useMemo(() => {
    const q = debounced.trim().toLowerCase();
    if (!q) return list.data?.items ?? [];
    return (list.data?.items ?? []).filter((g) =>
      `${g.firstName} ${g.lastName} ${g.phone ?? ""} ${g.email ?? ""} ${g.city ?? ""} ${g.company ?? ""}`
        .toLowerCase()
        .includes(q)
    );
  }, [list.data, debounced]);

  const [viewId, setViewId] = React.useState<string | null>(null);
  const [formOpen, setFormOpen] = React.useState(false);
  const [editGuest, setEditGuest] = React.useState<Guest | null>(null);

  const tabs = [
    { id: "insights", label: "Insights" },
    { id: "master", label: "Master Guests", count: list.data?.total },
    { id: "duplicates", label: "Duplicates", count: stats.data?.duplicates },
  ];

  async function deleteGuest(g: Guest) {
    try {
      await apiDelete(`/api/guests/${g.id}`);
      toast.success(`${fullName(g)} deleted`);
      list.refetch();
      stats.refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to delete guest");
    }
  }

  const s = stats.data;

  return (
    <div className="space-y-4">
      <PageHeader title="Guests" crumbs={["Front Desk", "Check-ins & Guests", "Guests"]} />

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
              tab === t.id
                ? "border-amber-600 bg-white text-amber-700 shadow-sm"
                : "border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:text-gray-900"
            )}
          >
            {t.label}
            {typeof t.count === "number" && <span className="ml-1 text-gray-400">({t.count})</span>}
          </button>
        ))}
      </div>

      {/* ── Insights ── */}
      {tab === "insights" &&
        (stats.loading ? (
          <Spinner />
        ) : stats.error || !s ? (
          <EmptyState title="Couldn't load guest insights" description={stats.error ?? undefined} />
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <StatCard label="Total guests" value={s.totalGuests} sub="in the CRM" tone="amber" icon={<Users className="h-4 w-4" />} />
              <StatCard
                label="Repeat guests"
                value={`${s.totalGuests ? Math.round((s.repeatGuests / s.totalGuests) * 100) : 0}%`}
                sub={`${s.repeatGuests} returning`}
                tone="teal"
              />
              <StatCard label="Average stay" value={`${s.avgStayNights} nights`} sub="per reservation" tone="sky" />
              <StatCard label="No-show rate" value={`${s.noShowRate}%`} sub="of all bookings" tone="rose" />
            </div>

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
              <Card className="lg:col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold text-gray-900">New guests by month</CardTitle>
                </CardHeader>
                <CardContent className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={s.newByMonth} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
                      <XAxis
                        dataKey="month"
                        tick={{ fontSize: 11, fill: "#9CA3AF" }}
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(m: string) => m.slice(5)}
                      />
                      <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#9CA3AF" }} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12, borderColor: "#E5E7EB" }} />
                      <Bar dataKey="count" fill="#D97706" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold text-gray-900">Nationalities</CardTitle>
                </CardHeader>
                <CardContent className="h-56">
                  {s.nationalityBreakdown.length === 0 ? (
                    <EmptyState title="No data" />
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={s.nationalityBreakdown}
                          dataKey="count"
                          nameKey="name"
                          innerRadius={40}
                          outerRadius={70}
                          paddingAngle={2}
                          strokeWidth={0}
                        >
                          {s.nationalityBreakdown.map((entry, i) => (
                            <Cell key={entry.name} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12, borderColor: "#E5E7EB" }} />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold text-gray-900">Booking source breakdown</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {s.sourceBreakdown.length === 0 ? (
                    <EmptyState title="No bookings yet" />
                  ) : (
                    s.sourceBreakdown.map((src) => {
                      const max = Math.max(...s.sourceBreakdown.map((x) => x.count), 1);
                      return (
                        <div key={src.name} className="flex items-center gap-3">
                          <span className="w-28 shrink-0 truncate text-xs text-gray-600">
                            {SOURCE_LABELS[src.name] ?? src.name.replace(/_/g, " ")}
                          </span>
                          <div className="h-2 flex-1 overflow-hidden rounded-full bg-gray-100">
                            <div
                              className="h-full rounded-full bg-amber-500"
                              style={{ width: `${(src.count / max) * 100}%` }}
                            />
                          </div>
                          <span className="w-6 text-right text-xs font-semibold text-gray-900">{src.count}</span>
                        </div>
                      );
                    })
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-semibold text-gray-900">Data quality</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex items-center justify-between rounded-lg bg-gray-50 px-3 py-2">
                    <span className="text-gray-600">Missing ID document</span>
                    <span className={cn("font-bold", s.missingId > 0 ? "text-rose-600" : "text-emerald-600")}>
                      {s.missingId}
                    </span>
                  </div>
                  <div className="flex items-center justify-between rounded-lg bg-gray-50 px-3 py-2">
                    <span className="text-gray-600">Missing contact (phone &amp; email)</span>
                    <span className={cn("font-bold", s.missingContact > 0 ? "text-amber-600" : "text-emerald-600")}>
                      {s.missingContact}
                    </span>
                  </div>
                  <div className="flex items-center justify-between rounded-lg bg-gray-50 px-3 py-2">
                    <span className="text-gray-600">Possible duplicate profiles</span>
                    <span className={cn("font-bold", s.duplicates > 0 ? "text-rose-600" : "text-emerald-600")}>
                      {s.duplicates}
                    </span>
                  </div>
                  <div className="pt-1 text-xs text-gray-400">
                    {s.idDocsRecorded} guests have ID documents recorded.
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        ))}

      {/* ── Master guests ── */}
      {tab === "master" && (
        <>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <SearchInput
              value={search}
              onChange={setSearch}
              placeholder="Search name / phone / email / city"
              className="w-full sm:w-80"
            />
            <Button
              size="sm"
              onClick={() => {
                setEditGuest(null);
                setFormOpen(true);
              }}
              className="h-9 rounded-lg bg-amber-600 text-white hover:bg-amber-700"
            >
              <Plus className="mr-1.5 h-4 w-4" /> Add Guest
            </Button>
          </div>

          <div className="rounded-lg border border-gray-200">
            {list.loading ? (
              <Spinner />
            ) : list.error ? (
              <EmptyState title="Couldn't load guests" description={list.error} />
            ) : (
              <DataTable<Guest>
                keyField="id"
                rows={filtered}
                empty={<EmptyState icon={<Users className="h-7 w-7" />} title="No guests found" description="Try another search, or add a new guest." />}
                columns={[
                  {
                    key: "name",
                    header: "Name",
                    render: (g) => (
                      <div className="flex items-center gap-1.5">
                        <span className="font-medium text-gray-900">{fullName(g)}</span>
                        {g.vip && <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />}
                      </div>
                    ),
                  },
                  {
                    key: "contact",
                    header: "Contact",
                    render: (g) => (
                      <div>
                        <div className="text-gray-700">{g.phone ?? "—"}</div>
                        <div className="text-xs text-gray-400">{g.email ?? "—"}</div>
                      </div>
                    ),
                  },
                  {
                    key: "id",
                    header: "ID doc",
                    render: (g) =>
                      g.idNumber ? (
                        <span className="text-xs text-gray-600">
                          {(g.idType ?? "ID").replace(/_/g, " ")} · {g.idNumber}
                        </span>
                      ) : (
                        <span className="text-xs text-gray-400">missing</span>
                      ),
                  },
                  { key: "nationality", header: "Nationality", render: (g) => g.nationality ?? "—" },
                  { key: "city", header: "City", render: (g) => g.city ?? "—" },
                  { key: "stays", header: "Stays", render: (g) => g.reservationCount ?? 0 },
                  { key: "lastStay", header: "Last stay", render: (g) => formatDate(g.lastStay) },
                  {
                    key: "actions",
                    header: "",
                    className: "text-right",
                    render: (g) => (
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => setViewId(g.id)}>
                          <Eye className="h-4 w-4 text-gray-500" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0"
                          onClick={() => {
                            setEditGuest(g);
                            setFormOpen(true);
                          }}
                        >
                          <Pencil className="h-4 w-4 text-gray-500" />
                        </Button>
                        <GuestDeleteButton guest={g} onDelete={() => void deleteGuest(g)} />
                      </div>
                    ),
                  },
                ]}
              />
            )}
          </div>
        </>
      )}

      {/* ── Duplicates ── */}
      {tab === "duplicates" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <StatCard
              label="Duplicate profiles"
              value={s?.duplicates ?? "—"}
              sub={s?.duplicates ? "needs review" : "all clean"}
              tone={(s?.duplicates ?? 0) > 0 ? "rose" : "teal"}
            />
            <StatCard label="Missing ID docs" value={s?.missingId ?? "—"} tone="amber" />
            <StatCard label="Missing contact" value={s?.missingContact ?? "—"} tone="sky" />
          </div>
          {(s?.duplicates ?? 0) > 0 ? (
            <div className="rounded-lg border border-gray-200 p-4 text-sm text-gray-600">
              {s!.duplicates} guest profile pair{sd(s!.duplicates)} share the same phone + ID number. Open the Master
              Guests tab, review the matching profiles and merge them manually.
            </div>
          ) : (
            <EmptyState
              icon={<IdCard className="h-7 w-7" />}
              title="No duplicates detected"
              description="Guests are matched on phone + ID number. New duplicates will be flagged here."
            />
          )}
        </div>
      )}

      <GuestDetailDialog id={viewId} onClose={() => setViewId(null)} />

      <GuestFormDialog
        open={formOpen}
        edit={editGuest}
        onClose={() => {
          setFormOpen(false);
          setEditGuest(null);
        }}
        onSaved={() => {
          list.refetch();
          stats.refetch();
        }}
      />
    </div>
  );
}

function sd(n: number): string {
  return n === 1 ? "" : "s";
}

// ─── Delete button ────────────────────────────────────────────

function GuestDeleteButton({ guest, onDelete }: { guest: Guest; onDelete: () => void }) {
  const [busy, setBusy] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Button
        variant="ghost"
        size="sm"
        className="h-8 w-8 p-0"
        onClick={() => setOpen(true)}
        disabled={busy}
      >
        <Trash2 className="h-4 w-4 text-rose-500" />
      </Button>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Delete {fullName(guest)}?</DialogTitle>
          <DialogDescription>
            Guests with active reservations cannot be deleted. This also removes their orders, reviews and invoices.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button
            className="bg-rose-600 hover:bg-rose-700"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              onDelete();
              setBusy(false);
              setOpen(false);
            }}
          >
            {busy ? "Deleting..." : "Delete"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Detail dialog ────────────────────────────────────────────

function GuestDetailDialog({ id, onClose }: { id: string | null; onClose: () => void }) {
  const [detail, setDetail] = React.useState<GuestDetail | null>(null);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    if (!id) {
      setDetail(null);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setDetail(null);
    apiGet<GuestDetail>(`/api/guests/${id}`)
      .then((d) => !cancelled && setDetail(d))
      .catch((e: unknown) => toast.error(e instanceof Error ? e.message : "Failed to load guest"))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [id]);

  if (!id) return null;

  return (
    <Dialog open={true} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
        {loading || !detail ? (
          <Spinner />
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {fullName(detail.guest)}
                {detail.guest.vip && <Star className="h-4 w-4 fill-amber-400 text-amber-400" />}
              </DialogTitle>
              <DialogDescription>
                {[detail.guest.phone, detail.guest.email, detail.guest.city].filter(Boolean).join(" · ") || "—"}
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <StatCard label="Stays" value={detail.stats.stays} tone="amber" />
              <StatCard label="Total spend" value={formatMoney(detail.stats.spend)} tone="teal" />
              <StatCard label="Orders" value={detail.orders.length} tone="sky" />
              <StatCard label="Reviews" value={detail.reviews.length} tone="amber" />
            </div>

            <div className="rounded-xl border border-gray-200">
              <div className="border-b border-gray-100 px-4 py-2 text-xs font-medium uppercase tracking-wide text-gray-500">
                Profile
              </div>
              <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 px-4 py-3 text-sm">
                <DetailRow label="Nationality" value={detail.guest.nationality} />
                <DetailRow label="Company" value={detail.guest.company} />
                <DetailRow label="Address" value={detail.guest.address} />
                <DetailRow label="City" value={detail.guest.city} />
                <DetailRow
                  label="ID"
                  value={detail.guest.idNumber ? `${(detail.guest.idType ?? "ID").replace(/_/g, " ")} · ${detail.guest.idNumber}` : null}
                />
                <DetailRow label="Notes" value={detail.guest.notes} />
              </div>
            </div>

            <div className="rounded-xl border border-gray-200">
              <div className="border-b border-gray-100 px-4 py-2 text-xs font-medium uppercase tracking-wide text-gray-500">
                Reservation history
              </div>
              <div className="max-h-44 overflow-y-auto">
                <DataTable
                  keyField="id"
                  rows={detail.reservations}
                  empty={<div className="px-4 py-4 text-center text-xs text-gray-400">No reservations yet.</div>}
                  columns={[
                    { key: "code", header: "Code", render: (r) => <span className="font-medium">{r.code}</span> },
                    { key: "dates", header: "Dates", render: (r) => `${formatDate(r.checkIn)} → ${formatDate(r.checkOut)}` },
                    { key: "room", header: "Room", render: (r) => r.room?.number ?? "—" },
                    { key: "totalAmount", header: "Total", render: (r) => <Money v={r.totalAmount} /> },
                    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
                  ]}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-gray-200 p-3">
                <div className="text-xs font-medium uppercase tracking-wide text-gray-400">F&amp;B orders</div>
                {detail.orders.length === 0 ? (
                  <div className="mt-1 text-xs text-gray-400">No orders yet.</div>
                ) : (
                  detail.orders.slice(0, 5).map((o) => (
                    <div key={o.id} className="mt-1.5 flex items-center justify-between text-xs">
                      <span className="font-medium text-gray-800">{o.orderNumber}</span>
                      <span className="flex items-center gap-1.5">
                        {formatMoney(o.totalAmount)} <StatusBadge status={o.status} />
                      </span>
                    </div>
                  ))
                )}
              </div>
              <div className="rounded-xl border border-gray-200 p-3">
                <div className="text-xs font-medium uppercase tracking-wide text-gray-400">Reviews</div>
                {detail.reviews.length === 0 ? (
                  <div className="mt-1 text-xs text-gray-400">No reviews yet.</div>
                ) : (
                  detail.reviews.slice(0, 3).map((rv) => (
                    <div key={rv.id} className="mt-1.5 text-xs">
                      <span className="font-medium text-amber-500">{"★".repeat(rv.rating)}</span>{" "}
                      <span className="text-gray-600">{rv.comment}</span>
                      <div className="text-[11px] text-gray-400">{formatDateTime(rv.createdAt)}</div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function DetailRow({ label, value }: { label: string; value: string | null | undefined }) {
  return (
    <div>
      <div className="text-[11px] uppercase tracking-wide text-gray-400">{label}</div>
      <div className="truncate text-gray-800">{value || "—"}</div>
    </div>
  );
}

// ─── Add / Edit dialog ────────────────────────────────────────

function GuestFormDialog({
  open,
  edit,
  onClose,
  onSaved,
}: {
  open: boolean;
  edit: Guest | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [f, setF] = React.useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    idType: "AADHAAR",
    idNumber: "",
    nationality: "Indian",
    address: "",
    city: "",
    company: "",
    notes: "",
    vip: false,
  });
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    if (!open) return;
    if (edit) {
      setF({
        firstName: edit.firstName ?? "",
        lastName: edit.lastName ?? "",
        email: edit.email ?? "",
        phone: edit.phone ?? "",
        idType: edit.idType ?? "AADHAAR",
        idNumber: edit.idNumber ?? "",
        nationality: edit.nationality ?? "",
        address: edit.address ?? "",
        city: edit.city ?? "",
        company: edit.company ?? "",
        notes: edit.notes ?? "",
        vip: !!edit.vip,
      });
    } else {
      setF({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        idType: "AADHAAR",
        idNumber: "",
        nationality: "Indian",
        address: "",
        city: "",
        company: "",
        notes: "",
        vip: false,
      });
    }
  }, [open, edit]);

  async function save() {
    if (!f.firstName.trim() || !f.lastName.trim()) {
      toast.error("First and last name are required");
      return;
    }
    setBusy(true);
    const body = {
      firstName: f.firstName.trim(),
      lastName: f.lastName.trim(),
      email: f.email.trim() || undefined,
      phone: f.phone.trim() || undefined,
      idType: f.idType,
      idNumber: f.idNumber.trim() || undefined,
      nationality: f.nationality.trim() || undefined,
      address: f.address.trim() || undefined,
      city: f.city.trim() || undefined,
      company: f.company.trim() || undefined,
      notes: f.notes.trim() || undefined,
      vip: f.vip,
    };
    try {
      if (edit) {
        await apiPut(`/api/guests/${edit.id}`, body);
        toast.success(`${body.firstName} ${body.lastName} updated`);
      } else {
        await apiPost("/api/guests", body);
        toast.success(`${body.firstName} ${body.lastName} added`);
      }
      onClose();
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to save guest");
    } finally {
      setBusy(false);
    }
  }

  const set = (k: keyof typeof f) => (v: string | boolean) => setF((p) => ({ ...p, [k]: v }));

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{edit ? `Edit ${fullName(edit)}` : "Add Guest"}</DialogTitle>
          <DialogDescription>Guest profile used for reservations, folios and F&amp;B orders.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="First name" required>
            <Input value={f.firstName} onChange={(e) => set("firstName")(e.target.value)} />
          </Field>
          <Field label="Last name" required>
            <Input value={f.lastName} onChange={(e) => set("lastName")(e.target.value)} />
          </Field>
          <Field label="Phone">
            <Input value={f.phone} onChange={(e) => set("phone")(e.target.value)} placeholder="+91 …" />
          </Field>
          <Field label="Email">
            <Input value={f.email} onChange={(e) => set("email")(e.target.value)} />
          </Field>
          <Field label="ID type">
            <Select value={f.idType} onValueChange={(v) => set("idType")(v)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["AADHAAR", "PASSPORT", "DRIVING_LICENSE", "VOTER_ID", "PAN", "OTHER"].map((t) => (
                  <SelectItem key={t} value={t}>
                    {t.replace(/_/g, " ")}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="ID number">
            <Input value={f.idNumber} onChange={(e) => set("idNumber")(e.target.value)} />
          </Field>
          <Field label="Nationality">
            <Input value={f.nationality} onChange={(e) => set("nationality")(e.target.value)} />
          </Field>
          <Field label="City">
            <Input value={f.city} onChange={(e) => set("city")(e.target.value)} />
          </Field>
          <Field label="Address" className="sm:col-span-2">
            <Input value={f.address} onChange={(e) => set("address")(e.target.value)} />
          </Field>
          <Field label="Company">
            <Input value={f.company} onChange={(e) => set("company")(e.target.value)} />
          </Field>
          <div className="flex items-end gap-3 pb-1">
            <div className="flex items-center gap-2">
              <Switch checked={f.vip} onCheckedChange={(v) => set("vip")(v)} id="vip-switch" />
              <label htmlFor="vip-switch" className="text-sm text-gray-700">
                VIP guest
              </label>
            </div>
          </div>
          <Field label="Notes" className="sm:col-span-2">
            <Textarea value={f.notes} onChange={(e) => set("notes")(e.target.value)} rows={2} />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button disabled={busy} onClick={() => void save()} className="bg-amber-600 hover:bg-amber-700">
            {busy ? "Saving..." : "Save Guest"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
