"use client";

import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AlertOctagon,
  AlertTriangle,
  BedDouble,
  Check,
  Info,
  Loader2,
  MessageSquareReply,
  RefreshCw,
  Sparkles,
  TrendingUp,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { apiGet, apiPost, apiPut, qs } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import {
  EmptyState,
  PageHeader,
  formatMoney,
  useApi,
  type ViewProps,
} from "@/components/views/shared";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";

// ─── Shared API types ─────────────────────────────────────────

type Insight = {
  title: string;
  detail: string;
  severity: "positive" | "warning" | "critical" | "info";
  action: string;
};

type InsightsData = {
  insights: Insight[];
  generatedAt: string;
  cached: boolean;
};

type PricingSuggestion = {
  roomTypeId: string;
  roomTypeName: string;
  currentRate: number;
  suggestedRate: number;
  deltaPercent: number;
  occupancy14d: number;
  next14dBookedRatio: number;
  reason: string;
};

type PricingData = {
  suggestions: PricingSuggestion[];
  generatedAt: string;
};

type ReviewGuest = { id: string; firstName: string; lastName: string } | null;

type Review = {
  id: string;
  channel: string | null;
  rating: number;
  title: string | null;
  comment: string | null;
  reply: string | null;
  status: string;
  createdAt: string;
  guest: ReviewGuest;
};

type ReviewsData = { items: Review[] };

type ReviewReplyDraft = {
  reply: string;
  sentiment: "positive" | "neutral" | "negative";
  themes: string[];
};

type ReservationRow = {
  id: string;
  code: string;
  status: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  guest: { firstName: string; lastName: string } | null;
  roomType: { name: string } | null;
  room: { id: string; number: string } | null;
};

type ReservationsData = { items: ReservationRow[] };

type SmartSuggestion = {
  roomId: string;
  roomNumber: string;
  typeName: string;
  score: number;
  reasons: string[];
};

type SmartAssignData = {
  suggestions: SmartSuggestion[];
  bestRoomId: string | null;
};

// ─── Helpers ──────────────────────────────────────────────────

const CHANNEL_LABELS: Record<string, string> = {
  DIRECT: "Direct",
  BOOKING_COM: "Booking.com",
  GOOGLE: "Google",
  TRIPADVISOR: "TripAdvisor",
  AIRBNB: "Airbnb",
  MAKE_MY_TRIP: "MakeMyTrip",
};

const SEVERITY_META: Record<
  Insight["severity"],
  { icon: React.ReactNode; cls: string; label: string }
> = {
  positive: {
    icon: <TrendingUp className="h-4 w-4" />,
    cls: "bg-emerald-100 text-emerald-600",
    label: "Positive",
  },
  warning: {
    icon: <AlertTriangle className="h-4 w-4" />,
    cls: "bg-amber-100 text-amber-600",
    label: "Warning",
  },
  critical: {
    icon: <AlertOctagon className="h-4 w-4" />,
    cls: "bg-rose-100 text-rose-600",
    label: "Critical",
  },
  info: {
    icon: <Info className="h-4 w-4" />,
    cls: "bg-gray-100 text-gray-600",
    label: "Info",
  },
};

function hhmm(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

function ymd(d: string | Date): string {
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return "—";
  const y = dt.getFullYear();
  const m = String(dt.getMonth() + 1).padStart(2, "0");
  const day = String(dt.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function guestName(g: ReviewGuest): string {
  return g ? `${g.firstName} ${g.lastName}` : "Unknown guest";
}

function pct(n: number | null | undefined): string {
  const v = typeof n === "number" && Number.isFinite(n) ? Math.round(n * 100) : 0;
  return `${v}%`;
}

// ─── Insights tab ─────────────────────────────────────────────

function InsightsSkeleton() {
  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <div key={i} className="rounded-xl border border-gray-200 bg-white p-5">
          <Skeleton className="h-4 w-2/3" />
          <Skeleton className="mt-3 h-3 w-full" />
          <Skeleton className="mt-1.5 h-3 w-4/5" />
          <Skeleton className="mt-4 h-5 w-28 rounded-full" />
        </div>
      ))}
    </div>
  );
}

function InsightsTab() {
  const [refreshing, setRefreshing] = React.useState(false);
  const { data, loading, error, refetch } = useApi<InsightsData>("/api/ai/insights");

  async function refresh() {
    setRefreshing(true);
    try {
      await apiGet<InsightsData>("/api/ai/insights?refresh=1");
      toast.success("Insights refreshed");
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to refresh insights");
    } finally {
      setRefreshing(false);
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs text-gray-500">
          Live operational signals generated by DigiAI from your hotel data, refreshed automatically every 5 minutes.
        </p>
        <Button
          variant="outline"
          size="sm"
          className="shrink-0 border-amber-200 text-amber-700 hover:bg-amber-50"
          disabled={refreshing}
          onClick={() => void refresh()}
        >
          <RefreshCw className={cn("mr-1.5 h-3.5 w-3.5", refreshing && "animate-spin")} />
          {refreshing ? "Refreshing..." : "Refresh"}
        </Button>
      </div>

      {loading ? (
        <InsightsSkeleton />
      ) : error ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-gray-200 bg-white px-6 py-10 text-center">
          <div className="text-sm font-medium text-gray-900">Couldn&apos;t load insights</div>
          <div className="text-xs text-gray-500">{error}</div>
          <Button
            size="sm"
            variant="outline"
            className="border-amber-200 text-amber-700 hover:bg-amber-50"
            onClick={refetch}
          >
            <RefreshCw className="mr-1.5 h-3.5 w-3.5" /> Retry
          </Button>
        </div>
      ) : !data || data.insights.length === 0 ? (
        <EmptyState
          icon={<Sparkles className="h-7 w-7" />}
          title="No insights yet"
          description="DigiAI needs a little activity data first — insights will appear as bookings and operations flow in."
        />
      ) : (
        <div>
          {data.cached && (
            <div className="mb-3 text-xs text-gray-400">
              Cached · generated {hhmm(data.generatedAt)}
            </div>
          )}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {data.insights.map((ins, i) => {
              const meta = SEVERITY_META[ins.severity] ?? SEVERITY_META.info;
              return (
                <motion.div
                  key={`${ins.title}-${i}`}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25, delay: i * 0.05 }}
                >
                  <Card className="h-full">
                    <CardContent className="flex h-full flex-col p-5">
                      <div className="flex items-start gap-2.5">
                        <span
                          className={cn(
                            "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
                            meta.cls
                          )}
                        >
                          {meta.icon}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="text-sm font-semibold leading-snug text-gray-900">
                            {ins.title}
                          </div>
                          <div className="mt-0.5 text-[11px] font-medium uppercase tracking-wide text-gray-400">
                            {meta.label}
                          </div>
                        </div>
                      </div>
                      <p className="mt-3 text-sm text-gray-600">{ins.detail}</p>
                      <div className="mt-auto pt-4">
                        <span className="inline-flex max-w-full items-center gap-1 rounded-full bg-amber-50 px-2.5 py-1 text-xs font-medium text-amber-700">
                          <Zap className="h-3 w-3 shrink-0" />
                          <span className="truncate">Action: {ins.action}</span>
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Dynamic pricing tab ──────────────────────────────────────

function PricingTab() {
  const { data, loading, error, refetch } = useApi<PricingData>("/api/ai/pricing");
  const [applyingId, setApplyingId] = React.useState<string | null>(null);

  async function applyRate(s: PricingSuggestion) {
    setApplyingId(s.roomTypeId);
    try {
      await apiPut(`/api/room-types/${s.roomTypeId}`, { baseRate: s.suggestedRate });
      toast.success(`Rate for ${s.roomTypeName} set to ₹${s.suggestedRate}`);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to apply rate");
    } finally {
      setApplyingId(null);
    }
  }

  return (
    <div className="space-y-3">
      <p className="text-xs text-gray-500">
        AI reads 14-day occupancy, forward demand and weekend skew per room type, then suggests an
        optimal nightly rate. Suggestions are advisory — applying updates the public booking rates
        instantly.
      </p>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="space-y-3 p-4">
              {[0, 1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : error ? (
            <div className="flex flex-col items-center gap-3 px-6 py-10 text-center">
              <div className="text-sm font-medium text-gray-900">Couldn&apos;t load pricing</div>
              <div className="text-xs text-gray-500">{error}</div>
              <Button
                size="sm"
                variant="outline"
                className="border-amber-200 text-amber-700 hover:bg-amber-50"
                onClick={refetch}
              >
                <RefreshCw className="mr-1.5 h-3.5 w-3.5" /> Retry
              </Button>
            </div>
          ) : !data || data.suggestions.length === 0 ? (
            <EmptyState
              icon={<BedDouble className="h-7 w-7" />}
              title="No room types yet"
              description="Add room types and rates in Room view — pricing suggestions appear here."
            />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 hover:bg-gray-50">
                    <TableHead>Room type</TableHead>
                    <TableHead className="text-right">Current rate (₹)</TableHead>
                    <TableHead className="text-right">AI suggested rate (₹)</TableHead>
                    <TableHead className="text-center">Δ%</TableHead>
                    <TableHead className="min-w-[220px]">Why</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.suggestions.map((s) => {
                    const delta = s.deltaPercent;
                    const deltaBadge =
                      delta > 0
                        ? "bg-emerald-100 text-emerald-700"
                        : delta < 0
                          ? "bg-rose-100 text-rose-700"
                          : "bg-gray-100 text-gray-600";
                    return (
                      <TableRow key={s.roomTypeId}>
                        <TableCell className="font-medium text-gray-900">{s.roomTypeName}</TableCell>
                        <TableCell className="text-right text-gray-700">
                          {formatMoney(s.currentRate)}
                        </TableCell>
                        <TableCell className="text-right font-semibold text-gray-900">
                          {formatMoney(s.suggestedRate)}
                        </TableCell>
                        <TableCell className="text-center">
                          <span
                            className={cn(
                              "inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium",
                              deltaBadge
                            )}
                          >
                            {delta > 0 ? "+" : ""}
                            {delta}%
                          </span>
                        </TableCell>
                        <TableCell
                          className="max-w-[260px] truncate text-gray-500"
                          title={s.reason}
                        >
                          {s.reason}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                            disabled={applyingId === s.roomTypeId}
                            onClick={() => void applyRate(s)}
                          >
                            {applyingId === s.roomTypeId ? (
                              <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Check className="mr-1 h-3.5 w-3.5" />
                            )}
                            Apply rate
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Review assistant tab ─────────────────────────────────────

function StarRow({ value }: { value: number }) {
  return (
    <span className="inline-flex items-center gap-0.5" aria-label={`${value} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <svg
          key={i}
          viewBox="0 0 24 24"
          className={cn("h-3.5 w-3.5", i <= Math.round(value) ? "fill-amber-400 text-amber-400" : "text-gray-300")}
          fill={i <= Math.round(value) ? "currentColor" : "none"}
          stroke="currentColor"
          strokeWidth="2"
          aria-hidden="true"
        >
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
        </svg>
      ))}
    </span>
  );
}

function DraftReplyEditor({
  reviewId,
  draft,
  onSent,
  onDiscard,
}: {
  reviewId: string;
  draft: ReviewReplyDraft;
  onSent: () => void;
  onDiscard: () => void;
}) {
  const [text, setText] = React.useState(draft.reply);
  const [sending, setSending] = React.useState(false);

  const sentimentBadge =
    draft.sentiment === "positive"
      ? "bg-emerald-100 text-emerald-700"
      : draft.sentiment === "negative"
        ? "bg-rose-100 text-rose-700"
        : "bg-gray-100 text-gray-600";

  async function sendReply() {
    if (!text.trim()) {
      toast.error("Write a response first");
      return;
    }
    setSending(true);
    try {
      await apiPut(`/api/reviews/${reviewId}`, { reply: text.trim() });
      toast.success("Reply published");
      onSent();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to publish reply");
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="mt-3 rounded-lg border border-amber-100 bg-amber-50/50 p-3">
      <div className="flex flex-wrap items-center gap-2">
        <span
          className={cn(
            "rounded-full px-2 py-0.5 text-xs font-medium",
            sentimentBadge
          )}
        >
          {draft.sentiment}
        </span>
        {draft.themes.map((t) => (
          <span
            key={t}
            className="rounded-full border border-gray-200 bg-white px-2 py-0.5 text-xs text-gray-600"
          >
            {t}
          </span>
        ))}
      </div>
      <Textarea
        rows={4}
        className="mt-2 bg-white"
        value={text}
        onChange={(e) => setText(e.target.value)}
        aria-label={`AI draft reply for review ${reviewId}`}
        placeholder="AI reply draft..."
      />
      <div className="mt-2 flex items-center gap-2">
        <Button
          size="sm"
          className="rounded-lg bg-amber-600 text-white hover:bg-amber-700"
          disabled={sending}
          onClick={() => void sendReply()}
        >
          {sending ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <Check className="mr-1 h-3.5 w-3.5" />}
          Send reply
        </Button>
        <Button size="sm" variant="outline" disabled={sending} onClick={onDiscard}>
          Discard
        </Button>
      </div>
    </div>
  );
}

function ReviewAssistantTab() {
  const { data, loading, error, refetch } = useApi<ReviewsData>(
    `/api/reviews${qs({ period: "90" })}`
  );
  const [draftingId, setDraftingId] = React.useState<string | null>(null);
  const [drafts, setDrafts] = React.useState<Record<string, ReviewReplyDraft>>({});

  const pending = (data?.items ?? []).filter((r) => !r.reply);

  async function draftReply(reviewId: string) {
    setDraftingId(reviewId);
    try {
      const res = await apiPost<ReviewReplyDraft>("/api/ai/review-reply", { reviewId });
      setDrafts((prev) => ({ ...prev, [reviewId]: res }));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "AI draft failed");
    } finally {
      setDraftingId(null);
    }
  }

  return (
    <div className="space-y-3">
      <p className="text-xs text-gray-500">
        Reviews from the last 90 days that haven&apos;t been answered yet. DigiAI drafts a warm,
        on-brand reply — review it, tweak it, then send.
      </p>

      {loading ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-28 w-full rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-gray-200 bg-white px-6 py-10 text-center">
          <div className="text-sm font-medium text-gray-900">Couldn&apos;t load reviews</div>
          <div className="text-xs text-gray-500">{error}</div>
          <Button
            size="sm"
            variant="outline"
            className="border-amber-200 text-amber-700 hover:bg-amber-50"
            onClick={refetch}
          >
            <RefreshCw className="mr-1.5 h-3.5 w-3.5" /> Retry
          </Button>
        </div>
      ) : pending.length === 0 ? (
        <EmptyState
          icon={<MessageSquareReply className="h-7 w-7" />}
          title="Inbox zero!"
          description="Every guest review has a reply. New unanswered reviews will show up here."
        />
      ) : (
        <div className="max-h-[560px] space-y-3 overflow-y-auto pr-1">
          {pending.map((r) => {
            const draft = drafts[r.id];
            return (
              <div key={r.id} className="rounded-xl border border-gray-200 bg-white p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-semibold text-gray-900">{guestName(r.guest)}</span>
                  <StarRow value={r.rating} />
                  <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs text-gray-600">
                    {CHANNEL_LABELS[r.channel ?? ""] ?? (r.channel ?? "—")}
                  </span>
                </div>
                {r.title && (
                  <div className="mt-1 text-sm font-medium text-gray-900">{r.title}</div>
                )}
                <p className="mt-1 line-clamp-2 text-sm text-gray-600">{r.comment}</p>
                <div className="mt-3">
                  {draft ? (
                    <DraftReplyEditor
                      reviewId={r.id}
                      draft={draft}
                      onSent={() => {
                        setDrafts((prev) => {
                          const next = { ...prev };
                          delete next[r.id];
                          return next;
                        });
                        refetch();
                      }}
                      onDiscard={() =>
                        setDrafts((prev) => {
                          const next = { ...prev };
                          delete next[r.id];
                          return next;
                        })
                      }
                    />
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                      disabled={draftingId === r.id}
                      onClick={() => void draftReply(r.id)}
                    >
                      {draftingId === r.id ? (
                        <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Sparkles className="mr-1 h-3.5 w-3.5" />
                      )}
                      Draft AI reply
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── Smart assign tab ─────────────────────────────────────────

function SmartAssignTab() {
  const { data, loading, error, refetch } = useApi<ReservationsData>(
    `/api/reservations${qs({ tab: "upcoming" })}`
  );
  const [reservationId, setReservationId] = React.useState("");
  const [searching, setSearching] = React.useState(false);
  const [assigningId, setAssigningId] = React.useState<string | null>(null);
  const [result, setResult] = React.useState<SmartAssignData | null>(null);

  const upcoming = (data?.items ?? []).filter((r) => r.status === "PENDING" || r.status === "CONFIRMED");

  React.useEffect(() => {
    if (!reservationId && upcoming.length > 0) {
      setReservationId(upcoming[0].id);
    }
  }, [upcoming, reservationId]);

  async function findRooms() {
    if (!reservationId) {
      toast.error("Pick a reservation first");
      return;
    }
    setSearching(true);
    setResult(null);
    try {
      const res = await apiPost<SmartAssignData>("/api/ai/smart-assign", { reservationId });
      setResult(res);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Smart assign failed");
    } finally {
      setSearching(false);
    }
  }

  async function assignRoom(s: SmartSuggestion) {
    if (!reservationId) return;
    setAssigningId(s.roomId);
    try {
      await apiPut(`/api/reservations/${reservationId}`, { roomId: s.roomId });
      toast.success(`Room ${s.roomNumber} assigned to ${upcoming.find((r) => r.id === reservationId)?.code ?? "reservation"}`);
      setResult(null);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to assign room");
    } finally {
      setAssigningId(null);
    }
  }

  return (
    <div className="space-y-3">
      <p className="text-xs text-gray-500">
        DigiAI scans free rooms for each upcoming stay, scores them against guest history and
        special requests, and ranks the best matches — assign with one click.
      </p>

      {loading ? (
        <div className="space-y-3">
          <Skeleton className="h-10 w-full max-w-xl" />
          <Skeleton className="h-24 w-full rounded-xl" />
        </div>
      ) : error ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-gray-200 bg-white px-6 py-10 text-center">
          <div className="text-sm font-medium text-gray-900">Couldn&apos;t load reservations</div>
          <div className="text-xs text-gray-500">{error}</div>
          <Button
            size="sm"
            variant="outline"
            className="border-amber-200 text-amber-700 hover:bg-amber-50"
            onClick={refetch}
          >
            <RefreshCw className="mr-1.5 h-3.5 w-3.5" /> Retry
          </Button>
        </div>
      ) : upcoming.length === 0 ? (
        <EmptyState
          icon={<BedDouble className="h-7 w-7" />}
          title="No upcoming reservations"
          description="Create a reservation first — smart assignment works on upcoming PENDING/CONFIRMED stays."
        />
      ) : (
        <>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <Select value={reservationId} onValueChange={setReservationId}>
              <SelectTrigger className="w-full max-w-xl" aria-label="Select reservation">
                <SelectValue placeholder="Select a reservation" />
              </SelectTrigger>
              <SelectContent>
                {upcoming.map((r) => (
                  <SelectItem key={r.id} value={r.id}>
                    {`${r.code} · ${r.guest ? `${r.guest.firstName} ${r.guest.lastName}` : "Unknown"} · ${ymd(r.checkIn)}→${ymd(r.checkOut)}`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              className="shrink-0 rounded-lg bg-amber-600 text-white hover:bg-amber-700"
              disabled={searching || !reservationId}
              onClick={() => void findRooms()}
            >
              {searching ? (
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="mr-1.5 h-4 w-4" />
              )}
              {searching ? "Scanning rooms..." : "Find best rooms"}
            </Button>
          </div>

          <AnimatePresence>
            {result && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25 }}
              >
                {result.suggestions.length === 0 ? (
                  <div className="rounded-xl border border-gray-200 bg-white px-5 py-8 text-center text-sm text-gray-600">
                    No rooms of this type are free for those dates — try an upgrade type or shift
                    dates.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {result.suggestions.map((s, idx) => {
                      const isBest = result.bestRoomId === s.roomId || idx === 0;
                      return (
                        <div
                          key={s.roomId}
                          className={cn(
                            "rounded-xl border bg-white p-4",
                            isBest ? "border-amber-300 ring-1 ring-amber-200" : "border-gray-200"
                          )}
                        >
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-gray-100 text-xs font-semibold text-gray-600">
                              #{idx + 1}
                            </span>
                            <span className="text-sm font-semibold text-gray-900">
                              Room {s.roomNumber}
                            </span>
                            <span className="text-sm text-gray-500">({s.typeName})</span>
                            {isBest && (
                              <Badge className="border-transparent bg-amber-600 text-white hover:bg-amber-600">
                                Best match
                              </Badge>
                            )}
                            <span className="rounded-full bg-amber-50 px-2 py-0.5 text-xs font-semibold text-amber-700">
                              Score {s.score}
                            </span>
                            <Button
                              size="sm"
                              variant="outline"
                              className="ml-auto h-8 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                              disabled={assigningId !== null}
                              onClick={() => void assignRoom(s)}
                            >
                              {assigningId === s.roomId ? (
                                <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
                              ) : (
                                <Check className="mr-1 h-3.5 w-3.5" />
                              )}
                              Assign room {s.roomNumber}
                            </Button>
                          </div>
                          <ul className="mt-2 list-disc space-y-0.5 pl-9 text-xs text-gray-500">
                            {s.reasons.map((reason, i) => (
                              <li key={i}>{reason}</li>
                            ))}
                          </ul>
                        </div>
                      );
                    })}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </>
      )}
    </div>
  );
}

// ─── View ─────────────────────────────────────────────────────

export default function AiHubView({ user: _user }: ViewProps) {
  return (
    <div className="space-y-4">
      <PageHeader title="AI Automation Hub" crumbs={["Dashboard", "AI Automation"]}>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-200 bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-700">
          <Sparkles className="h-3.5 w-3.5" />
          Powered by DigiAI 2.0
        </span>
      </PageHeader>

      <p className="max-w-2xl text-sm text-gray-500">
        Agentic AI built into your operations — it reads live hotel data, suggests smarter rates and
        room assignments, and drafts guest replies so your team can act in one click.
      </p>

      <Tabs defaultValue="insights">
        <TabsList className="h-auto w-full max-w-full flex-wrap justify-start gap-0 overflow-x-auto bg-amber-50/70 p-[3px] sm:inline-flex sm:w-fit">
          <TabsTrigger value="insights" className="whitespace-nowrap">Insights</TabsTrigger>
          <TabsTrigger value="pricing" className="whitespace-nowrap">Dynamic Pricing</TabsTrigger>
          <TabsTrigger value="review-assistant" className="whitespace-nowrap">Review Assistant</TabsTrigger>
          <TabsTrigger value="smart-assign" className="whitespace-nowrap">Smart Assign</TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="mt-3">
          <InsightsTab />
        </TabsContent>
        <TabsContent value="pricing" className="mt-3">
          <PricingTab />
        </TabsContent>
        <TabsContent value="review-assistant" className="mt-3">
          <ReviewAssistantTab />
        </TabsContent>
        <TabsContent value="smart-assign" className="mt-3">
          <SmartAssignTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
