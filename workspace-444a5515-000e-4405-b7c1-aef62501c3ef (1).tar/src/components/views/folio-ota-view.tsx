'use client';

import { FolioManager } from "./folio-company-view";
import type { ViewProps } from "./shared";

export default function FolioOtaView({ user }: ViewProps) {
  return <FolioManager user={user} mode="OTA" />;
}
