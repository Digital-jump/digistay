"use client";

import * as React from "react";
import {
  ArrowDownToLine,
  CalendarClock,
  ClipboardCheck,
  LogIn,
  LogOut,
  Search,
} from "lucide-react";
import { toast } from "sonner";
import { apiGet, apiPost, qs } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import {
  DataTable,
  EmptyState,
  Field,
  Money,
  PageHeader,
  Spinner,
  StatCard,
  StatusBadge,
  formatDate,
  formatMoney,
  ymd,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// ─── Types ────────────────────────────────────────────────────

type ReservationRow = {
  id: string;
  code: string;
  status: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  totalAmount: number;
  paidAmount: number;
  source: string;
  guest: { firstName: string; lastName: string; phone?: string | null } | null;
  roomType: { id: string; name: string } | null;
  room: { id: string; number: string } | null;
};

type ReservationsData = { items: ReservationRow[]; counts: { upcoming: number; checkedin: number; history: number } };

type DashboardData = {
  stats: { inHouseGuests: number; arrivalsToday: number; departuresToday: number };
};

type AvailabilityData = {
  available: { id: string; number: string; floor: number }[];
  nights: number;
  rate: number;
};

function guestName(r: ReservationRow): string {
  return r.guest ? `${r.guest.firstName} ${r.guest.lastName}` : "—";
}

function daysUntil(iso: string): number {
  const target = new Date(`${ymd(iso)}T00:00:00`).getTime();
  const now = new Date(`${ymd(new Date())}T00:00:00`).getTime();
  return Math.round((target - now) / 86400000);
}

// ─── View ─────────────────────────────────────────────────────

export default function CheckinsView(_props: ViewProps) {
  const [tab, setTab] = React.useState("active");

  const { data: dash } = useApi<DashboardData>("/api/dashboard");
  const active = useApi<ReservationsData>("/api/reservations?tab=checkedin");
  const past = useApi<ReservationsData>("/api/reservations?tab=history");
  const upcoming = useApi<ReservationsData>("/api/reservations?tab=upcoming");

  const [startOpen, setStartOpen] = React.useState(false);
  const [busyId, setBusyId] = React.useState<string | null>(null);
  const [viewRow, setViewRow] = React.useState<ReservationRow | null>(null);
  const [payRow, setPayRow] = React.useState<ReservationRow | null>(null);
  const [pickRow, setPickRow] = React.useState<ReservationRow | null>(null);

  function refetchAll() {
    active.refetch();
    past.refetch();
    upcoming.refetch();
  }

  async function checkOut(r: ReservationRow) {
    setBusyId(r.id);
    try {
      await apiPost(`/api/reservations/${r.id}/checkout`);
      toast.success(`${r.code} checked out`);
      refetchAll();
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Check-out failed";
      toast.error(/unsettled|balance/i.test(msg) ? `${msg}. Settle the folio before checkout.` : msg);
    } finally {
      setBusyId(null);
    }
  }

  async function checkIn(r: ReservationRow) {
    if (!r.room?.id) {
      setPickRow(r);
      return;
    }
    setBusyId(r.id);
    try {
      await apiPost(`/api/reservations/${r.id}/checkin`, { roomId: r.room.id });
      toast.success(`${r.code} checked in to room ${r.room.number}`);
      refetchAll();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Check-in failed");
    } finally {
      setBusyId(null);
    }
  }

  const tabs = [
    { id: "active", label: "Active", count: active.data?.items.length ?? undefined },
    { id: "past", label: "Past", count: past.data?.counts.history ?? undefined },
    { id: "requests", label: "Requests" },
  ];

  const requests = (upcoming.data?.items ?? []).filter((r) => {
    if (r.status !== "PENDING" && r.status !== "CONFIRMED") return false;
    const d = daysUntil(r.checkIn);
    return d === 0 || d === 1;
  });

  return (
    <div className="space-y-4">
      <PageHeader title="All Checkins" crumbs={["Front Desk", "Check-ins & Guests", "Check-ins"]}>
        <Button
          size="sm"
          onClick={() => setStartOpen(true)}
          className="h-9 rounded-lg bg-amber-600 text-white hover:bg-amber-700"
        >
          <LogIn className="mr-1.5 h-4 w-4" /> Start Check-in
        </Button>
      </PageHeader>

      {/* Guest stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          label="In-house now"
          value={dash?.stats.inHouseGuests ?? "—"}
          sub={`${active.data?.items.length ?? 0} active stays`}
          tone="amber"
          icon={<ClipboardCheck className="h-4 w-4" />}
        />
        <StatCard
          label="Arrivals today"
          value={dash?.stats.arrivalsToday ?? "—"}
          sub={`${requests.length} arriving today/tomorrow`}
          tone="teal"
          icon={<ArrowDownToLine className="h-4 w-4" />}
        />
        <StatCard
          label="Departures today"
          value={dash?.stats.departuresToday ?? "—"}
          sub="checkouts pending"
          tone="amber"
          icon={<LogOut className="h-4 w-4" />}
        />
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
              tab === t.id
                ? "border-amber-600 bg-white text-amber-700 shadow-sm"
                : "border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:text-gray-900"
            )}
          >
            {t.label}
            {typeof t.count === "number" && <span className="ml-1 text-gray-400">({t.count})</span>}
          </button>
        ))}
      </div>

      {/* Active */}
      {tab === "active" &&
        (active.loading ? (
          <Spinner />
        ) : active.error ? (
          <EmptyState title="Couldn't load in-house stays" description={active.error} />
        ) : (active.data?.items.length ?? 0) === 0 ? (
          <EmptyState
            icon={<ClipboardCheck className="h-7 w-7" />}
            title="No in-house guests"
            description="Check-ins will appear here as guests arrive."
          />
        ) : (
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
            {active.data!.items.map((r) => {
              const dep = daysUntil(r.checkOut);
              return (
                <div key={r.id} className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="text-2xl font-bold text-amber-700">{r.room?.number ?? "—"}</div>
                      <div className="text-xs text-gray-400">{r.roomType?.name ?? "—"}</div>
                    </div>
                    <StatusBadge status={r.status} />
                  </div>
                  <div className="mt-3">
                    <div className="font-semibold text-gray-900">{guestName(r)}</div>
                    <div className="text-xs text-gray-500">{r.code}</div>
                  </div>
                  <div className="mt-2 flex items-center gap-3 text-xs text-gray-500">
                    <span>
                      in {formatDate(r.checkIn)} · out {formatDate(r.checkOut)}
                    </span>
                    <span
                      className={cn(
                        "ml-auto whitespace-nowrap rounded-full px-2 py-0.5 font-medium",
                        dep === 0 ? "bg-amber-100 text-amber-700" : "bg-gray-100 text-gray-500"
                      )}
                    >
                      {dep === 0 ? "departs today" : `departs in ${dep} day${dep === 1 ? "" : "s"}`}
                    </span>
                  </div>
                  <div className="mt-3 flex items-center justify-between border-t border-gray-100 pt-3">
                    <div className="text-xs text-gray-500">
                      Total <span className="font-semibold text-gray-900"><Money v={r.totalAmount} /></span>
                      {r.paidAmount > 0 && <span className="ml-1">· paid {formatMoney(r.paidAmount)}</span>}
                    </div>
                    <div className="flex gap-1.5">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setViewRow(r)}
                        className="h-8 rounded-lg border-gray-200 text-xs text-gray-700 hover:bg-gray-50"
                      >
                        View
                      </Button>
                      <Button
                        size="sm"
                        disabled={busyId === r.id}
                        onClick={() => void checkOut(r)}
                        className="h-8 rounded-lg bg-amber-600 text-xs text-white hover:bg-amber-700"
                      >
                        <LogOut className="mr-1 h-3.5 w-3.5" /> Check-out
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ))}

      {/* Past */}
      {tab === "past" && (
        <div className="rounded-lg border border-gray-200">
          {past.loading ? (
            <Spinner />
          ) : past.error ? (
            <EmptyState title="Couldn't load history" description={past.error} />
          ) : (
            <DataTable<ReservationRow>
              keyField="id"
              rows={past.data?.items ?? []}
              empty={<EmptyState title="No past checkins" />}
              columns={[
                { key: "code", header: "Code", render: (r) => <span className="font-medium text-gray-900">{r.code}</span> },
                { key: "guest", header: "Guest", render: guestName },
                { key: "room", header: "Room", render: (r) => r.room?.number ?? "—" },
                {
                  key: "dates",
                  header: "Dates",
                  render: (r) => (
                    <span className="whitespace-nowrap">
                      {formatDate(r.checkIn)} → {formatDate(r.checkOut)}
                    </span>
                  ),
                },
                { key: "totalAmount", header: "Total", render: (r) => <Money v={r.totalAmount} /> },
                { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
              ]}
            />
          )}
        </div>
      )}

      {/* Requests (arriving today/tomorrow) */}
      {tab === "requests" && (
        <div className="rounded-lg border border-gray-200">
          {upcoming.loading ? (
            <Spinner />
          ) : upcoming.error ? (
            <EmptyState title="Couldn't load upcoming" description={upcoming.error} />
          ) : (
            <DataTable<ReservationRow>
              keyField="id"
              rows={requests}
              empty={
                <EmptyState
                  icon={<CalendarClock className="h-7 w-7" />}
                  title="No arrivals today or tomorrow"
                  description="Upcoming PENDING / CONFIRMED stays arriving within 24 hours appear here."
                />
              }
              columns={[
                { key: "code", header: "Code", render: (r) => <span className="font-medium text-gray-900">{r.code}</span> },
                {
                  key: "guest",
                  header: "Guest",
                  render: (r) => (
                    <div>
                      <div className="font-medium text-gray-900">{guestName(r)}</div>
                      <div className="text-xs text-gray-400">{r.guest?.phone ?? "—"}</div>
                    </div>
                  ),
                },
                { key: "roomType", header: "Type", render: (r) => r.roomType?.name ?? "—" },
                { key: "room", header: "Room", render: (r) => r.room?.number ?? "Unassigned" },
                {
                  key: "checkIn",
                  header: "Arrives",
                  render: (r) => (
                    <span className="whitespace-nowrap">
                      {formatDate(r.checkIn)}
                      <span className="ml-1 text-xs text-gray-400">
                        ({daysUntil(r.checkIn) === 0 ? "today" : "tomorrow"})
                      </span>
                    </span>
                  ),
                },
                { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
                {
                  key: "actions",
                  header: "",
                  className: "text-right",
                  render: (r) => (
                    <Button
                      size="sm"
                      disabled={busyId === r.id}
                      onClick={() => void checkIn(r)}
                      className="h-8 rounded-lg bg-amber-600 text-xs text-white hover:bg-amber-700"
                    >
                      <LogIn className="mr-1 h-3.5 w-3.5" /> Check-in
                    </Button>
                  ),
                },
              ]}
            />
          )}
        </div>
      )}

      <StartCheckInDialog open={startOpen} onOpenChange={setStartOpen} onDone={refetchAll} />

      <PickRoomDialog
        row={pickRow}
        onClose={() => setPickRow(null)}
        onDone={() => {
          setPickRow(null);
          refetchAll();
        }}
      />

      {/* Active guest view dialog */}
      <Dialog open={!!viewRow} onOpenChange={(open) => !open && setViewRow(null)}>
        <DialogContent className="sm:max-w-md">
          {viewRow && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {guestName(viewRow)} <StatusBadge status={viewRow.status} />
                </DialogTitle>
                <DialogDescription>
                  {viewRow.code} · Room {viewRow.room?.number ?? "—"} · {viewRow.roomType?.name ?? "—"}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-2 rounded-lg bg-gray-50 p-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Stay</span>
                  <span className="font-medium text-gray-900">
                    {formatDate(viewRow.checkIn)} → {formatDate(viewRow.checkOut)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Guests</span>
                  <span className="font-medium text-gray-900">
                    {viewRow.adults} adults{viewRow.children ? `, ${viewRow.children} children` : ""}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Total</span>
                  <span className="font-medium text-gray-900">
                    <Money v={viewRow.totalAmount} />
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Paid</span>
                  <span className="font-medium text-gray-900">
                    <Money v={viewRow.paidAmount} />
                  </span>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setPayRow(viewRow)} className="rounded-lg">
                  Record Payment
                </Button>
                <Button
                  disabled={busyId === viewRow.id}
                  onClick={() => {
                    const r = viewRow;
                    setViewRow(null);
                    void checkOut(r);
                  }}
                  className="rounded-lg bg-amber-600 hover:bg-amber-700"
                >
                  <LogOut className="mr-1.5 h-4 w-4" /> Check-out
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <RecordPaymentDialog
        row={payRow}
        onClose={() => setPayRow(null)}
        onDone={() => {
          setPayRow(null);
          refetchAll();
        }}
      />
    </div>
  );
}

// ─── Check-in helper (shared) ──────────────────────────────────

async function checkInReservation(r: ReservationRow, roomId: string | undefined, onDone: () => void) {
  try {
    await apiPost(`/api/reservations/${r.id}/checkin`, roomId ? { roomId } : {});
    toast.success(`${r.code} checked in${r.room ? ` to room ${r.room.number}` : ""}`);
    onDone();
  } catch (e) {
    toast.error(e instanceof Error ? e.message : "Check-in failed");
  }
}

// ─── Start check-in search dialog ─────────────────────────────

function StartCheckInDialog({
  open,
  onOpenChange,
  onDone,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onDone: () => void;
}) {
  const [search, setSearch] = React.useState("");
  const [results, setResults] = React.useState<ReservationRow[] | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [busyId, setBusyId] = React.useState<string | null>(null);
  const [pickRow, setPickRow] = React.useState<ReservationRow | null>(null);

  React.useEffect(() => {
    if (!open) {
      setSearch("");
      setResults(null);
      setPickRow(null);
    }
  }, [open]);

  React.useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setLoading(true);
    const t = window.setTimeout(() => {
      apiGet<ReservationsData>(`/api/reservations${qs({ tab: "upcoming", search })}`)
        .then((d) => !cancelled && setResults(d.items))
        .catch((e: unknown) => toast.error(e instanceof Error ? e.message : "Search failed"))
        .finally(() => !cancelled && setLoading(false));
    }, 300);
    return () => {
      cancelled = true;
      window.clearTimeout(t);
    };
  }, [open, search]);

  async function doCheckIn(r: ReservationRow) {
    setBusyId(r.id);
    if (r.room?.id) {
      await checkInReservation(r, r.room.id, () => {
        onDone();
        onOpenChange(false);
      });
      setBusyId(null);
    } else {
      setBusyId(null);
      setPickRow(r);
    }
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Start Check-in</DialogTitle>
            <DialogDescription>Search upcoming reservations by guest name or booking code.</DialogDescription>
          </DialogHeader>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Name or code, e.g. RSV-2026…"
              className="pl-9"
              autoFocus
            />
          </div>
          <div className="max-h-72 space-y-1.5 overflow-y-auto">
            {loading ? (
              <Spinner />
            ) : !results ? null : results.length === 0 ? (
              <EmptyState title="No upcoming reservations found" />
            ) : (
              results.slice(0, 25).map((r) => {
                const eligible = r.status === "PENDING" || r.status === "CONFIRMED";
                return (
                  <div
                    key={r.id}
                    className="flex items-center gap-3 rounded-lg border border-gray-200 px-3 py-2"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium text-gray-900">
                        {guestName(r)}{" "}
                        <span className="font-normal text-gray-400">· {r.code}</span>
                      </div>
                      <div className="text-xs text-gray-500">
                        {r.roomType?.name ?? "—"} · {formatDate(r.checkIn)} → {formatDate(r.checkOut)} ·{" "}
                        {r.room?.number ? `Room ${r.room.number}` : "room at check-in"}
                      </div>
                    </div>
                    <StatusBadge status={r.status} />
                    {eligible ? (
                      <Button
                        size="sm"
                        disabled={busyId === r.id}
                        onClick={() => void doCheckIn(r)}
                        className="h-8 shrink-0 rounded-lg bg-amber-600 text-xs text-white hover:bg-amber-700"
                      >
                        <LogIn className="mr-1 h-3.5 w-3.5" /> Check-in
                      </Button>
                    ) : null}
                  </div>
                );
              })
            )}
          </div>
        </DialogContent>
      </Dialog>

      <PickRoomDialog
        row={pickRow}
        onClose={() => setPickRow(null)}
        onDone={() => {
          setPickRow(null);
          onDone();
          onOpenChange(false);
        }}
      />
    </>
  );
}

// ─── Pick room dialog ─────────────────────────────────────────

function PickRoomDialog({
  row,
  onClose,
  onDone,
}: {
  row: ReservationRow | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const [rooms, setRooms] = React.useState<AvailabilityData["available"] | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    if (!row) return;
    let cancelled = false;
    setLoading(true);
    setRooms(null);
    apiGet<AvailabilityData>(
      `/api/reservations/availability${qs({
        roomTypeId: row.roomType?.id,
        checkIn: ymd(row.checkIn),
        checkOut: ymd(row.checkOut),
        excludeReservationId: row.id,
      })}`
    )
      .then((d) => !cancelled && setRooms(d.available))
      .catch((e: unknown) => toast.error(e instanceof Error ? e.message : "Failed to load availability"))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [row]);

  if (!row) return null;

  return (
    <Dialog open={true} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Assign a room — {row.code}</DialogTitle>
          <DialogDescription>
            {guestName(row)} · {row.roomType?.name ?? "—"} · {formatDate(row.checkIn)} → {formatDate(row.checkOut)}
          </DialogDescription>
        </DialogHeader>
        {loading ? (
          <Spinner />
        ) : (rooms?.length ?? 0) === 0 ? (
          <EmptyState title="No rooms available" description="Try different dates or another room type." />
        ) : (
          <div className="max-h-64 space-y-1.5 overflow-y-auto">
            {rooms!.map((rm) => (
              <button
                key={rm.id}
                type="button"
                disabled={busy}
                onClick={() => {
                  setBusy(true);
                  void checkInReservation(row, rm.id, onDone).finally(() => setBusy(false));
                }}
                className="flex w-full items-center justify-between rounded-lg border border-gray-200 px-3 py-2 text-left text-sm transition-colors hover:border-amber-300 hover:bg-amber-50"
              >
                <span className="font-semibold text-gray-900">Room {rm.number}</span>
                <span className="text-xs text-gray-400">Floor {rm.floor}</span>
              </button>
            ))}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ─── Record payment ───────────────────────────────────────────

function RecordPaymentDialog({
  row,
  onClose,
  onDone,
}: {
  row: ReservationRow | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const [amount, setAmount] = React.useState("");
  const [method, setMethod] = React.useState("CASH");
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    if (row) {
      setAmount(String(Math.max(0, (row.totalAmount ?? 0) - (row.paidAmount ?? 0)) || ""));
      setMethod("CASH");
    }
  }, [row]);

  if (!row) return null;

  async function save() {
    if (!row) return;
    const amt = Number(amount);
    if (!amt || amt <= 0) {
      toast.error("Enter a valid amount");
      return;
    }
    setBusy(true);
    try {
      await apiPost(`/api/reservations/${row.id}/payment`, { amount: amt, method });
      toast.success(`Payment of ${formatMoney(amt)} recorded`);
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Payment failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={true} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Record Payment — {row.code}</DialogTitle>
          <DialogDescription>
            Paid so far: {formatMoney(row.paidAmount)} of {formatMoney(row.totalAmount)}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <Field label="Amount (₹)" required>
            <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </Field>
          <Field label="Method" required>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["CASH", "UPI", "DEBIT_CARD", "CREDIT_CARD", "BANK_TRANSFER", "RAZORPAY", "OTHER"].map((m) => (
                  <SelectItem key={m} value={m}>
                    {m.replace(/_/g, " ")}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button disabled={busy} onClick={() => void save()} className="bg-amber-600 hover:bg-amber-700">
            {busy ? "Saving..." : "Record Payment"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
