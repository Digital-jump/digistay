'use client';

import * as React from "react";
import { Download, Info } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  DataTable,
  downloadCsv,
  EmptyState,
  formatDateTime,
  formatMoney,
  PageHeader,
  Spinner,
  TabsBar,
  useApi,
  type ViewProps,
  ymd,
} from "./shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// ─── Shared report plumbing ───────────────────────────────────

type ExportSpec = {
  filename: string;
  columns: { key: string; header: string }[];
  rows: Record<string, unknown>[];
} | null;

type TabProps = { onExport: (spec: ExportSpec) => void };

function monthStart(): string {
  const now = new Date();
  return ymd(new Date(now.getFullYear(), now.getMonth(), 1));
}

function DateRangeFilter({
  from,
  to,
  setFrom,
  setTo,
}: {
  from: string;
  to: string;
  setFrom: (v: string) => void;
  setTo: (v: string) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-xl border border-gray-200 bg-white p-3">
      <span className="text-sm font-medium text-gray-600">From</span>
      <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="w-[150px]" />
      <span className="text-xs text-gray-400">to</span>
      <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="w-[150px]" />
    </div>
  );
}

function SingleDateFilter({ date, setDate }: { date: string; setDate: (v: string) => void }) {
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-xl border border-gray-200 bg-white p-3">
      <span className="text-sm font-medium text-gray-600">Date</span>
      <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-[170px]" />
    </div>
  );
}

function FinCard({
  title,
  subtitle,
  rows,
  totalLabel,
  totalValue,
}: {
  title: string;
  subtitle: string;
  rows: { label: string; value: number; cls?: string }[];
  totalLabel: string;
  totalValue: number;
}) {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4">
      <div className="text-sm font-semibold text-gray-900">{title}</div>
      <div className="mb-3 text-xs text-gray-400">{subtitle}</div>
      <div className="space-y-1.5">
        {rows.map((r) => (
          <div key={r.label} className="flex items-center justify-between text-sm">
            <span className="text-gray-500">{r.label}</span>
            <span className={cn("font-medium text-gray-900", r.cls)}>{formatMoney(r.value)}</span>
          </div>
        ))}
      </div>
      <div className="mt-2 flex items-center justify-between border-t border-gray-100 pt-2 text-sm font-bold text-gray-900">
        <span>{totalLabel}</span>
        <span>{formatMoney(totalValue)}</span>
      </div>
    </div>
  );
}

const thCls =
  "sticky top-0 z-10 whitespace-nowrap bg-gray-50 px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wide text-gray-500";
const tdCls = "px-4 py-3 text-gray-700";
const tdRight = "px-4 py-3 text-right tabular-nums text-gray-700";
const money = (n: number | null | undefined) => formatMoney(n ?? 0);

function TableWrap({ children }: { children: React.ReactNode }) {
  return <div className="overflow-x-auto rounded-xl border border-gray-200 bg-white">{children}</div>;
}

const METHOD_COLUMNS: { key: string; header: string }[] = [
  { key: "CASH", header: "Cash" },
  { key: "UPI", header: "UPI" },
  { key: "DEBIT_CARD", header: "Debit Card" },
  { key: "CREDIT_CARD", header: "Credit Card" },
  { key: "BANK_TRANSFER", header: "Bank Transfer" },
  { key: "RAZORPAY", header: "Razorpay" },
  { key: "OTHER", header: "Other" },
];

// ─── Revenue ──────────────────────────────────────────────────

type RevenueData = {
  rows: { date: string; roomRevenue: number; fbRevenue: number; other: number; total: number }[];
  totals: { room: number; fb: number; other: number; total: number };
};

function RevenueTab({ onExport }: TabProps) {
  const [from, setFrom] = React.useState(monthStart);
  const [to, setTo] = React.useState(ymd(new Date()));
  const { data, loading, error } = useApi<RevenueData>(`/api/reports/revenue?from=${from}&to=${to}`);

  React.useEffect(() => {
    const spec: ExportSpec =
      data && data.rows.length
        ? {
            filename: "revenue-report",
            columns: [
              { key: "date", header: "Date" },
              { key: "roomRevenue", header: "Room Revenue" },
              { key: "fbRevenue", header: "F&B Revenue" },
              { key: "other", header: "Other" },
              { key: "total", header: "Total" },
            ],
            rows: data.rows,
          }
        : null;
    onExport(spec);
    return () => onExport(null);
  }, [data, onExport]);

  if (loading) return <Spinner />;
  if (error) return <EmptyState title="Couldn't load revenue report" description={error} />;

  return (
    <div className="space-y-4">
      <DateRangeFilter from={from} to={to} setFrom={setFrom} setTo={setTo} />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl bg-amber-50 p-4">
          <div className="text-sm font-medium text-gray-600">Room Revenue</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{money(data?.totals.room)}</div>
        </div>
        <div className="rounded-xl bg-teal-50 p-4">
          <div className="text-sm font-medium text-gray-600">F&amp;B Revenue</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{money(data?.totals.fb)}</div>
        </div>
        <div className="rounded-xl bg-amber-50 p-4">
          <div className="text-sm font-medium text-gray-600">Other</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{money(data?.totals.other)}</div>
        </div>
        <div className="rounded-xl bg-sky-50 p-4">
          <div className="text-sm font-medium text-gray-600">Total</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{money(data?.totals.total)}</div>
        </div>
      </div>
      <TableWrap>
        <DataTable
          keyField="date"
          rows={data?.rows ?? []}
          empty={<EmptyState title="No revenue in this period" />}
          columns={[
            { key: "date", header: "Date", render: (r) => <span className="font-medium text-gray-900">{String(r.date)}</span> },
            { key: "roomRevenue", header: "Room Revenue", className: "text-right", render: (r) => money(Number(r.roomRevenue)) },
            { key: "fbRevenue", header: "F&B Revenue", className: "text-right", render: (r) => money(Number(r.fbRevenue)) },
            { key: "other", header: "Other", className: "text-right", render: (r) => money(Number(r.other)) },
            { key: "total", header: "Total", className: "text-right font-semibold text-gray-900", render: (r) => money(Number(r.total)) },
          ]}
        />
      </TableWrap>
    </div>
  );
}

// ─── Payment Ledger ───────────────────────────────────────────

type PaymentsData = {
  rows: Record<string, string | number>[];
  totals: Record<string, number>;
};

function PaymentLedgerTab({ onExport }: TabProps) {
  const [from, setFrom] = React.useState(monthStart);
  const [to, setTo] = React.useState(ymd(new Date()));
  const { data, loading, error } = useApi<PaymentsData>(`/api/reports/payments?from=${from}&to=${to}`);

  React.useEffect(() => {
    const spec: ExportSpec =
      data && data.rows.length
        ? {
            filename: "payment-ledger",
            columns: [{ key: "date", header: "Date" }, ...METHOD_COLUMNS, { key: "total", header: "Total" }],
            rows: data.rows,
          }
        : null;
    onExport(spec);
    return () => onExport(null);
  }, [data, onExport]);

  if (loading) return <Spinner />;
  if (error) return <EmptyState title="Couldn't load payment ledger" description={error} />;

  return (
    <div className="space-y-4">
      <DateRangeFilter from={from} to={to} setFrom={setFrom} setTo={setTo} />
      <TableWrap>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr>
                <th className={thCls}>Date</th>
                {METHOD_COLUMNS.map((m) => (
                  <th key={m.key} className={cn(thCls, "text-right")}>
                    {m.header}
                  </th>
                ))}
                <th className={cn(thCls, "text-right")}>Total</th>
              </tr>
            </thead>
            <tbody>
              {(data?.rows ?? []).length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-0 py-0">
                    <EmptyState title="No payments in this period" />
                  </td>
                </tr>
              ) : (
                (data?.rows ?? []).map((row, i) => (
                  <tr key={String(row.date ?? i)} className="border-b border-gray-100 last:border-b-0 hover:bg-gray-50">
                    <td className={cn(tdCls, "font-medium text-gray-900")}>{String(row.date)}</td>
                    {METHOD_COLUMNS.map((m) => (
                      <td key={m.key} className={tdRight}>
                        {money(Number(row[m.key] ?? 0))}
                      </td>
                    ))}
                    <td className={cn(tdRight, "font-semibold text-gray-900")}>{money(Number(row.total ?? 0))}</td>
                  </tr>
                ))
              )}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-gray-200 bg-gray-50">
                <td className="px-4 py-2.5 text-sm font-bold text-gray-900">Total</td>
                {METHOD_COLUMNS.map((m) => (
                  <td key={m.key} className={cn(tdRight, "font-bold text-gray-900")}>
                    {money(Number(data?.totals?.[m.key] ?? 0))}
                  </td>
                ))}
                <td className={cn(tdRight, "font-bold text-amber-700")}>{money(Number(data?.totals?.total ?? 0))}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </TableWrap>
    </div>
  );
}

// ─── Outstanding Payment ──────────────────────────────────────

type OutstandingData = {
  rows: {
    invoiceNumber: string;
    billingType: string;
    guestName: string;
    folioName: string | null;
    issuedAt: string;
    total: number;
    paidAmount: number;
    balance: number;
    daysDue: number;
  }[];
  totals: { total: number; collected: number; outstanding: number };
};

function OutstandingTab({ onExport }: TabProps) {
  const { data, loading, error } = useApi<OutstandingData>("/api/reports/outstanding");

  React.useEffect(() => {
    const spec: ExportSpec =
      data && data.rows.length
        ? {
            filename: "outstanding-payments",
            columns: [
              { key: "invoiceNumber", header: "Invoice No." },
              { key: "guestName", header: "Guest" },
              { key: "issuedAt", header: "Issued" },
              { key: "total", header: "Total" },
              { key: "paidAmount", header: "Paid" },
              { key: "balance", header: "Balance" },
              { key: "daysDue", header: "Days Due" },
            ],
            rows: data.rows.map((r) => ({ ...r, issuedAt: r.issuedAt?.slice(0, 10) })),
          }
        : null;
    onExport(spec);
    return () => onExport(null);
  }, [data, onExport]);

  if (loading) return <Spinner />;
  if (error) return <EmptyState title="Couldn't load outstanding payments" description={error} />;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-xl bg-amber-50 p-4">
          <div className="text-sm font-medium text-gray-600">Total Billed</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{money(data?.totals.total)}</div>
        </div>
        <div className="rounded-xl bg-emerald-50 p-4">
          <div className="text-sm font-medium text-gray-600">Collected</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{money(data?.totals.collected)}</div>
        </div>
        <div className="rounded-xl bg-rose-50 p-4">
          <div className="text-sm font-medium text-gray-600">Outstanding</div>
          <div className="mt-1 text-2xl font-bold text-rose-700">{money(data?.totals.outstanding)}</div>
        </div>
      </div>
      <TableWrap>
        <DataTable
          keyField="invoiceNumber"
          rows={data?.rows ?? []}
          empty={<EmptyState title="Nothing outstanding" description="Every invoice has been settled." />}
          columns={[
            { key: "invoiceNumber", header: "Invoice No.", render: (r) => <span className="font-medium text-gray-900">{String(r.invoiceNumber)}</span> },
            { key: "guestName", header: "Guest / Folio", render: (r) => String(r.folioName || r.guestName || "—") },
            { key: "issuedAt", header: "Issued", render: (r) => String(r.issuedAt).slice(0, 10) },
            { key: "total", header: "Total", className: "text-right", render: (r) => money(Number(r.total)) },
            { key: "paidAmount", header: "Paid", className: "text-right", render: (r) => money(Number(r.paidAmount)) },
            { key: "balance", header: "Balance", className: "text-right font-semibold text-rose-600", render: (r) => money(Number(r.balance)) },
            { key: "daysDue", header: "Days Due", className: "text-right", render: (r) => <span className={cn(Number(r.daysDue) > 7 && "font-semibold text-rose-600")}>{String(r.daysDue)}</span> },
          ]}
        />
      </TableWrap>
    </div>
  );
}

// ─── Invoice Summary ──────────────────────────────────────────

type InvoiceSummaryData = {
  rows: {
    number: string;
    issuedAt: string;
    billingType: string;
    guestName: string;
    subtotal: number;
    tax: number;
    discount: number;
    total: number;
    paidAmount: number;
    status: string;
  }[];
  totals: { count: number; subtotal: number; tax: number; discount: number; total: number; paidAmount: number };
};

function InvoiceSummaryTab({ onExport }: TabProps) {
  const [from, setFrom] = React.useState(monthStart);
  const [to, setTo] = React.useState(ymd(new Date()));
  const { data, loading, error } = useApi<InvoiceSummaryData>(`/api/reports/invoice-summary?from=${from}&to=${to}`);

  React.useEffect(() => {
    const spec: ExportSpec =
      data && data.rows.length
        ? {
            filename: "invoice-summary",
            columns: [
              { key: "number", header: "Invoice No." },
              { key: "issuedAt", header: "Issued" },
              { key: "billingType", header: "Type" },
              { key: "guestName", header: "Guest" },
              { key: "subtotal", header: "Subtotal" },
              { key: "tax", header: "Tax" },
              { key: "discount", header: "Discount" },
              { key: "total", header: "Total" },
              { key: "paidAmount", header: "Paid" },
              { key: "status", header: "Status" },
            ],
            rows: data.rows.map((r) => ({ ...r, issuedAt: r.issuedAt?.slice(0, 10) })),
          }
        : null;
    onExport(spec);
    return () => onExport(null);
  }, [data, onExport]);

  if (loading) return <Spinner />;
  if (error) return <EmptyState title="Couldn't load invoice summary" description={error} />;

  const t = data?.totals;
  return (
    <div className="space-y-4">
      <DateRangeFilter from={from} to={to} setFrom={setFrom} setTo={setTo} />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl bg-amber-50 p-4">
          <div className="text-sm font-medium text-gray-600">Invoices</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{t?.count ?? 0}</div>
        </div>
        <div className="rounded-xl bg-sky-50 p-4">
          <div className="text-sm font-medium text-gray-600">Total Billed</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{money(t?.total)}</div>
        </div>
        <div className="rounded-xl bg-emerald-50 p-4">
          <div className="text-sm font-medium text-gray-600">Collected</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{money(t?.paidAmount)}</div>
        </div>
        <div className="rounded-xl bg-rose-50 p-4">
          <div className="text-sm font-medium text-gray-600">Outstanding</div>
          <div className="mt-1 text-2xl font-bold text-rose-700">{money((t?.total ?? 0) - (t?.paidAmount ?? 0))}</div>
        </div>
      </div>
      <TableWrap>
        <DataTable
          keyField="number"
          rows={data?.rows ?? []}
          empty={<EmptyState title="No invoices in this period" />}
          columns={[
            { key: "number", header: "Invoice No.", render: (r) => <span className="font-medium text-gray-900">{String(r.number)}</span> },
            { key: "issuedAt", header: "Issued", render: (r) => String(r.issuedAt).slice(0, 10) },
            { key: "billingType", header: "Type", render: (r) => String(r.billingType) },
            { key: "guestName", header: "Guest / Folio", render: (r) => String(r.guestName || "—") },
            { key: "subtotal", header: "Subtotal", className: "text-right", render: (r) => money(Number(r.subtotal)) },
            { key: "tax", header: "Tax", className: "text-right", render: (r) => money(Number(r.tax)) },
            { key: "discount", header: "Discount", className: "text-right", render: (r) => money(Number(r.discount)) },
            { key: "total", header: "Total", className: "text-right font-semibold", render: (r) => money(Number(r.total)) },
            { key: "paidAmount", header: "Paid", className: "text-right", render: (r) => money(Number(r.paidAmount)) },
            { key: "status", header: "Status", render: (r) => String(r.status) },
          ]}
        />
      </TableWrap>
    </div>
  );
}

// ─── Room Sales ───────────────────────────────────────────────

type RoomSalesData = {
  rows: { roomNumber: string; roomTypeName: string; nights: number; revenue: number; reservations: number }[];
  totals: { nights: number; revenue: number };
};

function RoomSalesTab({ onExport }: TabProps) {
  const [from, setFrom] = React.useState(monthStart);
  const [to, setTo] = React.useState(ymd(new Date()));
  const { data, loading, error } = useApi<RoomSalesData>(`/api/reports/room-sales?from=${from}&to=${to}`);

  React.useEffect(() => {
    const spec: ExportSpec =
      data && data.rows.length
        ? {
            filename: "room-sales",
            columns: [
              { key: "roomNumber", header: "Room" },
              { key: "roomTypeName", header: "Room Type" },
              { key: "nights", header: "Nights" },
              { key: "reservations", header: "Reservations" },
              { key: "revenue", header: "Revenue" },
            ],
            rows: data.rows,
          }
        : null;
    onExport(spec);
    return () => onExport(null);
  }, [data, onExport]);

  if (loading) return <Spinner />;
  if (error) return <EmptyState title="Couldn't load room sales" description={error} />;

  return (
    <div className="space-y-4">
      <DateRangeFilter from={from} to={to} setFrom={setFrom} setTo={setTo} />
      <div className="grid grid-cols-2 gap-4">
        <div className="rounded-xl bg-amber-50 p-4">
          <div className="text-sm font-medium text-gray-600">Room Nights Sold</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{data?.totals.nights ?? 0}</div>
        </div>
        <div className="rounded-xl bg-teal-50 p-4">
          <div className="text-sm font-medium text-gray-600">Room Revenue</div>
          <div className="mt-1 text-2xl font-bold text-gray-900">{money(data?.totals.revenue)}</div>
        </div>
      </div>
      <TableWrap>
        <DataTable
          keyField="roomNumber"
          rows={data?.rows ?? []}
          empty={<EmptyState title="No room sales in this period" />}
          columns={[
            { key: "roomNumber", header: "Room", render: (r) => <span className="font-medium text-gray-900">{String(r.roomNumber)}</span> },
            { key: "roomTypeName", header: "Room Type", render: (r) => String(r.roomTypeName ?? "—") },
            { key: "nights", header: "Nights", className: "text-right", render: (r) => String(r.nights) },
            { key: "reservations", header: "Reservations", className: "text-right", render: (r) => String(r.reservations) },
            { key: "revenue", header: "Revenue", className: "text-right font-semibold text-gray-900", render: (r) => money(Number(r.revenue)) },
          ]}
        />
      </TableWrap>
    </div>
  );
}

// ─── Night Audit ──────────────────────────────────────────────

type NightAuditData = {
  date: string;
  revenue: { roomRevenue: number; fbRoomService: number; fbRestaurant: number; roomDiscount: number; foodDiscount: number; total: number };
  tax: { roomTaxes: number; fbTaxes: number; total: number };
  payments: Record<string, number> & { total: number };
  reservationsActivity: { code: string; guestName: string; roomNumber: string | null; action: string; time: string }[];
  checkinActivity: { code: string; guestName: string; roomNumber: string | null; time: string }[];
  occupancy: { totalRooms: number; occupiedTonight: number; occupancyRate: number; arrivals: number; departures: number; inHouse: number };
};

const ACTION_BADGE: Record<string, string> = {
  ARRIVAL: "bg-amber-100 text-amber-700",
  DEPARTURE: "bg-amber-100 text-amber-700",
  CREATED: "bg-emerald-100 text-emerald-700",
  CANCELLED: "bg-rose-100 text-rose-700",
};

function NightAuditTab({ onExport }: TabProps) {
  const [date, setDate] = React.useState(ymd(new Date()));
  const { data, loading, error } = useApi<NightAuditData>(`/api/reports/night-audit?date=${date}`);

  React.useEffect(() => {
    if (!data || data.date !== date) {
      onExport(null);
      return () => onExport(null);
    }
    const spec: ExportSpec = {
      filename: `night-audit-${date}`,
      columns: [
        { key: "section", header: "Section" },
        { key: "label", header: "Item" },
        { key: "value", header: "Value" },
      ],
      rows: [
        ...Object.entries(data.revenue).map(([k, v]) => ({ section: "Revenue", label: k, value: Number(v) })),
        ...Object.entries(data.tax).map(([k, v]) => ({ section: "Tax", label: k, value: Number(v) })),
        ...Object.entries(data.payments).map(([k, v]) => ({ section: "Payments", label: k, value: Number(v) })),
        ...data.reservationsActivity.map((a) => ({ section: "Activity", label: `${a.code} ${a.action}`, value: a.time })),
      ],
    };
    onExport(spec);
    return () => onExport(null);
  }, [data, date, onExport]);

  if (loading) return <Spinner />;
  if (error) return <EmptyState title="Couldn't load night audit" description={error} />;

  const occ = data?.occupancy;
  const activity = data?.reservationsActivity ?? [];

  return (
    <div className="space-y-4">
      <SingleDateFilter date={date} setDate={setDate} />

      {/* Occupancy chips */}
      <div className="flex flex-wrap items-center gap-2">
        {[
          { label: "Total Rooms", value: occ?.totalRooms ?? 0 },
          { label: "Occupied Tonight", value: occ?.occupiedTonight ?? 0 },
          { label: "Occupancy", value: `${occ?.occupancyRate ?? 0}%` },
          { label: "Arrivals", value: occ?.arrivals ?? 0 },
          { label: "Departures", value: occ?.departures ?? 0 },
          { label: "In-House", value: occ?.inHouse ?? 0 },
        ].map((c) => (
          <span key={c.label} className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-3 py-1 text-xs text-gray-600">
            {c.label}
            <span className="font-semibold text-gray-900">{c.value}</span>
          </span>
        ))}
      </div>

      <div>
        <h2 className="mb-2 text-base font-semibold text-gray-900">Financial Overview</h2>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <FinCard
            title="Revenue"
            subtitle="Total revenue made on the current day"
            rows={[
              { label: "Room Revenue (incl. additional charges)", value: data?.revenue.roomRevenue ?? 0 },
              { label: "F&B Revenue (In-Room Dining)", value: data?.revenue.fbRoomService ?? 0 },
              { label: "F&B Revenue (Restaurant)", value: data?.revenue.fbRestaurant ?? 0 },
              { label: "Room Discount", value: data?.revenue.roomDiscount ?? 0, cls: "text-rose-600" },
              { label: "Food Discount", value: data?.revenue.foodDiscount ?? 0, cls: "text-rose-600" },
            ]}
            totalLabel="Total"
            totalValue={data?.revenue.total ?? 0}
          />
          <FinCard
            title="Invoice Tax Summary"
            subtitle="Applied on revenue booked on current date"
            rows={[
              { label: "Room Taxes", value: data?.tax.roomTaxes ?? 0 },
              { label: "F&B Taxes", value: data?.tax.fbTaxes ?? 0 },
            ]}
            totalLabel="Total Tax"
            totalValue={data?.tax.total ?? 0}
          />
          <FinCard
            title="Payments Summary"
            subtitle="Transactions happened on the current date"
            rows={METHOD_COLUMNS.map((m) => ({ label: m.header, value: Number(data?.payments?.[m.key] ?? 0) }))}
            totalLabel="Total"
            totalValue={Number(data?.payments?.total ?? 0)}
          />
        </div>
      </div>

      <div>
        <h2 className="mb-2 text-base font-semibold text-gray-900">Reservations Overview</h2>
        <TableWrap>
          <DataTable
            keyField="key"
            rows={activity.map((a, i) => ({ ...a, key: `${a.code}-${i}` }))}
            empty={<EmptyState title="No reservations activity for the date" />}
            columns={[
              { key: "time", header: "Time", render: (r) => formatDateTime(String(r.time)) },
              { key: "code", header: "Booking", render: (r) => <span className="font-medium text-gray-900">{String(r.code)}</span> },
              { key: "guestName", header: "Guest", render: (r) => String(r.guestName ?? "—") },
              { key: "roomNumber", header: "Room", render: (r) => String(r.roomNumber ?? "—") },
              {
                key: "action",
                header: "Action",
                render: (r) => (
                  <span className={cn("inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium", ACTION_BADGE[String(r.action)] ?? "bg-gray-100 text-gray-600")}>
                    {String(r.action).replace(/_/g, " ")}
                  </span>
                ),
              },
            ]}
          />
        </TableWrap>
      </div>

      <div>
        <h2 className="mb-2 text-base font-semibold text-gray-900">Guest Activity</h2>
        <TableWrap>
          <DataTable
            keyField="key"
            rows={(data?.checkinActivity ?? []).map((a, i) => ({ ...a, key: `${a.code}-${i}` }))}
            empty={<EmptyState title="No checkin activity for the date" />}
            columns={[
              { key: "time", header: "Time", render: (r) => formatDateTime(String(r.time)) },
              { key: "code", header: "Booking", render: (r) => <span className="font-medium text-gray-900">{String(r.code)}</span> },
              { key: "guestName", header: "Guest", render: (r) => String(r.guestName ?? "—") },
              { key: "roomNumber", header: "Room", render: (r) => String(r.roomNumber ?? "—") },
            ]}
          />
        </TableWrap>
      </div>
    </div>
  );
}

// ─── OTA Commission ───────────────────────────────────────────

const OTA_LABELS: Record<string, string> = {
  OTA_BOOKING_COM: "Booking.com",
  OTA_MAKE_MY_TRIP: "MakeMyTrip",
  OTA_AIRBNB: "Airbnb",
  OTA_EXPEDIA: "Expedia",
  OTA_GOIBIBO: "Goibibo",
};

type OtaData = {
  rows: { source: string; bookings: number; nights: number; revenue: number; commissionRate: number; commission: number }[];
  totals: { bookings: number; nights: number; revenue: number; commission: number };
};

function OtaCommissionTab({ onExport }: TabProps) {
  const [from, setFrom] = React.useState(monthStart);
  const [to, setTo] = React.useState(ymd(new Date()));
  const { data, loading, error } = useApi<OtaData>(`/api/reports/ota?from=${from}&to=${to}`);

  React.useEffect(() => {
    const spec: ExportSpec =
      data && data.rows.length
        ? {
            filename: "ota-commission",
            columns: [
              { key: "source", header: "Source" },
              { key: "bookings", header: "Bookings" },
              { key: "nights", header: "Nights" },
              { key: "revenue", header: "Revenue" },
              { key: "commissionRate", header: "Commission %" },
              { key: "commission", header: "Commission" },
            ],
            rows: data.rows.map((r) => ({ ...r, source: OTA_LABELS[r.source] ?? r.source })),
          }
        : null;
    onExport(spec);
    return () => onExport(null);
  }, [data, onExport]);

  if (loading) return <Spinner />;
  if (error) return <EmptyState title="Couldn't load OTA commission" description={error} />;

  return (
    <div className="space-y-4">
      <DateRangeFilter from={from} to={to} setFrom={setFrom} setTo={setTo} />
      <TableWrap>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr>
                <th className={thCls}>Source</th>
                <th className={cn(thCls, "text-right")}>Bookings</th>
                <th className={cn(thCls, "text-right")}>Nights</th>
                <th className={cn(thCls, "text-right")}>Revenue</th>
                <th className={cn(thCls, "text-right")}>Commission %</th>
                <th className={cn(thCls, "text-right")}>Commission</th>
              </tr>
            </thead>
            <tbody>
              {(data?.rows ?? []).length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-0 py-0">
                    <EmptyState title="No OTA bookings in this period" />
                  </td>
                </tr>
              ) : (
                (data?.rows ?? []).map((r) => (
                  <tr key={r.source} className="border-b border-gray-100 last:border-b-0 hover:bg-gray-50">
                    <td className={cn(tdCls, "font-medium text-gray-900")}>{OTA_LABELS[r.source] ?? r.source.replace(/_/g, " ")}</td>
                    <td className={tdRight}>{r.bookings}</td>
                    <td className={tdRight}>{r.nights}</td>
                    <td className={tdRight}>{money(r.revenue)}</td>
                    <td className={tdRight}>{r.commissionRate}%</td>
                    <td className={cn(tdRight, "font-semibold text-rose-600")}>{money(r.commission)}</td>
                  </tr>
                ))
              )}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-gray-200 bg-gray-50">
                <td className="px-4 py-2.5 text-sm font-bold text-gray-900">Total</td>
                <td className={cn(tdRight, "font-bold text-gray-900")}>{data?.totals.bookings ?? 0}</td>
                <td className={cn(tdRight, "font-bold text-gray-900")}>{data?.totals.nights ?? 0}</td>
                <td className={cn(tdRight, "font-bold text-gray-900")}>{money(data?.totals.revenue)}</td>
                <td />
                <td className={cn(tdRight, "font-bold text-rose-700")}>{money(data?.totals.commission)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </TableWrap>
    </div>
  );
}

// ─── Police Verification ──────────────────────────────────────

type PoliceData = {
  rows: {
    guestName: string;
    nationality: string | null;
    idType: string | null;
    idNumber: string | null;
    phone: string | null;
    roomNumber: string | null;
    checkIn: string;
    checkOut: string;
  }[];
  date: string;
};

function PoliceTab({ onExport }: TabProps) {
  const [date, setDate] = React.useState(ymd(new Date()));
  const { data, loading, error } = useApi<PoliceData>(`/api/reports/police?date=${date}`);

  React.useEffect(() => {
    const spec: ExportSpec =
      data && data.rows.length
        ? {
            filename: `police-verification-${date}`,
            columns: [
              { key: "guestName", header: "Guest" },
              { key: "nationality", header: "Nationality" },
              { key: "idType", header: "ID Type" },
              { key: "idNumber", header: "ID Number" },
              { key: "phone", header: "Phone" },
              { key: "roomNumber", header: "Room" },
              { key: "checkIn", header: "Check-in" },
              { key: "checkOut", header: "Check-out" },
            ],
            rows: data.rows.map((r) => ({
              ...r,
              checkIn: r.checkIn?.slice(0, 10),
              checkOut: r.checkOut?.slice(0, 10),
            })),
          }
        : null;
    onExport(spec);
    return () => onExport(null);
  }, [data, date, onExport]);

  if (loading) return <Spinner />;
  if (error) return <EmptyState title="Couldn't load police register" description={error} />;

  return (
    <div className="space-y-4">
      <SingleDateFilter date={date} setDate={setDate} />
      <TableWrap>
        <DataTable
          keyField="idNumber"
          rows={(data?.rows ?? []).map((r, i) => ({ ...r, id: String(i) }))}
          empty={<EmptyState title="No arrivals to report for the date" />}
          columns={[
            { key: "guestName", header: "Guest", render: (r) => <span className="font-medium text-gray-900">{String(r.guestName)}</span> },
            { key: "nationality", header: "Nationality", render: (r) => String(r.nationality ?? "—") },
            { key: "idType", header: "ID Type", render: (r) => String(r.idType ?? "—") },
            { key: "idNumber", header: "ID Number", render: (r) => String(r.idNumber ?? "—") },
            { key: "phone", header: "Phone", render: (r) => String(r.phone ?? "—") },
            { key: "roomNumber", header: "Room", render: (r) => String(r.roomNumber ?? "—") },
            { key: "checkIn", header: "Check-in", render: (r) => String(r.checkIn).slice(0, 10) },
            { key: "checkOut", header: "Check-out", render: (r) => String(r.checkOut).slice(0, 10) },
          ]}
        />
      </TableWrap>
      <div className="flex items-start gap-2 rounded-lg bg-gray-50 px-3 py-2 text-xs text-gray-500">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        Verified arrivals only — guests who checked in (or were due to arrive) on the selected date.
      </div>
    </div>
  );
}

// ─── Parent view ──────────────────────────────────────────────

const REPORT_TABS = [
  { id: "revenue", label: "Revenue" },
  { id: "payments", label: "Payment Ledger" },
  { id: "outstanding", label: "Outstanding Payment" },
  { id: "invoice-summary", label: "Invoice Summary" },
  { id: "room-sales", label: "Room Sales" },
  { id: "night-audit", label: "Night Audit" },
  { id: "ota", label: "OTA Commission" },
  { id: "police", label: "Police Verification" },
];

export default function ReportsStandardView({ user: _user }: ViewProps) {
  const [tab, setTab] = React.useState("revenue");
  const [exportSpec, setExportSpec] = React.useState<ExportSpec>(null);

  const tabs = REPORT_TABS.map((t) => ({ ...t }));

  return (
    <div className="space-y-4">
      <PageHeader title="Standard Reports" crumbs={["Dashboard", "Reports", "Standard"]}>
        <Button
          variant="outline"
          disabled={!exportSpec}
          onClick={() => {
            if (exportSpec) downloadCsv(exportSpec.filename, exportSpec.columns, exportSpec.rows);
          }}
        >
          <Download className="mr-1.5 h-4 w-4" /> Export CSV
        </Button>
      </PageHeader>

      <TabsBar tabs={tabs} active={tab} onChange={setTab} />

      {tab === "revenue" && <RevenueTab onExport={setExportSpec} />}
      {tab === "payments" && <PaymentLedgerTab onExport={setExportSpec} />}
      {tab === "outstanding" && <OutstandingTab onExport={setExportSpec} />}
      {tab === "invoice-summary" && <InvoiceSummaryTab onExport={setExportSpec} />}
      {tab === "room-sales" && <RoomSalesTab onExport={setExportSpec} />}
      {tab === "night-audit" && <NightAuditTab onExport={setExportSpec} />}
      {tab === "ota" && <OtaCommissionTab onExport={setExportSpec} />}
      {tab === "police" && <PoliceTab onExport={setExportSpec} />}
    </div>
  );
}
