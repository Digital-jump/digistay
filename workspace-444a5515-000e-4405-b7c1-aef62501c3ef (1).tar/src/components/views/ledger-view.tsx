'use client';

import * as React from "react";
import { ArrowDownToLine, ArrowUpFromLine, Banknote, Download, Wallet } from "lucide-react";
import { toast } from "sonner";
import { apiPost, qs } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import {
  DataTable,
  downloadCsv,
  EmptyState,
  Field,
  formatDateTime,
  formatMoney,
  PageHeader,
  Spinner,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

// ─── Types ────────────────────────────────────────────────────

type LedgerEntry = {
  id: string;
  type: string; // OPENING | CASH_IN | CASH_OUT
  amount: number;
  method: string;
  category: string | null;
  remarks: string | null;
  createdAt: string;
};

type LedgerSummary = {
  opening: number;
  cashIn: number;
  cashOut: number;
  closing: number;
  inByMethod: Record<string, number>;
  outByMethod: Record<string, number>;
  paymentsByMethod: Record<string, number>;
};

type LedgerData = { entries: LedgerEntry[]; summary: LedgerSummary };

type DialogKind = "cashin" | "cashout" | "petty" | "opening";

// ─── Local label helpers ──────────────────────────────────────

const METHOD_LABELS: Record<string, string> = {
  CASH: "Cash",
  UPI: "UPI",
  DEBIT_CARD: "Debit Card",
  CREDIT_CARD: "Credit Card",
  BANK_TRANSFER: "Bank Transfer",
  RAZORPAY: "Razorpay",
  OTHER: "Other",
};
const METHODS = Object.keys(METHOD_LABELS);

const CATEGORY_LABELS: Record<string, string> = {
  OWNER_DEPOSIT: "Owner Deposit",
  PETTY_CASH: "Petty Cash",
  SUPPLIER: "Supplier",
  STAFF: "Staff",
  REFUND: "Refund",
  OTHER: "Other",
};

const TYPE_BADGE: Record<string, string> = {
  OPENING: "bg-amber-100 text-amber-700",
  CASH_IN: "bg-emerald-100 text-emerald-700",
  CASH_OUT: "bg-rose-100 text-rose-700",
};

function TypeBadge({ type }: { type: string }) {
  return (
    <span
      className={cn(
        "inline-flex whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium",
        TYPE_BADGE[type] ?? "bg-gray-100 text-gray-600"
      )}
    >
      {(CATEGORY_LABELS[type] ?? type).replace(/_/g, " ")}
    </span>
  );
}

function prettyCategory(c: string | null): string {
  if (!c) return "—";
  return CATEGORY_LABELS[c] ?? c.replace(/_/g, " ");
}

// ─── View ─────────────────────────────────────────────────────

export default function LedgerView({ user: _user }: ViewProps) {
  const [type, setType] = React.useState("all");
  const [method, setMethod] = React.useState("all");
  const [from, setFrom] = React.useState("");
  const [to, setTo] = React.useState("");

  const url = `/api/ledger${qs({
    from: from || undefined,
    to: to || undefined,
    type: type === "all" ? undefined : type,
    method: method === "all" ? undefined : method,
  })}`;
  const { data, loading, error, refetch } = useApi<LedgerData>(url);

  const [dialog, setDialog] = React.useState<DialogKind | null>(null);
  const [amount, setAmount] = React.useState("");
  const [dlgMethod, setDlgMethod] = React.useState("CASH");
  const [category, setCategory] = React.useState("OWNER_DEPOSIT");
  const [remarks, setRemarks] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  function openDialog(kind: DialogKind) {
    setDialog(kind);
    setAmount("");
    setDlgMethod("CASH");
    setCategory(kind === "cashout" ? "SUPPLIER" : kind === "opening" || kind === "petty" ? "PETTY_CASH" : "OWNER_DEPOSIT");
    setRemarks("");
  }

  async function submitEntry() {
    if (!dialog) return;
    const value = Number(amount);
    if (!value || value <= 0) {
      toast.error("Enter an amount greater than 0");
      return;
    }
    const body =
      dialog === "cashin"
        ? { type: "CASH_IN", amount: value, method: dlgMethod, category, remarks }
        : dialog === "cashout"
          ? { type: "CASH_OUT", amount: value, method: dlgMethod, category, remarks }
          : dialog === "petty"
            ? { type: "CASH_IN", amount: value, method: dlgMethod, category: "PETTY_CASH", remarks: remarks || "Petty cash top-up" }
            : { type: "OPENING", amount: value, method: dlgMethod, category: "PETTY_CASH", remarks: remarks || "Opening balance" };
    setSaving(true);
    try {
      await apiPost("/api/ledger", body);
      toast.success(
        dialog === "cashin"
          ? "Cash in recorded"
          : dialog === "cashout"
            ? "Cash out recorded"
            : dialog === "petty"
              ? "Petty cash added"
              : "Opening balance set"
      );
      setDialog(null);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to record entry");
    } finally {
      setSaving(false);
    }
  }

  function exportCsv() {
    if (!data) return;
    downloadCsv(
      "ledger-transactions",
      [
        { key: "date", header: "Date & Time" },
        { key: "type", header: "Type" },
        { key: "category", header: "Category" },
        { key: "method", header: "Payment Method" },
        { key: "amount", header: "Amount" },
        { key: "remarks", header: "Remarks" },
      ],
      data.entries.map((e) => ({
        date: formatDateTime(e.createdAt),
        type: e.type,
        category: prettyCategory(e.category),
        method: METHOD_LABELS[e.method] ?? e.method,
        amount: e.type === "CASH_OUT" ? -e.amount : e.amount,
        remarks: e.remarks ?? "",
      }))
    );
  }

  if (loading) return <Spinner />;
  if (error) return <EmptyState title="Couldn't load ledger" description={error} />;

  const summary = data?.summary;
  const entries = data?.entries ?? [];
  const methodBalance = (m: string) =>
    (summary?.inByMethod?.[m] ?? 0) - (summary?.outByMethod?.[m] ?? 0);
  const breakdown = (map: Record<string, number> | undefined) =>
    METHODS.filter((m) => (map?.[m] ?? 0) !== 0).map((m) => ({
      method: m,
      value: map?.[m] ?? 0,
    }));

  return (
    <div className="space-y-4">
      <style>{`@media print { .print-hide { display: none !important; } }`}</style>
      <PageHeader title="Ledger" crumbs={["Dashboard", "Finance", "Ledger"]}>
        <Button
          variant="outline"
          className="border-amber-300 text-amber-700 hover:bg-amber-50"
          onClick={() => openDialog("cashin")}
        >
          <ArrowDownToLine className="mr-1.5 h-4 w-4" /> Cash In
        </Button>
        <Button
          variant="outline"
          className="border-rose-300 text-rose-700 hover:bg-rose-50"
          onClick={() => openDialog("cashout")}
        >
          <ArrowUpFromLine className="mr-1.5 h-4 w-4" /> Cash Out
        </Button>
        <Button className="bg-amber-600 text-white hover:bg-amber-700" onClick={() => openDialog("petty")}>
          <Wallet className="mr-1.5 h-4 w-4" /> Petty Cash
        </Button>
      </PageHeader>

      {/* Balance strip */}
      <div className="flex flex-col gap-3 rounded-xl border border-gray-200 bg-white px-4 py-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-rose-500" />
          <span className="text-sm font-semibold text-gray-900">Current Balance</span>
          <span className="text-lg font-bold text-gray-900">{formatMoney(summary?.closing)}</span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {METHODS.map((m) => (
            <span
              key={m}
              className="inline-flex items-center gap-1 rounded-full border border-gray-200 px-2.5 py-1 text-xs text-gray-600"
            >
              {METHOD_LABELS[m]}
              <span className="font-semibold text-gray-900">{formatMoney(methodBalance(m))}</span>
            </span>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="print-hide flex flex-wrap items-center gap-2 rounded-xl border border-gray-200 bg-white p-3">
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Select type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All types</SelectItem>
            <SelectItem value="OPENING">Opening</SelectItem>
            <SelectItem value="CASH_IN">Cash In</SelectItem>
            <SelectItem value="CASH_OUT">Cash Out</SelectItem>
          </SelectContent>
        </Select>
        <Select value={method} onValueChange={setMethod}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Payment method" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All methods</SelectItem>
            {METHODS.map((m) => (
              <SelectItem key={m} value={m}>
                {METHOD_LABELS[m]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="w-[150px]" />
        <span className="text-xs text-gray-400">to</span>
        <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="w-[150px]" />
        <Select value="date-desc" onValueChange={() => undefined}>
          <SelectTrigger className="w-[150px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="date-desc">Newest first</SelectItem>
            <SelectItem value="date-asc">Oldest first</SelectItem>
            <SelectItem value="amount-desc">Amount high → low</SelectItem>
          </SelectContent>
        </Select>
        <div className="ml-auto">
          <Button variant="outline" size="sm" className="h-9" onClick={exportCsv}>
            <Download className="mr-1.5 h-3.5 w-3.5" /> Export CSV
          </Button>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <div className="text-sm font-medium text-gray-600">BALANCE</div>
          <div className="mt-1 text-3xl font-bold text-gray-900">{formatMoney(summary?.closing)}</div>
          <div className="mt-1 flex items-center gap-2 text-xs text-gray-500">
            Opening {formatMoney(summary?.opening)}
            <button
              type="button"
              className="font-medium text-amber-600 underline-offset-2 hover:underline"
              onClick={() => openDialog("opening")}
            >
              Set opening
            </button>
          </div>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <div className="text-sm font-medium text-gray-600">CASH IN</div>
          <div className="mt-1 text-3xl font-bold text-emerald-600">{formatMoney(summary?.cashIn)}</div>
          <div className="mt-2 space-y-1">
            {breakdown(summary?.inByMethod).length === 0 ? (
              <div className="text-xs text-gray-400">No cash in for this period</div>
            ) : (
              breakdown(summary?.inByMethod).map((r) => (
                <div key={r.method} className="flex items-center justify-between text-xs text-gray-600">
                  <span>{METHOD_LABELS[r.method]}</span>
                  <span className="font-medium text-gray-900">{formatMoney(r.value)}</span>
                </div>
              ))
            )}
          </div>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <div className="text-sm font-medium text-gray-600">CASH OUT</div>
          <div className="mt-1 text-3xl font-bold text-rose-600">{formatMoney(summary?.cashOut)}</div>
          <div className="mt-2 space-y-1">
            {breakdown(summary?.outByMethod).length === 0 ? (
              <div className="text-xs text-gray-400">No cash out for this period</div>
            ) : (
              breakdown(summary?.outByMethod).map((r) => (
                <div key={r.method} className="flex items-center justify-between text-xs text-gray-600">
                  <span>{METHOD_LABELS[r.method]}</span>
                  <span className="font-medium text-gray-900">{formatMoney(r.value)}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Transactions */}
      <div className="rounded-xl border border-gray-200 bg-white">
        <div className="flex items-center justify-between border-b border-gray-100 px-4 py-3">
          <div className="text-sm font-semibold text-gray-900">Transactions</div>
          <div className="text-xs text-gray-400">{entries.length} entries</div>
        </div>
        <div className="overflow-x-auto">
          <DataTable<LedgerEntry>
            keyField="id"
            rows={entries}
            empty={
              <EmptyState
                icon={<Banknote className="h-7 w-7" />}
                title="No transactions found for this period"
                description="Cash in, cash out and opening entries will appear here."
              />
            }
            columns={[
              { key: "createdAt", header: "Date & Time", render: (r) => formatDateTime(r.createdAt) },
              { key: "type", header: "Type", render: (r) => <TypeBadge type={r.type} /> },
              { key: "category", header: "Category", render: (r) => prettyCategory(r.category) },
              { key: "method", header: "Payment Method", render: (r) => METHOD_LABELS[r.method] ?? r.method },
              {
                key: "amount",
                header: "Amount",
                className: "text-right",
                render: (r) => (
                  <span
                    className={cn(
                      "font-semibold",
                      r.type === "CASH_OUT" ? "text-rose-600" : r.type === "CASH_IN" ? "text-emerald-600" : "text-amber-600"
                    )}
                  >
                    {r.type === "CASH_OUT" ? "−" : "+"}
                    {formatMoney(r.amount)}
                  </span>
                ),
              },
              {
                key: "remarks",
                header: "Remarks",
                render: (r) => <span className="text-gray-500">{r.remarks ?? "—"}</span>,
              },
            ]}
          />
        </div>
      </div>

      {/* Cash In / Out / Petty / Opening dialog */}
      <Dialog open={dialog !== null} onOpenChange={(o) => !o && setDialog(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {dialog === "cashin"
                ? "Record Cash In"
                : dialog === "cashout"
                  ? "Record Cash Out"
                  : dialog === "petty"
                    ? "Add Petty Cash"
                    : "Set Opening Balance"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Field label="Amount" required>
              <Input
                type="number"
                min="0"
                step="0.01"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </Field>
            <Field label="Payment Method" required>
              <Select value={dlgMethod} onValueChange={setDlgMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {METHODS.map((m) => (
                    <SelectItem key={m} value={m}>
                      {METHOD_LABELS[m]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            {(dialog === "cashin" || dialog === "cashout") && (
              <Field label="Category" required>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {dialog === "cashin" ? (
                      <>
                        <SelectItem value="OWNER_DEPOSIT">Owner Deposit</SelectItem>
                        <SelectItem value="OTHER">Other</SelectItem>
                      </>
                    ) : (
                      <>
                        <SelectItem value="SUPPLIER">Supplier</SelectItem>
                        <SelectItem value="STAFF">Staff</SelectItem>
                        <SelectItem value="REFUND">Refund</SelectItem>
                        <SelectItem value="OTHER">Other</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </Field>
            )}
            <Field label="Remarks">
              <Textarea
                rows={2}
                placeholder="Optional note"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
              />
            </Field>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog(null)}>
              Cancel
            </Button>
            <Button
              className={cn(
                "text-white",
                dialog === "cashout" ? "bg-rose-600 hover:bg-rose-700" : "bg-amber-600 hover:bg-amber-700"
              )}
              disabled={saving}
              onClick={() => void submitEntry()}
            >
              {saving ? "Saving..." : "Save Entry"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
