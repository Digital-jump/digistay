'use client';

import * as React from "react";
import {
  Download,
  FileText,
  HandCoins,
  MoreHorizontal,
  Plus,
  Receipt,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { apiDelete, apiGet, apiPost, qs } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import {
  DataTable,
  downloadCsv,
  EmptyState,
  Field,
  formatDate,
  formatMoney,
  Money,
  PageHeader,
  SearchInput,
  Spinner,
  StatCard,
  StatusBadge,
  TabsBar,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

// ─── Types ────────────────────────────────────────────────────

type FolioType = "COMPANY" | "INDIVIDUAL" | "OTA";

type CompanyLite = { id: string; name: string; contactPerson?: string | null; phone?: string | null; gstin?: string | null };

type FolioRow = {
  id: string;
  code: string;
  type: string;
  name: string;
  contact: string | null;
  phone: string | null;
  gstin: string | null;
  otaName: string | null;
  companyId: string | null;
  reservationId: string | null;
  dueDate: string | null;
  status: string;
  notes: string | null;
  createdAt: string;
  company: CompanyLite | null;
  reservation: { code: string } | null;
  balance: number;
};

type FolioEntry = {
  id: string;
  type: string; // CHARGE | PAYMENT | ADJUSTMENT
  description: string;
  amount: number;
  category: string | null;
  createdAt: string;
};

type FolioDetail = FolioRow & {
  entries: FolioEntry[];
  reservation: { code?: string; id?: string } | null;
  invoices: { id: string; number: string; status: string; total: number }[];
  balance: number;
};

type FolioSummary = {
  totalUnsettled: number;
  individualUnsettled: number;
  companyUnsettled: number;
  otaUnsettled: number;
};

// ─── Local label helpers ──────────────────────────────────────

const OTA_LABELS: Record<string, string> = {
  BOOKING_COM: "Booking.com",
  MAKE_MY_TRIP: "MakeMyTrip",
  AIRBNB: "Airbnb",
  EXPEDIA: "Expedia",
  GOIBIBO: "Goibibo",
};

const METHOD_LABELS: Record<string, string> = {
  CASH: "Cash",
  UPI: "UPI",
  DEBIT_CARD: "Debit Card",
  CREDIT_CARD: "Credit Card",
  BANK_TRANSFER: "Bank Transfer",
  RAZORPAY: "Razorpay",
  OTHER: "Other",
};

const ENTRY_BADGE: Record<string, string> = {
  CHARGE: "bg-rose-100 text-rose-700",
  PAYMENT: "bg-emerald-100 text-emerald-700",
  ADJUSTMENT: "bg-amber-100 text-amber-700",
};

const CHARGE_CATEGORIES = ["ROOM", "FOOD", "BEVERAGE", "SERVICE", "LAUNDRY", "MINIBAR", "OTHER"];

const CATEGORY_LABELS: Record<string, string> = {
  ROOM: "Room",
  FOOD: "Food",
  BEVERAGE: "Beverage",
  SERVICE: "Service",
  LAUNDRY: "Laundry",
  MINIBAR: "Minibar",
  OTHER: "Other",
};

function EntryBadge({ type }: { type: string }) {
  return (
    <span
      className={cn(
        "inline-flex whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium",
        ENTRY_BADGE[type] ?? "bg-gray-100 text-gray-600"
      )}
    >
      {type.replace(/_/g, " ")}
    </span>
  );
}

function prettyCategory(c: string | null): string {
  if (!c) return "—";
  return CATEGORY_LABELS[c] ?? c.replace(/_/g, " ");
}

function entryAmount(entry: FolioEntry) {
  if (entry.type === "PAYMENT") {
    return <span className="font-medium text-emerald-600">−{formatMoney(Math.abs(entry.amount))}</span>;
  }
  if (entry.type === "ADJUSTMENT") {
    return (
      <span className="font-medium text-amber-600">
        {entry.amount < 0 ? "−" : "+"}
        {formatMoney(Math.abs(entry.amount))}
      </span>
    );
  }
  return <span className="font-medium text-gray-900">+{formatMoney(entry.amount)}</span>;
}

// ─── Shared folio manager (COMPANY / OTA modes) ───────────────

export type FolioManagerProps = ViewProps & { mode: "COMPANY" | "OTA" };

export function FolioManager({ user, mode }: FolioManagerProps) {
  const isAdmin = user.role === "ADMIN";
  const [search, setSearch] = React.useState("");
  const [statusTab, setStatusTab] = React.useState("all");
  const [typeTab, setTypeTab] = React.useState("all"); // COMPANY view: all | COMPANY | INDIVIDUAL

  const listType = mode === "OTA" ? "OTA" : typeTab === "all" ? undefined : typeTab;
  const url = `/api/folios${qs({
    type: listType,
    search,
    status: statusTab === "all" ? undefined : statusTab,
  })}`;
  const { data, loading, error, refetch } = useApi<{ items: FolioRow[] }>(url);
  const { data: summary } = useApi<FolioSummary>("/api/folios/summary");
  const { data: companies } = useApi<CompanyLite[]>(mode === "COMPANY" ? "/api/companies" : null);

  // Add folio dialog state
  const [addOpen, setAddOpen] = React.useState(false);
  const [fType, setFType] = React.useState<"COMPANY" | "INDIVIDUAL">("COMPANY");
  const [linkCompanyId, setLinkCompanyId] = React.useState("none");
  const [name, setName] = React.useState("");
  const [contact, setContact] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [gstin, setGstin] = React.useState("");
  const [otaName, setOtaName] = React.useState("BOOKING_COM");
  const [dueDate, setDueDate] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const [chargeDescription, setChargeDescription] = React.useState("");
  const [chargeAmount, setChargeAmount] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  // Detail dialog
  const [detailOpen, setDetailOpen] = React.useState(false);
  const [detail, setDetail] = React.useState<FolioDetail | null>(null);
  const [detailLoading, setDetailLoading] = React.useState(false);

  // Entry dialogs
  const [entryOpen, setEntryOpen] = React.useState<null | "CHARGE" | "PAYMENT" | "ADJUSTMENT">(null);
  const [entryDescription, setEntryDescription] = React.useState("");
  const [entryAmount_, setEntryAmount] = React.useState("");
  const [entryCategory, setEntryCategory] = React.useState("ROOM");
  const [entrySaving, setEntrySaving] = React.useState(false);

  // Settle dialog
  const [settleOpen, setSettleOpen] = React.useState(false);
  const [settleMethod, setSettleMethod] = React.useState("CASH");
  const [settleSaving, setSettleSaving] = React.useState(false);

  // Delete confirm
  const [deleteTarget, setDeleteTarget] = React.useState<FolioRow | null>(null);

  const openAddDialog = () => {
    setAddOpen(true);
    setFType("COMPANY");
    setLinkCompanyId("none");
    setName("");
    setContact("");
    setPhone("");
    setGstin("");
    setOtaName("BOOKING_COM");
    setDueDate("");
    setNotes("");
    setChargeDescription("");
    setChargeAmount("");
  };

  async function submitFolio() {
    const folioName = mode === "OTA" ? name.trim() || OTA_LABELS[otaName] : name.trim();
    if (!folioName) {
      toast.error("Name is required");
      return;
    }
    const entries =
      chargeDescription.trim() && Number(chargeAmount) > 0
        ? [{ type: "CHARGE", description: chargeDescription.trim(), amount: Number(chargeAmount), category: "OTHER" }]
        : undefined;
    const body: Record<string, unknown> = {
      type: mode === "OTA" ? "OTA" : fType,
      name: folioName,
      contact: contact || undefined,
      phone: phone || undefined,
      gstin: gstin || undefined,
      dueDate: dueDate || undefined,
      notes: notes || undefined,
      entries,
    };
    if (mode === "OTA") body.otaName = otaName;
    if (mode === "COMPANY" && fType === "COMPANY" && linkCompanyId !== "none") body.companyId = linkCompanyId;
    setSaving(true);
    try {
      await apiPost("/api/folios", body);
      toast.success("Folio created");
      setAddOpen(false);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to create folio");
    } finally {
      setSaving(false);
    }
  }

  async function openDetail(f: FolioRow) {
    setDetailOpen(true);
    setDetailLoading(true);
    setDetail(null);
    try {
      setDetail(await apiGet<FolioDetail>(`/api/folios/${f.id}`));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to load folio");
      setDetailOpen(false);
    } finally {
      setDetailLoading(false);
    }
  }

  async function refreshDetail(id: string) {
    try {
      setDetail(await apiGet<FolioDetail>(`/api/folios/${id}`));
    } catch {
      /* ignore */
    }
    refetch();
  }

  function openEntryDialog(kind: "CHARGE" | "PAYMENT" | "ADJUSTMENT") {
    setEntryOpen(kind);
    setEntryDescription(kind === "PAYMENT" ? "Payment received" : kind === "ADJUSTMENT" ? "Manual adjustment" : "");
    setEntryAmount("");
    setEntryCategory("ROOM");
  }

  async function submitEntry() {
    if (!detail || !entryOpen) return;
    const value = Number(entryAmount);
    if (!value) {
      toast.error("Enter an amount");
      return;
    }
    if (!entryDescription.trim()) {
      toast.error("Description is required");
      return;
    }
    setEntrySaving(true);
    try {
      await apiPost(`/api/folios/${detail.id}/entries`, {
        type: entryOpen,
        description: entryDescription.trim(),
        amount: entryOpen === "PAYMENT" ? -Math.abs(value) : value,
        category: entryOpen === "CHARGE" ? entryCategory : "OTHER",
      });
      toast.success(entryOpen === "CHARGE" ? "Charge added" : entryOpen === "PAYMENT" ? "Payment recorded" : "Adjustment saved");
      setEntryOpen(null);
      await refreshDetail(detail.id);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to add entry");
    } finally {
      setEntrySaving(false);
    }
  }

  async function settleFolio() {
    if (!detail) return;
    setSettleSaving(true);
    try {
      const res = await apiPost<{ folio: FolioRow; invoice?: { number: string } | null }>(
        `/api/folios/${detail.id}/settle`,
        { method: settleMethod }
      );
      toast.success(
        res.invoice ? `Folio settled — invoice ${res.invoice.number} created` : "Folio settled"
      );
      setSettleOpen(false);
      await refreshDetail(detail.id);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to settle folio");
    } finally {
      setSettleSaving(false);
    }
  }

  async function createInvoiceFromReservation(f: { id: string; reservationId: string | null }) {
    if (!f.reservationId) return;
    try {
      await apiPost("/api/invoices", { reservationId: f.reservationId });
      toast.success("Invoice generated from reservation");
      await refreshDetail(f.id);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to create invoice");
    }
  }

  async function deleteFolio(f: FolioRow) {
    try {
      await apiDelete(`/api/folios/${f.id}`);
      toast.success("Folio deleted");
      if (detail?.id === f.id) setDetailOpen(false);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to delete folio");
    }
  }

  function exportCsv() {
    if (!data) return;
    downloadCsv(
      mode === "OTA" ? "ota-folios" : "company-folios",
      [
        { key: "code", header: "Folio No." },
        { key: "name", header: "Name" },
        { key: "type", header: "Type" },
        { key: "phone", header: "Phone" },
        { key: "created", header: "Created On" },
        { key: "balance", header: "Balance" },
        { key: "due", header: "Due Date" },
        { key: "status", header: "Status" },
      ],
      (data.items ?? []).map((f) => ({
        code: f.code,
        name: f.name,
        type: f.type,
        phone: f.phone ?? "",
        created: formatDate(f.createdAt),
        balance: f.balance,
        due: f.dueDate ? formatDate(f.dueDate) : "",
        status: f.status,
      }))
    );
  }

  const items = data?.items ?? [];
  const statCards =
    mode === "COMPANY" ? (
      <>
        <StatCard label="Total Unsettled" value={formatMoney(summary?.totalUnsettled)} tone="amber" icon={<Receipt className="h-4 w-4" />} />
        <StatCard label="Individual Unsettled" value={formatMoney(summary?.individualUnsettled)} tone="sky" icon={<Receipt className="h-4 w-4" />} />
        <StatCard label="Company Unsettled" value={formatMoney(summary?.companyUnsettled)} tone="amber" icon={<Receipt className="h-4 w-4" />} />
      </>
    ) : (
      <>
        <StatCard label="Total Unsettled" value={formatMoney(summary?.totalUnsettled)} tone="amber" icon={<Receipt className="h-4 w-4" />} />
        <StatCard label="OTA Unsettled" value={formatMoney(summary?.otaUnsettled)} tone="amber" icon={<Receipt className="h-4 w-4" />} />
        <StatCard label="Open OTA Folios" value={items.filter((f) => f.status === "OPEN").length} tone="teal" icon={<FileText className="h-4 w-4" />} />
      </>
    );

  return (
    <div className="space-y-4">
      <PageHeader
        title={mode === "OTA" ? "OTA Folio" : "Company/Individual Folio"}
        crumbs={["Dashboard", "Finance", mode === "OTA" ? "OTA Folio" : "Company/Individual Folio"]}
      >
        <Button variant="outline" onClick={exportCsv}>
          <Download className="mr-1.5 h-4 w-4" /> Export CSV
        </Button>
        <Button className="bg-amber-600 text-white hover:bg-amber-700" onClick={openAddDialog}>
          <Plus className="mr-1.5 h-4 w-4" /> {mode === "OTA" ? "Add OTA Folio" : "Add Folio Source"}
        </Button>
      </PageHeader>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">{statCards}</div>

      <div className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder={mode === "OTA" ? "Search OTA folios..." : "Search folios..."}
            className="w-full sm:w-72"
          />
          {mode === "COMPANY" && (
            <Select value={typeTab} onValueChange={setTypeTab}>
              <SelectTrigger className="w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                <SelectItem value="COMPANY">Company</SelectItem>
                <SelectItem value="INDIVIDUAL">Individual</SelectItem>
              </SelectContent>
            </Select>
          )}
        </div>
        <TabsBar
          active={statusTab}
          onChange={setStatusTab}
          tabs={[
            { id: "all", label: "All", count: items.length },
            { id: "OPEN", label: "Open", count: items.filter((f) => f.status === "OPEN").length },
            { id: "SETTLED", label: "Settled", count: items.filter((f) => f.status === "SETTLED").length },
          ]}
        />
      </div>

      <div className="rounded-xl border border-gray-200 bg-white">
        {loading ? (
          <Spinner />
        ) : error ? (
          <EmptyState title="Couldn't load folios" description={error} />
        ) : (
          <div className="overflow-x-auto">
            <DataTable<FolioRow>
              keyField="id"
              rows={items}
              empty={
                <EmptyState
                  icon={<Receipt className="h-7 w-7" />}
                  title="No folios found"
                  description={mode === "OTA" ? "OTA settlement folios will appear here." : "Company & individual billing folios will appear here."}
                />
              }
              columns={[
                {
                  key: "name",
                  header: "Name",
                  render: (f) => (
                    <button type="button" className="text-left font-medium text-amber-700 hover:underline" onClick={() => void openDetail(f)}>
                      {f.name}
                      {mode === "OTA" && f.reservation?.code ? (
                        <span className="ml-1.5 text-xs text-gray-400">{f.reservation.code}</span>
                      ) : null}
                    </button>
                  ),
                },
                { key: "type", header: "Type", render: (f) => <StatusBadge status={f.type === "OTA" ? "OTA" : f.type} /> },
                { key: "phone", header: "Phone/Contact", render: (f) => f.phone ?? f.contact ?? "—" },
                { key: "createdAt", header: "Created On", render: (f) => formatDate(f.createdAt) },
                {
                  key: "balance",
                  header: "Amount",
                  className: "text-right",
                  render: (f) => (
                    <span className={cn("font-semibold", f.balance > 0 ? "text-rose-600" : "text-emerald-600")}>
                      <Money v={f.balance} />
                    </span>
                  ),
                },
                { key: "dueDate", header: "Due Date", render: (f) => (f.dueDate ? formatDate(f.dueDate) : "—") },
                { key: "status", header: "Status", render: (f) => <StatusBadge status={f.status} /> },
                {
                  key: "actions",
                  header: "Actions",
                  className: "text-right",
                  render: (f) => (
                    <div className="flex justify-end">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button size="sm" variant="outline" className="h-7 w-7 rounded-lg p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => void openDetail(f)}>Open</DropdownMenuItem>
                          {f.status === "OPEN" && (
                            <DropdownMenuItem
                              onClick={() => {
                                setDetail({ ...f, entries: [], invoices: [], reservation: f.reservation, balance: f.balance });
                                setSettleOpen(true);
                              }}
                            >
                              <HandCoins className="mr-2 h-4 w-4 text-amber-600" /> Settle
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-rose-600 focus:text-rose-600"
                            disabled={!isAdmin}
                            onSelect={() => setDeleteTarget(f)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  ),
                },
              ]}
            />
          </div>
        )}
      </div>

      {/* Delete folio confirm */}
      <AlertDialog open={deleteTarget !== null} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete folio {deleteTarget?.code}?</AlertDialogTitle>
            <AlertDialogDescription>
              Only open folios without invoices can be deleted. This permanently removes the folio and all its entries.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-rose-600 text-white hover:bg-rose-700"
              onClick={async (e) => {
                e.preventDefault();
                if (deleteTarget) await deleteFolio(deleteTarget);
                setDeleteTarget(null);
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Add folio dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{mode === "OTA" ? "Add OTA Folio" : "Add Folio Source"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {mode === "COMPANY" && (
              <div className="space-y-1.5">
                <Label>Folio Type</Label>
                <RadioGroup
                  value={fType}
                  onValueChange={(v) => setFType(v as "COMPANY" | "INDIVIDUAL")}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="COMPANY" id="ft-company" />
                    <Label htmlFor="ft-company" className="font-normal">Company</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="INDIVIDUAL" id="ft-individual" />
                    <Label htmlFor="ft-individual" className="font-normal">Individual</Label>
                  </div>
                </RadioGroup>
              </div>
            )}
            {mode === "OTA" && (
              <Field label="OTA Channel" required>
                <Select
                  value={otaName}
                  onValueChange={(v) => {
                    setOtaName(v);
                    if (!name || Object.values(OTA_LABELS).includes(name)) setName(OTA_LABELS[v]);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(OTA_LABELS).map(([k, label]) => (
                      <SelectItem key={k} value={k}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
            )}
            {mode === "COMPANY" && fType === "COMPANY" && (
              <Field label="Link existing company">
                <Select
                  value={linkCompanyId}
                  onValueChange={(v) => {
                    setLinkCompanyId(v);
                    const c = (companies ?? []).find((x) => x.id === v);
                    if (c) {
                      setName(c.name);
                      setContact(c.contactPerson ?? "");
                      setPhone(c.phone ?? "");
                      setGstin(c.gstin ?? "");
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="None — create new" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None — create new</SelectItem>
                    {(companies ?? []).map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
            )}
            <Field label="Name" required>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={mode === "OTA" ? OTA_LABELS[otaName] : fType === "COMPANY" ? "Company name" : "Guest / party name"}
              />
            </Field>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Field label="Contact person">
                <Input value={contact} onChange={(e) => setContact(e.target.value)} />
              </Field>
              <Field label="Phone">
                <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+91..." />
              </Field>
            </div>
            {(mode === "COMPANY" ? fType === "COMPANY" : true) && (
              <Field label="GSTIN">
                <Input value={gstin} onChange={(e) => setGstin(e.target.value)} placeholder="Optional" />
              </Field>
            )}
            <Field label="Payment due date">
              <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
            </Field>
            {mode === "OTA" && (
              <Field label="Notes">
                <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="e.g. Virtual card settlement terms" />
              </Field>
            )}
            <div className="rounded-lg border border-dashed border-gray-200 p-3">
              <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-500">Initial charge (optional)</div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <Field label="Description">
                  <Input value={chargeDescription} onChange={(e) => setChargeDescription(e.target.value)} placeholder="e.g. October bookings" />
                </Field>
                <Field label="Amount">
                  <Input type="number" min="0" step="0.01" value={chargeAmount} onChange={(e) => setChargeAmount(e.target.value)} placeholder="0" />
                </Field>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>
              Cancel
            </Button>
            <Button className="bg-amber-600 text-white hover:bg-amber-700" disabled={saving} onClick={() => void submitFolio()}>
              {saving ? "Creating..." : "Create Folio"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Folio detail dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
          {detailLoading || !detail ? (
            <Spinner />
          ) : (
            <>
              <DialogHeader>
                <DialogTitle className="flex flex-wrap items-center gap-2">
                  {detail.name}
                  <StatusBadge status={detail.type === "OTA" ? "OTA" : detail.type} />
                  <StatusBadge status={detail.status} />
                </DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-3 rounded-lg border border-gray-100 bg-gray-50 p-3 text-sm sm:grid-cols-4">
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Folio</div>
                  <div className="font-medium text-gray-900">{detail.code}</div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Contact</div>
                  <div className="font-medium text-gray-900">{detail.contact ?? "—"}</div>
                  <div className="text-xs text-gray-500">{detail.phone ?? ""}</div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Due</div>
                  <div className="font-medium text-gray-900">{detail.dueDate ? formatDate(detail.dueDate) : "—"}</div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Balance</div>
                  <div className={cn("font-bold", detail.balance > 0 ? "text-rose-600" : "text-emerald-600")}>
                    {formatMoney(detail.balance)}
                  </div>
                </div>
              </div>

              <div className="mt-3 overflow-x-auto rounded-lg border border-gray-200">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 text-left text-xs font-medium uppercase tracking-wide text-gray-500">
                      <th className="px-3 py-2">Date</th>
                      <th className="px-3 py-2">Description</th>
                      <th className="px-3 py-2">Type</th>
                      <th className="px-3 py-2">Category</th>
                      <th className="px-3 py-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {detail.entries.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-3 py-6 text-center text-sm text-gray-400">
                          No entries yet — add a charge, payment or adjustment below.
                        </td>
                      </tr>
                    ) : (
                      detail.entries.map((en) => (
                        <tr key={en.id} className="border-t border-gray-100">
                          <td className="whitespace-nowrap px-3 py-2 text-gray-500">{formatDate(en.createdAt)}</td>
                          <td className="px-3 py-2 text-gray-700">{en.description}</td>
                          <td className="px-3 py-2">
                            <EntryBadge type={en.type} />
                          </td>
                          <td className="px-3 py-2 text-gray-500">{prettyCategory(en.category)}</td>
                          <td className="px-3 py-2 text-right">{entryAmount(en)}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                  <tfoot>
                    <tr className="border-t border-gray-200 bg-gray-50">
                      <td colSpan={4} className="px-3 py-2 text-right text-xs font-semibold uppercase tracking-wide text-gray-500">
                        Running balance
                      </td>
                      <td className={cn("px-3 py-2 text-right font-bold", detail.balance > 0 ? "text-rose-600" : "text-emerald-600")}>
                        {formatMoney(detail.balance)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {detail.invoices.length > 0 && (
                <div className="mt-3 rounded-lg border border-gray-200 p-3">
                  <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-gray-500">Invoices</div>
                  <div className="flex flex-wrap gap-2">
                    {detail.invoices.map((inv) => (
                      <span key={inv.id} className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 px-2.5 py-1 text-xs">
                        <span className="font-medium text-gray-900">{inv.number}</span>
                        <StatusBadge status={inv.status} />
                        <span className="text-gray-500">{formatMoney(inv.total)}</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="mt-3 flex flex-wrap gap-2">
                {detail.status === "OPEN" && (
                  <>
                    <Button size="sm" variant="outline" className="border-amber-200 text-amber-700 hover:bg-amber-50" onClick={() => openEntryDialog("CHARGE")}>
                      <Plus className="mr-1 h-3.5 w-3.5" /> Add Charge
                    </Button>
                    <Button size="sm" variant="outline" className="border-emerald-200 text-emerald-700 hover:bg-emerald-50" onClick={() => openEntryDialog("PAYMENT")}>
                      <Plus className="mr-1 h-3.5 w-3.5" /> Add Payment
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => openEntryDialog("ADJUSTMENT")}>
                      <Plus className="mr-1 h-3.5 w-3.5" /> Add Adjustment
                    </Button>
                    <Button
                      size="sm"
                      className="bg-amber-600 text-white hover:bg-amber-700"
                      onClick={() => setSettleOpen(true)}
                    >
                      <HandCoins className="mr-1 h-3.5 w-3.5" /> Settle Folio
                    </Button>
                  </>
                )}
                {detail.reservationId && detail.invoices.length === 0 && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-gray-300"
                    onClick={() => void createInvoiceFromReservation(detail)}
                  >
                    <FileText className="mr-1 h-3.5 w-3.5" /> Create Invoice
                  </Button>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Add entry dialog */}
      <Dialog open={entryOpen !== null} onOpenChange={(o) => !o && setEntryOpen(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {entryOpen === "CHARGE" ? "Add Charge" : entryOpen === "PAYMENT" ? "Add Payment" : "Add Adjustment"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Field label="Description" required>
              <Input value={entryDescription} onChange={(e) => setEntryDescription(e.target.value)} />
            </Field>
            <Field
              label={entryOpen === "PAYMENT" ? "Amount received" : entryOpen === "ADJUSTMENT" ? "Amount (negative reduces balance)" : "Amount"}
              required
            >
              <Input type="number" step="0.01" value={entryAmount_} onChange={(e) => setEntryAmount(e.target.value)} placeholder="0" />
            </Field>
            {entryOpen === "CHARGE" && (
              <Field label="Category" required>
                <Select value={entryCategory} onValueChange={setEntryCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CHARGE_CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {CATEGORY_LABELS[c]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEntryOpen(null)}>
              Cancel
            </Button>
            <Button className="bg-amber-600 text-white hover:bg-amber-700" disabled={entrySaving} onClick={() => void submitEntry()}>
              {entrySaving ? "Saving..." : "Save Entry"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Settle dialog */}
      <Dialog open={settleOpen} onOpenChange={setSettleOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Settle Folio {detail?.code ? `— ${detail.code}` : ""}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="rounded-lg bg-gray-50 px-3 py-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Outstanding balance</span>
                <span className="font-bold text-gray-900">{formatMoney(detail?.balance ?? 0)}</span>
              </div>
            </div>
            <Field label="Payment Method" required>
              <Select value={settleMethod} onValueChange={setSettleMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(METHOD_LABELS).map(([k, label]) => (
                    <SelectItem key={k} value={k}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <p className="text-xs text-gray-400">
              Settling records a payment entry for the remaining balance, marks the folio SETTLED and creates an invoice if none exists.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSettleOpen(false)}>
              Cancel
            </Button>
            <Button className="bg-amber-600 text-white hover:bg-amber-700" disabled={settleSaving} onClick={() => void settleFolio()}>
              {settleSaving ? "Settling..." : "Settle & Create Invoice"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Default export: Company/Individual folio view ────────────

export default function FolioCompanyView({ user }: ViewProps) {
  return <FolioManager user={user} mode="COMPANY" />;
}
