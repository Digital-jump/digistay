'use client';

import * as React from "react";
import { MessageSquareReply, Plus, Sparkles, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { apiDelete, apiPost, apiPut, qs } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import {
  ConfirmButton,
  EmptyState,
  Field,
  formatDateTime,
  PageHeader,
  Spinner,
  StatCard,
  TabsBar,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

// ─── Types ────────────────────────────────────────────────────

type GuestLite = { id: string; firstName: string; lastName: string } | null;

type Review = {
  id: string;
  channel: string | null;
  rating: number;
  title: string | null;
  comment: string | null;
  reply: string | null;
  status: string;
  createdAt: string;
  guest: GuestLite;
};

type ReviewInsights = {
  avgRating: number;
  count: number;
  distribution: Record<string, number>;
  byChannel: { channel: string; count: number; avg: number }[];
  needsReply: number;
};

type ReviewsData = { items: Review[]; insights: ReviewInsights };

// ─── Local label helpers ──────────────────────────────────────

const CHANNEL_LABELS: Record<string, string> = {
  DIRECT: "Direct",
  BOOKING_COM: "Booking.com",
  GOOGLE: "Google",
  TRIPADVISOR: "TripAdvisor",
  AIRBNB: "Airbnb",
  MAKE_MY_TRIP: "MakeMyTrip",
};

const CHANNEL_BADGE: Record<string, string> = {
  DIRECT: "bg-amber-100 text-amber-700",
  BOOKING_COM: "bg-sky-100 text-sky-700",
  GOOGLE: "bg-amber-100 text-amber-700",
  TRIPADVISOR: "bg-emerald-100 text-emerald-700",
  AIRBNB: "bg-rose-100 text-rose-700",
  MAKE_MY_TRIP: "bg-teal-100 text-teal-700",
};

function Stars({ value, className }: { value: number; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-0.5", className)}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          className={cn("h-3.5 w-3.5", i <= Math.round(value) ? "fill-amber-400 text-amber-400" : "text-gray-300")}
        />
      ))}
    </span>
  );
}

function guestInitials(g: GuestLite): string {
  if (!g) return "?";
  return `${g.firstName[0] ?? ""}${g.lastName[0] ?? ""}`.toUpperCase();
}

function guestName(g: GuestLite): string {
  return g ? `${g.firstName} ${g.lastName}` : "Unknown guest";
}

// ─── View ─────────────────────────────────────────────────────

export default function ReviewsView({ user }: ViewProps) {
  const [tab, setTab] = React.useState("insights");
  const [period, setPeriod] = React.useState("30");
  const [channel, setChannel] = React.useState("all");

  const url = `/api/reviews${qs({ period, channel: channel === "all" ? undefined : channel })}`;
  const { data, loading, error, refetch } = useApi<ReviewsData>(url);
  const { data: guestList } = useApi<{ items: GuestLite[] }>("/api/guests?pageSize=100");

  // Reply dialog
  const [replyTarget, setReplyTarget] = React.useState<Review | null>(null);
  const [replyText, setReplyText] = React.useState("");
  const [replySaving, setReplySaving] = React.useState(false);
  const [aiDraftingId, setAiDraftingId] = React.useState<string | null>(null);

  async function aiDraftReply(r: Review) {
    setAiDraftingId(r.id);
    try {
      const res = await apiPost<{ reply: string }>('/api/ai/review-reply', { reviewId: r.id });
      setReplyTarget(r);
      setReplyText(res.reply ?? "");
      toast.info("AI draft ready — review and send");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "AI draft failed");
    } finally {
      setAiDraftingId(null);
    }
  }

  // Add review dialog
  const [addOpen, setAddOpen] = React.useState(false);
  const [addGuestId, setAddGuestId] = React.useState("none");
  const [addChannel, setAddChannel] = React.useState("DIRECT");
  const [addRating, setAddRating] = React.useState(5);
  const [addTitle, setAddTitle] = React.useState("");
  const [addComment, setAddComment] = React.useState("");
  const [addSaving, setAddSaving] = React.useState(false);

  async function submitReply() {
    if (!replyTarget) return;
    if (!replyText.trim()) {
      toast.error("Write a response first");
      return;
    }
    setReplySaving(true);
    try {
      await apiPut(`/api/reviews/${replyTarget.id}`, { reply: replyText.trim() });
      toast.success("Response published");
      setReplyTarget(null);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to save response");
    } finally {
      setReplySaving(false);
    }
  }

  async function submitAddReview() {
    const comment = addComment.trim();
    if (!comment) {
      toast.error("Comment is required");
      return;
    }
    setAddSaving(true);
    try {
      await apiPost("/api/reviews", {
        guestId: addGuestId === "none" ? undefined : addGuestId,
        channel: addChannel,
        rating: addRating,
        title: addTitle.trim() || undefined,
        comment,
      });
      toast.success("Review added");
      setAddOpen(false);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to add review");
    } finally {
      setAddSaving(false);
    }
  }

  async function deleteReview(r: Review) {
    try {
      await apiDelete(`/api/reviews/${r.id}`);
      toast.success("Review deleted");
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to delete review");
    }
  }

  const insights = data?.insights;
  const items = data?.items ?? [];
  const distribution = insights?.distribution ?? {};
  const fiveStarPct =
    insights && insights.count > 0 ? Math.round(((distribution["5"] ?? 0) / insights.count) * 100) : 0;

  return (
    <div className="space-y-4">
      <PageHeader title="Reviews" crumbs={["Dashboard", "Reviews"]}>
        <Button className="bg-amber-600 text-white hover:bg-amber-700" onClick={() => setAddOpen(true)}>
          <Plus className="mr-1.5 h-4 w-4" /> Add Review
        </Button>
      </PageHeader>

      <div className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: "30", label: "Last 30 days" },
            { id: "90", label: "Last 90 days" },
            { id: "365", label: "12 months" },
          ].map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPeriod(p.id)}
              className={cn(
                "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                period === p.id
                  ? "border-amber-600 bg-amber-50 text-amber-700"
                  : "border-gray-200 bg-white text-gray-600 hover:border-gray-300"
              )}
            >
              {p.label}
            </button>
          ))}
          <Select value={channel} onValueChange={setChannel}>
            <SelectTrigger className="w-[170px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All channels</SelectItem>
              {Object.entries(CHANNEL_LABELS).map(([k, label]) => (
                <SelectItem key={k} value={k}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <TabsBar
          active={tab}
          onChange={setTab}
          tabs={[
            { id: "insights", label: "Insights", count: insights?.count },
            { id: "inbox", label: "Inbox", count: insights?.needsReply },
            { id: "settings", label: "Settings" },
          ]}
        />
      </div>

      {loading ? (
        <Spinner />
      ) : error ? (
        <EmptyState title="Couldn't load reviews" description={error} />
      ) : tab === "insights" ? (
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard
              label="Average Rating"
              value={
                <span className="flex items-center gap-2">
                  {(insights?.avgRating ?? 0).toFixed(1)}
                  <Stars value={insights?.avgRating ?? 0} />
                </span>
              }
              sub="out of 5"
              tone="amber"
            />
            <StatCard label="Total Reviews" value={insights?.count ?? 0} sub="in the selected period" tone="sky" />
            <StatCard
              label="Needs Reply"
              value={insights?.needsReply ?? 0}
              sub="respond to protect your score"
              tone="amber"
            />
            <StatCard label="5-Star Reviews" value={`${fiveStarPct}%`} sub="of all reviews" tone="teal" />
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <div className="rounded-xl border border-gray-200 bg-white p-4">
              <div className="mb-3 text-sm font-semibold text-gray-900">Rating distribution</div>
              {[5, 4, 3, 2, 1].map((star) => {
                const n = Number(distribution[String(star)] ?? 0);
                const pct = insights && insights.count > 0 ? Math.round((n / insights.count) * 100) : 0;
                return (
                  <div key={star} className="mb-2 flex items-center gap-3">
                    <span className="flex w-10 items-center gap-1 text-sm text-gray-600">
                      {star} <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                    </span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-gray-100">
                      <div className="h-full rounded-full bg-amber-500" style={{ width: `${pct}%` }} />
                    </div>
                    <span className="w-10 text-right text-sm font-medium text-gray-900">{n}</span>
                  </div>
                );
              })}
            </div>

            <div className="rounded-xl border border-gray-200 bg-white p-4">
              <div className="mb-3 text-sm font-semibold text-gray-900">By channel</div>
              {(insights?.byChannel ?? []).length === 0 ? (
                <EmptyState title="No channel data yet" />
              ) : (
                <div className="space-y-2">
                  {(insights?.byChannel ?? []).map((c) => (
                    <div key={c.channel} className="flex items-center justify-between rounded-lg border border-gray-100 px-3 py-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={cn(
                            "rounded-full px-2 py-0.5 text-xs font-medium",
                            CHANNEL_BADGE[c.channel] ?? "bg-gray-100 text-gray-600"
                          )}
                        >
                          {CHANNEL_LABELS[c.channel] ?? c.channel}
                        </span>
                        <span className="text-xs text-gray-400">{c.count} review{c.count === 1 ? "" : "s"}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Stars value={c.avg} />
                        <span className="w-8 text-right text-sm font-semibold text-gray-900">{c.avg.toFixed(1)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : tab === "inbox" ? (
        <div className="space-y-3">
          {items.length === 0 ? (
            <EmptyState
              icon={<MessageSquareReply className="h-7 w-7" />}
              title="Inbox zero!"
              description="No guest reviews in this period — new ones will appear here."
            />
          ) : (
            items.map((r) => (
              <div key={r.id} className="rounded-xl border border-gray-200 bg-white p-4">
                <div className="flex items-start gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-100 text-sm font-semibold text-amber-700">
                    {guestInitials(r.guest)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-semibold text-gray-900">{guestName(r.guest)}</span>
                      <span
                        className={cn(
                          "rounded-full px-2 py-0.5 text-xs font-medium",
                          CHANNEL_BADGE[r.channel ?? ""] ?? "bg-gray-100 text-gray-600"
                        )}
                      >
                        {CHANNEL_LABELS[r.channel ?? ""] ?? (r.channel ?? "—")}
                      </span>
                      <span className="text-xs text-gray-400">{formatDateTime(r.createdAt)}</span>
                      <span className="ml-auto">
                        <Stars value={r.rating} />
                      </span>
                    </div>
                    {r.title && <div className="mt-1 text-sm font-medium text-gray-900">{r.title}</div>}
                    <p className="mt-1 text-sm text-gray-600">{r.comment}</p>
                    {r.reply && (
                      <div className="mt-3 rounded-lg border-l-2 border-amber-500 bg-amber-50/60 px-3 py-2">
                        <div className="text-xs font-semibold uppercase tracking-wide text-amber-600">Hotel response</div>
                        <p className="mt-0.5 text-sm text-gray-700">{r.reply}</p>
                      </div>
                    )}
                    <div className="mt-3 flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                        onClick={() => {
                          setReplyTarget(r);
                          setReplyText(r.reply ?? "");
                        }}
                      >
                        <MessageSquareReply className="mr-1 h-3.5 w-3.5" />
                        {r.reply ? "Edit Reply" : "Reply"}
                      </Button>
                      {!r.reply && (user.role === "ADMIN" || user.role === "RECEPTIONIST") && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                          disabled={aiDraftingId === r.id}
                          onClick={() => void aiDraftReply(r)}
                        >
                          <Sparkles className="mr-1 h-3.5 w-3.5" />
                          {aiDraftingId === r.id ? "Drafting..." : "AI draft"}
                        </Button>
                      )}
                      {user.role === "ADMIN" && (
                        <ConfirmButton
                          title="Delete this review?"
                          description="This permanently removes the guest review and cannot be undone."
                          confirmLabel="Delete"
                          onConfirm={() => deleteReview(r)}
                        >
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 rounded-lg border-rose-200 text-xs text-rose-600 hover:bg-rose-50"
                          >
                            <Trash2 className="mr-1 h-3.5 w-3.5" /> Delete
                          </Button>
                        </ConfirmButton>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        <EmptyState
          title="Review collection settings"
          description="Review collection settings coming from your website config — invite guests to review after checkout."
        />
      )}

      {/* Reply dialog */}
      <Dialog open={replyTarget !== null} onOpenChange={(o) => !o && setReplyTarget(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Respond to {replyTarget ? guestName(replyTarget.guest) : "review"}</DialogTitle>
          </DialogHeader>
          {replyTarget && (
            <div className="space-y-3">
              <div className="rounded-lg bg-gray-50 p-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-gray-900">{replyTarget.title ?? "Review"}</span>
                  <Stars value={replyTarget.rating} />
                </div>
                <p className="mt-1 text-gray-600">{replyTarget.comment}</p>
              </div>
              <Field label="Your response" required>
                <Textarea
                  rows={4}
                  placeholder="Thank the guest, address the issue, invite them back..."
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                />
              </Field>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setReplyTarget(null)}>
              Cancel
            </Button>
            <Button className="bg-amber-600 text-white hover:bg-amber-700" disabled={replySaving} onClick={() => void submitReply()}>
              {replySaving ? "Publishing..." : "Publish Response"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add review dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Add Review (demo)</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Field label="Guest">
              <Select value={addGuestId} onValueChange={setAddGuestId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select guest" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No guest link</SelectItem>
                  {(guestList?.items ?? []).map((g) => (
                    <SelectItem key={g?.id} value={g?.id ?? "none"}>
                      {g ? `${g.firstName} ${g.lastName}` : "—"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Channel" required>
              <Select value={addChannel} onValueChange={setAddChannel}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(CHANNEL_LABELS).map(([k, label]) => (
                    <SelectItem key={k} value={k}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Rating" required>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <button key={i} type="button" onClick={() => setAddRating(i)} className="rounded p-0.5 hover:scale-110">
                    <Star
                      className={cn("h-6 w-6", i <= addRating ? "fill-amber-400 text-amber-400" : "text-gray-300")}
                    />
                  </button>
                ))}
                <span className="ml-2 text-sm font-medium text-gray-600">{addRating}/5</span>
              </div>
            </Field>
            <Field label="Title">
              <Input value={addTitle} onChange={(e) => setAddTitle(e.target.value)} placeholder="e.g. Lovely stay" />
            </Field>
            <Field label="Comment" required>
              <Textarea rows={3} value={addComment} onChange={(e) => setAddComment(e.target.value)} placeholder="What did the guest say?" />
            </Field>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>
              Cancel
            </Button>
            <Button className="bg-amber-600 text-white hover:bg-amber-700" disabled={addSaving} onClick={() => void submitAddReview()}>
              {addSaving ? "Saving..." : "Add Review"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
