'use client';

import * as React from "react";
import { Check, Copy, ExternalLink, Globe, Info, Users } from "lucide-react";
import { toast } from "sonner";
import { apiPut, qs } from "@/lib/api-client";
import {
  DataTable,
  EmptyState,
  formatDate,
  formatMoney,
  Money,
  PageHeader,
  Spinner,
  StatusBadge,
  useApi,
  type ViewProps,
  ymd,
} from "./shared";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";

// ─── Types ────────────────────────────────────────────────────

type Settings = {
  bookingEngineEnabled: boolean;
  paymentMode: string; // PREPAID | UNPAID | BOTH
};

type WebsiteConfig = {
  name: string;
  tagline: string;
  bookingEngineEnabled: boolean;
  paymentMode: string;
  roomTypes: { id: string; name: string; description: string; baseRate: number; capacity: number; amenities: string[]; roomCount: number }[];
};

type AvailabilityData = {
  roomTypes: {
    id: string;
    name: string;
    description: string;
    baseRate: number;
    capacity: number;
    amenities: string[];
    available: number;
    total: number;
    nights: number;
    totalForStay: number;
  }[];
};

type WebsiteReservation = {
  id: string;
  code: string;
  checkIn: string;
  checkOut: string;
  totalAmount: number;
  status: string;
  guest: { firstName: string; lastName: string } | null;
};

const PAYMENT_MODES: { value: string; label: string; description: string }[] = [
  { value: "PREPAID", label: "Prepaid", description: "Guests pay online at booking time" },
  { value: "UNPAID", label: "Unpaid (Pay at Hotel)", description: "Guests pay at the front desk" },
  { value: "BOTH", label: "Both", description: "Guests choose at checkout" },
];

function plusDays(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return ymd(d);
}

// ─── View ─────────────────────────────────────────────────────

export default function BookingEngineView({ user }: ViewProps) {
  const isAdmin = user.role === "ADMIN";

  const { data: settings, loading: settingsLoading } = useApi<Settings>("/api/settings");
  const { data: config, loading: configLoading, refetch: refetchConfig } = useApi<WebsiteConfig>("/api/website/config");

  const [enabled, setEnabled] = React.useState(false);
  const [paymentMode, setPaymentMode] = React.useState("UNPAID");
  const [dirty, setDirty] = React.useState(false);
  const [saving, setSaving] = React.useState(false);

  const [checkIn, setCheckIn] = React.useState(() => plusDays(1));
  const [checkOut, setCheckOut] = React.useState(() => plusDays(3));
  const { data: availability, loading: availabilityLoading } = useApi<AvailabilityData>(
    `/api/website/availability${qs({ checkIn, checkOut })}`
  );

  const { data: websiteBookings, loading: bookingsLoading } = useApi<{ items: WebsiteReservation[] }>(
    "/api/reservations?tab=all&source=WEBSITE"
  );

  React.useEffect(() => {
    if (settings) {
      setEnabled(settings.bookingEngineEnabled);
      setPaymentMode(settings.paymentMode ?? "UNPAID");
      setDirty(false);
    }
  }, [settings]);

  const [origin, setOrigin] = React.useState("");
  const [copied, setCopied] = React.useState(false);
  React.useEffect(() => {
    setOrigin(window.location.origin);
  }, []);

  async function saveSettings() {
    setSaving(true);
    try {
      await apiPut("/api/settings", { bookingEngineEnabled: enabled, paymentMode });
      toast.success("Booking engine settings saved");
      setDirty(false);
      refetchConfig();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to save settings");
    } finally {
      setSaving(false);
    }
  }

  async function copyLink() {
    const link = `${origin}/#booking`;
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      toast.success("Booking link copied to clipboard");
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Couldn't copy — please copy manually: " + link);
    }
  }

  return (
    <div className="space-y-4">
      <PageHeader title="Booking Engine" crumbs={["Dashboard", "OTAs & Website", "Booking Engine"]} />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Toggle + payment mode */}
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
            <CardTitle className="text-sm font-semibold text-gray-900">Booking Engine</CardTitle>
            <Switch
              checked={enabled}
              disabled={!isAdmin || settingsLoading}
              onCheckedChange={(v) => {
                setEnabled(v);
                setDirty(true);
              }}
            />
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Globe className="h-4 w-4 text-amber-500" />
              {enabled ? "Your website booking engine is live." : "The booking engine is currently switched off."}
            </div>
            <div className="space-y-1.5">
              <Label>Payment Mode</Label>
              <RadioGroup
                value={paymentMode}
                onValueChange={(v) => {
                  setPaymentMode(v);
                  setDirty(true);
                }}
                className="grid grid-cols-1 gap-2 sm:grid-cols-3"
                disabled={!isAdmin}
              >
                {PAYMENT_MODES.map((m) => (
                  <Label
                    key={m.value}
                    htmlFor={`pm-${m.value}`}
                    className={
                      "flex cursor-pointer flex-col gap-0.5 rounded-lg border p-3 font-normal transition-colors " +
                      (paymentMode === m.value ? "border-amber-500 bg-amber-50" : "border-gray-200 hover:border-gray-300")
                    }
                  >
                    <div className="flex items-center gap-2">
                      <RadioGroupItem value={m.value} id={`pm-${m.value}`} />
                      <span className="text-sm font-medium text-gray-900">{m.label}</span>
                    </div>
                    <span className="pl-6 text-xs text-gray-500">{m.description}</span>
                  </Label>
                ))}
              </RadioGroup>
            </div>
            {isAdmin ? (
              <div className="flex items-center justify-between pt-1">
                <span className="text-xs text-gray-400">{dirty ? "Unsaved changes" : "Synced with hotel settings"}</span>
                <Button
                  size="sm"
                  className="bg-amber-600 text-white hover:bg-amber-700"
                  disabled={!dirty || saving}
                  onClick={() => void saveSettings()}
                >
                  {saving ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2 rounded-lg bg-gray-50 px-3 py-2 text-xs text-gray-500">
                <Info className="h-3.5 w-3.5 shrink-0" />
                Only administrators can change booking engine settings.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Live website links */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-gray-900">Live Website Links</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2 rounded-lg border border-gray-200 bg-gray-50 px-3 py-2">
              <ExternalLink className="h-4 w-4 shrink-0 text-amber-500" />
              <span className="min-w-0 flex-1 truncate font-mono text-sm text-gray-800">
                {origin ? `${origin}/#booking` : "…"}
              </span>
              <Button size="sm" variant="outline" className="h-7 shrink-0 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50" onClick={() => void copyLink()}>
                {copied ? <Check className="mr-1 h-3.5 w-3.5" /> : <Copy className="mr-1 h-3.5 w-3.5" />}
                {copied ? "Copied" : "Copy Link"}
              </Button>
            </div>
            {config && (
              <div className="rounded-lg border border-gray-100 p-3">
                <div className="text-xs uppercase tracking-wide text-gray-400">Public site</div>
                <div className="text-sm font-semibold text-gray-900">{config.name}</div>
                <div className="text-xs text-gray-500">{config.tagline}</div>
                <div className="mt-1.5 flex gap-2 text-xs">
                  <span className={config.bookingEngineEnabled ? "rounded-full bg-emerald-100 px-2 py-0.5 text-emerald-700" : "rounded-full bg-gray-100 px-2 py-0.5 text-gray-600"}>
                    Engine {config.bookingEngineEnabled ? "ON" : "OFF"}
                  </span>
                  <span className="rounded-full bg-amber-100 px-2 py-0.5 text-amber-700">{config.paymentMode}</span>
                </div>
              </div>
            )}
            <div className="flex items-start gap-2 text-xs text-gray-400">
              <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              Guests book at your public site — reservations arrive here instantly with source “Website”.
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Rooms & rates preview */}
      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="text-sm font-semibold text-gray-900">Rooms &amp; Rates Preview</CardTitle>
          <div className="flex items-center gap-2">
            <Input type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} className="h-8 w-[140px] text-xs" />
            <span className="text-xs text-gray-400">→</span>
            <Input type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} className="h-8 w-[140px] text-xs" />
          </div>
        </CardHeader>
        <CardContent>
          {availabilityLoading ? (
            <Spinner />
          ) : !availability || availability.roomTypes.length === 0 ? (
            <EmptyState title="No room types configured" description="Add room types to see them on the booking engine." />
          ) : (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
              {availability.roomTypes.map((rt) => (
                <div key={rt.id} className="flex flex-col rounded-xl border border-gray-200 p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="text-sm font-semibold text-gray-900">{rt.name}</div>
                    <span
                      className={
                        rt.available > 0
                          ? "shrink-0 rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-700"
                          : "shrink-0 rounded-full bg-rose-100 px-2 py-0.5 text-xs font-medium text-rose-700"
                      }
                    >
                      {rt.available}/{rt.total} available
                    </span>
                  </div>
                  <div className="mt-1 line-clamp-2 text-xs text-gray-500">{rt.description}</div>
                  <div className="mt-2 flex flex-wrap gap-1">
                    {(rt.amenities ?? []).map((a) => (
                      <span key={a} className="rounded-full bg-gray-100 px-2 py-0.5 text-[11px] text-gray-600">
                        {a}
                      </span>
                    ))}
                  </div>
                  <div className="mt-3 flex items-end justify-between border-t border-gray-100 pt-3">
                    <div>
                      <div className="text-lg font-bold text-gray-900">
                        {formatMoney(rt.baseRate)}
                        <span className="text-xs font-normal text-gray-400"> / night</span>
                      </div>
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Users className="h-3 w-3" /> up to {rt.capacity} guests
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-gray-400">{rt.nights} night{rt.nights === 1 ? "" : "s"} total</div>
                      <div className="text-sm font-semibold text-amber-700">{formatMoney(rt.totalForStay)}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent website bookings */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-gray-900">Recent Website Bookings</CardTitle>
        </CardHeader>
        <CardContent className="px-0 pb-0">
          {bookingsLoading ? (
            <Spinner />
          ) : (
            <DataTable<WebsiteReservation>
              keyField="id"
              rows={websiteBookings?.items ?? []}
              empty={<EmptyState title="No website bookings yet" description="Reservations made on your public site will appear here." />}
              columns={[
                { key: "code", header: "Code", render: (r) => <span className="font-medium text-gray-900">{r.code}</span> },
                { key: "guest", header: "Guest", render: (r) => (r.guest ? `${r.guest.firstName} ${r.guest.lastName}` : "—") },
                {
                  key: "dates",
                  header: "Dates",
                  render: (r) => (
                    <span className="whitespace-nowrap text-gray-600">
                      {formatDate(r.checkIn)} → {formatDate(r.checkOut)}
                    </span>
                  ),
                },
                { key: "totalAmount", header: "Total", className: "text-right", render: (r) => <Money v={r.totalAmount} /> },
                { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
              ]}
            />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
