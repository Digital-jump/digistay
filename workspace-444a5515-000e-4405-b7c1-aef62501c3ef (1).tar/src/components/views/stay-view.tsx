"use client";

import * as React from "react";
import { CalendarRange, ExternalLink } from "lucide-react";
import { useAppStore } from "@/store/app-store";
import { cn } from "@/lib/utils";
import {
  EmptyState,
  PageHeader,
  Spinner,
  formatDate,
  ymd,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// ─── Types ────────────────────────────────────────────────────

type StayCell = {
  status: string;
  reservationId?: string;
  guestName?: string;
  code?: string;
  checkOut?: string;
};

type StayRoom = {
  id: string;
  number: string;
  floor: number;
  roomType: { id: string; name: string } | null;
};

type StayData = {
  rooms: StayRoom[];
  days: string[];
  cells: Record<string, Record<string, StayCell>>;
  stats: { AVAILABLE: number; OCCUPIED: number; CHECKOUT_DUE: number; HOUSEKEEPING: number };
  unassigned?: {
    reservationId: string;
    code: string;
    guestName: string;
    roomTypeName: string;
    checkIn: string;
    checkOut: string;
  }[];
};

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const CELL_STYLES: Record<string, string> = {
  OCCUPIED: "bg-rose-100 text-rose-700 hover:bg-rose-200",
  CHECKOUT_DUE: "bg-amber-100 text-amber-700 hover:bg-amber-200",
  HOUSEKEEPING: "bg-orange-100 text-orange-700 hover:bg-orange-200",
};

function dayLabel(iso: string): { wd: string; dm: string } {
  const d = new Date(`${iso}T00:00:00`);
  if (isNaN(d.getTime())) return { wd: "—", dm: iso };
  return { wd: WEEKDAYS[d.getDay()], dm: `${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}` };
}

function initials(name?: string): string {
  if (!name) return "";
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}

// ─── View ─────────────────────────────────────────────────────

export default function StayView(_props: ViewProps) {
  const setModule = useAppStore((s) => s.setModule);
  const [start, setStart] = React.useState<string>(ymd(new Date()));
  const [days, setDays] = React.useState("14");

  const { data, loading, error, refetch } = useApi<StayData>(
    `/api/stay-view?start=${start}&days=${days}`
  );

  const [selected, setSelected] = React.useState<{
    room: StayRoom;
    day: string;
    cell: StayCell;
  } | null>(null);

  const allDays = data?.days ?? [];
  const rooms = data?.rooms ?? [];

  // Group rooms by type (preserve API order within group)
  const groups = React.useMemo(() => {
    const map = new Map<string, { name: string; rooms: StayRoom[] }>();
    for (const r of rooms) {
      const key = r.roomType?.id ?? "none";
      if (!map.has(key)) map.set(key, { name: r.roomType?.name ?? "Unassigned type", rooms: [] });
      map.get(key)!.rooms.push(r);
    }
    return Array.from(map.values());
  }, [rooms]);

  // occupied count per day column (OCCUPIED + CHECKOUT_DUE = room in use that night/day)
  const occPerDay = React.useMemo(() => {
    const m = new Map<string, number>();
    for (const day of allDays) {
      let n = 0;
      for (const r of rooms) {
        const cell = data?.cells?.[r.id]?.[day];
        if (cell && (cell.status === "OCCUPIED" || cell.status === "CHECKOUT_DUE")) n += 1;
      }
      m.set(day, n);
    }
    return m;
  }, [allDays, rooms, data]);

  const stats = data?.stats;

  return (
    <div className="space-y-4">
      <PageHeader title="Stay View" crumbs={["Front Desk", "Stay View"]} />

      {/* Controls */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">From</span>
            <Input
              type="date"
              value={start}
              onChange={(e) => setStart(e.target.value)}
              className="h-9 w-40 rounded-lg"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">Days</span>
            <Select value={days} onValueChange={setDays}>
              <SelectTrigger className="h-9 w-24 rounded-lg">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["7", "14", "21", "30"].map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Legend chips */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-3 py-1 font-medium text-gray-600">
            <span className="h-2 w-2 rounded-full bg-emerald-500" /> Available
            <span className="font-semibold text-gray-900">{stats?.AVAILABLE ?? 0}</span>
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-3 py-1 font-medium text-gray-600">
            <span className="h-2 w-2 rounded-full bg-rose-500" /> Occupied
            <span className="font-semibold text-gray-900">{stats?.OCCUPIED ?? 0}</span>
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-3 py-1 font-medium text-gray-600">
            <span className="h-2 w-2 rounded-full bg-amber-500" /> Checkout Due
            <span className="font-semibold text-gray-900">{stats?.CHECKOUT_DUE ?? 0}</span>
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-3 py-1 font-medium text-gray-600">
            <span className="h-2 w-2 rounded-full bg-orange-500" /> Housekeeping
            <span className="font-semibold text-gray-900">{stats?.HOUSEKEEPING ?? 0}</span>
          </span>
        </div>
      </div>

      {loading ? (
        <Spinner />
      ) : error ? (
        <EmptyState title="Couldn't load stay view" description={error} />
      ) : rooms.length === 0 ? (
        <EmptyState
          icon={<CalendarRange className="h-7 w-7" />}
          title="No rooms in inventory"
          description="Add rooms from the Room View to see the availability grid."
        />
      ) : (
        <div className="overflow-x-auto rounded-lg border border-gray-200">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr>
                <th className="sticky left-0 z-20 min-w-[150px] border-b border-r border-gray-200 bg-gray-50 px-3 py-2 text-left text-xs font-medium uppercase tracking-wide text-gray-500">
                  Room
                </th>
                {allDays.map((day) => {
                  const { wd, dm } = dayLabel(day);
                  const total = rooms.length || 1;
                  const occ = occPerDay.get(day) ?? 0;
                  const pct = Math.round((occ / total) * 100);
                  const isToday = day === ymd(new Date());
                  return (
                    <th
                      key={day}
                      className={cn(
                        "min-w-[74px] border-b border-gray-200 px-1 py-2 text-center text-xs font-medium",
                        isToday ? "bg-amber-50 text-amber-700" : "bg-gray-50 text-gray-500"
                      )}
                    >
                      <div className={cn("uppercase tracking-wide", isToday && "font-semibold")}>{wd}</div>
                      <div className={cn("font-semibold text-gray-900")}>{dm}</div>
                      <div className="text-[10px] text-gray-400">{pct}% occ</div>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {groups.map((g) => (
                <React.Fragment key={g.name}>
                  <tr>
                    <td
                      colSpan={allDays.length + 1}
                      className="sticky left-0 border-b border-gray-200 bg-amber-50/60 px-3 py-1.5 text-xs font-semibold uppercase tracking-wide text-amber-700"
                    >
                      {g.name}{" "}
                      <span className="font-normal normal-case text-amber-400">({g.rooms.length} rooms)</span>
                    </td>
                  </tr>
                  {g.rooms.map((room) => (
                    <tr key={room.id} className="group hover:bg-gray-50/60">
                      <td className="sticky left-0 z-10 border-b border-r border-gray-100 bg-white px-3 py-1.5 group-hover:bg-gray-50">
                        <div className="text-sm font-semibold text-gray-900">{room.number}</div>
                        <div className="text-[11px] text-gray-400">{g.name}</div>
                      </td>
                      {allDays.map((day) => {
                        const cell = data?.cells?.[room.id]?.[day];
                        const status = cell?.status ?? "AVAILABLE";
                        const isBusy = status === "OCCUPIED" || status === "CHECKOUT_DUE";
                        const isToday = day === ymd(new Date());
                        return (
                          <td key={day} className="border-b border-gray-100 px-1 py-1.5">
                            {isBusy ? (
                              <button
                                type="button"
                                onClick={() => setSelected({ room, day, cell: cell! })}
                                className={cn(
                                  "w-full rounded-md px-1 py-1 text-center text-[10px] font-medium transition-colors",
                                  CELL_STYLES[status] ?? "bg-gray-100 text-gray-600 hover:bg-gray-200",
                                  isToday && "ring-1 ring-amber-300"
                                )}
                                title={`${cell?.guestName ?? "Guest"} · ${cell?.code ?? ""}`}
                              >
                                {status === "CHECKOUT_DUE" ? (
                                  <span>out ↑ {initials(cell?.guestName)}</span>
                                ) : (
                                  <span>{initials(cell?.guestName) || "G"}</span>
                                )}
                              </button>
                            ) : (
                              <div
                                className={cn(
                                  "w-full rounded-md bg-emerald-50 px-1 py-1.5 text-center text-[10px] text-emerald-400",
                                  status === "HOUSEKEEPING" && "bg-orange-100 text-orange-700",
                                  isToday && "ring-1 ring-amber-100"
                                )}
                              >
                                {status === "HOUSEKEEPING" ? "HK" : ""}
                              </div>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Unassigned reservations hint */}
      {(data?.unassigned?.length ?? 0) > 0 && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
          <div className="text-sm font-semibold text-amber-800">
            {data!.unassigned!.length} upcoming reservation{data!.unassigned!.length > 1 ? "s" : ""} without a room
          </div>
          <div className="mt-2 space-y-1.5">
            {data!.unassigned!.map((u) => (
              <div key={u.reservationId} className="flex flex-wrap items-center gap-2 text-xs text-amber-900">
                <span className="font-semibold">{u.code}</span>
                <span>{u.guestName}</span>
                <span className="text-amber-700">
                  {u.roomTypeName} · {formatDate(u.checkIn)} → {formatDate(u.checkOut)}
                </span>
              </div>
            ))}
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setModule("reservations")}
            className="mt-3 h-8 rounded-lg border-amber-300 bg-white text-xs text-amber-800 hover:bg-amber-100"
          >
            Open Reservations
          </Button>
        </div>
      )}

      {/* Occupied cell dialog */}
      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="sm:max-w-sm">
          {selected && selected.cell.status !== "AVAILABLE" && (
            <>
              <DialogHeader>
                <DialogTitle>
                  Room {selected.room.number} — {selected.cell.guestName}
                </DialogTitle>
                <DialogDescription>
                  {selected.cell.status === "CHECKOUT_DUE" ? "Checkout due on " : "Staying on "}
                  {formatDate(selected.day)}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-2 rounded-lg bg-gray-50 p-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Booking</span>
                  <span className="font-medium text-gray-900">{selected.cell.code ?? "—"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Guest</span>
                  <span className="font-medium text-gray-900">{selected.cell.guestName ?? "—"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Departs</span>
                  <span className="font-medium text-gray-900">
                    {selected.cell.checkOut ? formatDate(selected.cell.checkOut) : "—"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Status</span>
                  <span className="font-medium text-gray-900">{selected.cell.status.replace(/_/g, " ")}</span>
                </div>
              </div>
              <Button
                onClick={() => {
                  setSelected(null);
                  setModule("reservations");
                }}
                className="w-full bg-amber-600 hover:bg-amber-700"
              >
                <ExternalLink className="mr-1.5 h-4 w-4" /> Open Reservations
              </Button>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* subtle auto refresh affordance */}
      <div className="flex justify-end">
        <Button variant="ghost" size="sm" onClick={refetch} className="text-xs text-gray-400 hover:text-gray-600">
          Refresh
        </Button>
      </div>
    </div>
  );
}
