'use client';

import * as React from "react";
import { Bot, MessageSquare, Send, Sparkles, Unlock, User } from "lucide-react";
import { toast } from "sonner";
import { apiGet, apiPost } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import { EmptyState, PageHeader, Spinner, TabsBar, useApi, type ViewProps } from "./shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// ─── Types ────────────────────────────────────────────────────

type SupportMessage = {
  id: string;
  sessionId: string;
  role: string; // USER | ASSISTANT
  content: string;
  createdAt: string;
};

const SUGGESTIONS = [
  "How many rooms are available tonight?",
  "Show today's arrivals",
  "What's our outstanding balance?",
];

function timeLabel(d: string): string {
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return "";
  return dt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

// ─── View ─────────────────────────────────────────────────────

export default function ChatsView({ user }: ViewProps) {
  const sessionId = `user-${user.id}`;
  const [sessionTab, setSessionTab] = React.useState("active");
  const [search, setSearch] = React.useState("");

  const { data: messages, loading, refetch } = useApi<SupportMessage[]>(`/api/support/messages?sessionId=${sessionId}`);

  const [localMessages, setLocalMessages] = React.useState<SupportMessage[]>([]);
  const [input, setInput] = React.useState("");
  const [sending, setSending] = React.useState(false);
  const scrollRef = React.useRef<HTMLDivElement | null>(null);

  // Sync server messages into local state (server is source of truth)
  React.useEffect(() => {
    if (messages) setLocalMessages(messages);
  }, [messages]);

  React.useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [localMessages.length, sending]);

  async function sendMessage(text?: string) {
    const content = (text ?? input).trim();
    if (!content || sending) return;
    setInput("");
    const optimistic: SupportMessage = {
      id: `local-${Date.now()}`,
      sessionId,
      role: "USER",
      content,
      createdAt: new Date().toISOString(),
    };
    setLocalMessages((prev) => [...prev, optimistic]);
    setSending(true);
    try {
      const res = await apiPost<{ reply?: string; messages?: SupportMessage[] }>("/api/support/chat", {
        sessionId,
        message: content,
      });
      if (Array.isArray(res.messages) && res.messages.length > 0) {
        setLocalMessages(res.messages);
      } else {
        setLocalMessages((prev) => [
          ...prev,
          {
            id: `local-${Date.now()}-a`,
            sessionId,
            role: "ASSISTANT",
            content: res.reply ?? "…",
            createdAt: new Date().toISOString(),
          },
        ]);
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "DigiAI couldn't reply — try again");
      setLocalMessages((prev) => prev.filter((m) => m.id !== optimistic.id));
      try {
        const fresh = await apiGet<SupportMessage[]>(`/api/support/messages?sessionId=${sessionId}`);
        setLocalMessages(fresh);
      } catch {
        /* ignore */
      }
    } finally {
      setSending(false);
    }
  }

  const visible = localMessages.filter((m) =>
    search.trim() ? m.content.toLowerCase().includes(search.trim().toLowerCase()) : true
  );

  return (
    <div className="space-y-4">
      <PageHeader title="Communication Hub" crumbs={["Dashboard", "Communication Hub"]} />

      <div className="grid h-[calc(100vh-12rem)] min-h-[480px] grid-cols-1 gap-4 md:grid-cols-[320px_1fr]">
        {/* Left pane: session list */}
        <div className="flex min-h-0 flex-col rounded-xl border border-gray-200 bg-white">
          <div className="space-y-3 border-b border-gray-100 p-3">
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, message..."
              className="h-9"
            />
            <div className="rounded-lg bg-amber-50 p-3">
              <div className="text-sm font-semibold text-gray-900">Use your own WhatsApp number</div>
              <p className="mt-0.5 text-xs text-gray-500">
                Guests see your logo, your number — chats land right here in the hub.
              </p>
              <Button
                size="sm"
                variant="outline"
                className="mt-2 h-7 rounded-full border-amber-300 bg-white text-xs text-amber-700 hover:bg-amber-100"
                onClick={() => toast.info("Available on Business plan")}
              >
                <Unlock className="mr-1 h-3 w-3" /> Unlock
              </Button>
            </div>
            <TabsBar
              active={sessionTab}
              onChange={setSessionTab}
              tabs={[
                { id: "active", label: "Active", count: 1 },
                { id: "expired", label: "Expired", count: 0 },
              ]}
            />
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto p-3">
            <button
              type="button"
              onClick={() => setSearch("")}
              className={cn(
                "flex w-full items-center gap-3 rounded-xl border p-3 text-left transition-colors",
                "border-amber-200 bg-amber-50/60 hover:bg-amber-50"
              )}
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-600 text-white">
                <Bot className="h-5 w-5" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center justify-between">
                  <span className="truncate text-sm font-semibold text-gray-900">DigiAI Assistant</span>
                  <span className="shrink-0 text-[11px] text-gray-400">always on</span>
                </span>
                <span className="mt-0.5 block truncate text-xs text-gray-500">
                  AI hotel assistant — occupancy, arrivals, revenue &amp; more
                </span>
              </span>
            </button>
            <div className="mt-3 flex items-start gap-2 rounded-lg bg-gray-50 px-3 py-2 text-xs text-gray-500">
              <MessageSquare className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              Guest WhatsApp integration is available on request — the assistant above is active for your team today.
            </div>
          </div>
        </div>

        {/* Right pane: conversation */}
        <div className="flex min-h-0 flex-col overflow-hidden rounded-xl border border-gray-200 bg-white">
          <div className="flex items-center gap-3 border-b border-gray-100 px-4 py-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-amber-600 text-white">
              <Bot className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-semibold text-gray-900">DigiAI Assistant</div>
              <div className="text-xs text-gray-400">{sending ? "typing…" : "online · answers from live hotel data"}</div>
            </div>
            <Sparkles className="h-4 w-4 text-amber-400" />
          </div>

          <div ref={scrollRef} className="min-h-0 flex-1 space-y-3 overflow-y-auto bg-gray-50/50 p-4">
            {loading ? (
              <Spinner />
            ) : visible.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center">
                <EmptyState
                  icon={<MessageSquare className="h-7 w-7" />}
                  title="No conversation yet"
                  description="Ask DigiAI anything about your hotel — occupancy, arrivals, revenue, housekeeping."
                />
                <div className="mt-2 flex flex-wrap justify-center gap-2">
                  {SUGGESTIONS.map((s) => (
                    <Button
                      key={s}
                      size="sm"
                      variant="outline"
                      className="h-8 rounded-full border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                      onClick={() => void sendMessage(s)}
                    >
                      {s}
                    </Button>
                  ))}
                </div>
              </div>
            ) : (
              visible.map((m) => {
                const isUser = m.role === "USER";
                return (
                  <div key={m.id} className={cn("flex items-end gap-2", isUser && "flex-row-reverse")}>
                    <span
                      className={cn(
                        "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-white",
                        isUser ? "bg-gray-400" : "bg-amber-600"
                      )}
                    >
                      {isUser ? <User className="h-3.5 w-3.5" /> : <Bot className="h-3.5 w-3.5" />}
                    </span>
                    <div
                      className={cn(
                        "max-w-[75%] whitespace-pre-wrap rounded-2xl px-3.5 py-2.5 text-sm shadow-sm",
                        isUser
                          ? "rounded-br-md bg-amber-600 text-white"
                          : "rounded-bl-md border border-gray-100 bg-white text-gray-800"
                      )}
                    >
                      {m.content}
                      <div className={cn("mt-1 text-[10px]", isUser ? "text-amber-200" : "text-gray-400")}>
                        {timeLabel(m.createdAt)}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            {sending && (
              <div className="flex items-end gap-2">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-amber-600 text-white">
                  <Bot className="h-3.5 w-3.5" />
                </span>
                <div className="flex items-center gap-1 rounded-2xl rounded-bl-md border border-gray-100 bg-white px-4 py-3 shadow-sm">
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-amber-400 [animation-delay:0ms]" />
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-amber-400 [animation-delay:150ms]" />
                  <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-amber-400 [animation-delay:300ms]" />
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-gray-100 p-3">
            <form
              className="flex items-center gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                void sendMessage();
              }}
            >
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask DigiAI about your hotel..."
                disabled={sending}
              />
              <Button
                type="submit"
                size="icon"
                className="h-9 w-9 shrink-0 rounded-full bg-amber-600 text-white hover:bg-amber-700"
                disabled={sending || !input.trim()}
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
