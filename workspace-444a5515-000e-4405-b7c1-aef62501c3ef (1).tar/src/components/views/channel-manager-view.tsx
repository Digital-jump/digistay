'use client';

import * as React from "react";
import { CheckCircle2, Info, XCircle } from "lucide-react";
import { toast } from "sonner";
import { apiPut, qs } from "@/lib/api-client";
import {
  DataTable,
  EmptyState,
  formatDate,
  formatMoney,
  Money,
  PageHeader,
  SearchInput,
  Spinner,
  StatCard,
  StatusBadge,
  TabsBar,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// ─── Types ────────────────────────────────────────────────────

type OtaBooking = {
  id: string;
  code: string;
  checkIn: string;
  checkOut: string;
  status: string;
  source: string;
  adults: number;
  children: number;
  totalAmount: number;
  specialRequests: string | null;
  notes: string | null;
  guest: { firstName: string; lastName: string; phone?: string | null; email?: string | null } | null;
  roomType: { name: string } | null;
  room: { number: string } | null;
};

type OtaBookingsData = {
  items: OtaBooking[];
  counts: Record<string, number>;
};

type OtaReportTotals = { totals: { bookings: number; nights: number; revenue: number; commission: number } };

// ─── Local label helpers ──────────────────────────────────────

const OTA_LABELS: Record<string, string> = {
  OTA_BOOKING_COM: "Booking.com",
  OTA_MAKE_MY_TRIP: "MakeMyTrip",
  OTA_AIRBNB: "Airbnb",
  OTA_EXPEDIA: "Expedia",
  OTA_GOIBIBO: "Goibibo",
};

const OTA_BADGE: Record<string, string> = {
  OTA_BOOKING_COM: "bg-sky-100 text-sky-700",
  OTA_MAKE_MY_TRIP: "bg-rose-100 text-rose-700",
  OTA_AIRBNB: "bg-amber-100 text-amber-700",
  OTA_EXPEDIA: "bg-amber-100 text-amber-700",
  OTA_GOIBIBO: "bg-teal-100 text-teal-700",
};

const STATUS_OPTIONS = ["PENDING", "CONFIRMED", "CANCELLED", "NO_SHOW"];

// ─── View ─────────────────────────────────────────────────────

export default function ChannelManagerView({ user: _user }: ViewProps) {
  const [tab, setTab] = React.useState("all");
  const [status, setStatus] = React.useState("all");
  const [search, setSearch] = React.useState("");

  const source = tab === "all" ? undefined : tab;
  const url = `/api/ota/bookings${qs({
    source,
    status: status === "all" ? undefined : status,
    search,
  })}`;
  const { data, loading, error, refetch } = useApi<OtaBookingsData>(url);
  const { data: otaReport } = useApi<OtaReportTotals>("/api/reports/ota");

  const [viewTarget, setViewTarget] = React.useState<OtaBooking | null>(null);
  const [busyId, setBusyId] = React.useState<string | null>(null);

  async function updateStatus(b: OtaBooking, next: "CONFIRMED" | "CANCELLED") {
    setBusyId(b.id);
    try {
      await apiPut(`/api/ota/bookings/${b.id}/status`, { status: next });
      toast.success(`${b.code} ${next === "CONFIRMED" ? "confirmed" : "cancelled"}`);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to update booking");
    } finally {
      setBusyId(null);
    }
  }

  const items = data?.items ?? [];
  const counts = data?.counts ?? {};
  const totalCount = Object.values(counts).reduce((a, b) => a + b, 0);

  const tabs = [
    { id: "all", label: "All", count: totalCount },
    ...Object.entries(OTA_LABELS).map(([k, label]) => ({ id: k, label, count: counts[k] ?? 0 })),
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Channel Manager" crumbs={["Dashboard", "OTAs & Website", "Channel Manager"]} />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          label="OTA Bookings"
          value={otaReport?.totals.bookings ?? totalCount}
          sub="across all channels"
          tone="amber"
        />
        <StatCard
          label="OTA Revenue"
          value={formatMoney(otaReport?.totals.revenue)}
          sub={`${otaReport?.totals.nights ?? 0} room nights`}
          tone="teal"
        />
        <StatCard
          label="Commission Payable"
          value={formatMoney(otaReport?.totals.commission)}
          sub="based on channel rates"
          tone="rose"
        />
      </div>

      <TabsBar tabs={tabs} active={tab} onChange={setTab} />

      <div className="flex flex-wrap items-center gap-2 rounded-xl border border-gray-200 bg-white p-3">
        <SearchInput value={search} onChange={setSearch} placeholder="Search code or guest..." className="w-full sm:w-72" />
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[160px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {STATUS_OPTIONS.map((s) => (
              <SelectItem key={s} value={s}>
                {s.replace(/_/g, " ")}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border border-gray-200 bg-white">
        {loading ? (
          <Spinner />
        ) : error ? (
          <EmptyState title="Couldn't load OTA bookings" description={error} />
        ) : (
          <div className="overflow-x-auto">
            <DataTable<OtaBooking>
              keyField="id"
              rows={items}
              empty={<EmptyState title="No OTA bookings" description="Bookings synced from channels will appear here." />}
              columns={[
                { key: "code", header: "Code", render: (b) => <span className="font-medium text-gray-900">{b.code}</span> },
                {
                  key: "guest",
                  header: "Guest",
                  render: (b) => (b.guest ? `${b.guest.firstName} ${b.guest.lastName}` : "—"),
                },
                { key: "roomType", header: "Room Type", render: (b) => b.roomType?.name ?? "—" },
                {
                  key: "dates",
                  header: "Dates",
                  render: (b) => (
                    <span className="whitespace-nowrap text-gray-600">
                      {formatDate(b.checkIn)} → {formatDate(b.checkOut)}
                    </span>
                  ),
                },
                {
                  key: "source",
                  header: "Source",
                  render: (b) => (
                    <span
                      className={
                        "inline-flex whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium " +
                        (OTA_BADGE[b.source] ?? "bg-gray-100 text-gray-600")
                      }
                    >
                      {OTA_LABELS[b.source] ?? b.source.replace(/_/g, " ")}
                    </span>
                  ),
                },
                { key: "status", header: "Status", render: (b) => <StatusBadge status={b.status} /> },
                { key: "totalAmount", header: "Total", className: "text-right", render: (b) => <Money v={b.totalAmount} /> },
                {
                  key: "actions",
                  header: "Actions",
                  className: "text-right",
                  render: (b) => (
                    <div className="flex items-center justify-end gap-1.5">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 rounded-lg border-gray-200 px-2 text-xs text-gray-600 hover:text-gray-900"
                        onClick={() => setViewTarget(b)}
                      >
                        View
                      </Button>
                      {b.status === "PENDING" && (
                        <Button
                          size="sm"
                          className="h-7 rounded-lg bg-amber-600 px-2 text-xs text-white hover:bg-amber-700"
                          disabled={busyId === b.id}
                          onClick={() => void updateStatus(b, "CONFIRMED")}
                        >
                          <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Confirm
                        </Button>
                      )}
                      {b.status === "PENDING" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 rounded-lg border-rose-200 px-2 text-xs text-rose-600 hover:bg-rose-50"
                          disabled={busyId === b.id}
                          onClick={() => void updateStatus(b, "CANCELLED")}
                        >
                          <XCircle className="mr-1 h-3.5 w-3.5" /> Cancel
                        </Button>
                      )}
                    </div>
                  ),
                },
              ]}
            />
          </div>
        )}
      </div>

      <div className="flex items-start gap-2 rounded-lg bg-amber-50 px-3 py-2.5 text-xs text-amber-900">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" />
        Bookings from OTA channels sync automatically. Commission rates: Booking.com 15%, MakeMyTrip 18%, Airbnb 12%, Expedia 15%, Goibibo 16%.
      </div>

      {/* View dialog */}
      <Dialog open={viewTarget !== null} onOpenChange={(o) => !o && setViewTarget(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Booking {viewTarget?.code}</DialogTitle>
          </DialogHeader>
          {viewTarget && (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3 rounded-lg border border-gray-100 bg-gray-50 p-3">
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Guest</div>
                  <div className="font-medium text-gray-900">
                    {viewTarget.guest ? `${viewTarget.guest.firstName} ${viewTarget.guest.lastName}` : "—"}
                  </div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Channel</div>
                  <div className="font-medium text-gray-900">
                    {OTA_LABELS[viewTarget.source] ?? viewTarget.source.replace(/_/g, " ")}
                  </div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Phone</div>
                  <div className="text-gray-700">{viewTarget.guest?.phone ?? "—"}</div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Email</div>
                  <div className="truncate text-gray-700">{viewTarget.guest?.email ?? "—"}</div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Stay</div>
                  <div className="text-gray-700">
                    {formatDate(viewTarget.checkIn)} → {formatDate(viewTarget.checkOut)}
                  </div>
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wide text-gray-400">Total</div>
                  <div className="font-medium text-gray-900">{formatMoney(viewTarget.totalAmount)}</div>
                </div>
              </div>
              <div>
                <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-gray-500">Special requests</div>
                <div className="rounded-lg border border-gray-200 p-3 text-gray-700">
                  {viewTarget.specialRequests || "None"}
                </div>
              </div>
              {viewTarget.notes && (
                <div>
                  <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-gray-500">Notes</div>
                  <div className="rounded-lg border border-gray-200 p-3 text-gray-700">{viewTarget.notes}</div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
