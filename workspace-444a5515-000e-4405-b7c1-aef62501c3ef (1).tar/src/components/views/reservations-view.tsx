"use client";

import * as React from "react";
import {
  CalendarDays,
  Eye,
  LogIn,
  LogOut,
  MoreHorizontal,
  Pencil,
  Plus,
  Trash2,
  UserX,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { apiDelete, apiGet, apiPost, apiPut, qs } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import {
  DataTable,
  EmptyState,
  Field,
  Money,
  PageHeader,
  SearchInput,
  Spinner,
  StatusBadge,
  formatDate,
  formatMoney,
  ymd,
  useApi,
  type ViewProps,
} from "./shared";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// ─── Types ────────────────────────────────────────────────────

type Guest = {
  id: string;
  firstName: string;
  lastName: string;
  email?: string | null;
  phone?: string | null;
  vip?: boolean;
};

type RoomTypeLite = { id: string; name: string; baseRate: number; capacity: number };

type ReservationRow = {
  id: string;
  code: string;
  status: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  rate: number;
  totalAmount: number;
  paidAmount: number;
  source: string;
  specialRequests: string | null;
  notes: string | null;
  guest: Guest | null;
  roomType: { id: string; name: string } | null;
  room: { id: string; number: string; floor?: number } | null;
};

type ReservationsData = {
  items: ReservationRow[];
  counts: { upcoming: number; checkedin: number; history: number };
};

type FolioEntry = { id: string; type: string; description: string; amount: number; category?: string | null };

type ReservationDetail = {
  reservation: ReservationRow & {
    folio: { id: string; code: string; status: string; entries: FolioEntry[] } | null;
    invoices: { id: string; number: string; total: number; paidAmount: number; status: string }[];
    orders: { id: string; orderNumber: string; totalAmount: number; status: string }[];
  };
  canCheckIn: boolean;
  canCheckOut: boolean;
};

type AvailabilityData = {
  available: { id: string; number: string; floor: number }[];
  totalOfType: number;
  nights: number;
  rate: number;
};

// ─── Helpers ──────────────────────────────────────────────────

export const SOURCE_LABELS: Record<string, string> = {
  DIRECT: "Direct",
  WEBSITE: "Website",
  OTA_BOOKING_COM: "Booking.com",
  OTA_MAKE_MY_TRIP: "MakeMyTrip",
  OTA_AIRBNB: "Airbnb",
  OTA_EXPEDIA: "Expedia",
  OTA_GOIBIBO: "Goibibo",
  PHONE: "Phone",
  WALK_IN: "Walk-in",
  COMPANY: "Company",
};

function sourceLabel(s: string): string {
  return SOURCE_LABELS[s] ?? s.replace(/_/g, " ");
}

function guestFullName(g: Guest | null): string {
  return g ? `${g.firstName} ${g.lastName}` : "—";
}

function nightsBetween(checkIn: string, checkOut: string): number {
  const a = new Date(`${ymd(checkIn)}T00:00:00`).getTime();
  const b = new Date(`${ymd(checkOut)}T00:00:00`).getTime();
  if (isNaN(a) || isNaN(b)) return 0;
  return Math.max(0, Math.round((b - a) / 86400000));
}

function addDays(iso: string, n: number): string {
  const d = new Date(`${iso}T00:00:00`);
  d.setDate(d.getDate() + n);
  return ymd(d);
}

function folioBalance(folio: { entries: FolioEntry[] } | null | undefined): number {
  if (!folio?.entries) return 0;
  return folio.entries.reduce((sum, e) => sum + (e.type === "PAYMENT" ? -Math.abs(e.amount) : e.amount), 0);
}

// ─── View ─────────────────────────────────────────────────────

export default function ReservationsView(_props: ViewProps) {
  const [tab, setTab] = React.useState("upcoming");
  const [search, setSearch] = React.useState("");
  const [debounced, setDebounced] = React.useState("");
  const [from, setFrom] = React.useState("");
  const [to, setTo] = React.useState("");
  const [source, setSource] = React.useState("all");

  React.useEffect(() => {
    const t = window.setTimeout(() => setDebounced(search), 350);
    return () => window.clearTimeout(t);
  }, [search]);

  const url = `/api/reservations${qs({ tab, search: debounced, from, to, source: source === "all" ? "" : source })}`;
  const { data, loading, error, refetch } = useApi<ReservationsData>(url);
  const { data: roomTypes } = useApi<RoomTypeLite[]>("/api/room-types");

  const [detailId, setDetailId] = React.useState<string | null>(null);
  const [formOpen, setFormOpen] = React.useState(false);
  const [editRow, setEditRow] = React.useState<ReservationRow | null>(null);
  const [cancelRow, setCancelRow] = React.useState<ReservationRow | null>(null);
  const [roomPick, setRoomPick] = React.useState<ReservationRow | null>(null);
  const [busyId, setBusyId] = React.useState<string | null>(null);

  // Listen for the topbar "Create Reservation" event
  React.useEffect(() => {
    const handler = () => {
      setEditRow(null);
      setFormOpen(true);
    };
    window.addEventListener("digistay:new-reservation", handler);
    return () => window.removeEventListener("digistay:new-reservation", handler);
  }, []);

  async function doCheckIn(row: ReservationRow) {
    if (!row.room?.id) {
      setRoomPick(row);
      return;
    }
    setBusyId(row.id);
    try {
      await apiPost(`/api/reservations/${row.id}/checkin`, { roomId: row.room.id });
      toast.success(`${row.code} checked in to room ${row.room.number}`);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Check-in failed");
    } finally {
      setBusyId(null);
    }
  }

  async function doCheckOut(row: ReservationRow) {
    setBusyId(row.id);
    try {
      await apiPost(`/api/reservations/${row.id}/checkout`);
      toast.success(`${row.code} checked out`);
      refetch();
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Check-out failed";
      toast.error(/unsettled|balance/i.test(msg) ? `${msg}. Settle the folio before checkout.` : msg);
    } finally {
      setBusyId(null);
    }
  }

  async function doNoShow(row: ReservationRow) {
    setBusyId(row.id);
    try {
      await apiPost(`/api/reservations/${row.id}/no-show`);
      toast.success(`${row.code} marked as no-show`);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to mark no-show");
    } finally {
      setBusyId(null);
    }
  }

  async function doDelete(row: ReservationRow) {
    try {
      await apiDelete(`/api/reservations/${row.id}`);
      toast.success(`${row.code} deleted`);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to delete reservation");
    }
  }

  const tabs = [
    { id: "upcoming", label: "Upcoming", count: data?.counts.upcoming },
    { id: "checkedin", label: "Checked In", count: data?.counts.checkedin },
    { id: "history", label: "History", count: data?.counts.history },
    { id: "all", label: "All" },
  ];

  const SOURCES = [
    "DIRECT",
    "WEBSITE",
    "OTA_BOOKING_COM",
    "OTA_MAKE_MY_TRIP",
    "OTA_AIRBNB",
    "OTA_EXPEDIA",
    "OTA_GOIBIBO",
    "PHONE",
    "WALK_IN",
    "COMPANY",
  ];

  return (
    <div className="space-y-4">
      <PageHeader title="Reservations" crumbs={["Front Desk", "Reservations"]}>
        <Button
          size="sm"
          onClick={() => {
            setEditRow(null);
            setFormOpen(true);
          }}
          className="h-9 rounded-lg bg-amber-600 text-white hover:bg-amber-700"
        >
          <Plus className="mr-1.5 h-4 w-4" /> Create Reservation
        </Button>
      </PageHeader>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
              tab === t.id
                ? "border-amber-600 bg-white text-amber-700 shadow-sm"
                : "border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:text-gray-900"
            )}
          >
            {t.label}
            {typeof t.count === "number" && <span className="ml-1 text-gray-400">({t.count})</span>}
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-2 md:flex-row md:items-center">
        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search code / guest / name"
          className="w-full md:w-72"
        />
        <div className="flex items-center gap-2">
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="h-9 w-40 rounded-lg" />
          <span className="text-xs text-gray-400">to</span>
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="h-9 w-40 rounded-lg" />
        </div>
        <Select value={source} onValueChange={setSource}>
          <SelectTrigger className="h-9 w-44 rounded-lg">
            <SelectValue placeholder="Source" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All sources</SelectItem>
            {SOURCES.map((s) => (
              <SelectItem key={s} value={s}>
                {sourceLabel(s)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div className="rounded-lg border border-gray-200">
        {loading ? (
          <Spinner />
        ) : error ? (
          <EmptyState title="Couldn't load reservations" description={error} />
        ) : (
          <DataTable<ReservationRow>
            keyField="id"
            rows={data?.items ?? []}
            empty={<EmptyState icon={<CalendarDays className="h-7 w-7" />} title="No reservations found" description="Try adjusting filters or create a new reservation." />}
            columns={[
              {
                key: "code",
                header: "Code",
                render: (r) => (
                  <button
                    type="button"
                    className="font-medium text-amber-700 hover:underline"
                    onClick={() => setDetailId(r.id)}
                  >
                    {r.code}
                  </button>
                ),
              },
              {
                key: "guest",
                header: "Guest",
                render: (r) => (
                  <div>
                    <div className="font-medium text-gray-900">
                      {guestFullName(r.guest)}
                      {r.guest?.vip && <span className="ml-1 text-amber-500">★</span>}
                    </div>
                    <div className="text-xs text-gray-400">{r.guest?.phone ?? "—"}</div>
                  </div>
                ),
              },
              {
                key: "room",
                header: "Room",
                render: (r) => (
                  <div>
                    <div className="text-gray-900">{r.room?.number ?? "Unassigned"}</div>
                    <div className="text-xs text-gray-400">{r.roomType?.name ?? "—"}</div>
                  </div>
                ),
              },
              {
                key: "dates",
                header: "Dates",
                render: (r) => {
                  const n = nightsBetween(r.checkIn, r.checkOut);
                  return (
                    <div>
                      <div className="whitespace-nowrap text-gray-900">
                        {formatDate(r.checkIn)} → {formatDate(r.checkOut)}
                      </div>
                      <div className="text-xs text-gray-400">
                        {n} night{n === 1 ? "" : "s"}
                      </div>
                    </div>
                  );
                },
              },
              {
                key: "guests",
                header: "Guests",
                render: (r) => `${r.adults ?? 0} ad${r.children ? ` · ${r.children} ch` : ""}`,
              },
              {
                key: "source",
                header: "Source",
                render: (r) => (
                  <span className="inline-flex whitespace-nowrap rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-600">
                    {sourceLabel(r.source)}
                  </span>
                ),
              },
              { key: "totalAmount", header: "Total", render: (r) => <Money v={r.totalAmount} /> },
              { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
              {
                key: "actions",
                header: "",
                className: "text-right",
                render: (r) => (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-44">
                      <DropdownMenuItem onClick={() => setDetailId(r.id)}>
                        <Eye className="mr-2 h-4 w-4" /> View
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => {
                          setEditRow(r);
                          setFormOpen(true);
                        }}
                      >
                        <Pencil className="mr-2 h-4 w-4" /> Edit
                      </DropdownMenuItem>
                      {(r.status === "PENDING" || r.status === "CONFIRMED") && (
                        <DropdownMenuItem disabled={busyId === r.id} onClick={() => void doCheckIn(r)}>
                          <LogIn className="mr-2 h-4 w-4" /> Check-in
                        </DropdownMenuItem>
                      )}
                      {r.status === "CHECKED_IN" && (
                        <DropdownMenuItem disabled={busyId === r.id} onClick={() => void doCheckOut(r)}>
                          <LogOut className="mr-2 h-4 w-4" /> Check-out
                        </DropdownMenuItem>
                      )}
                      {(r.status === "PENDING" || r.status === "CONFIRMED") && (
                        <DropdownMenuItem disabled={busyId === r.id} onClick={() => void doNoShow(r)}>
                          <UserX className="mr-2 h-4 w-4" /> Mark No-Show
                        </DropdownMenuItem>
                      )}
                      {(r.status === "CANCELLED" || r.status === "NO_SHOW" || r.status === "PENDING") && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-rose-600 focus:text-rose-600"
                            onClick={() => void doDelete(r)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" /> Delete
                          </DropdownMenuItem>
                        </>
                      )}
                      {(r.status === "PENDING" || r.status === "CONFIRMED") && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-rose-600 focus:text-rose-600"
                            onClick={() => setCancelRow(r)}
                          >
                            <XCircle className="mr-2 h-4 w-4" /> Cancel
                          </DropdownMenuItem>
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                ),
              },
            ]}
          />
        )}
      </div>

      <ReservationDetailDialog id={detailId} onClose={() => setDetailId(null)} onChanged={refetch} />
      <ReservationFormDialog
        open={formOpen}
        edit={editRow}
        roomTypes={roomTypes ?? []}
        onClose={() => {
          setFormOpen(false);
          setEditRow(null);
        }}
        onSaved={refetch}
      />
      <CancelDialog
        row={cancelRow}
        onClose={() => setCancelRow(null)}
        onDone={() => {
          setCancelRow(null);
          refetch();
        }}
      />
      <PickRoomDialog
        row={roomPick}
        onClose={() => setRoomPick(null)}
        onDone={() => {
          setRoomPick(null);
          refetch();
        }}
      />
    </div>
  );
}

// ─── Detail dialog ────────────────────────────────────────────

function ReservationDetailDialog({
  id,
  onClose,
  onChanged,
}: {
  id: string | null;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [detail, setDetail] = React.useState<ReservationDetail | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [payOpen, setPayOpen] = React.useState(false);
  const [busy, setBusy] = React.useState(false);
  const [pickRooms, setPickRooms] = React.useState<{ id: string; number: string; floor: number }[] | null>(null);

  React.useEffect(() => {
    if (!id) {
      setDetail(null);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setDetail(null);
    apiGet<ReservationDetail>(`/api/reservations/${id}`)
      .then((d) => !cancelled && setDetail(d))
      .catch((e: unknown) => toast.error(e instanceof Error ? e.message : "Failed to load reservation"))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [id]);

  if (!id) return null;

  const r = detail?.reservation;

  async function action(kind: "checkin" | "checkout") {
    if (!r) return;
    setBusy(true);
    try {
      if (kind === "checkin") {
        if (!r.room) {
          // Unassigned reservation → load availability and prompt room pick inline
          const avail = await apiGet<{ available: { id: string; number: string; floor: number }[] }>(
            `/api/reservations/availability${qs({
              roomTypeId: r.roomType?.id,
              checkIn: ymd(r.checkIn),
              checkOut: ymd(r.checkOut),
              excludeReservationId: r.id,
            })}`
          );
          setBusy(false);
          setPickRooms(avail.available);
          return;
        }
        await apiPost(`/api/reservations/${r.id}/checkin`, { roomId: r.room.id });
        toast.success(`${r.code} checked in to room ${r.room.number}`);
      } else {
        await apiPost(`/api/reservations/${r.id}/checkout`);
        toast.success(`${r.code} checked out`);
      }
      onClose();
      onChanged();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Action failed");
    } finally {
      setBusy(false);
    }
  }

  async function checkinToRoom(roomId: string, number: string) {
    if (!r) return;
    setBusy(true);
    try {
      await apiPost(`/api/reservations/${r.id}/checkin`, { roomId });
      toast.success(`${r.code} checked in to room ${number}`);
      setPickRooms(null);
      onClose();
      onChanged();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Check-in failed");
    } finally {
      setBusy(false);
    }
  }

  async function cancel() {
    if (!r) return;
    setBusy(true);
    try {
      await apiPost(`/api/reservations/${r.id}/cancel`, { reason: "Cancelled from reservation detail" });
      toast.success(`${r.code} cancelled`);
      onClose();
      onChanged();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Cancel failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={true} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
        {loading || !r ? (
          <Spinner />
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {r.code} <StatusBadge status={r.status} />
              </DialogTitle>
              <DialogDescription>
                {r.roomType?.name ?? "—"} · {r.room?.number ? `Room ${r.room.number}` : "Unassigned"}
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {/* Guest card */}
              <div className="rounded-xl bg-amber-50 p-3">
                <div className="text-xs font-medium uppercase tracking-wide text-amber-500">Guest</div>
                <div className="mt-1 font-semibold text-gray-900">
                  {guestFullName(r.guest)}
                  {r.guest?.vip && <span className="ml-1 text-amber-500">★</span>}
                </div>
                <div className="mt-0.5 text-xs text-gray-500">{r.guest?.phone ?? "—"}</div>
                <div className="text-xs text-gray-500">{r.guest?.email ?? "—"}</div>
              </div>
              {/* Stay card */}
              <div className="rounded-xl bg-gray-50 p-3">
                <div className="text-xs font-medium uppercase tracking-wide text-gray-400">Stay</div>
                <div className="mt-1 text-sm text-gray-900">
                  {formatDate(r.checkIn)} → {formatDate(r.checkOut)}
                </div>
                <div className="mt-0.5 text-xs text-gray-500">
                  {nightsBetween(r.checkIn, r.checkOut)} nights · {r.adults} adults{r.children ? `, ${r.children} children` : ""}
                </div>
                <div className="mt-0.5 text-xs text-gray-500">
                  {sourceLabel(r.source)} · {formatMoney(r.rate)}/night
                </div>
              </div>
            </div>

            {/* Folio summary */}
            <div className="rounded-xl border border-gray-200 p-3">
              <div className="flex items-center justify-between">
                <div className="text-xs font-medium uppercase tracking-wide text-gray-400">Folio</div>
                {r.folio && (
                  <span className="text-xs text-gray-400">
                    {r.folio.code} · {r.folio.status}
                  </span>
                )}
              </div>
              {r.folio?.entries?.length ? (
                <div className="mt-2 max-h-32 space-y-1 overflow-y-auto">
                  {r.folio.entries.map((e) => (
                    <div key={e.id} className="flex justify-between text-xs">
                      <span className="truncate pr-2 text-gray-600">{e.description}</span>
                      <span className={cn("whitespace-nowrap font-medium", e.type === "PAYMENT" ? "text-emerald-600" : "text-gray-900")}>
                        {e.type === "PAYMENT" ? "−" : ""}
                        {formatMoney(Math.abs(e.amount))}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="mt-1 text-xs text-gray-400">No entries yet.</div>
              )}
              <div className="mt-2 flex justify-between border-t border-gray-100 pt-2 text-sm font-semibold">
                <span className="text-gray-600">Balance due</span>
                <span className={cn(folioBalance(r.folio) > 0 ? "text-rose-600" : "text-emerald-600")}>
                  {formatMoney(folioBalance(r.folio))}
                </span>
              </div>
            </div>

            {/* Invoices + orders */}
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-gray-200 p-3">
                <div className="text-xs font-medium uppercase tracking-wide text-gray-400">Invoices</div>
                {r.invoices?.length ? (
                  r.invoices.map((inv) => (
                    <div key={inv.id} className="mt-1.5 flex items-center justify-between text-xs">
                      <span className="font-medium text-gray-800">{inv.number}</span>
                      <span className="flex items-center gap-1.5">
                        {formatMoney(inv.total)} <StatusBadge status={inv.status} />
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="mt-1 text-xs text-gray-400">No invoices yet.</div>
                )}
              </div>
              <div className="rounded-xl border border-gray-200 p-3">
                <div className="text-xs font-medium uppercase tracking-wide text-gray-400">F&amp;B Orders</div>
                {r.orders?.length ? (
                  r.orders.map((o) => (
                    <div key={o.id} className="mt-1.5 flex items-center justify-between text-xs">
                      <span className="font-medium text-gray-800">{o.orderNumber}</span>
                      <span className="flex items-center gap-1.5">
                        {formatMoney(o.totalAmount)} <StatusBadge status={o.status} />
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="mt-1 text-xs text-gray-400">No orders yet.</div>
                )}
              </div>
            </div>

            {r.specialRequests && (
              <div className="rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-800">
                <span className="font-semibold">Special requests:</span> {r.specialRequests}
              </div>
            )}

            {pickRooms !== null && (r.status === "PENDING" || r.status === "CONFIRMED") && (
              <div className="rounded-xl border border-amber-200 bg-amber-50/50 p-3">
                <div className="mb-2 flex items-center justify-between">
                  <div className="text-xs font-semibold uppercase tracking-wide text-amber-700">
                    Assign a room to check in
                  </div>
                  <button
                    type="button"
                    className="text-xs text-gray-400 hover:text-gray-600"
                    onClick={() => setPickRooms(null)}
                  >
                    Cancel
                  </button>
                </div>
                {pickRooms.length === 0 ? (
                  <div className="text-xs text-gray-500">No rooms of this type are available for these dates.</div>
                ) : (
                  <div className="max-h-40 space-y-1.5 overflow-y-auto">
                    {pickRooms.map((rm) => (
                      <button
                        key={rm.id}
                        type="button"
                        disabled={busy}
                        onClick={() => void checkinToRoom(rm.id, rm.number)}
                        className="flex w-full items-center justify-between rounded-lg border border-gray-200 bg-white px-3 py-2 text-left text-sm transition-colors hover:border-amber-300 hover:bg-amber-50"
                      >
                        <span className="font-semibold text-gray-900">Room {rm.number}</span>
                        <span className="text-xs text-gray-400">Floor {rm.floor}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            <DialogFooter className="flex flex-wrap gap-2 sm:justify-start">
              {(r.status === "PENDING" || r.status === "CONFIRMED") && (
                <Button
                  size="sm"
                  disabled={busy || (!detail?.canCheckIn && !r.room)}
                  onClick={() => void action("checkin")}
                  className="h-8 rounded-lg bg-amber-600 text-xs text-white hover:bg-amber-700"
                >
                  <LogIn className="mr-1 h-3.5 w-3.5" /> Check-in
                </Button>
              )}
              {r.status === "CHECKED_IN" && (
                <>
                  <Button
                    size="sm"
                    disabled={busy}
                    onClick={() => void action("checkout")}
                    className="h-8 rounded-lg bg-amber-600 text-xs text-white hover:bg-amber-700"
                  >
                    <LogOut className="mr-1 h-3.5 w-3.5" /> Check-out
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setPayOpen(true)}
                    className="h-8 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                  >
                    Record Payment
                  </Button>
                </>
              )}
              {(r.status === "PENDING" || r.status === "CONFIRMED") && (
                <Button
                  size="sm"
                  variant="outline"
                  disabled={busy}
                  onClick={() => void cancel()}
                  className="h-8 rounded-lg border-rose-200 text-xs text-rose-600 hover:bg-rose-50"
                >
                  <XCircle className="mr-1 h-3.5 w-3.5" /> Cancel Booking
                </Button>
              )}
            </DialogFooter>

            <RecordPaymentDialog
              open={payOpen}
              reservation={r}
              onClose={() => setPayOpen(false)}
              onDone={() => {
                setPayOpen(false);
                onClose();
                onChanged();
              }}
            />
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ─── Record payment ───────────────────────────────────────────

function RecordPaymentDialog({
  open,
  reservation,
  onClose,
  onDone,
}: {
  open: boolean;
  reservation: ReservationRow;
  onClose: () => void;
  onDone: () => void;
}) {
  const [amount, setAmount] = React.useState("");
  const [method, setMethod] = React.useState("CASH");
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setAmount(String(Math.max(0, (reservation.totalAmount ?? 0) - (reservation.paidAmount ?? 0)) || ""));
      setMethod("CASH");
    }
  }, [open, reservation]);

  async function save() {
    const amt = Number(amount);
    if (!amt || amt <= 0) {
      toast.error("Enter a valid amount");
      return;
    }
    setBusy(true);
    try {
      await apiPost(`/api/reservations/${reservation.id}/payment`, { amount: amt, method });
      toast.success(`Payment of ${formatMoney(amt)} recorded`);
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Payment failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Record Payment — {reservation.code}</DialogTitle>
          <DialogDescription>
            Paid so far: {formatMoney(reservation.paidAmount)} of {formatMoney(reservation.totalAmount)}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <Field label="Amount (₹)" required>
            <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </Field>
          <Field label="Method" required>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["CASH", "UPI", "DEBIT_CARD", "CREDIT_CARD", "BANK_TRANSFER", "RAZORPAY", "OTHER"].map((m) => (
                  <SelectItem key={m} value={m}>
                    {m.replace(/_/g, " ")}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button disabled={busy} onClick={() => void save()} className="bg-amber-600 hover:bg-amber-700">
            {busy ? "Saving..." : "Record Payment"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Cancel dialog ────────────────────────────────────────────

function CancelDialog({
  row,
  onClose,
  onDone,
}: {
  row: ReservationRow | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const [reason, setReason] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    if (row) setReason("");
  }, [row]);

  if (!row) return null;

  async function confirm() {
    if (!row) return;
    setBusy(true);
    try {
      await apiPost(`/api/reservations/${row.id}/cancel`, { reason: reason.trim() || undefined });
      toast.success(`${row.code} cancelled`);
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Cancel failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={true} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Cancel {row.code}?</DialogTitle>
          <DialogDescription>
            {guestFullName(row.guest)} · {formatDate(row.checkIn)} → {formatDate(row.checkOut)}. The room will be
            released back to inventory.
          </DialogDescription>
        </DialogHeader>
        <Field label="Reason (optional)">
          <Textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={2} placeholder="e.g. Guest changed travel plans" />
        </Field>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Keep booking
          </Button>
          <Button disabled={busy} onClick={() => void confirm()} className="bg-rose-600 hover:bg-rose-700">
            {busy ? "Cancelling..." : "Cancel Booking"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Pick room dialog (check-in when unassigned) ──────────────

function PickRoomDialog({
  row,
  onClose,
  onDone,
}: {
  row: ReservationRow | null;
  onClose: () => void;
  onDone: () => void;
}) {
  const [rooms, setRooms] = React.useState<AvailabilityData["available"] | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    if (!row) return;
    let cancelled = false;
    setLoading(true);
    setRooms(null);
    apiGet<AvailabilityData>(
      `/api/reservations/availability${qs({
        roomTypeId: row.roomType?.id,
        checkIn: ymd(row.checkIn),
        checkOut: ymd(row.checkOut),
        excludeReservationId: row.id,
      })}`
    )
      .then((d) => !cancelled && setRooms(d.available))
      .catch((e: unknown) => toast.error(e instanceof Error ? e.message : "Failed to load availability"))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [row]);

  if (!row) return null;

  async function pick(roomId: string, number: string) {
    if (!row) return;
    setBusy(true);
    try {
      await apiPost(`/api/reservations/${row.id}/checkin`, { roomId });
      toast.success(`${row.code} checked in to room ${number}`);
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Check-in failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={true} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Assign a room — {row.code}</DialogTitle>
          <DialogDescription>
            {guestFullName(row.guest)} · {row.roomType?.name ?? "—"} · {formatDate(row.checkIn)} →{" "}
            {formatDate(row.checkOut)}
          </DialogDescription>
        </DialogHeader>
        {loading ? (
          <Spinner />
        ) : (rooms?.length ?? 0) === 0 ? (
          <EmptyState title="No rooms available" description="Try different dates or another room type." />
        ) : (
          <div className="max-h-64 space-y-1.5 overflow-y-auto">
            {rooms!.map((rm) => (
              <button
                key={rm.id}
                type="button"
                disabled={busy}
                onClick={() => void pick(rm.id, rm.number)}
                className="flex w-full items-center justify-between rounded-lg border border-gray-200 px-3 py-2 text-left text-sm transition-colors hover:border-amber-300 hover:bg-amber-50"
              >
                <span className="font-semibold text-gray-900">Room {rm.number}</span>
                <span className="text-xs text-gray-400">Floor {rm.floor}</span>
              </button>
            ))}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ─── Create / Edit dialog ─────────────────────────────────────

function ReservationFormDialog({
  open,
  edit,
  roomTypes,
  onClose,
  onSaved,
}: {
  open: boolean;
  edit: ReservationRow | null;
  roomTypes: RoomTypeLite[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const today = ymd(new Date());

  const [guestId, setGuestId] = React.useState("");
  const [guestSearch, setGuestSearch] = React.useState("");
  const [guests, setGuests] = React.useState<Guest[]>([]);
  const [newGuest, setNewGuest] = React.useState(false);
  const [ngFirst, setNgFirst] = React.useState("");
  const [ngLast, setNgLast] = React.useState("");
  const [ngPhone, setNgPhone] = React.useState("");
  const [ngEmail, setNgEmail] = React.useState("");

  const [roomTypeId, setRoomTypeId] = React.useState("");
  const [roomId, setRoomId] = React.useState(""); // "" = auto-assign
  const [checkIn, setCheckIn] = React.useState(addDays(today, 1));
  const [checkOut, setCheckOut] = React.useState(addDays(today, 3));
  const [adults, setAdults] = React.useState("2");
  const [children, setChildren] = React.useState("0");
  const [rate, setRate] = React.useState("");
  const [source, setSource] = React.useState("DIRECT");
  const [specialRequests, setSpecialRequests] = React.useState("");

  const [availability, setAvailability] = React.useState<AvailabilityData | null>(null);
  const [loadingGuests, setLoadingGuests] = React.useState(false);
  const [busy, setBusy] = React.useState(false);

  const nights = nightsBetween(checkIn, checkOut);
  const summaryTotal = nights * (Number(rate) || 0);

  // Reset on open
  React.useEffect(() => {
    if (!open) return;
    if (edit) {
      setGuestId(edit.guest?.id ?? "");
      setNewGuest(false);
      setRoomTypeId(edit.roomType?.id ?? "");
      setRoomId(edit.room?.id ?? "");
      setCheckIn(ymd(edit.checkIn));
      setCheckOut(ymd(edit.checkOut));
      setAdults(String(edit.adults ?? 2));
      setChildren(String(edit.children ?? 0));
      setRate(String(edit.rate ?? ""));
      setSource(edit.source ?? "DIRECT");
      setSpecialRequests(edit.specialRequests ?? "");
      setGuestSearch("");
    } else {
      setGuestId("");
      setNewGuest(false);
      setRoomTypeId(roomTypes[0]?.id ?? "");
      setRoomId("");
      setCheckIn(addDays(today, 1));
      setCheckOut(addDays(today, 3));
      setAdults("2");
      setChildren("0");
      setRate(roomTypes[0] ? String(roomTypes[0].baseRate) : "");
      setSource("DIRECT");
      setSpecialRequests("");
      setGuestSearch("");
      setNgFirst("");
      setNgLast("");
      setNgPhone("");
      setNgEmail("");
    }
  }, [open, edit]);

  // Search guests (debounced)
  React.useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setLoadingGuests(true);
    const t = window.setTimeout(() => {
      apiGet<{ items: Guest[] }>(`/api/guests${qs({ search: guestSearch, pageSize: 50 })}`)
        .then((d) => !cancelled && setGuests(d.items))
        .catch(() => {})
        .finally(() => !cancelled && setLoadingGuests(false));
    }, 300);
    return () => {
      cancelled = true;
      window.clearTimeout(t);
    };
  }, [open, guestSearch]);

  // Fetch availability when type/dates change
  React.useEffect(() => {
    if (!open || !roomTypeId || !checkIn || !checkOut) return;
    let cancelled = false;
    apiGet<AvailabilityData>(
      `/api/reservations/availability${qs({
        roomTypeId,
        checkIn,
        checkOut,
        excludeReservationId: edit?.id,
      })}`
    )
      .then((d) => {
        if (cancelled) return;
        setAvailability(d);
        if (!edit && d.rate) setRate(String(d.rate));
      })
      .catch(() => !cancelled && setAvailability(null));
    return () => {
      cancelled = true;
    };
  }, [open, roomTypeId, checkIn, checkOut]);

  async function save() {
    let finalGuestId = guestId;
    if (newGuest) {
      if (!ngFirst.trim() || !ngLast.trim()) {
        toast.error("New guest needs first and last name");
        return;
      }
      try {
        const created = await apiPost<Guest>("/api/guests", {
          firstName: ngFirst.trim(),
          lastName: ngLast.trim(),
          phone: ngPhone.trim() || undefined,
          email: ngEmail.trim() || undefined,
        });
        finalGuestId = created.id;
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "Failed to create guest");
        return;
      }
    }
    if (!finalGuestId || !roomTypeId) {
      toast.error("Guest and room type are required");
      return;
    }
    if (!checkIn || !checkOut || nights <= 0) {
      toast.error("Check-out must be after check-in");
      return;
    }
    const body = {
      guestId: finalGuestId,
      roomTypeId,
      roomId: roomId || undefined,
      checkIn,
      checkOut,
      adults: Number(adults) || 1,
      children: Number(children) || 0,
      rate: rate ? Number(rate) : undefined,
      source,
      specialRequests: specialRequests.trim() || undefined,
    };
    setBusy(true);
    try {
      if (edit) {
        await apiPut(`/api/reservations/${edit.id}`, body);
        toast.success(`${edit.code} updated`);
      } else {
        const created = await apiPost<ReservationRow>("/api/reservations", body);
        toast.success(`Reservation ${created.code} created`);
      }
      onClose();
      onSaved();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to save reservation");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{edit ? `Edit ${edit.code}` : "Create Reservation"}</DialogTitle>
          <DialogDescription>
            {availability
              ? `${availability.nights} night${availability.nights === 1 ? "" : "s"} · rate ${formatMoney(availability.rate)} · ${availability.available.length}/${availability.totalOfType} rooms free`
              : "Pick a room type and dates to see availability."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          {/* Guest */}
          <div className="rounded-xl border border-gray-200 p-3">
            <div className="mb-2 flex items-center justify-between">
              <Label className="text-sm font-medium text-gray-700">
                Guest<span className="ml-0.5 text-rose-500">*</span>
              </Label>
              <button
                type="button"
                onClick={() => setNewGuest((v) => !v)}
                className="text-xs font-medium text-amber-600 hover:underline"
              >
                {newGuest ? "Pick existing guest" : "+ New guest"}
              </button>
            </div>
            {newGuest ? (
              <div className="grid grid-cols-2 gap-2">
                <Input placeholder="First name" value={ngFirst} onChange={(e) => setNgFirst(e.target.value)} />
                <Input placeholder="Last name" value={ngLast} onChange={(e) => setNgLast(e.target.value)} />
                <Input placeholder="Phone" value={ngPhone} onChange={(e) => setNgPhone(e.target.value)} />
                <Input placeholder="Email" value={ngEmail} onChange={(e) => setNgEmail(e.target.value)} />
              </div>
            ) : (
              <div className="space-y-2">
                <Input
                  placeholder="Search guests by name / phone / email"
                  value={guestSearch}
                  onChange={(e) => setGuestSearch(e.target.value)}
                />
                <Select value={guestId} onValueChange={setGuestId}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder={loadingGuests ? "Loading guests..." : "Select guest"} />
                  </SelectTrigger>
                  <SelectContent>
                    {guests.map((g) => (
                      <SelectItem key={g.id} value={g.id}>
                        {g.firstName} {g.lastName}
                        {g.phone ? ` · ${g.phone}` : ""}
                        {g.vip ? " ★" : ""}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          {/* Stay */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Field label="Room type" required>
              <Select
                value={roomTypeId}
                onValueChange={(v) => {
                  setRoomTypeId(v);
                  setRoomId("");
                }}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {roomTypes.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.name} — {formatMoney(t.baseRate)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Room">
              <Select
                value={roomId || "none-none"}
                onValueChange={(v) => setRoomId(v === "none-none" ? "" : v)}
                disabled={!availability || availability.available.length === 0}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Auto-assign at check-in" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none-none">Auto-assign at check-in</SelectItem>
                  {availability?.available.map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      Room {r.number} (floor {r.floor})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Check-in" required>
              <Input type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} />
            </Field>
            <Field label="Check-out" required>
              <Input type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} />
            </Field>
            <Field label="Adults">
              <Input type="number" min={1} value={adults} onChange={(e) => setAdults(e.target.value)} />
            </Field>
            <Field label="Children">
              <Input type="number" min={0} value={children} onChange={(e) => setChildren(e.target.value)} />
            </Field>
            <Field label="Rate per night (₹)">
              <Input type="number" value={rate} onChange={(e) => setRate(e.target.value)} />
            </Field>
            <Field label="Source">
              <Select value={source} onValueChange={setSource}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {["DIRECT", "WEBSITE", "OTA_BOOKING_COM", "OTA_MAKE_MY_TRIP", "OTA_AIRBNB", "OTA_EXPEDIA", "OTA_GOIBIBO", "PHONE", "WALK_IN", "COMPANY"].map(
                    (s) => (
                      <SelectItem key={s} value={s}>
                        {sourceLabel(s)}
                      </SelectItem>
                    )
                  )}
                </SelectContent>
              </Select>
            </Field>
          </div>

          <Field label="Special requests">
            <Textarea
              value={specialRequests}
              onChange={(e) => setSpecialRequests(e.target.value)}
              rows={2}
              placeholder="Late check-in, high floor, allergies…"
            />
          </Field>

          {/* Live summary */}
          <div className="rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-800">
            {nights > 0 && Number(rate) > 0 ? (
              <>
                <span className="font-semibold">
                  {nights} night{nights === 1 ? "" : "s"} × {formatMoney(Number(rate))}
                </span>{" "}
                = <span className="font-bold">{formatMoney(summaryTotal)}</span>
                <span className="ml-1 text-xs text-amber-500">(taxes at invoicing)</span>
              </>
            ) : (
              "Select dates and a rate to see the stay total."
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button disabled={busy} onClick={() => void save()} className="bg-amber-600 hover:bg-amber-700">
            {busy ? "Saving..." : edit ? "Save changes" : "Create Reservation"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
