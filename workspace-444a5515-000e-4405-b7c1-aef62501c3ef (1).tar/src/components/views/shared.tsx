"use client";

import * as React from "react";
import { Loader2, Search } from "lucide-react";
import { apiGet } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";

// ─── Types ────────────────────────────────────────────────────

export type ViewProps = {
  user: { id: string; name: string; email: string; role: string };
};

// ─── PageHeader ───────────────────────────────────────────────

export function PageHeader({
  title,
  crumbs,
  children,
}: {
  title: string;
  crumbs?: string[];
  children?: React.ReactNode;
}) {
  return (
    <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        {crumbs && crumbs.length > 0 && (
          <div className="mb-0.5 text-xs text-gray-400">
            {crumbs.map((c, i) => (
              <span key={i}>
                {i > 0 && <span className="mx-1 text-gray-300">/</span>}
                <span className={i === crumbs.length - 1 ? "text-gray-500" : ""}>{c}</span>
              </span>
            ))}
          </div>
        )}
        <h1 className="truncate text-xl font-semibold text-gray-900">{title}</h1>
      </div>
      {children && <div className="flex shrink-0 flex-wrap items-center gap-2">{children}</div>}
    </div>
  );
}

// ─── StatCard ─────────────────────────────────────────────────

const TONE_BG: Record<NonNullable<StatCardProps["tone"]>, string> = {
  teal: "bg-teal-50",
  amber: "bg-amber-50",
  rose: "bg-rose-50",
  sky: "bg-sky-50",
};

const TONE_CHIP: Record<NonNullable<StatCardProps["tone"]>, string> = {
  teal: "bg-teal-100 text-teal-600",
  amber: "bg-amber-100 text-amber-600",
  rose: "bg-rose-100 text-rose-600",
  sky: "bg-sky-100 text-sky-600",
};

export type StatCardProps = {
  label: string;
  value: React.ReactNode;
  sub?: React.ReactNode;
  icon?: React.ReactNode;
  tone?: "amber" | "teal" | "rose" | "sky";
};

export function StatCard({ label, value, sub, icon, tone = "amber" }: StatCardProps) {
  return (
    <div className={cn("rounded-xl p-4", TONE_BG[tone])}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate text-sm font-medium text-gray-600">{label}</div>
          <div className="mt-1 truncate text-2xl font-bold text-gray-900">{value}</div>
          {sub !== undefined && sub !== null && (
            <div className="mt-0.5 truncate text-xs text-gray-500">{sub}</div>
          )}
        </div>
        {icon && (
          <div className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-lg", TONE_CHIP[tone])}>
            {icon}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── EmptyState ───────────────────────────────────────────────

export function EmptyState({
  icon,
  title,
  description,
}: {
  icon?: React.ReactNode;
  title: string;
  description?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-amber-50 text-amber-400">
        {icon ?? (
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="4" width="18" height="14" rx="2" />
            <path d="M8 21h8" />
            <path d="M12 18v3" />
            <path d="M7 9h4" />
            <path d="M7 13h10" />
          </svg>
        )}
      </div>
      <div className="text-base font-semibold text-gray-900">{title}</div>
      {description && <div className="mt-1 max-w-sm text-sm text-gray-500">{description}</div>}
    </div>
  );
}

// ─── StatusBadge ──────────────────────────────────────────────

const STATUS_STYLES: Record<string, string> = {
  // Reservation statuses
  CONFIRMED: "bg-amber-100 text-amber-700",
  PENDING: "bg-amber-100 text-amber-700",
  CHECKED_IN: "bg-emerald-100 text-emerald-700",
  CHECKED_OUT: "bg-gray-100 text-gray-600",
  CANCELLED: "bg-rose-100 text-rose-700",
  NO_SHOW: "bg-gray-100 text-gray-600",
  // Room statuses
  AVAILABLE: "bg-emerald-100 text-emerald-700",
  OCCUPIED: "bg-rose-100 text-rose-700",
  RESERVED: "bg-amber-100 text-amber-700",
  DIRTY: "bg-amber-100 text-amber-700",
  MAINTENANCE: "bg-gray-100 text-gray-600",
  CHECKOUT_DUE: "bg-amber-100 text-amber-700",
  // Invoice statuses
  UNPAID: "bg-rose-100 text-rose-700",
  PARTIAL: "bg-amber-100 text-amber-700",
  PAID: "bg-emerald-100 text-emerald-700",
  VOID: "bg-gray-100 text-gray-600",
  // Folio statuses
  OPEN: "bg-amber-100 text-amber-700",
  SETTLED: "bg-emerald-100 text-emerald-700",
  // Order statuses
  ACCEPTED: "bg-sky-100 text-sky-700",
  DELIVERED: "bg-emerald-100 text-emerald-700",
  PARTIALLY_DELIVERED: "bg-amber-100 text-amber-700",
};

export function StatusBadge({ status }: { status: string }) {
  const style = STATUS_STYLES[status] ?? "bg-gray-100 text-gray-600";
  const label = status.replace(/_/g, " ");
  return (
    <span className={cn("inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium", style)}>
      {label}
    </span>
  );
}

// ─── Money & date helpers ─────────────────────────────────────

const inrFormat = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 2,
});

export function formatMoney(n: number | null | undefined): string {
  return inrFormat.format(typeof n === "number" && Number.isFinite(n) ? n : 0);
}

export function Money({ v }: { v: number | null | undefined }) {
  return <span>{formatMoney(v)}</span>;
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export function formatDate(d: string | Date | null | undefined): string {
  if (!d) return "—";
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return "—";
  return `${dt.getDate()} ${MONTHS[dt.getMonth()]} ${dt.getFullYear()}`;
}

export function formatDateTime(d: string | Date | null | undefined): string {
  if (!d) return "—";
  const dt = new Date(d);
  if (isNaN(dt.getTime())) return "—";
  const hh = String(dt.getHours()).padStart(2, "0");
  const mm = String(dt.getMinutes()).padStart(2, "0");
  return `${formatDate(dt)}, ${hh}:${mm}`;
}

export function ymd(d: string | Date): string {
  const dt = new Date(d);
  const y = dt.getFullYear();
  const m = String(dt.getMonth() + 1).padStart(2, "0");
  const day = String(dt.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

// ─── Spinner ──────────────────────────────────────────────────

export function Spinner() {
  return (
    <div className="flex items-center justify-center py-16">
      <Loader2 className="h-6 w-6 animate-spin text-amber-600" />
    </div>
  );
}

// ─── useApi ───────────────────────────────────────────────────

export function useApi<T>(url: string | null): {
  data: T | null;
  loading: boolean;
  error: string | null;
  refetch: () => void;
} {
  const [data, setData] = React.useState<T | null>(null);
  const [loading, setLoading] = React.useState<boolean>(!!url);
  const [error, setError] = React.useState<string | null>(null);
  const [tick, setTick] = React.useState(0);

  React.useEffect(() => {
    if (!url) {
      setData(null);
      setLoading(false);
      setError(null);
      return;
    }
    let cancelled = false;
    const startedAt = Date.now();
    setLoading(true);
    setError(null);
    apiGet<T>(url)
      .then((d) => {
        if (!cancelled) setData(d);
      })
      .catch((e: unknown) => {
        if (!cancelled) setError(e instanceof Error ? e.message : "Failed to load data");
      })
      .finally(() => {
        if (cancelled) return;
        const wait = Math.max(0, 300 - (Date.now() - startedAt));
        window.setTimeout(() => {
          if (!cancelled) setLoading(false);
        }, wait);
      });
    return () => {
      cancelled = true;
    };
  }, [url, tick]);

  const refetch = React.useCallback(() => setTick((t) => t + 1), []);
  return { data, loading, error, refetch };
}

// ─── DataTable ────────────────────────────────────────────────

export type DataTableColumn<T> = {
  key: string;
  header: string;
  className?: string;
  render?: (row: T) => React.ReactNode;
};

export function DataTable<T extends Record<string, unknown>>({
  columns,
  rows,
  empty,
  keyField = "id",
}: {
  columns: DataTableColumn<T>[];
  rows: T[];
  empty?: React.ReactNode;
  keyField?: string;
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-full border-collapse text-sm">
        <thead>
          <tr>
            {columns.map((c) => (
              <th
                key={c.key}
                className={cn(
                  "sticky top-0 z-10 whitespace-nowrap bg-gray-50 px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wide text-gray-500",
                  c.className
                )}
              >
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="px-0 py-0">
                {empty ?? <EmptyState title="No records found" />}
              </td>
            </tr>
          ) : (
            rows.map((row, idx) => (
              <tr
                key={String(row[keyField] ?? idx)}
                className="border-b border-gray-100 transition-colors last:border-b-0 hover:bg-gray-50"
              >
                {columns.map((c) => (
                  <td key={c.key} className={cn("px-4 py-3 align-middle text-gray-700", c.className)}>
                    {c.render ? c.render(row) : String(row[c.key] ?? "—")}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

// ─── SearchInput ──────────────────────────────────────────────

export function SearchInput({
  value,
  onChange,
  placeholder = "Search...",
  className,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  className?: string;
}) {
  return (
    <div className={cn("relative", className)}>
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
      <Input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="pl-9"
      />
    </div>
  );
}

// ─── ConfirmButton ────────────────────────────────────────────

export function ConfirmButton({
  onConfirm,
  title,
  description,
  confirmLabel = "Confirm",
  children,
}: {
  onConfirm: () => void | Promise<void>;
  title: string;
  description?: string;
  confirmLabel?: string;
  children: React.ReactElement;
}) {
  const [pending, setPending] = React.useState(false);
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>{children}</AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          {description && <AlertDialogDescription>{description}</AlertDialogDescription>}
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={pending}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            disabled={pending}
            onClick={async (e) => {
              e.preventDefault();
              setPending(true);
              try {
                await onConfirm();
              } finally {
                setPending(false);
              }
            }}
          >
            {pending ? "Working..." : confirmLabel}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

// ─── Field ────────────────────────────────────────────────────

export function Field({
  label,
  children,
  required,
  className,
}: {
  label: string;
  children: React.ReactNode;
  required?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("space-y-1.5", className)}>
      <label className="block text-sm font-medium text-gray-700">
        {label}
        {required && <span className="ml-0.5 text-rose-500">*</span>}
      </label>
      {children}
    </div>
  );
}

// ─── downloadCsv ──────────────────────────────────────────────

export function downloadCsv(
  filename: string,
  columns: { key: string; header: string }[],
  rows: Record<string, unknown>[]
) {
  const escapeCell = (val: unknown): string => {
    const s =
      val === null || val === undefined
        ? ""
        : typeof val === "object"
          ? JSON.stringify(val)
          : String(val);
    if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  const lines = [
    columns.map((c) => escapeCell(c.header)).join(","),
    ...rows.map((r) => columns.map((c) => escapeCell(r[c.key])).join(",")),
  ];
  const blob = new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename.endsWith(".csv") ? filename : `${filename}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ─── TabsBar ──────────────────────────────────────────────────

export function TabsBar({
  tabs,
  active,
  onChange,
}: {
  tabs: { id: string; label: string; count?: number }[];
  active: string;
  onChange: (id: string) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {tabs.map((t) => {
        const isActive = t.id === active;
        return (
          <button
            key={t.id}
            type="button"
            onClick={() => onChange(t.id)}
            className={cn(
              "rounded-full border px-4 py-1.5 text-sm font-medium transition-colors",
              isActive
                ? "border-amber-600 bg-white text-amber-700 shadow-sm"
                : "border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:text-gray-900"
            )}
          >
            {t.label}
            {typeof t.count === "number" && <span className="ml-1 text-gray-400">({t.count})</span>}
          </button>
        );
      })}
    </div>
  );
}
