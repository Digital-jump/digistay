"use client";

import * as React from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Activity,
  AlertOctagon,
  AlertTriangle,
  ArrowDownRight,
  BedDouble,
  CalendarCheck,
  CheckCircle2,
  ClipboardList,
  Coins,
  Info,
  KeyRound,
  LogIn,
  LogOut,
  Pencil,
  PlusCircle,
  Sparkles,
  TrendingUp,
  Users,
  Wallet,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { apiPost } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import { useAppStore } from "@/store/app-store";
import {
  DataTable,
  EmptyState,
  PageHeader,
  Spinner,
  StatCard,
  StatusBadge,
  formatMoney,
  useApi,
  type ViewProps,
} from "@/components/views/shared";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

// ─── Types ────────────────────────────────────────────────────

type Stats = {
  totalRooms: number;
  availableRooms: number;
  occupiedRooms: number;
  reservedRooms: number;
  dirtyRooms: number;
  maintenanceRooms: number;
  occupancyRate: number;
  arrivalsToday: number;
  departuresToday: number;
  inHouseGuests: number;
  todayRevenue: number;
  monthRevenue: number;
  outstandingBalance: number;
  pendingOrders: number;
};

type TrendPoint = { date: string; occupancy: number; revenue: number };
type RevenueMonth = { month: string; room: number; fb: number };
type SourcePoint = { source: string; count: number };
type RoomStatusPoint = { status: string; count: number };
type ActivityItem = {
  id: string;
  action: string;
  userName: string | null;
  entity: string;
  details: string | null;
  createdAt: string;
};

type ReservationRow = {
  id: string;
  code: string;
  status: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  totalAmount: number;
  source: string;
  guest: { firstName: string; lastName: string } | null;
  roomType: { name: string } | null;
  room: { id: string; number: string } | null;
};

type DashboardData = {
  stats: Stats;
  occupancyTrend: TrendPoint[];
  revenueByMonth: RevenueMonth[];
  sourceBreakdown: SourcePoint[];
  roomStatusBreakdown: RoomStatusPoint[];
  recentActivity: ActivityItem[];
  arrivalsTodayList: ReservationRow[];
  departuresTodayList: ReservationRow[];
};

type RoomTypeLite = { id: string; name: string };

type AiInsight = {
  title: string;
  detail: string;
  severity: "positive" | "warning" | "critical" | "info";
  action: string;
};

type AiInsightsData = { insights: AiInsight[]; generatedAt: string; cached: boolean };

// ─── Source label mapping ─────────────────────────────────────

const SOURCE_LABELS: Record<string, string> = {
  DIRECT: "Direct",
  WEBSITE: "Website",
  OTA_BOOKING_COM: "Booking.com",
  OTA_MAKE_MY_TRIP: "MakeMyTrip",
  OTA_AIRBNB: "Airbnb",
  OTA_EXPEDIA: "Expedia",
  OTA_GOIBIBO: "Goibibo",
  PHONE: "Phone",
  WALK_IN: "Walk-in",
  COMPANY: "Company",
};

const PIE_COLORS = ["#D97706", "#14B8A6", "#F59E0B", "#F43F5E", "#0EA5E9", "#B45309", "#10B981", "#6366F1", "#EC4899", "#64748B"];

const ROOM_STATUS_DOT: Record<string, string> = {
  AVAILABLE: "bg-emerald-500",
  OCCUPIED: "bg-rose-500",
  RESERVED: "bg-amber-500",
  DIRTY: "bg-amber-500",
  MAINTENANCE: "bg-gray-400",
};

const MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function shortDayLabel(iso: string): string {
  const d = new Date(`${iso}T00:00:00`);
  if (isNaN(d.getTime())) return iso;
  return `${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}`;
}

function timeAgo(d: string | Date): string {
  const then = new Date(d).getTime();
  if (isNaN(then)) return "";
  const secs = Math.max(0, Math.floor((Date.now() - then) / 1000));
  if (secs < 60) return "just now";
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function guestName(r: ReservationRow): string {
  if (!r.guest) return "—";
  return `${r.guest.firstName} ${r.guest.lastName}`;
}

// ─── DigiAI insights card (ADMIN only) ────────────────────────

const AI_SEVERITY_ICON: Record<AiInsight["severity"], { icon: React.ReactNode; cls: string }> = {
  positive: { icon: <TrendingUp className="h-4 w-4" />, cls: "bg-emerald-100 text-emerald-600" },
  warning: { icon: <AlertTriangle className="h-4 w-4" />, cls: "bg-amber-100 text-amber-600" },
  critical: { icon: <AlertOctagon className="h-4 w-4" />, cls: "bg-rose-100 text-rose-600" },
  info: { icon: <Info className="h-4 w-4" />, cls: "bg-gray-100 text-gray-600" },
};

function DigiAIInsightsCard() {
  const setModule = useAppStore((s) => s.setModule);
  const { data, loading, error } = useApi<AiInsightsData>("/api/ai/insights");

  if (error) {
    console.error("DigiAI insights failed to load:", error);
    return null;
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="flex items-center gap-1.5 text-sm font-semibold text-gray-900">
          <Sparkles className="h-4 w-4 text-amber-600" /> DigiAI Insights
        </CardTitle>
        <Button
          variant="ghost"
          size="sm"
          className="h-8 rounded-lg px-2 text-xs text-amber-700 hover:bg-amber-50 hover:text-amber-700"
          onClick={() => setModule("ai-hub")}
        >
          Open AI Hub
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : (data?.insights ?? []).length === 0 ? (
          <div className="py-2 text-center text-xs text-gray-400">
            No insights yet — DigiAI needs a little activity data first.
          </div>
        ) : (
          <div className="space-y-1">
            {(data?.insights ?? []).slice(0, 3).map((ins, i) => {
              const meta = AI_SEVERITY_ICON[ins.severity] ?? AI_SEVERITY_ICON.info;
              return (
                <div key={`${ins.title}-${i}`} className="flex items-start gap-2.5 rounded-lg px-1 py-1.5">
                  <span className={cn("mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md", meta.cls)}>
                    {meta.icon}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium text-gray-900">{ins.title}</div>
                    <div className="truncate text-xs text-gray-500">{ins.detail}</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── Activity icon map ────────────────────────────────────────

function ActivityIcon({ action }: { action: string }) {
  const cfg: Record<string, { icon: React.ReactNode; cls: string }> = {
    CREATE: { icon: <PlusCircle className="h-4 w-4" />, cls: "bg-emerald-100 text-emerald-600" },
    UPDATE: { icon: <Pencil className="h-4 w-4" />, cls: "bg-sky-100 text-sky-600" },
    CHECKIN: { icon: <LogIn className="h-4 w-4" />, cls: "bg-amber-100 text-amber-600" },
    CHECKOUT: { icon: <LogOut className="h-4 w-4" />, cls: "bg-amber-100 text-amber-600" },
    CANCEL: { icon: <XCircle className="h-4 w-4" />, cls: "bg-rose-100 text-rose-600" },
    PAYMENT: { icon: <Wallet className="h-4 w-4" />, cls: "bg-teal-100 text-teal-600" },
    LOGIN: { icon: <KeyRound className="h-4 w-4" />, cls: "bg-gray-100 text-gray-500" },
    NO_SHOW: { icon: <XCircle className="h-4 w-4" />, cls: "bg-rose-100 text-rose-600" },
  };
  const c = cfg[action] ?? { icon: <Activity className="h-4 w-4" />, cls: "bg-gray-100 text-gray-500" };
  return (
    <span className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-full", c.cls)}>
      {c.icon}
    </span>
  );
}

// ─── View ─────────────────────────────────────────────────────

export default function DashboardView({ user }: ViewProps) {
  const setModule = useAppStore((s) => s.setModule);
  const { data, loading, error, refetch } = useApi<DashboardData>("/api/dashboard");
  const { data: roomTypes } = useApi<RoomTypeLite[]>("/api/room-types");
  const [checkingIn, setCheckingIn] = React.useState<string | null>(null);
  const [checkingOut, setCheckingOut] = React.useState<string | null>(null);

  async function handleCheckIn(res: ReservationRow) {
    if (res.room?.id) {
      setCheckingIn(res.id);
      try {
        await apiPost(`/api/reservations/${res.id}/checkin`, { roomId: res.room.id });
        toast.success(`${res.code} checked in to room ${res.room.number}`);
        refetch();
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "Check-in failed");
      } finally {
        setCheckingIn(null);
      }
    } else {
      // Room not assigned yet — let reception pick one in the Reservations module.
      setModule("reservations");
    }
  }

  async function handleCheckOut(res: ReservationRow) {
    setCheckingOut(res.id);
    try {
      await apiPost(`/api/reservations/${res.id}/checkout`);
      toast.success(`${res.code} checked out`);
      refetch();
    } catch (e) {
      const message = e instanceof Error ? e.message : "Check-out failed";
      toast.error(/unsettled|balance/i.test(message) ? `${message}. Settle the folio before checkout.` : message);
    } finally {
      setCheckingOut(null);
    }
  }

  if (loading) return <Spinner />;
  if (error) return <EmptyState title="Couldn't load dashboard" description={error} />;
  if (!data) return null;

  const { stats } = data;
  const occupancyTrend = data.occupancyTrend.map((p) => ({ ...p, label: shortDayLabel(p.date) }));
  const sourceData = data.sourceBreakdown.map((s) => ({
    ...s,
    label: SOURCE_LABELS[s.source] ?? s.source.replace(/_/g, " "),
  }));
  const roomTypesCount = roomTypes?.length ?? 0;

  return (
    <div className="space-y-4">
      <PageHeader title="Dashboard" crumbs={["Dashboard"]} />

      {/* Row 1 stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Total Rooms"
          value={stats.totalRooms}
          sub={roomTypesCount > 0 ? `across ${roomTypesCount} room types` : undefined}
          tone="amber"
          icon={<BedDouble className="h-4 w-4" />}
        />
        <StatCard
          label="Available"
          value={stats.availableRooms}
          sub={`${stats.reservedRooms} reserved · ${stats.dirtyRooms} dirty`}
          tone="teal"
          icon={<CheckCircle2 className="h-4 w-4" />}
        />
        <StatCard
          label="Occupied"
          value={stats.occupiedRooms}
          sub={`${stats.occupancyRate}% occupancy`}
          tone="amber"
          icon={<KeyRound className="h-4 w-4" />}
        />
        <StatCard
          label="Today's Revenue"
          value={formatMoney(stats.todayRevenue)}
          sub={`month ${formatMoney(stats.monthRevenue)}`}
          tone="rose"
          icon={<Coins className="h-4 w-4" />}
        />
      </div>

      {/* Row 2 stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Arrivals Today"
          value={stats.arrivalsToday}
          sub={`departures: ${stats.departuresToday}`}
          tone="amber"
          icon={<ArrowDownRight className="h-4 w-4" />}
        />
        <StatCard
          label="In-House Guests"
          value={stats.inHouseGuests}
          sub={`${stats.occupiedRooms} rooms occupied`}
          tone="sky"
          icon={<Users className="h-4 w-4" />}
        />
        <StatCard
          label="Pending F&B Orders"
          value={stats.pendingOrders}
          sub="kitchen queue"
          tone="amber"
          icon={<ClipboardList className="h-4 w-4" />}
        />
        <StatCard
          label="Outstanding"
          value={formatMoney(stats.outstandingBalance)}
          sub="unpaid invoices"
          tone="rose"
          icon={<Wallet className="h-4 w-4" />}
        />
      </div>

      {/* DigiAI insights (ADMIN only) */}
      {user.role === "ADMIN" && <DigiAIInsightsCard />}

      {/* Room status chips */}
      <div className="flex flex-wrap items-center gap-2">
        {data.roomStatusBreakdown.map((r) => (
          <span
            key={r.status}
            className="inline-flex items-center gap-1.5 rounded-full border border-gray-200 bg-white px-3 py-1 text-xs font-medium text-gray-600"
          >
            <span className={cn("h-2 w-2 rounded-full", ROOM_STATUS_DOT[r.status] ?? "bg-gray-300")} />
            {r.status.replace(/_/g, " ")}
            <span className="font-semibold text-gray-900">{r.count}</span>
          </span>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-gray-900">Occupancy — last 14 days</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={occupancyTrend} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id="occFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#D97706" stopOpacity={0.25} />
                    <stop offset="100%" stopColor="#D97706" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#9CA3AF" }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
                <YAxis tick={{ fontSize: 11, fill: "#9CA3AF" }} tickLine={false} axisLine={false} unit="%" domain={[0, 100]} />
                <Tooltip
                  formatter={(v: number | string) => [`${v}%`, "Occupancy"]}
                  contentStyle={{ borderRadius: 8, fontSize: 12, borderColor: "#E5E7EB" }}
                />
                <Area type="monotone" dataKey="occupancy" stroke="#D97706" strokeWidth={2} fill="url(#occFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-gray-900">Revenue by month</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.revenueByMonth} margin={{ top: 8, right: 8, left: -8, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#9CA3AF" }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#9CA3AF" }} tickLine={false} axisLine={false} tickFormatter={(v: number) => (v >= 1000 ? `${Math.round(v / 1000)}k` : String(v))} />
                <Tooltip
                  formatter={(v: number | string, name: string) => [formatMoney(Number(v)), name === "room" ? "Rooms" : "F&B"]}
                  contentStyle={{ borderRadius: 8, fontSize: 12, borderColor: "#E5E7EB" }}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="room" name="Rooms" fill="#FBBF24" radius={[4, 4, 0, 0]} />
                <Bar dataKey="fb" name="F&B" fill="#2DD4BF" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Sources + arrivals */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-gray-900">Bookings by source</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {sourceData.length === 0 ? (
              <EmptyState title="No bookings yet" />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={sourceData}
                    dataKey="count"
                    nameKey="label"
                    innerRadius={45}
                    outerRadius={75}
                    paddingAngle={2}
                    strokeWidth={0}
                  >
                    {sourceData.map((entry, i) => (
                      <Cell key={entry.source} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(v: number | string, name: string) => [`${v} bookings`, name]}
                    contentStyle={{ borderRadius: 8, fontSize: 12, borderColor: "#E5E7EB" }}
                  />
                  <Legend wrapperStyle={{ fontSize: 11 }} iconSize={8} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-semibold text-gray-900">Today&apos;s Arrivals</CardTitle>
            <Button
              variant="outline"
              size="sm"
              className="h-8 rounded-lg text-xs"
              onClick={() => setModule("reservations")}
            >
              <CalendarCheck className="mr-1 h-3.5 w-3.5" /> All reservations
            </Button>
          </CardHeader>
          <CardContent className="px-0 pb-0">
            <DataTable<ReservationRow>
              keyField="id"
              rows={data.arrivalsTodayList}
              empty={<EmptyState title="No arrivals today" description="New bookings arriving today will show up here." />}
              columns={[
                {
                  key: "code",
                  header: "Booking",
                  render: (r) => <span className="font-medium text-gray-900">{r.code}</span>,
                },
                { key: "guest", header: "Guest", render: (r) => guestName(r) },
                { key: "roomType", header: "Type", render: (r) => r.roomType?.name ?? "—" },
                { key: "room", header: "Room", render: (r) => r.room?.number ?? "Unassigned" },
                { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
                {
                  key: "actions",
                  header: "",
                  className: "text-right",
                  render: (r) =>
                    r.status === "PENDING" || r.status === "CONFIRMED" ? (
                      <Button
                        size="sm"
                        disabled={checkingIn === r.id}
                        onClick={() => void handleCheckIn(r)}
                        className="h-8 rounded-lg bg-amber-600 text-xs text-white hover:bg-amber-700"
                      >
                        Check-in
                      </Button>
                    ) : null,
                },
              ]}
            />
          </CardContent>
        </Card>
      </div>

      {/* Departures + activity */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-gray-900">Today&apos;s Departures</CardTitle>
          </CardHeader>
          <CardContent className="px-0 pb-0">
            <DataTable<ReservationRow>
              keyField="id"
              rows={data.departuresTodayList}
              empty={<EmptyState title="No departures today" description="In-house stays checking out today will show up here." />}
              columns={[
                {
                  key: "code",
                  header: "Booking",
                  render: (r) => <span className="font-medium text-gray-900">{r.code}</span>,
                },
                { key: "guest", header: "Guest", render: (r) => guestName(r) },
                { key: "room", header: "Room", render: (r) => r.room?.number ?? "—" },
                { key: "nights", header: "Nights", render: (r) => `${r.adults ?? 0} ad · ${r.children ?? 0} ch` },
                {
                  key: "actions",
                  header: "",
                  className: "text-right",
                  render: (r) => (
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={checkingOut === r.id}
                      onClick={() => void handleCheckOut(r)}
                      className="h-8 rounded-lg border-amber-200 text-xs text-amber-700 hover:bg-amber-50"
                    >
                      Check-out
                    </Button>
                  ),
                },
              ]}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-gray-900">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent className="max-h-80 space-y-3 overflow-y-auto">
            {data.recentActivity.length === 0 ? (
              <EmptyState title="No activity yet" />
            ) : (
              data.recentActivity.map((a) => (
                <div key={a.id} className="flex items-start gap-2.5">
                  <ActivityIcon action={a.action} />
                  <div className="min-w-0 flex-1">
                    <div className="text-sm text-gray-700">
                      <span className="font-medium text-gray-900">{a.userName ?? "System"}</span>{" "}
                      <span className="text-xs text-gray-400">{a.action.toLowerCase().replace(/_/g, " ")} · {a.entity}</span>
                    </div>
                    {a.details && <div className="truncate text-xs text-gray-500">{a.details}</div>}
                    <div className="text-[11px] text-gray-400">{timeAgo(a.createdAt)}</div>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      <div className="flex items-start gap-2 rounded-lg bg-gray-50 px-3 py-2 text-xs text-gray-500">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        Demo data is pre-seeded for evaluation — Settings → Users &amp; Data lets you reset it.
      </div>
    </div>
  );
}
