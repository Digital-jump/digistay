"use client";

import * as React from "react";
import { Pencil, Plus, RotateCcw, ShieldAlert, Trash2, TriangleAlert } from "lucide-react";
import { toast } from "sonner";
import { apiDelete, apiPost, apiPut } from "@/lib/api-client";
import { cn } from "@/lib/utils";
import { ROLE_LABELS, type Role } from "@/lib/permissions";
import { useAppStore } from "@/store/app-store";
import {
  ConfirmButton,
  DataTable,
  EmptyState,
  Field,
  PageHeader,
  SearchInput,
  Spinner,
  TabsBar,
  formatDateTime,
  useApi,
  type ViewProps,
} from "@/components/views/shared";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";

// ─── Types ────────────────────────────────────────────────────

type HotelSettings = {
  id: string;
  name: string;
  tagline: string;
  address: string;
  phone: string;
  email: string;
  gstin: string;
  currency: string;
  taxRate: number;
  fbTaxRate: number;
  checkInTime: string;
  checkOutTime: string;
  otaCommission: number;
  bookingEngineEnabled: boolean;
  paymentMode: string;
  themeColor: string;
};

type AdminUser = {
  id: string;
  name: string;
  email: string;
  role: string;
  phone: string | null;
  active: boolean;
  createdAt: string;
  sessionCount?: number;
};

type AuditLogRow = {
  id: string;
  userName: string | null;
  action: string;
  entity: string;
  entityId: string | null;
  details: string | null;
  createdAt: string;
};

const ROLE_OPTIONS: Role[] = ["ADMIN", "RECEPTIONIST", "ACCOUNTANT", "STAFF"];

const ROLE_BADGE: Record<string, string> = {
  ADMIN: "bg-amber-100 text-amber-700",
  RECEPTIONIST: "bg-sky-100 text-sky-700",
  ACCOUNTANT: "bg-teal-100 text-teal-700",
  STAFF: "bg-amber-100 text-amber-700",
};

const ACTION_BADGE: Record<string, string> = {
  CREATE: "bg-emerald-100 text-emerald-700",
  UPDATE: "bg-sky-100 text-sky-700",
  DELETE: "bg-rose-100 text-rose-700",
  CHECKIN: "bg-amber-100 text-amber-700",
  CHECKOUT: "bg-amber-100 text-amber-700",
  CANCEL: "bg-rose-100 text-rose-700",
  PAYMENT: "bg-teal-100 text-teal-700",
  LOGIN: "bg-gray-100 text-gray-600",
  LOGOUT: "bg-gray-100 text-gray-600",
};

const THEME_SWATCHES = ["#F59E0B", "#2563EB", "#059669", "#D97706", "#E11D48", "#0F172A"];

const EMPTY_FORM: HotelSettings = {
  id: "main",
  name: "",
  tagline: "",
  address: "",
  phone: "",
  email: "",
  gstin: "",
  currency: "INR",
  taxRate: 12,
  fbTaxRate: 5,
  checkInTime: "14:00",
  checkOutTime: "11:00",
  otaCommission: 15,
  bookingEngineEnabled: true,
  paymentMode: "UNPAID",
  themeColor: "#D97706",
};

function RoleBadge({ role }: { role: string }) {
  return (
    <span className={cn("inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium", ROLE_BADGE[role] ?? "bg-gray-100 text-gray-600")}>
      {ROLE_LABELS[role as Role] ?? role}
    </span>
  );
}

function ActionBadge({ action }: { action: string }) {
  return (
    <span className={cn("inline-flex whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium", ACTION_BADGE[action] ?? "bg-gray-100 text-gray-600")}>
      {action.replace(/_/g, " ")}
    </span>
  );
}

function ReadOnlyNote() {
  return (
    <div className="flex items-center gap-2 rounded-lg bg-gray-50 px-3 py-2 text-xs text-gray-500">
      <ShieldAlert className="h-3.5 w-3.5 shrink-0" />
      Read-only — administrator access is required to make changes.
    </div>
  );
}

// ─── View ─────────────────────────────────────────────────────

export default function SettingsView({ user }: ViewProps) {
  const isAdmin = user.role === "ADMIN";
  const logout = useAppStore((s) => s.logout);

  const [tab, setTab] = React.useState("profile");
  const { data: settings, loading: settingsLoading, refetch: refetchSettings } = useApi<HotelSettings>("/api/settings");
  const [form, setForm] = React.useState<HotelSettings>(EMPTY_FORM);
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (settings) setForm({ ...EMPTY_FORM, ...settings });
  }, [settings]);

  const set = <K extends keyof HotelSettings>(key: K, value: HotelSettings[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  async function save() {
    setSaving(true);
    try {
      await apiPut("/api/settings", {
        name: form.name,
        tagline: form.tagline,
        address: form.address,
        phone: form.phone,
        email: form.email,
        gstin: form.gstin,
        currency: form.currency,
        taxRate: Number(form.taxRate),
        fbTaxRate: Number(form.fbTaxRate),
        checkInTime: form.checkInTime,
        checkOutTime: form.checkOutTime,
        otaCommission: Number(form.otaCommission),
        bookingEngineEnabled: form.bookingEngineEnabled,
        paymentMode: form.paymentMode,
        themeColor: form.themeColor,
      });
      toast.success("Settings saved");
      refetchSettings();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to save settings");
    } finally {
      setSaving(false);
    }
  }

  if (settingsLoading && !settings) return <Spinner />;

  return (
    <div className="space-y-4">
      <PageHeader title="Settings" crumbs={["Settings"]}>
        {isAdmin && (
          <Button
            onClick={() => void save()}
            disabled={saving}
            className="rounded-lg bg-amber-600 text-white hover:bg-amber-700"
          >
            Save Changes
          </Button>
        )}
      </PageHeader>

      <TabsBar
        tabs={[
          { id: "profile", label: "Hotel Profile" },
          { id: "rates", label: "Rates & Taxes" },
          { id: "engine", label: "Booking Engine" },
          { id: "users", label: "Users" },
          { id: "audit", label: "Audit Log" },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === "profile" && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-gray-900">Hotel Profile</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <Field label="Hotel Name" required>
                <Input value={form.name} onChange={(e) => set("name", e.target.value)} disabled={!isAdmin} />
              </Field>
              <Field label="Tagline">
                <Input value={form.tagline} onChange={(e) => set("tagline", e.target.value)} disabled={!isAdmin} />
              </Field>
            </div>
            <Field label="Address">
              <Textarea rows={2} value={form.address} onChange={(e) => set("address", e.target.value)} disabled={!isAdmin} />
            </Field>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <Field label="Phone">
                <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} disabled={!isAdmin} />
              </Field>
              <Field label="Email">
                <Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} disabled={!isAdmin} />
              </Field>
              <Field label="GSTIN">
                <Input value={form.gstin} onChange={(e) => set("gstin", e.target.value)} disabled={!isAdmin} />
              </Field>
            </div>
            {!isAdmin && <ReadOnlyNote />}
          </CardContent>
        </Card>
      )}

      {tab === "rates" && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-gray-900">Rates &amp; Taxes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <Field label="Room Tax Rate (%)">
                <Input
                  type="number"
                  min={0}
                  value={form.taxRate}
                  onChange={(e) => set("taxRate", Number(e.target.value))}
                  disabled={!isAdmin}
                />
              </Field>
              <Field label="F&B Tax Rate (%)">
                <Input
                  type="number"
                  min={0}
                  value={form.fbTaxRate}
                  onChange={(e) => set("fbTaxRate", Number(e.target.value))}
                  disabled={!isAdmin}
                />
              </Field>
              <Field label="OTA Commission (%)">
                <Input
                  type="number"
                  min={0}
                  value={form.otaCommission}
                  onChange={(e) => set("otaCommission", Number(e.target.value))}
                  disabled={!isAdmin}
                />
              </Field>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <Field label="Currency">
                <Input value={form.currency} onChange={(e) => set("currency", e.target.value)} disabled={!isAdmin} />
              </Field>
              <Field label="Check-in Time">
                <Input type="time" value={form.checkInTime} onChange={(e) => set("checkInTime", e.target.value)} disabled={!isAdmin} />
              </Field>
              <Field label="Check-out Time">
                <Input type="time" value={form.checkOutTime} onChange={(e) => set("checkOutTime", e.target.value)} disabled={!isAdmin} />
              </Field>
            </div>
            {!isAdmin && <ReadOnlyNote />}
          </CardContent>
        </Card>
      )}

      {tab === "engine" && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-gray-900">Booking Engine</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="flex items-center justify-between rounded-lg border border-gray-100 p-3">
              <div>
                <div className="text-sm font-medium text-gray-900">Public booking engine</div>
                <div className="text-xs text-gray-500">Allow website visitors to book rooms in real time.</div>
              </div>
              <Switch
                checked={form.bookingEngineEnabled}
                onCheckedChange={(v) => set("bookingEngineEnabled", v)}
                disabled={!isAdmin}
              />
            </div>

            <Field label="Payment Mode">
              <RadioGroup
                value={form.paymentMode}
                onValueChange={(v) => set("paymentMode", v)}
                className="flex flex-wrap gap-4"
                disabled={!isAdmin}
              >
                {["PREPAID", "UNPAID", "BOTH"].map((mode) => (
                  <div key={mode} className="flex items-center space-x-2">
                    <RadioGroupItem value={mode} id={`pm-${mode}`} disabled={!isAdmin} />
                    <Label htmlFor={`pm-${mode}`} className="text-sm font-normal">
                      {mode === "PREPAID" ? "Prepaid" : mode === "UNPAID" ? "Pay at hotel" : "Both"}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </Field>

            <Field label="Theme Color">
              <div className="flex items-center gap-2">
                {THEME_SWATCHES.map((color) => (
                  <button
                    key={color}
                    type="button"
                    disabled={!isAdmin}
                    onClick={() => set("themeColor", color)}
                    className={cn(
                      "h-8 w-8 rounded-full border-2 transition-transform",
                      form.themeColor?.toLowerCase() === color.toLowerCase()
                        ? "scale-110 border-gray-900"
                        : "border-transparent hover:scale-105"
                    )}
                    style={{ backgroundColor: color }}
                    title={color}
                  />
                ))}
                <span className="ml-2 text-xs text-gray-400">{form.themeColor}</span>
              </div>
            </Field>
            {!isAdmin && <ReadOnlyNote />}
          </CardContent>
        </Card>
      )}

      {tab === "users" && <UsersTab isAdmin={isAdmin} currentUserId={user.id} />}
      {tab === "audit" && <AuditTab isAdmin={isAdmin} />}

      {isAdmin && (
        <Card className="border-rose-100">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold text-rose-700">
              <TriangleAlert className="h-4 w-4" /> Danger Zone
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
              <div className="text-sm text-gray-600">
                Reset Demo Data — wipes all bookings, guests, folios and restores the original demo dataset.
                You will be signed out.
              </div>
              <ConfirmButton
                title="Reset demo data?"
                description="This deletes all current data and re-seeds the original demo dataset. All sessions are invalidated and you will be signed out. This cannot be undone."
                confirmLabel="Reset Demo Data"
                onConfirm={async () => {
                  try {
                    await apiPost("/api/admin/reset-demo");
                    toast.success("Demo data has been reset. Please sign in again.");
                    logout();
                  } catch (e) {
                    toast.error(e instanceof Error ? e.message : "Reset failed");
                  }
                }}
              >
                <Button variant="destructive" className="rounded-lg">
                  <RotateCcw className="mr-1 h-4 w-4" /> Reset Demo Data
                </Button>
              </ConfirmButton>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ─── Users tab ────────────────────────────────────────────────

function UsersTab({ isAdmin, currentUserId }: { isAdmin: boolean; currentUserId: string }) {
  const { data: users, loading, refetch } = useApi<AdminUser[]>(isAdmin ? "/api/users" : null);
  const [addOpen, setAddOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<AdminUser | null>(null);
  const [addForm, setAddForm] = React.useState({ name: "", email: "", password: "", role: "RECEPTIONIST", phone: "" });
  const [saving, setSaving] = React.useState(false);

  if (!isAdmin) {
    return <EmptyState title="Administrator access required" description="Only administrators can view and manage users." />;
  }

  async function addUser() {
    setSaving(true);
    try {
      await apiPost("/api/users", addForm);
      toast.success("User created");
      setAddOpen(false);
      setAddForm({ name: "", email: "", password: "", role: "RECEPTIONIST", phone: "" });
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to create user");
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive(u: AdminUser, active: boolean) {
    try {
      await apiPut(`/api/users/${u.id}`, { active });
      refetch();
      toast.success(`${u.name} ${active ? "activated" : "deactivated"}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to update user");
    }
  }

  async function deleteUser(u: AdminUser) {
    try {
      await apiDelete(`/api/users/${u.id}`);
      toast.success(`${u.name} deleted`);
      refetch();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to delete user");
    }
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-semibold text-gray-900">Users &amp; Roles</CardTitle>
        <Button
          size="sm"
          onClick={() => setAddOpen(true)}
          className="rounded-lg bg-amber-600 text-white hover:bg-amber-700"
        >
          <Plus className="mr-1 h-4 w-4" /> Add User
        </Button>
      </CardHeader>
      <CardContent className="px-0 pb-0">
        {loading ? (
          <Spinner />
        ) : (
          <DataTable<AdminUser>
            keyField="id"
            rows={users ?? []}
            empty={<EmptyState title="No users" />}
            columns={[
              { key: "name", header: "Name", render: (u) => <span className="font-medium text-gray-900">{u.name}{u.id === currentUserId ? <span className="ml-1.5 text-xs text-gray-400">(you)</span> : null}</span> },
              { key: "email", header: "Email" },
              { key: "phone", header: "Phone", render: (u) => u.phone ?? "—" },
              { key: "role", header: "Role", render: (u) => <RoleBadge role={u.role} /> },
              {
                key: "active",
                header: "Active",
                render: (u) => <Switch checked={u.active} onCheckedChange={(v) => void toggleActive(u, v)} />,
              },
              { key: "sessions", header: "Sessions", render: (u) => u.sessionCount ?? 0 },
              {
                key: "actions",
                header: "",
                className: "text-right",
                render: (u) => (
                  <div className="flex items-center justify-end gap-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setEditing(u)}>
                      <Pencil className="h-4 w-4 text-gray-500" />
                    </Button>
                    {u.id !== currentUserId && (
                      <ConfirmButton
                        title={`Delete ${u.name}?`}
                        description="The user and their sessions will be removed. The audit trail keeps past entries."
                        confirmLabel="Delete"
                        onConfirm={() => deleteUser(u)}
                      >
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Trash2 className="h-4 w-4 text-rose-500" />
                        </Button>
                      </ConfirmButton>
                    )}
                  </div>
                ),
              },
            ]}
          />
        )}
      </CardContent>

      {/* Add user dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add User</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Field label="Full Name" required>
              <Input value={addForm.name} onChange={(e) => setAddForm({ ...addForm, name: e.target.value })} />
            </Field>
            <Field label="Email" required>
              <Input type="email" value={addForm.email} onChange={(e) => setAddForm({ ...addForm, email: e.target.value })} />
            </Field>
            <Field label="Password" required>
              <Input type="password" value={addForm.password} onChange={(e) => setAddForm({ ...addForm, password: e.target.value })} placeholder="min 6 characters" />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Role" required>
                <Select value={addForm.role} onValueChange={(v) => setAddForm({ ...addForm, role: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {ROLE_OPTIONS.map((r) => (
                      <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Phone">
                <Input value={addForm.phone} onChange={(e) => setAddForm({ ...addForm, phone: e.target.value })} />
              </Field>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button onClick={() => void addUser()} disabled={saving} className="rounded-lg bg-amber-600 text-white hover:bg-amber-700">
              Create User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit user dialog */}
      <EditUserDialog user={editing} onClose={() => setEditing(null)} onSaved={refetch} />
    </Card>
  );
}

function EditUserDialog({
  user,
  onClose,
  onSaved,
}: {
  user: AdminUser | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [role, setRole] = React.useState("STAFF");
  const [password, setPassword] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (user) {
      setName(user.name);
      setPhone(user.phone ?? "");
      setRole(user.role);
      setPassword("");
    }
  }, [user]);

  if (!user) return null;
  const target = user;

  async function save() {
    setSaving(true);
    try {
      const data: Record<string, unknown> = { name, role };
      if (phone.trim()) data.phone = phone.trim();
      if (password) data.password = password;
      await apiPut(`/api/users/${target.id}`, data);
      toast.success("User updated");
      onSaved();
      onClose();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to update user");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={!!user} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Edit User — {user.name}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <Field label="Full Name" required>
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Role">
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ROLE_OPTIONS.map((r) => (
                    <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Phone">
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
            </Field>
          </div>
          <Field label="New Password">
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="leave blank to keep current" />
          </Field>
          <div className="text-xs text-gray-400">Email: {user.email}</div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => void save()} disabled={saving} className="rounded-lg bg-amber-600 text-white hover:bg-amber-700">
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Audit tab ────────────────────────────────────────────────

function AuditTab({ isAdmin }: { isAdmin: boolean }) {
  const [search, setSearch] = React.useState("");
  const [debounced, setDebounced] = React.useState("");

  React.useEffect(() => {
    const t = window.setTimeout(() => setDebounced(search.trim()), 300);
    return () => window.clearTimeout(t);
  }, [search]);

  const url = isAdmin
    ? `/api/audit-logs?limit=100${debounced ? `&search=${encodeURIComponent(debounced)}` : ""}`
    : null;
  const { data, loading } = useApi<AuditLogRow[]>(url);

  if (!isAdmin) {
    return <EmptyState title="Administrator access required" description="Only administrators can view the audit log." />;
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-semibold text-gray-900">Audit Log</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="w-full sm:w-72">
          <SearchInput value={search} onChange={setSearch} placeholder="Search audit log..." />
        </div>
        {loading ? (
          <Spinner />
        ) : (
          <DataTable<AuditLogRow>
            keyField="id"
            rows={data ?? []}
            empty={<EmptyState title="No audit entries" description="Actions performed across the system will be logged here." />}
            columns={[
              { key: "createdAt", header: "Time", render: (l) => formatDateTime(l.createdAt) },
              { key: "userName", header: "User", render: (l) => l.userName ?? "System" },
              { key: "action", header: "Action", render: (l) => <ActionBadge action={l.action} /> },
              { key: "entity", header: "Entity" },
              { key: "details", header: "Details", render: (l) => <span className="line-clamp-1 text-gray-500">{l.details ?? "—"}</span> },
            ]}
          />
        )}
      </CardContent>
    </Card>
  );
}
