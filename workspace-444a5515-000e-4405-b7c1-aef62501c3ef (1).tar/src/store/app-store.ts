"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { ModuleId } from "@/lib/permissions";

export type AppUser = {
  id: string;
  name: string;
  email: string;
  role: string;
  phone?: string | null;
};

type AppState = {
  token: string | null;
  user: AppUser | null;
  activeModule: ModuleId;
  mobileNavOpen: boolean;
  setAuth: (token: string, user: AppUser) => void;
  logout: () => void;
  setModule: (m: ModuleId) => void;
  setMobileNavOpen: (open: boolean) => void;
};

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      token: null,
      user: null,
      activeModule: "dashboard",
      mobileNavOpen: false,
      setAuth: (token, user) => set({ token, user }),
      logout: () => set({ token: null, user: null, activeModule: "dashboard" }),
      setModule: (m) => set({ activeModule: m, mobileNavOpen: false }),
      setMobileNavOpen: (open) => set({ mobileNavOpen: open }),
    }),
    { name: "digistay-app" }
  )
);
