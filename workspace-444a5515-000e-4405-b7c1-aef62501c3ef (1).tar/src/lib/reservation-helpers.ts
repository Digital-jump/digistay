import { db } from "./db";
import { ApiError, overlappingReservationsFilter } from "./api-helpers";
import { canAccess, type ModuleId } from "./permissions";

/**
 * Shared helpers for the reservations endpoints (Task 2-a scope).
 * Kept out of route.ts because Next.js route files may only export HTTP handlers.
 */

export function parseDateStr(value: unknown, kind: "checkIn" | "checkOut"): Date {
  const s = typeof value === "string" ? value.trim() : "";
  const time = kind === "checkIn" ? "T14:00:00" : "T11:00:00";
  const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(s) ? `${s}${time}` : s);
  if (isNaN(d.getTime())) throw new ApiError(`Invalid ${kind === "checkIn" ? "check-in" : "check-out"} date`, 400);
  return d;
}

/** Throws 409/400/404 when the given room/type is not bookable for the window. */
export async function assertNoOverlap(opts: {
  roomTypeId: string;
  roomId?: string | null;
  checkIn: Date;
  checkOut: Date;
  excludeId?: string;
}) {
  const { roomTypeId, roomId, checkIn, checkOut, excludeId } = opts;

  if (roomId) {
    const room = await db.room.findUnique({ where: { id: roomId } });
    if (!room) throw new ApiError("Room not found", 404);
    if (room.roomTypeId !== roomTypeId) throw new ApiError("Room does not belong to the selected room type", 400);
    if (room.status === "MAINTENANCE") throw new ApiError("Room is under maintenance", 409);
    const clash = await db.reservation.findFirst({
      where: overlappingReservationsFilter({ roomId, checkIn, checkOut, excludeId }),
    });
    if (clash) throw new ApiError(`Room ${room.number} is already booked for the selected dates`, 409);
    return;
  }

  const rooms = await db.room.findMany({ where: { roomTypeId } });
  for (const room of rooms) {
    if (room.status === "MAINTENANCE") continue;
    const clash = await db.reservation.findFirst({
      where: overlappingReservationsFilter({ roomId: room.id, checkIn, checkOut, excludeId }),
    });
    if (!clash) return; // at least one room of this type is free
  }
  throw new ApiError("No rooms of this type available for the selected dates", 409);
}

/** Dual-module access check helper (single `module` option is not enough for some routes). */
export function canAccessAny(role: string, modules: ModuleId[]): boolean {
  return modules.some((m) => canAccess(role, m));
}
