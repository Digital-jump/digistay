export type Role = "ADMIN" | "RECEPTIONIST" | "ACCOUNTANT" | "STAFF";

// Sidebar module ids (must match frontend navigation registry)
export type ModuleId =
  | "dashboard"
  | "ai-hub"
  | "room-view"
  | "stay-view"
  | "reservations"
  | "checkins"
  | "guests"
  | "food-orders"
  | "food-menu"
  | "ledger"
  | "invoices"
  | "folio-company"
  | "folio-ota"
  | "reports-standard"
  | "reports-custom"
  | "reports-bi"
  | "channel-manager"
  | "booking-engine"
  | "chats"
  | "reviews"
  | "guides"
  | "settings";

export const ROLE_MODULES: Record<Role, ModuleId[]> = {
  ADMIN: [
    "dashboard", "ai-hub", "room-view", "stay-view", "reservations", "checkins", "guests",
    "food-orders", "food-menu", "ledger", "invoices", "folio-company", "folio-ota",
    "reports-standard", "reports-custom", "reports-bi", "channel-manager",
    "booking-engine", "chats", "reviews", "guides", "settings",
  ],
  RECEPTIONIST: [
    "dashboard", "room-view", "stay-view", "reservations", "checkins", "guests",
    "food-orders", "food-menu", "invoices", "folio-company", "folio-ota",
    "reports-standard", "channel-manager", "booking-engine", "chats", "reviews", "guides",
  ],
  ACCOUNTANT: [
    "dashboard", "ledger", "invoices", "folio-company", "folio-ota",
    "reports-standard", "reports-custom", "reports-bi", "guides",
  ],
  STAFF: ["dashboard", "room-view", "stay-view", "food-orders", "guides"],
};

export const ROLE_LABELS: Record<Role, string> = {
  ADMIN: "Administrator",
  RECEPTIONIST: "Receptionist",
  ACCOUNTANT: "Accountant",
  STAFF: "Staff",
};

export function canAccess(role: string, moduleId: ModuleId): boolean {
  const mods = ROLE_MODULES[role as Role];
  return !!mods?.includes(moduleId);
}
