import { db } from "./db";
import { ApiError, money } from "./api-helpers";

/**
 * Shared billing core:
 *  - Invoice generation from a reservation folio / restaurant order
 *  - Payment application to invoices + folio payment entries
 *  - Folio balance helpers
 * Used by both reservations (check-in payments) and finance endpoints.
 */

export async function getSettings() {
  const s = await db.hotelSetting.findUnique({ where: { id: "main" } });
  return (
    s ?? {
      id: "main", name: "DigiStay Grand Hotel", tagline: "", address: "", phone: "",
      email: "", gstin: "", currency: "INR", taxRate: 12, fbTaxRate: 5,
      checkInTime: "14:00", checkOutTime: "11:00", otaCommission: 15,
      bookingEngineEnabled: true, paymentMode: "UNPAID", themeColor: "#D97706",
      updatedAt: new Date(),
    }
  );
}

export async function nextCodeFor(prefix: string, model: { findMany: (...args: never[]) => unknown }) {
  const field = prefix === "INV" ? "number" : "code";
  const yearPrefix = `${prefix}-${new Date().getFullYear()}-`;
  const rows = (await model.findMany({
    where: { [field]: { startsWith: yearPrefix } },
    select: { [field]: true },
  } as never)) as Array<Record<string, unknown>>;
  let max = 0;
  for (const r of rows) {
    const n = parseInt(String(r[field] ?? "").slice(yearPrefix.length), 10);
    if (!isNaN(n) && n > max) max = n;
  }
  return `${yearPrefix}${String(max + 1).padStart(4, "0")}`;
}

/** Sum of folio entries. CHARGE positive, PAYMENT negative, ADJUSTMENT either. */
export function folioBalanceOf(entries: { type: string; amount: number }[]): number {
  return money(entries.reduce((sum, e) => sum + e.amount, 0));
}

/**
 * Create an invoice from the folio attached to a reservation (if any) — grouping
 * charges by category and applying GST (room rate on rooms, fb rate on food).
 * Returns the existing non-void invoice if one already exists.
 */
export async function ensureInvoiceForReservation(reservationId: string) {
  const reservation = await db.reservation.findUnique({
    where: { id: reservationId },
    include: { guest: true, roomType: true, room: true, invoices: true },
  });
  if (!reservation) throw new ApiError("Reservation not found", 404);

  const existing = reservation.invoices.find((i) => i.status !== "VOID");
  if (existing) return existing;

  const folio = await db.folio.findFirst({
    where: { reservationId },
    include: { entries: true },
  });

  const settings = await getSettings();
  const charges = (folio?.entries ?? []).filter((e) => e.type === "CHARGE" || e.type === "ADJUSTMENT");
  const roomCharges = money(charges.filter((e) => e.category === "ROOM").reduce((s, e) => s + e.amount, 0));
  const foodCharges = money(charges.filter((e) => e.category === "FOOD").reduce((s, e) => s + e.amount, 0));
  const otherCharges = money(
    charges.filter((e) => e.category !== "ROOM" && e.category !== "FOOD").reduce((s, e) => s + e.amount, 0)
  );
  const subtotal = money(roomCharges + foodCharges + otherCharges);
  const roomTax = money((roomCharges * (settings.taxRate ?? 12)) / 100);
  const fbTax = money((foodCharges * (settings.fbTaxRate ?? 5)) / 100);
  const tax = money(roomTax + fbTax);
  const total = money(subtotal + tax);

  // Fallback: folio missing/empty → bill the room stay itself
  const nights = Math.max(1, Math.round((new Date(reservation.checkOut).getTime() - new Date(reservation.checkIn).getTime()) / 86400000));
  const fallbackRoom = subtotal === 0 ? money(reservation.rate * nights) : 0;
  const finalSubtotal = money(subtotal + fallbackRoom);
  const finalRoomTax = money(((roomCharges + fallbackRoom) * (settings.taxRate ?? 12)) / 100);
  const finalTax = money(finalRoomTax + fbTax);
  const finalTotal = money(finalSubtotal + finalTax);

  const number = await nextCodeFor("INV", db.invoice);
  const invoice = await db.invoice.create({
    data: {
      number,
      billingType: reservation.source === "COMPANY" ? "COMPANY" : reservation.source.startsWith("OTA") ? "OTA" : "INDIVIDUAL",
      guestId: reservation.guestId,
      reservationId: reservation.id,
      folioId: folio?.id,
      subtotal: finalSubtotal,
      tax: finalTax,
      discount: 0,
      total: finalTotal,
      status: "UNPAID",
    },
  });

  const items: { invoiceId: string; description: string; type: string; quantity: number; unitPrice: number; amount: number }[] = [];
  if (fallbackRoom > 0) {
    items.push({
      invoiceId: invoice.id,
      description: `${reservation.roomType.name}${reservation.room ? ` — Room ${reservation.room.number}` : ""} × ${nights} night(s)`,
      type: "ROOM", quantity: nights, unitPrice: reservation.rate, amount: fallbackRoom,
    });
  } else {
    for (const e of charges) {
      if (e.amount === 0) continue;
      items.push({
        invoiceId: invoice.id,
        description: e.description,
        type: e.category === "ROOM" ? "ROOM" : e.category === "FOOD" ? "FOOD" : "SERVICE",
        quantity: 1, unitPrice: money(e.amount), amount: money(e.amount),
      });
    }
  }
  if (finalTax > 0) {
    const parts: string[] = [];
    if (roomCharges + fallbackRoom > 0) parts.push(`GST ${(settings.taxRate ?? 12)}% on rooms`);
    if (foodCharges > 0) parts.push(`GST ${(settings.fbTaxRate ?? 5)}% on F&B`);
    items.push({ invoiceId: invoice.id, description: parts.join(" + ") || "GST", type: "TAX", quantity: 1, unitPrice: finalTax, amount: finalTax });
  }
  await db.invoiceItem.createMany({ data: items });

  return db.invoice.findUnique({
    where: { id: invoice.id },
    include: { items: true, payments: true, guest: true, reservation: { include: { roomType: true, room: true } } },
  });
}

/** Create an invoice for a restaurant order. */
export async function ensureInvoiceForOrder(orderId: string) {
  const order = await db.restaurantOrder.findUnique({
    where: { id: orderId },
    include: { items: { include: { menuItem: true } }, guest: true, reservation: true },
  });
  if (!order) throw new ApiError("Order not found", 404);
  const existing = await db.invoice.findFirst({ where: { orderId: order.orderNumber, status: { not: "VOID" } } });
  if (existing) return existing;

  const number = await nextCodeFor("INV", db.invoice);
  const invoice = await db.invoice.create({
    data: {
      number,
      billingType: "INDIVIDUAL",
      guestId: order.guestId,
      reservationId: order.reservationId,
      orderId: order.orderNumber,
      subtotal: order.subtotal,
      tax: order.tax,
      discount: 0,
      total: order.totalAmount,
      status: "UNPAID",
    },
  });
  await db.invoiceItem.createMany({
    data: [
      ...order.items.map((it) => ({
        invoiceId: invoice.id,
        description: `${it.menuItem.name} × ${it.quantity}`,
        type: "FOOD",
        quantity: it.quantity,
        unitPrice: it.unitPrice,
        amount: money(it.unitPrice * it.quantity),
      })),
      ...(order.tax > 0
        ? [{ invoiceId: invoice.id, description: "GST 5% on F&B", type: "TAX", quantity: 1, unitPrice: order.tax, amount: order.tax }]
        : []),
    ],
  });
  return db.invoice.findUnique({
    where: { id: invoice.id },
    include: { items: true, payments: true, guest: true },
  });
}

/**
 * Record a payment against an invoice: updates paidAmount + status,
 * appends a folio PAYMENT entry when the invoice belongs to a folio,
 * and updates the linked reservation's paidAmount.
 */
export async function recordInvoicePayment(
  invoiceId: string,
  input: { amount: number; method: string; reference?: string; remarks?: string; receivedBy?: string }
) {
  const invoice = await db.invoice.findUnique({ where: { id: invoiceId }, include: { reservation: true } });
  if (!invoice) throw new ApiError("Invoice not found", 404);
  if (invoice.status === "VOID") throw new ApiError("Cannot pay a void invoice");
  const amount = money(input.amount);
  if (!(amount > 0)) throw new ApiError("Payment amount must be greater than zero");
  const balance = money(invoice.total - invoice.paidAmount);
  if (amount - balance > 0.005) throw new ApiError(`Amount exceeds outstanding balance (₹${balance.toFixed(2)})`);

  const payment = await db.payment.create({
    data: {
      invoiceId: invoice.id,
      folioId: invoice.folioId,
      direction: "IN",
      amount,
      method: input.method,
      category: invoice.orderId ? "FOOD" : "ROOM",
      reference: input.reference,
      remarks: input.remarks,
      receivedBy: input.receivedBy,
    },
  });

  const paidAmount = money(invoice.paidAmount + amount);
  await db.invoice.update({
    where: { id: invoice.id },
    data: { paidAmount, status: paidAmount >= invoice.total - 0.005 ? "PAID" : "PARTIAL" },
  });

  if (invoice.reservationId) {
    const reservation = invoice.reservation;
    if (reservation) {
      await db.reservation.update({
        where: { id: reservation.id },
        data: { paidAmount: money(reservation.paidAmount + amount) },
      });
    }
  }

  if (invoice.folioId) {
    await db.folioEntry.create({
      data: {
        folioId: invoice.folioId,
        type: "PAYMENT",
        description: `Payment via ${input.method}${input.reference ? ` (${input.reference})` : ""}`,
        amount: -amount,
        category: "OTHER",
        createdBy: input.receivedBy,
      },
    });
    const folio = await db.folio.findUnique({ where: { id: invoice.folioId }, include: { entries: true } });
    if (folio && folioBalanceOf(folio.entries) <= 0.005 && folio.status === "OPEN") {
      await db.folio.update({ where: { id: folio.id }, data: { status: "SETTLED" } });
    }
  }

  return payment;
}
