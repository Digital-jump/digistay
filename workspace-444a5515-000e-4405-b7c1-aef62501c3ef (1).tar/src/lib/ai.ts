import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";
import { ACTIVE_RESERVATION_STATUSES, addDays, money, startOfDay } from "@/lib/api-helpers";

// ─── ZAI singleton factory ────────────────────────────────────────────────
// One shared client for the whole app. The promise is cached on globalThis so
// hot reloads / route modules reuse it; a failed create() is retried next call.

type ZAIClient = Awaited<ReturnType<typeof ZAI.create>>;

const globalForAI = globalThis as unknown as {
  __digistayZAI?: Promise<ZAIClient> | undefined;
};

export function getZAI(): Promise<ZAIClient> {
  if (!globalForAI.__digistayZAI) {
    globalForAI.__digistayZAI = ZAI.create().catch((e: unknown) => {
      globalForAI.__digistayZAI = undefined; // allow a fresh attempt next time
      throw e;
    });
  }
  return globalForAI.__digistayZAI;
}

// ─── LLM call helper ──────────────────────────────────────────────────────

export type LLMMessage = { role: "system" | "user" | "assistant"; content: string };

/** Calls the LLM with the shared client; retries once on error/empty. Returns null on failure. */
export async function callLLM(messages: LLMMessage[]): Promise<string | null> {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const zai = await getZAI();
      const completion = await zai.chat.completions.create({
        messages,
        thinking: { type: "disabled" },
      });
      const text = completion.choices[0]?.message?.content;
      if (text && text.trim()) return text;
      console.error(`[ai] LLM returned empty content (attempt ${attempt + 1})`);
    } catch (e) {
      console.error("[ai] LLM call failed:", e);
    }
  }
  return null;
}

// ─── JSON extraction ──────────────────────────────────────────────────────

/**
 * Robustly extracts the first JSON value from LLM output.
 * Strips ```json fences, tries a direct parse, then brace-matches the first
 * {...} or [...] block. Returns null when nothing parseable is found.
 */
export function extractJson<T = unknown>(text: string | null | undefined): T | null {
  if (!text) return null;
  let s = text.trim();
  if (!s) return null;
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence && fence[1].trim()) s = fence[1].trim();
  try {
    return JSON.parse(s) as T;
  } catch {
    /* fall through to brace matching */
  }
  const start = s.search(/[{[]/);
  if (start === -1) return null;
  const open = s[start];
  const close = open === "{" ? "}" : "]";
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < s.length; i++) {
    const ch = s[i];
    if (inStr) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') inStr = true;
    else if (ch === open) depth += 1;
    else if (ch === close) {
      depth -= 1;
      if (depth === 0) {
        try {
          return JSON.parse(s.slice(start, i + 1)) as T;
        } catch {
          return null;
        }
      }
    }
  }
  return null;
}

// ─── Small shared utilities ───────────────────────────────────────────────

export function ymd(d: Date | string): string {
  const x = new Date(d);
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}-${String(x.getDate()).padStart(2, "0")}`;
}

export function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

/** 0..1 fraction → 0..100 percentage rounded to 1 decimal. */
export function pct(n: number): number {
  return round1(n * 100);
}

export function inr(n: number): string {
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}

const STAY_STATUSES = ["PENDING", "CONFIRMED", "CHECKED_IN", "CHECKED_OUT"];

/** Nights a stay [checkIn, checkOut) overlaps the window [ws, we) — day-granular. */
function overlapNights(checkIn: Date, checkOut: Date, ws: number, we: number): number {
  const start = Math.max(startOfDay(checkIn).getTime(), ws);
  const end = Math.min(startOfDay(checkOut).getTime(), we);
  return Math.max(0, Math.round((end - start) / 86400000));
}

// ─── Shared hotel context builders (used by multiple AI routes) ───────────

export type HotelSnapshot = {
  date: string;
  totalRooms: number;
  occupiedRooms: number;
  outOfServiceRooms: number;
  occupancyPct: number;
  arrivalsToday: number;
  departuresToday: number;
  outstandingTotal: number;
  pendingFoodOrders: number;
};

/** Today's ops snapshot — occupancy, arrivals/departures, outstanding, pending orders. */
export async function getHotelSnapshot(): Promise<HotelSnapshot> {
  const dayStart = startOfDay(new Date());
  const dayEnd = dayStart.getTime() + 86400000; // exclusive
  const [totalRooms, occupiedRooms, outOfServiceRooms, arrivalsToday, departuresToday, inv, pendingFoodOrders] =
    await Promise.all([
      db.room.count(),
      db.room.count({ where: { status: "OCCUPIED" } }),
      db.room.count({ where: { status: "MAINTENANCE" } }),
      db.reservation.count({
        where: {
          checkIn: { gte: dayStart, lt: new Date(dayEnd) },
          status: { in: ACTIVE_RESERVATION_STATUSES },
        },
      }),
      db.reservation.count({
        where: {
          checkOut: { gte: dayStart, lt: new Date(dayEnd) },
          status: { in: ["CHECKED_IN", "CHECKED_OUT"] },
        },
      }),
      db.invoice.aggregate({ where: { status: { not: "VOID" } }, _sum: { total: true, paidAmount: true } }),
      db.restaurantOrder.count({ where: { status: "PENDING" } }),
    ]);
  return {
    date: ymd(dayStart),
    totalRooms,
    occupiedRooms,
    outOfServiceRooms,
    occupancyPct: totalRooms ? pct(occupiedRooms / totalRooms) : 0,
    arrivalsToday,
    departuresToday,
    outstandingTotal: money((inv._sum.total ?? 0) - (inv._sum.paidAmount ?? 0)),
    pendingFoodOrders,
  };
}

export type TrendPoint = { date: string; occupancyPct: number };

/** Daily occupancy % for the last `daysBack` nights (room-level, reports/occupancy pattern). */
export async function getOccupancyTrend(daysBack = 14): Promise<TrendPoint[]> {
  const windowStart = startOfDay(addDays(new Date(), -(daysBack - 1)));
  const windowEnd = startOfDay(addDays(new Date(), 1)); // exclusive
  const [stays, totalRooms] = await Promise.all([
    db.reservation.findMany({
      where: { status: { in: STAY_STATUSES }, checkIn: { lt: windowEnd }, checkOut: { gt: windowStart } },
      select: { checkIn: true, checkOut: true, roomId: true },
    }),
    db.room.count(),
  ]);
  const out: TrendPoint[] = [];
  for (let i = 0; i < daysBack; i++) {
    const day = startOfDay(addDays(windowStart, i)).getTime();
    const seen = new Set<string>();
    for (const s of stays) {
      if (s.roomId && startOfDay(s.checkIn).getTime() <= day && startOfDay(s.checkOut).getTime() > day) {
        seen.add(s.roomId);
      }
    }
    out.push({ date: ymd(new Date(day)), occupancyPct: totalRooms ? pct(seen.size / totalRooms) : 0 });
  }
  return out;
}

export type RevenueSummary = {
  days: number;
  roomRevenue: number;
  fbRevenue: number;
  otherRevenue: number;
  paymentsReceived: number;
};

/** Room / F&B revenue (issued invoices) + payments received over the last `days` days. */
export async function getRevenueSummary(days = 30): Promise<RevenueSummary> {
  const since = startOfDay(addDays(new Date(), -(days - 1)));
  const [invoices, payments] = await Promise.all([
    db.invoice.findMany({
      where: { status: { not: "VOID" }, issuedAt: { gte: since } },
      select: { items: { select: { type: true, amount: true } } },
    }),
    db.payment.findMany({ where: { direction: "IN", paidAt: { gte: since } }, select: { amount: true } }),
  ]);
  let room = 0;
  let fb = 0;
  let other = 0;
  for (const inv of invoices) {
    for (const it of inv.items) {
      if (it.type === "ROOM") room += it.amount;
      else if (it.type === "FOOD") fb += it.amount;
      else other += it.amount;
    }
  }
  return {
    days,
    roomRevenue: money(room),
    fbRevenue: money(fb),
    otherRevenue: money(other),
    paymentsReceived: money(payments.reduce((s, p) => s + p.amount, 0)),
  };
}

export type TypeAvailability = {
  roomTypeId: string;
  name: string;
  total: number;
  available: number;
  booked: number;
  capacity: number;
  baseRate: number;
};

/** Per room type availability for a window (website/availability pattern, incl. type-level state). */
export async function getRoomTypeAvailability(checkIn: Date, checkOut: Date): Promise<TypeAvailability[]> {
  const [overlapping, rooms, roomTypes] = await Promise.all([
    db.reservation.findMany({
      where: {
        status: { in: ACTIVE_RESERVATION_STATUSES },
        checkIn: { lt: checkOut },
        checkOut: { gt: checkIn },
      },
      select: { roomId: true },
    }),
    db.room.findMany({ select: { id: true, status: true, roomTypeId: true } }),
    db.roomType.findMany({ orderBy: { baseRate: "asc" } }),
  ]);
  const blocked = new Set(overlapping.map((r) => r.roomId).filter((id): id is string => !!id));
  return roomTypes.map((rt) => {
    const typeRooms = rooms.filter((r) => r.roomTypeId === rt.id);
    const available = typeRooms.filter(
      (r) => r.status !== "MAINTENANCE" && r.status !== "RESERVED" && !blocked.has(r.id)
    ).length;
    return {
      roomTypeId: rt.id,
      name: rt.name,
      total: typeRooms.length,
      available,
      booked: typeRooms.length - available,
      capacity: rt.capacity,
      baseRate: money(rt.baseRate),
    };
  });
}

export type StayRevenueStats = {
  roomNightsSold: number;
  roomRevenue: number;
  availableRoomNights: number;
};

/** Pro-rated room-charge revenue + room-nights sold for stays overlapping the window (ADR/RevPAR). */
export async function getStayRevenueStats(
  windowStart: Date,
  windowEnd: Date,
  totalRooms: number
): Promise<StayRevenueStats> {
  const stays = await db.reservation.findMany({
    where: { status: { in: STAY_STATUSES }, checkIn: { lt: windowEnd }, checkOut: { gt: windowStart } },
    select: { checkIn: true, checkOut: true, rate: true },
  });
  const ws = startOfDay(windowStart).getTime();
  const we = startOfDay(windowEnd).getTime();
  let nights = 0;
  let revenue = 0;
  for (const s of stays) {
    const n = overlapNights(s.checkIn, s.checkOut, ws, we);
    nights += n;
    revenue += n * s.rate;
  }
  const windowDays = Math.max(1, Math.round((we - ws) / 86400000));
  return {
    roomNightsSold: nights,
    roomRevenue: money(revenue),
    availableRoomNights: totalRooms * windowDays,
  };
}

/** How many rooms of a type are committed (active reservations) per night of a window. */
export async function getCommittedByType(
  windowStart: Date,
  windowEnd: Date
): Promise<{ byType: Map<string, number[]>; days: Date[]; roomTypeByRoomId: Map<string, string> }> {
  const [rooms, upcoming] = await Promise.all([
    db.room.findMany({ select: { id: true, roomTypeId: true } }),
    db.reservation.findMany({
      where: {
        status: { in: ACTIVE_RESERVATION_STATUSES },
        checkIn: { lt: windowEnd },
        checkOut: { gt: windowStart },
      },
      select: { roomTypeId: true, roomId: true, checkIn: true, checkOut: true },
    }),
  ]);
  const days: Date[] = [];
  for (let d = startOfDay(windowStart); d.getTime() < startOfDay(windowEnd).getTime(); d = addDays(d, 1)) {
    days.push(startOfDay(d));
  }
  const roomTypeByRoomId = new Map(rooms.map((r) => [r.id, r.roomTypeId]));
  const byType = new Map<string, number[]>();
  for (let di = 0; di < days.length; di++) {
    const dayMs = days[di].getTime();
    for (const u of upcoming) {
      if (startOfDay(u.checkIn).getTime() > dayMs || startOfDay(u.checkOut).getTime() <= dayMs) continue;
      const typeId = u.roomId ? roomTypeByRoomId.get(u.roomId) : u.roomTypeId;
      if (!typeId) continue;
      let arr = byType.get(typeId);
      if (!arr) {
        arr = new Array<number>(days.length).fill(0);
        byType.set(typeId, arr);
      }
      arr[di] += 1;
    }
  }
  return { byType, days, roomTypeByRoomId };
}
