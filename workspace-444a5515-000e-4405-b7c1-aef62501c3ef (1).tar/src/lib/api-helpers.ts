import { NextResponse } from "next/server";
import { db } from "./db";
import { extractToken, getSessionUser, type AuthUser } from "./auth";
import { canAccess, type ModuleId } from "./permissions";

export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export function ok<T>(data: T, status = 200) {
  return NextResponse.json(data, { status });
}

export function fail(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

type Handler = (req: Request, ctx: { user: AuthUser; params: Record<string, string> }) => Promise<Response>;

/**
 * Wraps an API route handler with authentication + role-based permission.
 * `module` gates access by sidebar module id; omit for any authenticated user.
 */
export function withAuth(handler: Handler, opts?: { module?: ModuleId; roles?: string[] }) {
  return async (req: Request, routeCtx?: { params?: Promise<Record<string, string>> }) => {
    try {
      const user = await getSessionUser(extractToken(req));
      if (!user) return fail("Unauthorized. Please sign in.", 401);
      if (opts?.roles && !opts.roles.includes(user.role)) {
        return fail("Forbidden: insufficient role", 403);
      }
      if (opts?.module && !canAccess(user.role, opts.module)) {
        return fail("Forbidden: module not allowed for your role", 403);
      }
      const params = (await routeCtx?.params) ?? {};
      return await handler(req, { user, params });
    } catch (e: unknown) {
      if (e instanceof ApiError) return fail(e.message, e.status);
      const message = e instanceof Error ? e.message : "Internal server error";
      console.error("[API]", message, e);
      return fail(message, 500);
    }
  };
}

export async function audit(
  user: AuthUser | null,
  action: string,
  entity: string,
  entityId?: string,
  details?: string
) {
  await db.auditLog.create({
    data: {
      userId: user?.id,
      userName: user?.name,
      action,
      entity,
      entityId,
      details,
    },
  }).catch(() => {});
}

/** Generate sequential codes like RSV-2025-0007 based on max existing code (robust to deletions). */
type AnyDelegate = { findMany: (...args: never[]) => unknown };
export async function nextCode(prefix: string, model: AnyDelegate, field = "code") {
  const yearPrefix = `${prefix}-${new Date().getFullYear()}-`;
  const rows = (await model.findMany({
    where: { [field]: { startsWith: yearPrefix } },
    select: { [field]: true },
  } as never)) as Array<Record<string, unknown>>;
  let max = 0;
  for (const r of rows) {
    const n = parseInt(String(r[field] ?? "").slice(yearPrefix.length), 10);
    if (!isNaN(n) && n > max) max = n;
  }
  return `${yearPrefix}${String(max + 1).padStart(4, "0")}`;
}

// ─── Date helpers (local-time safe) ───────────────────────────

export function startOfDay(d: Date | string): Date {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export function endOfDay(d: Date | string): Date {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
}

export function addDays(d: Date | string, days: number): Date {
  const x = new Date(d);
  x.setDate(x.getDate() + days);
  return x;
}

export function nightsBetween(checkIn: Date | string, checkOut: Date | string): number {
  const a = startOfDay(checkIn).getTime();
  const b = startOfDay(checkOut).getTime();
  return Math.max(0, Math.round((b - a) / 86400000));
}

export function money(n: number): number {
  return Math.round(n * 100) / 100;
}

/**
 * Finds ACTIVE (double-booking-relevant) reservations overlapping [checkIn, checkOut)
 * for a room. Statuses that block: PENDING, CONFIRMED, CHECKED_IN.
 */
export function overlappingReservationsFilter(opts: {
  roomId?: string | null;
  roomTypeId?: string;
  checkIn: Date;
  checkOut: Date;
  excludeId?: string;
}) {
  const { roomId, roomTypeId, checkIn, checkOut, excludeId } = opts;
  return {
    status: { in: ["PENDING", "CONFIRMED", "CHECKED_IN"] },
    id: excludeId ? { not: excludeId } : undefined,
    checkIn: { lt: checkOut },
    checkOut: { gt: checkIn },
    ...(roomId ? { roomId } : {}),
    ...(roomTypeId ? { roomTypeId } : {}),
  };
}

export const ACTIVE_RESERVATION_STATUSES = ["PENDING", "CONFIRMED", "CHECKED_IN"];

export function parseBody<T>(req: Request): Promise<T> {
  return req.json() as Promise<T>;
}
