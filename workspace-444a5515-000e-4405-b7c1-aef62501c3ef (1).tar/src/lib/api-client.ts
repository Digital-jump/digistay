"use client";

import { useAppStore } from "@/store/app-store";

export class ApiClientError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const token = useAppStore.getState().token;
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(init?.headers as Record<string, string> | undefined),
  };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(url, { ...init, headers });
  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }
  if (!res.ok) {
    const message = (body as { error?: string } | null)?.error ?? `Request failed (${res.status})`;
    if (res.status === 401) {
      useAppStore.getState().logout();
    }
    throw new ApiClientError(message, res.status);
  }
  return body as T;
}

export const apiGet = <T,>(url: string) => request<T>(url);
export const apiPost = <T,>(url: string, data?: unknown) =>
  request<T>(url, { method: "POST", body: JSON.stringify(data ?? {}) });
export const apiPut = <T,>(url: string, data?: unknown) =>
  request<T>(url, { method: "PUT", body: JSON.stringify(data ?? {}) });
export const apiDelete = <T,>(url: string) => request<T>(url, { method: "DELETE" });

export function qs(params: Record<string, string | number | undefined | null>): string {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== "") sp.set(k, String(v));
  }
  const s = sp.toString();
  return s ? `?${s}` : "";
}
