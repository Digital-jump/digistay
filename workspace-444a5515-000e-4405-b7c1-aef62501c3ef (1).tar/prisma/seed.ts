/**
 * Seed script — DigiStay Hotel Management System demo data.
 * Run: bun prisma/seed.ts
 * Wipes all tables and inserts a realistic, self-consistent demo dataset.
 * All demo data uses dates relative to "today" so dashboards always look alive.
 */
import { PrismaClient } from "@prisma/client";
import { randomBytes, scryptSync } from "crypto";

const prisma = new PrismaClient();

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

const NOW = new Date();
function d(daysOffset: number, h = 12, m = 0): Date {
  const x = new Date(NOW);
  x.setDate(x.getDate() + daysOffset);
  x.setHours(h, m, 0, 0);
  return x;
}
function checkInDate(daysOffset: number) { return d(daysOffset, 14, 0); }
function checkOutDate(daysOffset: number) { return d(daysOffset, 11, 0); }
const year = NOW.getFullYear();

let rsvSeq = 0, invSeq = 0, ordSeq = 0, folSeq = 0;
const rsvCode = () => `RSV-${year}-${String(++rsvSeq).padStart(4, "0")}`;
const invCode = () => `INV-${year}-${String(++invSeq).padStart(4, "0")}`;
const ordCode = () => `ORD-${year}-${String(++ordSeq).padStart(4, "0")}`;
const folCode = () => `FOL-${year}-${String(++folSeq).padStart(4, "0")}`;

async function main() {
  console.log("Seeding DigiStay demo data...");

  // Wipe in FK-safe order
  await prisma.auditLog.deleteMany();
  await prisma.supportMessage.deleteMany();
  await prisma.review.deleteMany();
  await prisma.payment.deleteMany();
  await prisma.invoiceItem.deleteMany();
  await prisma.invoice.deleteMany();
  await prisma.folioEntry.deleteMany();
  await prisma.folio.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.restaurantOrder.deleteMany();
  await prisma.menuItem.deleteMany();
  await prisma.reservation.deleteMany();
  await prisma.room.deleteMany();
  await prisma.roomType.deleteMany();
  await prisma.company.deleteMany();
  await prisma.guest.deleteMany();
  await prisma.ledgerEntry.deleteMany();
  await prisma.session.deleteMany();
  await prisma.user.deleteMany();
  await prisma.hotelSetting.deleteMany();

  // ── Users ──────────────────────────────────────────────
  await prisma.user.createMany({
    data: [
      { name: "Aarav Mehta", email: "admin@digistay.com", passwordHash: hashPassword("admin123"), role: "ADMIN", phone: "+91 98200 11001" },
      { name: "Priya Sharma", email: "reception@digistay.com", passwordHash: hashPassword("reception123"), role: "RECEPTIONIST", phone: "+91 98200 11002" },
      { name: "Rahul Verma", email: "accounts@digistay.com", passwordHash: hashPassword("accounts123"), role: "ACCOUNTANT", phone: "+91 98200 11003" },
      { name: "Sunita Rao", email: "staff@digistay.com", passwordHash: hashPassword("staff123"), role: "STAFF", phone: "+91 98200 11004" },
      { name: "Aisha Kapoor", email: "guest@digistay.com", passwordHash: hashPassword("guest123"), role: "GUEST", phone: "+91 98200 11005" },
    ],
  });

  // ── Settings ───────────────────────────────────────────
  await prisma.hotelSetting.create({
    data: {
      id: "main",
      name: "DigiStay Grand Hotel",
      tagline: "A premium stay experience by the sea",
      address: "12 Marine Drive, Mumbai, Maharashtra 400020",
      phone: "+91 98200 12345",
      email: "frontdesk@digistay.example",
      gstin: "27AABCD1234E1ZV",
      taxRate: 12, fbTaxRate: 5, otaCommission: 15,
    },
  });

  // ── Room types & rooms ─────────────────────────────────
  const std = await prisma.roomType.create({ data: { name: "Standard Room", description: "Cozy room with garden view, perfect for short stays.", baseRate: 3500, capacity: 2, extraAdultCharge: 800, amenities: JSON.stringify(["Wi-Fi", "AC", "TV", "Garden View"]) } });
  const dlx = await prisma.roomType.create({ data: { name: "Deluxe Room", description: "Spacious room with city balcony and premium linen.", baseRate: 5500, capacity: 2, extraAdultCharge: 1200, amenities: JSON.stringify(["Wi-Fi", "AC", "TV", "Balcony", "Mini Fridge", "Bathtub"]) } });
  const exec = await prisma.roomType.create({ data: { name: "Executive Suite", description: "Separate living area, work desk and sea view.", baseRate: 8500, capacity: 3, extraAdultCharge: 1500, amenities: JSON.stringify(["Wi-Fi", "AC", "Sea View", "Living Room", "Work Desk", "Mini Bar"]) } });
  const fam = await prisma.roomType.create({ data: { name: "Family Room", description: "Two queen beds, ideal for a family of four.", baseRate: 7500, capacity: 4, extraAdultCharge: 1000, amenities: JSON.stringify(["Wi-Fi", "AC", "2 Queen Beds", "TV", "Bathtub"]) } });
  const pres = await prisma.roomType.create({ data: { name: "Presidential Suite", description: "Top-floor luxury suite with private terrace and butler service.", baseRate: 18000, capacity: 4, extraAdultCharge: 2500, amenities: JSON.stringify(["Wi-Fi", "Private Terrace", "Butler", "Jacuzzi", "Mini Bar", "Sea View"]) } });

  const roomDefs: { number: string; floor: number; typeId: string }[] = [];
  for (let i = 1; i <= 6; i++) roomDefs.push({ number: `1${String(i).padStart(2, "0")}`, floor: 1, typeId: std.id });
  for (let i = 1; i <= 6; i++) roomDefs.push({ number: `2${String(i).padStart(2, "0")}`, floor: 2, typeId: dlx.id });
  for (let i = 1; i <= 4; i++) roomDefs.push({ number: `3${String(i).padStart(2, "0")}`, floor: 3, typeId: exec.id });
  for (let i = 1; i <= 4; i++) roomDefs.push({ number: `4${String(i).padStart(2, "0")}`, floor: 4, typeId: fam.id });
  for (let i = 1; i <= 4; i++) roomDefs.push({ number: `5${String(i).padStart(2, "0")}`, floor: 5, typeId: pres.id });

  const rooms = [] as { id: string; number: string; typeId: string }[];
  for (const r of roomDefs) {
    const room = await prisma.room.create({
      data: { number: r.number, floor: r.floor, roomTypeId: r.typeId, status: "AVAILABLE", housekeeping: "CLEAN" },
    });
    rooms.push({ id: room.id, number: room.number, typeId: r.typeId });
  }
  const roomsOfType = (typeId: string) => rooms.filter((r) => r.typeId === typeId);

  // ── Guests ─────────────────────────────────────────────
  const guestData = [
    ["Kabir", "Anand", "kabir.anand@example.com", "+91 98111 20001", "AADHAAR", "4321 8765 1122", "Indian", "21 Lodhi Road", "New Delhi", true],
    ["Meera", "Iyer", "meera.iyer@example.com", "+91 98111 20002", "PASSPORT", "Z7845129", "Indian", "42 Anna Salai", "Chennai", false],
    ["Daniel", "D'Souza", "daniel.d@example.com", "+91 98111 20003", "AADHAAR", "8812 3345 9911", "Indian", "7 Hill Road", "Mumbai", false],
    ["Ananya", "Gupta", "ananya.g@example.com", "+91 98111 20004", "PAN", "AKJPG4521L", "Indian", "901 Sector 45", "Gurugram", false],
    ["Rohan", "Deshpande", "rohan.d@example.com", "+91 98111 20005", "DRIVING_LICENSE", "MH1220190045678", "Indian", "12 FC Road", "Pune", false],
    ["Sofia", "Khan", "sofia.k@example.com", "+91 98111 20006", "AADHAAR", "2211 4455 8899", "Indian", "3 MG Road", "Bengaluru", true],
    ["Vikram", "Malhotra", "vikram.m@example.com", "+91 98111 20007", "PASSPORT", "N5561234", "Indian", "88 Civil Lines", "Jaipur", false],
    ["Emma", "Watson", "emma.watson@example.com", "+44 7700 900123", "PASSPORT", "GB9933441", "British", "14 Kensington Lane", "London", false],
    ["Arjun", "Nair", "arjun.nair@example.com", "+91 98111 20009", "AADHAAR", "7788 1234 5566", "Indian", "5 Marine Street", "Kochi", false],
    ["Ishita", "Bose", "ishita.b@example.com", "+91 98111 20010", "VOTER_ID", "WB/123/456789", "Indian", "27 Park Street", "Kolkata", false],
    ["Farhan", "Qureshi", "farhan.q@example.com", "+91 98111 20011", "AADHAAR", "9012 3456 7890", "Indian", "61 Charminar Road", "Hyderabad", false],
    ["Lakshmi", "Menon", "lakshmi.m@example.com", "+91 98111 20012", "PAN", "BLXPM7789K", "Indian", "9 Beach Road", "Trivandrum", false],
  ] as const;

  const guests: { id: string; name: string }[] = [];
  for (const g of guestData) {
    const row = await prisma.guest.create({
      data: {
        firstName: g[0], lastName: g[1], email: g[2], phone: g[3],
        idType: g[4], idNumber: g[5], nationality: g[6], address: g[7], city: g[8], vip: g[9],
      },
    });
    guests.push({ id: row.id, name: `${row.firstName} ${row.lastName}` });
  }

  // ── Companies ──────────────────────────────────────────
  const techCorp = await prisma.company.create({ data: { name: "TechNova Solutions Pvt Ltd", contactPerson: "Nikhil Jain", email: "travel@technova.example", phone: "+91 98111 30001", address: "Tech Park, Whitefield, Bengaluru", gstin: "29AAACT1234F1Z5", creditLimit: 200000 } });
  const globalTours = await prisma.company.create({ data: { name: "Wanderlust Tours & Travel", contactPerson: "Sara D'Cruz", email: "corporate@wanderlust.example", phone: "+91 98111 30002", address: "Fort Area, Mumbai", gstin: "27AAW CW5678K1Z9", creditLimit: 100000 } });

  // ── Menu ───────────────────────────────────────────────
  const menu = [
    ["Paneer Tikka", "STARTER", "Char-grilled cottage cheese with mint chutney", 320, true],
    ["Chicken 65", "STARTER", "Spicy South-Indian fried chicken", 380, false],
    ["Veg Spring Rolls", "STARTER", "Crispy rolls with sweet chilli dip", 260, true],
    ["Butter Chicken", "MAIN_COURSE", "Creamy tomato gravy, tandoori chicken", 460, false],
    ["Paneer Butter Masala", "MAIN_COURSE", "Rich makhani gravy with soft paneer", 390, true],
    ["Dal Makhani", "MAIN_COURSE", "Slow-cooked black lentils", 310, true],
    ["Mutton Rogan Josh", "MAIN_COURSE", "Kashmiri lamb curry", 540, false],
    ["Butter Naan", "BREADS_RICE", "Tandoor-baked buttered naan", 70, true],
    ["Hyderabadi Chicken Biryani", "BREADS_RICE", "Fragrant dum biryani with raita", 420, false],
    ["Jeera Rice", "BREADS_RICE", "Cumin-tempered basmati rice", 180, true],
    ["Gulab Jamun", "DESSERTS", "Warm milk dumplings in sugar syrup (2 pc)", 150, true],
    ["Chocolate Brownie Sundae", "DESSERTS", "Brownie, vanilla ice cream, hot fudge", 240, true],
    ["Masala Chai", "BEVERAGES", "Spiced Indian tea", 90, true],
    ["Fresh Lime Soda", "BEVERAGES", "Sweet or salted", 120, true],
    ["Cold Coffee", "BEVERAGES", "Blended coffee with ice cream", 220, true],
    ["Kingfisher pint", "BAR", "Chilled lager 330ml", 250, false],
    ["House Red Wine (Glass)", "BAR", "Sula Rasa Shiraz", 350, false],
    ["Old Fashioned", "BAR", "Bourbon, bitters, orange peel", 450, false],
  ] as const;
  const menuItems: { id: string; name: string; price: number }[] = [];
  for (const m of menu) {
    const row = await prisma.menuItem.create({
      data: { name: m[0], category: m[1], description: m[2], price: m[3], isVeg: m[4] },
    });
    menuItems.push({ id: row.id, name: row.name, price: row.price });
  }
  const mi = (name: string) => menuItems.find((m) => m.name === name)!;

  // ── Reservations ───────────────────────────────────────
  // PAST stays (checked out) with invoices + payments
  const pastDefs = [
    { g: 0, type: std, rate: 3500, nights: 3, from: -34, source: "DIRECT" },
    { g: 1, type: dlx, rate: 5500, nights: 2, from: -28, source: "OTA_BOOKING_COM" },
    { g: 6, type: exec, rate: 8500, nights: 4, from: -21, source: "COMPANY" },
    { g: 7, type: pres, rate: 18000, nights: 2, from: -16, source: "WEBSITE" },
    { g: 8, type: std, rate: 3500, nights: 1, from: -12, source: "WALK_IN" },
    { g: 9, type: fam, rate: 7500, nights: 3, from: -10, source: "OTA_MAKE_MY_TRIP" },
    { g: 2, type: dlx, rate: 5500, nights: 2, from: -7, source: "DIRECT" },
    { g: 10, type: std, rate: 3500, nights: 2, from: -4, source: "PHONE" },
  ];
  let roomIdx = 0;
  for (const p of pastDefs) {
    const roomList = roomsOfType(p.type.id);
    const room = roomList[roomIdx++ % roomList.length];
    const subtotal = p.rate * p.nights;
    const tax = Math.round(subtotal * 0.12);
    const total = subtotal + tax;
    const rsv = await prisma.reservation.create({
      data: {
        code: rsvCode(), guestId: guests[p.g].id, roomTypeId: p.type.id, roomId: room.id,
        checkIn: checkInDate(p.from - p.nights), checkOut: checkOutDate(p.from),
        adults: 2, children: 0, status: "CHECKED_OUT", source: p.source, rate: p.rate,
        totalAmount: total, paidAmount: total,
        actualCheckIn: checkInDate(p.from - p.nights), actualCheckOut: checkOutDate(p.from),
        createdAt: d(p.from - p.nights - 5),
      },
    });
    const inv = await prisma.invoice.create({
      data: {
        number: invCode(), billingType: p.source === "COMPANY" ? "COMPANY" : p.source.startsWith("OTA") ? "OTA" : "INDIVIDUAL",
        guestId: guests[p.g].id, reservationId: rsv.id,
        subtotal, tax, discount: 0, total, paidAmount: total, status: "PAID",
        issuedAt: checkOutDate(p.from),
      },
    });
    await prisma.invoiceItem.createMany({
      data: [
        { invoiceId: inv.id, description: `${p.type.name} × ${p.nights} night(s) — Room ${room.number}`, type: "ROOM", quantity: p.nights, unitPrice: p.rate, amount: subtotal },
        { invoiceId: inv.id, description: "GST 12%", type: "TAX", quantity: 1, unitPrice: tax, amount: tax },
      ],
    });
    const methods = ["CASH", "UPI", "CREDIT_CARD", "RAZORPAY", "BANK_TRANSFER"];
    await prisma.payment.create({
      data: { invoiceId: inv.id, amount: total, method: methods[p.g % methods.length], category: "ROOM", paidAt: checkOutDate(p.from), receivedBy: "Priya Sharma" },
    });
    await prisma.folio.create({
      data: {
        code: folCode(), type: "INDIVIDUAL", name: guests[p.g].name, guestId: guests[p.g].id,
        reservationId: rsv.id, status: "SETTLED",
        entries: {
          create: [
            { type: "CHARGE", description: `Room charges (${p.nights} nights)`, amount: subtotal, category: "ROOM" },
            { type: "CHARGE", description: "GST 12%", amount: tax, category: "TAX" },
            { type: "PAYMENT", description: "Settled at checkout", amount: -total, category: "OTHER" },
          ],
        },
      },
    });
  }

  // CURRENT in-house guests (checked in)
  const currentDefs = [
    { g: 3, type: dlx, rate: 5500, from: -1, to: 2, room: 0, source: "DIRECT" },
    { g: 4, type: exec, rate: 8500, from: -2, to: 1, room: 0, source: "OTA_AIRBNB" },
    { g: 11, type: std, rate: 3500, from: 0, to: 3, room: 0, source: "WALK_IN" },
    { g: 5, type: pres, rate: 18000, from: -1, to: 4, room: 0, source: "WEBSITE" },
  ];
  const inHouse: { rsvId: string; guestName: string; roomId: string; roomNumber: string }[] = [];
  for (const c of currentDefs) {
    const roomList = roomsOfType(c.type.id);
    const room = roomList[c.room % roomList.length];
    const nights = c.to - c.from;
    const subtotal = c.rate * nights;
    const total = subtotal + Math.round(subtotal * 0.12);
    const rsv = await prisma.reservation.create({
      data: {
        code: rsvCode(), guestId: guests[c.g].id, roomTypeId: c.type.id, roomId: room.id,
        checkIn: checkInDate(c.from), checkOut: checkOutDate(c.to),
        adults: 2, children: c.g === 5 ? 1 : 0, status: "CHECKED_IN", source: c.source, rate: c.rate,
        totalAmount: total, paidAmount: 0,
        actualCheckIn: checkInDate(c.from),
        createdAt: d(c.from - 3),
      },
    });
    await prisma.room.update({ where: { id: room.id }, data: { status: "OCCUPIED", housekeeping: "CLEAN" } });
    await prisma.folio.create({
      data: {
        code: folCode(), type: "INDIVIDUAL", name: guests[c.g].name, guestId: guests[c.g].id,
        reservationId: rsv.id, status: "OPEN",
        entries: { create: [{ type: "CHARGE", description: `Room charges (${nights} nights × ₹${c.rate})`, amount: subtotal, category: "ROOM" }] },
      },
    });
    inHouse.push({ rsvId: rsv.id, guestName: guests[c.g].name, roomId: room.id, roomNumber: room.number });
  }

  // F&B orders: one delivered room-service (charged to folio), one pending restaurant
  const o1 = await prisma.restaurantOrder.create({
    data: {
      orderNumber: ordCode(), type: "ROOM_SERVICE", guestId: inHouse[0] ? guests[3].id : null,
      reservationId: inHouse[0]?.rsvId, roomId: inHouse[0]?.roomId, status: "DELIVERED",
      createdAt: d(0, 13, 30), deliveredAt: d(0, 14, 15), chargedToRoom: true,
    },
  });
  const o1items = [mi("Butter Chicken"), mi("Butter Naan"), mi("Masala Chai")];
  let sub = o1items.reduce((s, i) => s + i.price, 0) * 1;
  await prisma.orderItem.createMany({
    data: o1items.map((i) => ({ orderId: o1.id, menuItemId: i.id, quantity: 1, unitPrice: i.price })),
  });
  const o1tax = Math.round(sub * 0.05);
  await prisma.restaurantOrder.update({ where: { id: o1.id }, data: { subtotal: sub, tax: o1tax, totalAmount: sub + o1tax } });
  if (inHouse[0]) {
    const folio = await prisma.folio.findFirst({ where: { reservationId: inHouse[0].rsvId } });
    if (folio) {
      await prisma.folioEntry.create({
        data: { folioId: folio.id, type: "CHARGE", description: `In-room dining ${o1.orderNumber}`, amount: sub + o1tax, category: "FOOD" },
      });
    }
  }

  const o2 = await prisma.restaurantOrder.create({
    data: {
      orderNumber: ordCode(), type: "RESTAURANT", tableNumber: "T4", status: "PENDING",
      createdAt: d(0, 19, 5),
    },
  });
  const o2items = [mi("Paneer Tikka"), mi("Hyderabadi Chicken Biryani"), mi("Kingfisher pint")];
  sub = o2items.reduce((s, i) => s + i.price, 0);
  await prisma.orderItem.createMany({
    data: o2items.map((i) => ({ orderId: o2.id, menuItemId: i.id, quantity: i.name === "Butter Naan" ? 2 : 1, unitPrice: i.price })),
  });
  const o2tax = Math.round(sub * 0.05);
  await prisma.restaurantOrder.update({ where: { id: o2.id }, data: { subtotal: sub, tax: o2tax, totalAmount: sub + o2tax } });

  // FUTURE reservations
  const futureDefs = [
    { g: 0, type: std, rate: 3500, from: 1, to: 4, source: "OTA_BOOKING_COM", status: "CONFIRMED" },
    { g: 1, type: dlx, rate: 5500, from: 2, to: 5, source: "DIRECT", status: "CONFIRMED" },
    { g: 6, type: fam, rate: 7500, from: 3, to: 6, source: "COMPANY", status: "CONFIRMED" },
    { g: 7, type: exec, rate: 8500, from: 5, to: 8, source: "WEBSITE", status: "CONFIRMED" },
    { g: 8, type: std, rate: 3500, from: 6, to: 8, source: "OTA_GOIBIBO", status: "CONFIRMED" },
    { g: 9, type: pres, rate: 18000, from: 7, to: 10, source: "DIRECT", status: "CONFIRMED" },
    { g: 10, type: dlx, rate: 5500, from: 4, to: 7, source: "OTA_EXPEDIA", status: "PENDING" },
    { g: 2, type: std, rate: 3500, from: 5, to: 6, source: "PHONE", status: "PENDING" },
  ];
  let fIdx = 0;
  for (const f of futureDefs) {
    const roomList = roomsOfType(f.type.id);
    const room = roomList[(fIdx + 1) % roomList.length]; // skip first room (occupied if same type)
    fIdx++;
    const nights = f.to - f.from;
    const total = f.rate * nights;
    const withTax = total + Math.round(total * 0.12);
    await prisma.reservation.create({
      data: {
        code: rsvCode(), guestId: guests[f.g].id, roomTypeId: f.type.id, roomId: room.id,
        checkIn: checkInDate(f.from), checkOut: checkOutDate(f.to),
        adults: 2, children: 0, status: f.status, source: f.source, rate: f.rate,
        totalAmount: withTax, paidAmount: 0,
        specialRequests: f.g === 7 ? "High floor, late check-out if possible" : null,
        createdAt: d(f.from - 10),
      },
    });
  }

  // Cancelled + no-show
  await prisma.reservation.create({
    data: {
      code: rsvCode(), guestId: guests[11].id, roomTypeId: dlx.id,
      checkIn: checkInDate(-3), checkOut: checkOutDate(-1), adults: 2, status: "CANCELLED",
      source: "OTA_BOOKING_COM", rate: 5500, totalAmount: 11000,
      notes: "Guest cancelled due to flight change", createdAt: d(-9),
    },
  });
  await prisma.reservation.create({
    data: {
      code: rsvCode(), guestId: guests[2].id, roomTypeId: std.id,
      checkIn: checkInDate(-6), checkOut: checkOutDate(-4), adults: 1, status: "NO_SHOW",
      source: "WEBSITE", rate: 3500, totalAmount: 7000,
      notes: "Did not arrive, no cancellation", createdAt: d(-12),
    },
  });

  // One room in maintenance, one dirty (housekeeping)
  const maintRoom = roomsOfType(pres.id)[3];
  await prisma.room.update({ where: { id: maintRoom.id }, data: { status: "MAINTENANCE", notes: "AC compressor replacement" } });
  const dirtyRoom = roomsOfType(std.id)[5];
  await prisma.room.update({ where: { id: dirtyRoom.id }, data: { status: "DIRTY", housekeeping: "DIRTY" } });

  // ── Company / OTA folios ───────────────────────────────
  const compFolio = await prisma.folio.create({
    data: {
      code: folCode(), type: "COMPANY", name: techCorp.name, companyId: techCorp.id,
      contact: techCorp.contactPerson, phone: techCorp.phone, gstin: techCorp.gstin,
      dueDate: d(14), status: "OPEN",
      entries: { create: [
        { type: "CHARGE", description: "Corporate stay — R. Malhotra (4 nights)", amount: 34000, category: "ROOM" },
        { type: "CHARGE", description: "Airport transfers", amount: 3500, category: "SERVICE" },
        { type: "PAYMENT", description: "Partial bank transfer", amount: -20000, category: "OTHER" },
      ] },
    },
  });
  const otaFolio = await prisma.folio.create({
    data: {
      code: folCode(), type: "OTA", name: "Booking.com", otaName: "BOOKING_COM",
      dueDate: d(7), status: "OPEN",
      entries: { create: [
        { type: "CHARGE", description: "M. Iyer — Deluxe × 2 nights (collect from OTA)", amount: 11000, category: "ROOM" },
        { type: "ADJUSTMENT", description: "Commission 15%", amount: -1650, category: "OTHER" },
      ] },
    },
  });

  // OTA invoices (unpaid)
  const otaInv = await prisma.invoice.create({
    data: {
      number: invCode(), billingType: "OTA", folioId: otaFolio.id,
      subtotal: 9350, tax: 0, discount: 0, total: 9350, paidAmount: 0, status: "UNPAID",
      notes: "Booking.com virtual card settlement pending",
      issuedAt: d(-2),
    },
  });
  await prisma.invoiceItem.createMany({
    data: [
      { invoiceId: otaInv.id, description: "M. Iyer — Deluxe Room 2 nights (net of 15% commission)", type: "ROOM", quantity: 2, unitPrice: 4675, amount: 9350 },
    ],
  });

  // ── Reviews ────────────────────────────────────────────
  const reviewData = [
    [0, "BOOKING_COM", 5, "Wonderful stay", "Immaculate rooms and the staff upgraded us for our anniversary. Sea view from the Executive Suite is to die for.", -30],
    [7, "GOOGLE", 4, "Great location", "Perfect location near Marine Drive. Breakfast could have more variety but overall a lovely stay.", -14],
    [9, "TRIPADVISOR", 4, "Family friendly", "Travelled with kids, the family room was spacious. Pool hours could be longer.", -9],
    [1, "MAKE_MY_TRIP", 3, "Good but noisy", "Room was comfortable but street-facing noise at night. Ask for a higher floor.", -6],
    [6, "DIRECT", 5, "Business travel sorted", "Fast check-in, great work desk and wifi. The executive suite is my new Mumbai base.", -20],
    [10, "AIRBNB", 2, "Slow room service", "The suite itself is nice but room service took 50 minutes. Expected better.", -3],
  ] as const;
  for (const r of reviewData) {
    await prisma.review.create({
      data: { guestId: guests[r[0]].id, channel: r[1], rating: r[2], title: r[3], comment: r[4], createdAt: d(r[5]) },
    });
  }

  // ── Ledger entries ─────────────────────────────────────
  await prisma.ledgerEntry.createMany({
    data: [
      { type: "OPENING", amount: 50000, method: "CASH", category: "PETTY_CASH", remarks: "Day opening float", createdAt: d(-1, 9) },
      { type: "CASH_IN", amount: 18000, method: "CASH", category: "OWNER_DEPOSIT", remarks: "Owner deposit — emergency fund", createdAt: d(-1, 10) },
      { type: "CASH_OUT", amount: 3500, method: "CASH", category: "SUPPLIER", remarks: "Florist — lobby arrangements", createdAt: d(0, 8) },
      { type: "CASH_OUT", amount: 1200, method: "UPI", category: "STAFF", remarks: "Staff refreshments", createdAt: d(0, 10) },
      { type: "CASH_IN", amount: 7000, method: "UPI", category: "OTHER", remarks: "Walk-in F&B settlement", createdAt: d(0, 12) },
    ],
  });

  // ── Audit logs ─────────────────────────────────────────
  await prisma.auditLog.createMany({
    data: [
      { userName: "Priya Sharma", action: "CHECKIN", entity: "Reservation", details: "Checked in " + guests[11].name, createdAt: d(0, 13, 5) },
      { userName: "Priya Sharma", action: "CREATE", entity: "RestaurantOrder", details: `Order ${o2.orderNumber} — table T4`, createdAt: d(0, 19, 5) },
      { userName: "Rahul Verma", action: "CREATE", entity: "LedgerEntry", details: "CASH_IN ₹7,000 UPI", createdAt: d(0, 12) },
      { userName: "Aarav Mehta", action: "UPDATE", entity: "Room", details: `Room ${maintRoom.number} → MAINTENANCE`, createdAt: d(-1, 9) },
    ],
  });

  console.log("Seed complete:");
  console.log(`  users=4 roomTypes=5 rooms=${rooms.length} guests=${guests.length}`);
  console.log(`  reservations=${rsvSeq} invoices=${invSeq} orders=${ordSeq} folios=${folSeq} menu=${menuItems.length}`);
  console.log("Logins: admin@digistay.com/admin123 · reception@digistay.com/reception123 · accounts@digistay.com/accounts123 · staff@digistay.com/staff123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
