# DigiStay — Hotel Management System

A complete, database-backed hotel management system (PMS) built with **Next.js 16 (App Router) + TypeScript + Tailwind CSS 4 + shadcn/ui + Prisma (SQLite)**. Every button, form, filter and table action is wired to real backend API endpoints with persistence, validation, and role-based access control.

![stack](https://img.shields.io/badge/Next.js-16-black) ![ts](https://img.shields.io/badge/TypeScript-5-blue) ![prisma](https://img.shields.io/badge/Prisma-SQLite-green)

---

## Quick start

```bash
# 1. Install dependencies
bun install        # or npm install

# 2. Configure environment
cp .env.example .env

# 3. Create + sync the database
bun run db:push

# 4. Seed demo data (rooms, guests, reservations, invoices, reviews…)
bun prisma/seed.ts

# 5. Run the dev server
bun run dev        # http://localhost:3000
```

## Demo logins

| Role          | Email                     | Password        | Access |
|---------------|---------------------------|-----------------|--------|
| Administrator | `admin@digistay.com`      | `admin123`      | Everything incl. Settings, Users, Audit Log |
| Receptionist  | `reception@digistay.com`  | `reception123`  | Front desk: rooms, stay view, reservations, check-ins, guests, F&B, folios, invoices (view), OTA/website |
| Accountant    | `accounts@digistay.com`   | `accounts123`   | Ledger, invoices, folios, all reports |
| Staff         | `staff@digistay.com`      | `staff123`      | Dashboard, room view/housekeeping, stay view, F&B orders |
| Guest (demo)  | `guest@digistay.com`      | `guest123`      | Public site guest portal — "My bookings", cancel upcoming website bookings |

Permissions are enforced **both** in the sidebar (module visibility) **and** on every API route (403s).

## Public website (landing / about / contact / booking)

Visitors land on a full public website in front of the PMS, navigated by hash routes on `/`:

- **#home** — hero with live hotel identity + stats (room categories, room count, average guest rating from the DB), Rooms & Rates from `/api/website/config`, amenities, real guest reviews from `/api/website/reviews`, CTA.
- **#about** — story, real-numbers stats strip, values, top review quotes.
- **#contact** — hotel contact info from the DB + working contact form → `POST /api/contact` (stored in `ContactMessage`; admin can list via `GET /api/contact`).
- **#booking** — real-time booking engine: availability search (`/api/website/availability`), reserve dialog, confirmation with a real `RSV-…` code (`POST /api/website/book`). No login needed; honours `bookingEngineEnabled` + `paymentMode` settings.
- **#login** — **portal login preface**: Hotel Owner / Admin · Staff · Guest. Each portal enforces its roles server-side (`portal` field on `/api/auth/login`, 403 with a helpful message on mismatch). Guest tab also has **Create account** (`POST /api/auth/register`, auto sign-in).
- **#portal** — guest "My Bookings": upcoming/past website bookings, status badges, cancel upcoming bookings (releases the room immediately).

Staff/admin sign-in hands over to the PMS app shell; guests stay on the public site with an account menu. Bookings made on the website (with or without an account) appear in the PMS reservations module instantly.

## Modules

1. **Dashboard** — live occupancy/revenue stats, 14-day occupancy trend, revenue by month, bookings-by-source, arrivals/departures with one-click check-in/out, recent activity (all computed from the DB).
2. **Room view** — status-filtered room card grid (available / occupied / checkout due / reservation / maintenance / housekeeping), housekeeping actions, room + room-type CRUD.
3. **Stay view** — availability grid per room × day with per-night occupancy %, unassigned-reservation alerts.
4. **Reservations** — create/edit/view/cancel/no-show, guest picker + inline new-guest, live availability-driven room assignment, automatic nights × rate totals, **overlap/double-booking prevention (409)**, record payments.
5. **Check-ins & Guests** — start check-in flow with room picker, active in-house list, checkout guard (blocks on unsettled folio), past stays, guest insights (repeat guests, avg stay, no-show rate, data quality).
6. **Food & Beverage** — menu CRUD with categories/veg flags, restaurant/bar/room-service orders with status pipeline, GST 5%, **auto charge-to-folio** for room service, invoice generation.
7. **Finance** — Ledger (cash in / cash out / petty cash + per-method balances), Invoices (generate from stays & orders, record payments, void, print/PDF), Company/Individual folios and OTA folios with charges/payments/adjustments and one-click settlement.
8. **Reports** — Standard: Revenue, Payment Ledger, Outstanding, Invoice Summary, Room Sales, **Night Audit**, OTA Commission, Police Verification. Custom report builder. Business Intelligence with charts. All exportable to CSV.
9. **OTAs & Website** — Channel manager (per-OTA booking tabs, confirm/cancel), public booking engine config (payment mode, enable toggle), live availability + rate preview, public booking API (`/api/website/*`).
10. **DigiAI 2.0 & Chats** — agentic AI assistant (dialog or topbar "Ask DigiAI") with 9 read-only hotel tools it calls on demand (occupancy, arrivals/departures, reservation search, room availability, guest profiles, pending F&B orders, outstanding invoices, revenue summary, review summary) — shows ⚡ tool-check badges and role-aware quick chips; communication hub UI.
11. **Reviews** — insights (average rating, distribution, by-channel), inbox with replies, add review.
12. **Guides & Tutorials** — searchable tutorial library.
13. **Settings** — hotel profile, taxes/currency/times, booking engine, user management (roles), audit log, reset-demo-data.
14. **AI Automation (admin)** — one-click hub: live **Insights** (LLM analyst over real metrics w/ rule-based fallback, 5-min cache), **Dynamic Pricing** (per-type rate suggestions with reasons — apply updates public booking rates), **Review Assistant** (AI-drafted sentiment-aware replies, editable before sending), **Smart Assign** (overlap-safe room ranking from guest history, special requests, housekeeping status — assign with one click). Endpoints under `/api/ai/*`.

## Architecture

```
prisma/schema.prisma      # 20 models: users/sessions, guests, rooms, reservations,
                          # folios, invoices, payments, menu/orders, reviews, audit…
prisma/seed.ts            # Realistic demo dataset (dates relative to today)
src/app/api/**            # 60+ REST route handlers (auth, CRUD, reports, booking engine)
src/lib/api-helpers.ts    # Auth wrapper (withAuth), audit log, overlap guard, money/date utils
src/lib/billing.ts        # Invoice generation from folios/orders, payment application
src/lib/ai.ts             # DigiAI 2.0 core: LLM singleton, JSON extraction, hotel metric builders
src/lib/permissions.ts    # Role → module map (ADMIN/RECEPTIONIST/ACCOUNTANT/STAFF)
src/store/app-store.ts    # Zustand (session + active module, persisted)
src/components/site/**    # Public website: home/about/contact/booking, portal login, guest portal
src/components/app/**     # Shell: sidebar, topbar, DigiAI dialog, login
src/components/views/**   # 19 module views (incl. AI Automation hub) + shared UI kit (shared.tsx)
```

- **Single-page app** at `/` — modules switch client-side; all data via `/api/*`.
- **Auth**: token sessions (scrypt-hashed passwords, 7-day expiry) via `Authorization: Bearer`.
- **Financial integrity**: checkout blocked while folio balance > 0; invoice payments update invoice + reservation + folio atomically; overpayment rejected.
- **Booking integrity**: overlapping PENDING/CONFIRMED/CHECKED_IN reservations for the same room (or sold-out room type) are rejected server-side.

## Testing

```bash
bash scripts/test-e2e-workflow.sh   # 36-check golden path: login → guest → reservation →
                                    # check-in → F&B order → invoice → payment → checkout →
                                    # reports + double-booking guard + role gates
```

## API documentation

See [`API-CONTRACT.md`](./API-CONTRACT.md) for the full endpoint reference (paths, payloads, response shapes, status codes).

## Resetting demo data

Settings → Users & Data → **Reset Demo Data** (admin only), or `bun prisma/seed.ts`.

## Notes

- Demo data is clearly labeled in the UI (dashboard banner + login hint). Records you create are real and persisted in `db/custom.db`.
- Currency is INR (₹). Taxes: 12% rooms / 5% F&B (configurable in Settings → Rates & Taxes).
