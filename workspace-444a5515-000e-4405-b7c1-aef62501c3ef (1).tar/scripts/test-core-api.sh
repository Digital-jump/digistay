#!/usr/bin/env bash
# =============================================================================
# DigiStay — Task 2-a Backend Core API test suite
# Run: bash scripts/test-core-api.sh   (dev server must be on port 3000)
# =============================================================================
BASE="${BASE:-http://localhost:3000/api}"
PASS=0; FAIL=0; TOTAL=0

# req METHOD PATH [TOKEN] [JSON_BODY] — sets STATUS + BODY, prints a trace line
req() {
  local method="$1" path="$2" token="$3" data="$4"
  local args=(-s -w $'\n%{http_code}' -X "$method" "$BASE$path" -H 'Content-Type: application/json')
  [ -n "$token" ] && args+=(-H "Authorization: Bearer $token")
  [ -n "$data" ] && args+=(-d "$data")
  local resp
  resp="$(curl "${args[@]}" 2>/dev/null)"
  STATUS="$(printf '%s' "$resp" | tail -n 1)"
  BODY="$(printf '%s' "$resp" | sed '$d')"
  echo "→ $method $path [$STATUS] $(printf '%s' "$BODY" | tr -d '\n' | head -c 180)"
}

# jget BODY 'python-expr' — evaluate expr with d=json body
jget() {
  printf '%s' "$1" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
except Exception:
    print('<<no-json>>'); sys.exit(0)
try:
    v = eval(sys.argv[1], {'d': d})
    print(v if not isinstance(v, (dict, list)) else json.dumps(v))
except Exception:
    print('<<expr-error>>')
" "$2" 2>/dev/null
}

report() { # report NAME EXPECTED ACTUAL
  TOTAL=$((TOTAL+1))
  if [ "$2" == "$3" ]; then PASS=$((PASS+1)); echo "PASS: $1"
  else FAIL=$((FAIL+1)); echo "FAIL: $1 (expected=[$2] actual=[$3])"; fi
}

contains() { # contains NAME HAYSTACK NEEDLE
  TOTAL=$((TOTAL+1))
  if printf '%s' "$2" | grep -qF -- "$3"; then PASS=$((PASS+1)); echo "PASS: $1"
  else FAIL=$((FAIL+1)); echo "FAIL: $1 (missing: $3)"; fi
}

echo "================ DigiStay Task 2-a: core API tests ================"

# ── 0. Login edge case: wrong password ─────────────────────────────
req POST /auth/login "" '{"email":"admin@digistay.com","password":"wrong-password"}'
report "login with wrong password → 401" 401 "$STATUS"

# ── 1. Login ───────────────────────────────────────────────────────
req POST /auth/login "" '{"email":"admin@digistay.com","password":"admin123"}'
report "POST /auth/login" 200 "$STATUS"
TOKEN="$(jget "$BODY" "d['token']")"
if [ -z "$TOKEN" ] || [ "$TOKEN" == "<<no-json>>" ]; then echo "FATAL: no token, aborting"; exit 1; fi

# ── 2. Auth me ─────────────────────────────────────────────────────
req GET /auth/me "$TOKEN"
report "GET /auth/me" 200 "$STATUS"
contains "me returns admin email" "$BODY" "admin@digistay.com"

# unauthenticated dashboard → 401
req GET /dashboard ""
report "unauthenticated GET /dashboard → 401" 401 "$STATUS"

# ── 3. Dashboard ───────────────────────────────────────────────────
req GET /dashboard "$TOKEN"
report "GET /dashboard" 200 "$STATUS"
report "dashboard stats.totalRooms >= 1" "$(jget "$BODY" "d['stats']['totalRooms'] >= 1")" "True"
report "dashboard stats has all keys" "$(jget "$BODY" "all(k in d['stats'] for k in ['totalRooms','availableRooms','occupiedRooms','occupancyRate','arrivalsToday','departuresToday','inHouseGuests','todayRevenue','monthRevenue','outstandingBalance','pendingOrders'])")" "True"
report "dashboard occupancyTrend has 14 days" "$(jget "$BODY" "len(d['occupancyTrend'])")" "14"
report "dashboard revenueByMonth has 6 months" "$(jget "$BODY" "len(d['revenueByMonth'])")" "6"
report "dashboard roomStatusBreakdown has 5 statuses" "$(jget "$BODY" "len(d['roomStatusBreakdown'])")" "5"
report "dashboard recentActivity <= 12" "$(jget "$BODY" "len(d['recentActivity']) <= 12")" "True"
report "dashboard has arrivals/departures lists" "$(jget "$BODY" "'arrivalsTodayList' in d and 'departuresTodayList' in d")" "True"

# ── 4. Companies cycle ─────────────────────────────────────────────
req GET /companies "$TOKEN"
report "GET /companies" 200 "$STATUS"
req POST /companies "$TOKEN" '{"name":"API Test Co","phone":"+91 90000 11111"}'
report "POST /companies" 200 "$STATUS"
CO="$(jget "$BODY" "d['id']")"
req PUT "/companies/$CO" "$TOKEN" '{"name":"API Test Co Updated"}'
report "PUT /companies/[id]" 200 "$STATUS"
report "company updated" "$(jget "$BODY" "d['name']")" "API Test Co Updated"
req DELETE "/companies/$CO" "$TOKEN"
report "DELETE /companies/[id]" 200 "$STATUS"

# ── 5. Room type create + list ─────────────────────────────────────
req GET /room-types "$TOKEN"
report "GET /room-types" 200 "$STATUS"
req POST /room-types "$TOKEN" '{"name":"API Test Suite","description":"created by api test","baseRate":1000,"capacity":2,"amenities":["Wi-Fi","Test"]}'
report "POST /room-types" 200 "$STATUS"
RT="$(jget "$BODY" "d['id']")"
report "room type amenities parsed as array" "$(jget "$BODY" "d['amenities']")" "['Wi-Fi', 'Test']"
req PUT "/room-types/$RT" "$TOKEN" '{"description":"API test suite updated"}'
report "PUT /room-types/[id]" 200 "$STATUS"

# ── 6. Room create + status changes ────────────────────────────────
req POST /rooms "$TOKEN" '{"number":"901","floor":9,"roomTypeId":"'"$RT"'"}'
report "POST /rooms" 200 "$STATUS"
RM="$(jget "$BODY" "d['id']")"
req POST /rooms "$TOKEN" '{"number":"901","floor":9,"roomTypeId":"'"$RT"'"}'
report "duplicate room number → 409" 409 "$STATUS"
contains "duplicate room error text" "$BODY" "Room number already exists"
req PUT "/rooms/$RM" "$TOKEN" '{"status":"OCCUPIED"}'
report "PUT room status=OCCUPIED → 400" 400 "$STATUS"
contains "OCCUPIED error text" "$BODY" "Use check-in to occupy a room"
req POST "/rooms/$RM/status" "$TOKEN" '{"status":"DIRTY"}'
report "POST /rooms/[id]/status DIRTY" 200 "$STATUS"
report "room now DIRTY" "$(jget "$BODY" "d['status']")" "DIRTY"
req POST "/rooms/$RM/status" "$TOKEN" '{"status":"MAINTENANCE"}'
report "POST /rooms/[id]/status MAINTENANCE" 200 "$STATUS"
req POST "/rooms/$RM/status" "$TOKEN" '{"status":"OCCUPIED"}'
report "status route rejects OCCUPIED → 400" 400 "$STATUS"
req POST "/rooms/$RM/status" "$TOKEN" '{"status":"AVAILABLE"}'
report "POST /rooms/[id]/status AVAILABLE" 200 "$STATUS"
req PUT "/rooms/$RM" "$TOKEN" '{"floor":9,"notes":"api test room"}'
report "PUT /rooms/[id]" 200 "$STATUS"

req GET "/rooms?search=901" "$TOKEN"
report "GET /rooms?search=901 finds the room" "$(jget "$BODY" "len(d['items'])")" "1"
report "rooms include roomType" "$(jget "$BODY" "d['items'][0]['roomType']['name']")" "API Test Suite"
req GET "/rooms?status=AVAILABLE" "$TOKEN"
report "GET /rooms?status filter works" "$(jget "$BODY" "all(r['status']=='AVAILABLE' for r in d['items'])")" "True"
req GET /rooms "$TOKEN"
report "rooms stats has all 5 status keys" "$(jget "$BODY" "all(k in d['stats'] for k in ['AVAILABLE','OCCUPIED','RESERVED','DIRTY','MAINTENANCE'])")" "True"
req GET "/room-types" "$TOKEN"
report "room-types list has roomCount=1 for test type" "$(jget "$BODY" "any(rt['id']=='$RT' and rt['roomCount']==1 for rt in d)")" "True"
report "room-types list has activeReservations" "$(jget "$BODY" "all('activeReservations' in rt for rt in d)")" "True"

# ── 7. Stay view ───────────────────────────────────────────────────
req GET "/stay-view?days=14" "$TOKEN"
report "GET /stay-view" 200 "$STATUS"
report "stay-view returns 14 days" "$(jget "$BODY" "len(d['days'])")" "14"
report "stay-view cells for every room" "$(jget "$BODY" "len(d['cells']) == len(d['rooms']) and len(d['rooms']) >= 1")" "True"
report "stay-view cell shape (room 901 day0)" "$(jget "$BODY" "all(k in list(d['cells'].values())[0][d['days'][0]] for k in ['status'])")" "True"
report "stay-view stats keys" "$(jget "$BODY" "all(k in d['stats'] for k in ['AVAILABLE','OCCUPIED','CHECKOUT_DUE','HOUSEKEEPING'])")" "True"

# ── 8. Guests cycle ────────────────────────────────────────────────
req POST /guests "$TOKEN" '{"firstName":"Testy","lastName":"McTestFace","email":"testy.mctestface@example.com","phone":"+91 90000 00001","idType":"AADHAAR","idNumber":"TEST-0001","nationality":"Indian"}'
report "POST /guests" 200 "$STATUS"
TG="$(jget "$BODY" "d['id']")"
req POST /guests "$TOKEN" '{"firstName":"Dup","lastName":"Dup","phone":"+91 90000 00001","idNumber":"TEST-0001"}'
report "guest duplicate phone+ID → 409" 409 "$STATUS"
contains "duplicate guest error text" "$BODY" "Guest with same phone and ID already exists"
req POST /guests "$TOKEN" '{"firstName":"Bad","lastName":"Email","email":"not-an-email"}'
report "guest invalid email → 400" 400 "$STATUS"
req POST /guests "$TOKEN" '{"firstName":"Bad","lastName":"Phone","phone":"123"}'
report "guest short phone → 400" 400 "$STATUS"
req GET "/guests?search=Testy" "$TOKEN"
report "guest list search finds Testy" "$(jget "$BODY" "any(g['id']=='$TG' for g in d['items'])")" "True"
req GET "/guests?page=1&pageSize=2" "$TOKEN"
report "guest list pagination honours pageSize" "$(jget "$BODY" "len(d['items']) <= 2 and d['pageSize'] == 2 and d['page'] == 1")" "True"
req GET "/guests" "$TOKEN"
report "guest list items have reservationCount+lastStay" "$(jget "$BODY" "all('reservationCount' in g and 'lastStay' in g for g in d['items'])")" "True"
req PUT "/guests/$TG" "$TOKEN" '{"firstName":"Testy","lastName":"McTestFace","email":"testy.mctestface@example.com","phone":"+91 90000 00001","idType":"AADHAAR","idNumber":"TEST-0001","city":"Mumbai","vip":true}'
report "PUT /guests/[id]" 200 "$STATUS"
report "guest updated city+vip" "$(jget "$BODY" "d['city']=='Mumbai' and d['vip']==True")" "True"
req GET "/guests/$TG" "$TOKEN"
report "GET /guests/[id]" 200 "$STATUS"
report "guest detail has reservations/orders/reviews/stats" "$(jget "$BODY" "all(k in d for k in ['guest','reservations','orders','reviews','stats']) and all(k in d['stats'] for k in ['stays','spend'])")" "True"
req GET /guests/stats "$TOKEN"
report "GET /guests/stats" 200 "$STATUS"
report "guest stats has all keys" "$(jget "$BODY" "all(k in d for k in ['totalGuests','repeatGuests','avgStayNights','noShowRate','newByMonth','idDocsRecorded','missingId','missingContact','duplicates','nationalityBreakdown','sourceBreakdown'])")" "True"
report "guest stats newByMonth has 12 months" "$(jget "$BODY" "len(d['newByMonth'])")" "12"

# ── 9. Reservation lifecycle ───────────────────────────────────────
D1=$(date -d "+1 day" +%F); D2=$(date -d "+2 days" +%F); D4=$(date -d "+4 days" +%F)
D5=$(date -d "+5 days" +%F); D6=$(date -d "+6 days" +%F); D7=$(date -d "+7 days" +%F)
D8=$(date -d "+8 days" +%F); D9=$(date -d "+9 days" +%F); D10=$(date -d "+10 days" +%F)

req GET "/guests?search=kabir" "$TOKEN"
SG="$(jget "$BODY" "d['items'][0]['id'] if d['items'] else '$TG'")"

# invalid dates → 409
req POST /reservations "$TOKEN" "{\"guestId\":\"$SG\",\"roomTypeId\":\"$RT\",\"checkIn\":\"$D4\",\"checkOut\":\"$D2\"}"
report "reservation checkOut<=checkIn → 409" 409 "$STATUS"
contains "date order error text" "$BODY" "Check-out must be after check-in"

# room under maintenance → 409
req POST /reservations "$TOKEN" "{\"guestId\":\"$SG\",\"roomTypeId\":\"$RT\",\"roomId\":\"$RM\",\"checkIn\":\"$D2\",\"checkOut\":\"$D4\"}"
report "reservation for MAINTENANCE room → 409" 409 "$STATUS"
contains "maintenance error text" "$BODY" "Room is under maintenance"

# main reservation: today+2 → today+4 (2 nights × ₹1000)
req POST /reservations "$TOKEN" "{\"guestId\":\"$SG\",\"roomTypeId\":\"$RT\",\"roomId\":\"$RM\",\"checkIn\":\"$D2\",\"checkOut\":\"$D4\",\"adults\":2,\"source\":\"DIRECT\"}"
report "POST /reservations" 200 "$STATUS"
RID="$(jget "$BODY" "d['id']")"
RCODE="$(jget "$BODY" "d['code']")"
report "reservation totalAmount = 2000" "$(jget "$BODY" "d['totalAmount']")" "2000"
report "reservation includes guest/roomType/room" "$(jget "$BODY" "all(k in d for k in ['guest','roomType','room'])")" "True"

# availability: room 901 must be excluded now
req GET "/reservations/availability?roomTypeId=$RT&checkIn=$D2&checkOut=$D4" "$TOKEN"
report "GET /reservations/availability" 200 "$STATUS"
report "availability excludes booked room 901" "$(jget "$BODY" "all(a['id'] != '$RM' for a in d['available'])")" "True"
report "availability nights = 2" "$(jget "$BODY" "d['nights']")" "2"
report "availability rate = 1000" "$(jget "$BODY" "d['rate']")" "1000"
report "availability roomType present" "$(jget "$BODY" "d['roomType']['id']=='$RT'")" "True"

# overlapping same room → 409
req POST /reservations "$TOKEN" "{\"guestId\":\"$SG\",\"roomTypeId\":\"$RT\",\"roomId\":\"$RM\",\"checkIn\":\"$D1\",\"checkOut\":\"$D4\"}"
report "overlapping reservation same room → 409" 409 "$STATUS"
contains "overlap error text" "$BODY" "Room 901 is already booked for the selected dates"

# check-in
req POST "/reservations/$RID/checkin" "$TOKEN" "{\"roomId\":\"$RM\"}"
report "POST /reservations/[id]/checkin" 200 "$STATUS"
report "reservation CHECKED_IN" "$(jget "$BODY" "d['status']")" "CHECKED_IN"
report "room OCCUPIED after checkin" "$(jget "$BODY" "d['room']['status']")" "OCCUPIED"
report "folio created with ROOM charge" "$(jget "$BODY" "d['folio'] and any(e['category']=='ROOM' and e['amount']==2000 for e in d['folio']['entries'])")" "True"
req POST "/reservations/$RID/checkin" "$TOKEN" "{\"roomId\":\"$RM\"}"
report "second checkin → 400" 400 "$STATUS"

# payment ₹1000 UPI
req POST "/reservations/$RID/payment" "$TOKEN" '{"amount":1000,"method":"UPI","reference":"TEST-UPI-001"}'
report "POST /reservations/[id]/payment" 200 "$STATUS"
report "payment method UPI recorded" "$(jget "$BODY" "d['payment']['method']=='UPI' and d['payment']['amount']==1000")" "True"
report "invoice total = 2240 (2000 + 12% GST)" "$(jget "$BODY" "d['invoice']['total']")" "2240"
report "invoice status PARTIAL" "$(jget "$BODY" "d['invoice']['status']")" "PARTIAL"

# checkout without force → 409 (folio balance 2000-1000=1000)
req POST "/reservations/$RID/checkout" "$TOKEN" '{}'
report "checkout with unsettled folio → 409" 409 "$STATUS"
report "checkout 409 error message" "$(jget "$BODY" "d['error']")" "Folio has unsettled charges"
report "checkout 409 balance = 1000" "$(jget "$BODY" "d['balance']")" "1000"

# forced checkout
req POST "/reservations/$RID/checkout" "$TOKEN" '{"force":true}'
report "forced checkout" 200 "$STATUS"
report "reservation CHECKED_OUT" "$(jget "$BODY" "d['reservation']['status']")" "CHECKED_OUT"

# room is DIRTY after checkout
req GET "/rooms?search=901" "$TOKEN"
report "room DIRTY after checkout" "$(jget "$BODY" "d['items'][0]['status']")" "DIRTY"

# reservation detail
req GET "/reservations/$RID" "$TOKEN"
report "GET /reservations/[id]" 200 "$STATUS"
report "detail has folio/invoices/orders/review flags" "$(jget "$BODY" "all(k in d['reservation'] for k in ['folio','invoices','orders','review']) and d['canCheckOut']==True and d['canCheckIn']==False")" "True"

# list tabs + counts + search
req GET "/reservations?tab=all" "$TOKEN"
report "GET /reservations?tab=all" 200 "$STATUS"
report "counts present" "$(jget "$BODY" "all(k in d['counts'] for k in ['upcoming','checkedin','history'])")" "True"
req GET "/reservations?tab=history" "$TOKEN"
report "history tab contains checked-out R1" "$(jget "$BODY" "any(r['id']=='$RID' for r in d['items'])")" "True"
req GET "/reservations?search=$RCODE" "$TOKEN"
report "search by code finds R1" "$(jget "$BODY" "any(r['id']=='$RID' for r in d['items'])")" "True"
req GET "/reservations?status=CHECKED_OUT" "$TOKEN"
report "status filter works" "$(jget "$BODY" "all(r['status']=='CHECKED_OUT' for r in d['items'])")" "True"

# ── 10. Cancel flow (R2, unassigned, with folio payload) ───────────
req POST /reservations "$TOKEN" "{\"guestId\":\"$TG\",\"roomTypeId\":\"$RT\",\"checkIn\":\"$D5\",\"checkOut\":\"$D7\",\"adults\":1,\"folio\":{\"type\":\"INDIVIDUAL\",\"name\":\"Testy Folio\"}}"
report "POST /reservations R2 with folio" 200 "$STATUS"
RID2="$(jget "$BODY" "d['id']")"
req PUT "/reservations/$RID2" "$TOKEN" '{"rate":1200}'
report "PUT /reservations/[id] rate change" 200 "$STATUS"
report "totalAmount recomputed = 2400" "$(jget "$BODY" "d['totalAmount']")" "2400"
req GET "/stay-view?start=$D5&days=14" "$TOKEN"
report "stay-view unassigned contains R2" "$(jget "$BODY" "any(u['reservationId']=='$RID2' for u in d['unassigned'])")" "True"
req GET "/reservations/$RID2" "$TOKEN"
report "R2 detail includes folio" "$(jget "$BODY" "d['reservation']['folio'] and d['reservation']['folio']['name']=='Testy Folio'")" "True"
req POST "/reservations/$RID2/cancel" "$TOKEN" '{"reason":"API test cancel"}'
report "POST /reservations/[id]/cancel" 200 "$STATUS"
report "R2 CANCELLED" "$(jget "$BODY" "d['status']")" "CANCELLED"
contains "cancel reason appended to notes" "$BODY" "API test cancel"

# ── 11. No-show flow (R3) ──────────────────────────────────────────
req POST /reservations "$TOKEN" "{\"guestId\":\"$TG\",\"roomTypeId\":\"$RT\",\"checkIn\":\"$D6\",\"checkOut\":\"$D8\",\"adults\":1}"
RID3="$(jget "$BODY" "d['id']")"
req POST "/reservations/$RID3/no-show" "$TOKEN" '{}'
report "POST /reservations/[id]/no-show" 200 "$STATUS"
report "R3 NO_SHOW" "$(jget "$BODY" "d['status']")" "NO_SHOW"
req POST "/reservations/$RID3/no-show" "$TOKEN" '{}'
report "second no-show → 400" 400 "$STATUS"

# ── 12. Delete guards ──────────────────────────────────────────────
req POST /reservations "$TOKEN" "{\"guestId\":\"$TG\",\"roomTypeId\":\"$RT\",\"checkIn\":\"$D9\",\"checkOut\":\"$D10\",\"adults\":1}"
RID4="$(jget "$BODY" "d['id']")"
req DELETE "/guests/$TG" "$TOKEN"
report "DELETE guest with active reservation → 409" 409 "$STATUS"
contains "guest active error text" "$BODY" "Guest has active reservations"
req DELETE "/reservations/$RID" "$TOKEN"
report "DELETE checked-out reservation → 409" 409 "$STATUS"
req DELETE "/reservations/$RID4" "$TOKEN"
report "DELETE pending reservation" 200 "$STATUS"
req DELETE "/reservations/$RID3" "$TOKEN"
report "DELETE no-show reservation" 200 "$STATUS"
req DELETE "/guests/$TG" "$TOKEN"
report "DELETE guest after terminal reservations" 200 "$STATUS"
req DELETE "/room-types/$RT" "$TOKEN"
report "DELETE room type with rooms → 409" 409 "$STATUS"
contains "room type error text" "$BODY" "Room type has rooms"
req DELETE "/rooms/$RM" "$TOKEN"
report "DELETE room (no active reservations)" 200 "$STATUS"

# ── 13. Users (admin only) ─────────────────────────────────────────
req GET /users "$TOKEN"
report "GET /users" 200 "$STATUS"
report "users exclude passwordHash" "$(jget "$BODY" "all('passwordHash' not in u for u in d)")" "True"
report "users include sessionCount" "$(jget "$BODY" "all('sessionCount' in u for u in d)")" "True"
req POST /users "$TOKEN" '{"name":"API Test Staff","email":"apitest.staff@digistay.com","password":"test123","role":"STAFF","phone":"+91 90000 22222"}'
report "POST /users" 200 "$STATUS"
TU="$(jget "$BODY" "d['id']")"
req POST /users "$TOKEN" '{"name":"Dup","email":"apitest.staff@digistay.com","password":"test123","role":"STAFF"}'
report "duplicate user email → 409" 409 "$STATUS"
req PUT "/users/$TU" "$TOKEN" '{"phone":"+91 90000 33333","active":false}'
report "PUT /users/[id]" 200 "$STATUS"
req DELETE "/users/$TU" "$TOKEN"
report "DELETE /users/[id]" 200 "$STATUS"

# non-admin restrictions
req POST /auth/login "" '{"email":"staff@digistay.com","password":"staff123"}'
STOKEN="$(jget "$BODY" "d['token']")"
req GET /users "$STOKEN"
report "non-admin GET /users → 403" 403 "$STATUS"
req GET /audit-logs "$STOKEN"
report "non-admin GET /audit-logs → 403" 403 "$STATUS"
req PUT /settings "$STOKEN" '{"tagline":"hacked"}'
report "non-admin PUT /settings → 403" 403 "$STATUS"

# ── 14. Settings ───────────────────────────────────────────────────
req GET /settings "$TOKEN"
report "GET /settings" 200 "$STATUS"
report "settings has hotel name" "$(jget "$BODY" "len(d['name']) > 0")" "True"
req PUT /settings "$TOKEN" '{"tagline":"A premium stay experience by the sea"}'
report "PUT /settings (admin)" 200 "$STATUS"

# ── 15. Audit logs ─────────────────────────────────────────────────
req GET "/audit-logs?limit=50" "$TOKEN"
report "GET /audit-logs" 200 "$STATUS"
report "audit logs non-empty" "$(jget "$BODY" "len(d) >= 5")" "True"
report "audit logs contain our CHECKIN" "$(jget "$BODY" "any(l.get('action')=='CHECKIN' for l in d)")" "True"
req GET "/audit-logs?search=login&limit=10" "$TOKEN"
report "audit-logs search filters" "$(jget "$BODY" "len(d) >= 1 and all('login' in ((l.get('action') or '') + (l.get('details') or '')).lower() for l in d)")" "True"

# ── 16. Logout ─────────────────────────────────────────────────────
req POST /auth/logout "$TOKEN"
report "POST /auth/logout" 200 "$STATUS"
req GET /auth/me "$TOKEN"
report "me after logout → 401" 401 "$STATUS"

echo ""
echo "================ SUMMARY: $PASS passed, $FAIL failed / $TOTAL checks ================"
if [ "$FAIL" -eq 0 ]; then echo "ALL TESTS PASSED ✔"; else echo "SOME TESTS FAILED ✘"; exit 1; fi
