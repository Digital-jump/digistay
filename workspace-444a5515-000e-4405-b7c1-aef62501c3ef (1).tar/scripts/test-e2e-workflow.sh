#!/usr/bin/env bash
# DigiStay end-to-end workflow verification (golden path)
set -u
BASE="http://localhost:3000/api"
PASS=0; FAIL=0
declare -a FAILURES

check() { # name, expected_status, actual_status, body
  local name="$1" exp="$2" act="$3" body="${4:-}"
  if [ "$exp" == "$act" ]; then PASS=$((PASS+1)); echo "PASS: $name";
  else FAIL=$((FAIL+1)); FAILURES+=("$name"); echo "FAIL: $name (expected=$exp actual=$act) ${body:0:200}"; fi
}
jget() { python3 -c "
import sys, json
try:
  d = json.load(sys.stdin)
  v = d
  for k in '$1'.split('.'):
    if k == '': continue
    if isinstance(v, list): v = v[int(k)]
    else: v = v.get(k) if isinstance(v, dict) else None
  print(v if v is not None else '')
except Exception:
  print('')
"; }

TODAY=$(date +%F)
CI1=$(date -d "+2 days" +%F 2>/dev/null || date -v+2d +%F)
CO1=$(date -d "+4 days" +%F 2>/dev/null || date -v+4d +%F)
CI2=$(date -d "+6 days" +%F 2>/dev/null || date -v+6d +%F)
CO2=$(date -d "+8 days" +%F 2>/dev/null || date -v+8d +%F)

# ── login ──
R=$(curl -s -X POST $BASE/auth/login -H 'Content-Type: application/json' -d '{"email":"admin@digistay.com","password":"admin123"}')
TOKEN=$(echo "$R" | jget token)
check "login" 200 200; [ -z "$TOKEN" ] && { echo "FATAL: no token"; exit 1; }
AUTH="Authorization: Bearer $TOKEN"
CT="Content-Type: application/json"

R=$(curl -s -X POST $BASE/auth/login -H "$CT" -d '{"email":"admin@digistay.com","password":"wrong"}')
check "login wrong password -> 401" 401 "$(curl -s -o /dev/null -w '%{http_code}' -X POST $BASE/auth/login -H "$CT" -d '{"email":"admin@digistay.com","password":"wrong"}')"

# ── guest create ──
R=$(curl -s -X POST $BASE/guests -H "$AUTH" -H "$CT" -d '{"firstName":"Test","lastName":"Workflow","phone":"+91 99999 88888","email":"workflow@test.example","idType":"AADHAAR","idNumber":"9999 8888 7777","nationality":"Indian"}')
GID=$(echo "$R" | jget id)
check "guest create" 200 200; [ -z "$GID" ] && { echo "FATAL: guest create failed: $R"; exit 1; }

# guest validation: missing firstName
code=$(curl -s -o /dev/null -w '%{http_code}' -X POST $BASE/guests -H "$AUTH" -H "$CT" -d '{"lastName":"NoFirst"}')
check "guest create missing firstName -> 400" 400 "$code"

# ── room type + rooms ──
TYPES=$(curl -s "$BASE/room-types" -H "$AUTH")
STD_ID=$(echo "$TYPES" | python3 -c "import sys,json; d=json.load(sys.stdin); print([t['id'] for t in d if t['name']=='Standard Room'][0])")
STD_RATE=$(echo "$TYPES" | python3 -c "import sys,json; d=json.load(sys.stdin); print([t['baseRate'] for t in d if t['name']=='Standard Room'][0])")
echo "Standard type: $STD_ID @$STD_RATE"

R=$(curl -s "$BASE/reservations/availability?roomTypeId=$STD_ID&checkIn=$CI1&checkOut=$CO1" -H "$AUTH")
ROOM_ID=$(echo "$R" | jget available.0.id)
ROOM_NUM=$(echo "$R" | jget available.0.number)
check "availability returns rooms" "OK" "$( [ -n "$ROOM_ID" ] && echo OK || echo EMPTY )"
echo "Room: $ROOM_ID ($ROOM_NUM)"

# ── create reservation ──
R=$(curl -s -X POST $BASE/reservations -H "$AUTH" -H "$CT" -d "{\"guestId\":\"$GID\",\"roomTypeId\":\"$STD_ID\",\"roomId\":\"$ROOM_ID\",\"checkIn\":\"$CI1\",\"checkOut\":\"$CO1\",\"adults\":2,\"source\":\"DIRECT\"}")
RSV_ID=$(echo "$R" | jget id)
RSV_CODE=$(echo "$R" | jget code)
RSV_TOTAL=$(echo "$R" | jget totalAmount)
check "reservation create" "OK" "$( [ -n "$RSV_ID" ] && echo OK || echo "EMPTY:$R" )"
echo "Reservation: $RSV_ID $RSV_CODE total=$RSV_TOTAL (expect 2 nights × $STD_RATE = $((STD_RATE*2)))"

# ── double-booking guard ──
# non-overlapping dates for same room succeed (throwaway reservation)
DBL=$(curl -s -X POST $BASE/reservations -H "$AUTH" -H "$CT" -d "{\"guestId\":\"$GID\",\"roomTypeId\":\"$STD_ID\",\"roomId\":\"$ROOM_ID\",\"checkIn\":\"$CI2\",\"checkOut\":\"$CO2\",\"adults\":2}")
DBL_ID=$(echo "$DBL" | jget id)
# true overlap must 409
OV1=$(date -d "+3 days" +%F 2>/dev/null || date -v+3d +%F)
OV2=$(date -d "+5 days" +%F 2>/dev/null || date -v+5d +%F)
code=$(curl -s -o /tmp/dbl.json -w '%{http_code}' -X POST $BASE/reservations -H "$AUTH" -H "$CT" -d "{\"guestId\":\"$GID\",\"roomTypeId\":\"$STD_ID\",\"roomId\":\"$ROOM_ID\",\"checkIn\":\"$OV1\",\"checkOut\":\"$OV2\",\"adults\":2}")
check "overlapping reservation -> 409" 409 "$code"

# ── check-in ──
R=$(curl -s -X POST "$BASE/reservations/$RSV_ID/checkin" -H "$AUTH" -H "$CT" -d "{\"roomId\":\"$ROOM_ID\"}")
check "check-in" "CHECKED_IN" "$(echo "$R" | jget status)"
RSTAT=$(curl -s "$BASE/rooms?search=$ROOM_NUM" -H "$AUTH")
check "room occupied after checkin" "OCCUPIED" "$(echo "$RSTAT" | jget items.0.status)"

# ── food order to room ──
MENU=$(curl -s "$BASE/menu" -H "$AUTH")
MI1=$(echo "$MENU" | python3 -c "import sys,json; d=json.load(sys.stdin); print([m['id'] for m in d if m['name']=='Butter Chicken'][0])")
R=$(curl -s -X POST $BASE/orders -H "$AUTH" -H "$CT" -d "{\"type\":\"ROOM_SERVICE\",\"reservationId\":\"$RSV_ID\",\"items\":[{\"menuItemId\":\"$MI1\",\"quantity\":2}]}")
ORD_ID=$(echo "$R" | jget id)
ORD_TOTAL=$(echo "$R" | jget totalAmount)
check "food order create" "PENDING" "$(echo "$R" | jget status)"
echo "Order: $ORD_ID total=$ORD_TOTAL"
R=$(curl -s -X PUT "$BASE/orders/$ORD_ID" -H "$AUTH" -H "$CT" -d '{"status":"DELIVERED"}')
check "order deliver" "DELIVERED" "$(echo "$R" | jget status)"

# ── folio has room + food charges ──
R=$(curl -s "$BASE/reservations/$RSV_ID" -H "$AUTH")
FOLIO_ID=$(echo "$R" | jget folio.id)
FOLIO_BAL=$(echo "$R" | jget folio.balance)
echo "Folio: $FOLIO_ID balance=$FOLIO_BAL (expect room $((STD_RATE*2)) + food $ORD_TOTAL)"

# ── checkout blocked until paid ──
R=$(curl -s -X POST "$BASE/reservations/$RSV_ID/checkout" -H "$AUTH" -H "$CT" -d '{}')
check "checkout blocked with balance" "unsettled" "$(echo "$R" | python3 -c "import sys,json; d=json.load(sys.stdin); print('unsettled' if d.get('error') and 'balance' in str(d) else 'other:'+str(d)[:100])")"

# ── invoice from folio ──
R=$(curl -s -X POST $BASE/invoices -H "$AUTH" -H "$CT" -d "{\"reservationId\":\"$RSV_ID\"}")
INV_ID=$(echo "$R" | jget id)
INV_TOTAL=$(echo "$R" | jget total)
check "invoice created" "OK" "$( [ -n "$INV_ID" ] && echo OK || echo "EMPTY:$R" )"
echo "Invoice: $INV_ID total=$INV_TOTAL"
code=$(curl -s -o /dev/null -w '%{http_code}' -X POST $BASE/invoices -H "$AUTH" -H "$CT" -d "{\"reservationId\":\"$RSV_ID\"}")
check "duplicate invoice -> 200 idempotent" 200 "$code"

# ── payment ──
R=$(curl -s -X POST "$BASE/invoices/$INV_ID/payments" -H "$AUTH" -H "$CT" -d '{"amount":1000,"method":"UPI"}')
check "partial payment" "PARTIAL" "$(echo "$R" | jget invoice.status)"
R=$(curl -s -X POST "$BASE/invoices/$INV_ID/payments" -H "$AUTH" -H "$CT" -d "{\"amount\":$INV_TOTAL,\"method\":\"CASH\"}")
check "overpay rejected" "exceeds" "$(echo "$R" | python3 -c "import sys,json; d=json.load(sys.stdin); print('exceeds' if 'exceeds' in str(d.get('error','')) else 'other')")"
BAL=$(python3 -c "print($INV_TOTAL-1000)")
R=$(curl -s -X POST "$BASE/invoices/$INV_ID/payments" -H "$AUTH" -H "$CT" -d "{\"amount\":$BAL,\"method\":\"CASH\"}")
check "full payment -> PAID" "PAID" "$(echo "$R" | jget invoice.status)"

# ── checkout now ──
R=$(curl -s -X POST "$BASE/reservations/$RSV_ID/checkout" -H "$AUTH" -H "$CT" -d '{}')
check "checkout after payment" "CHECKED_OUT" "$(echo "$R" | jget reservation.status)"
check "room dirty after checkout" "DIRTY" "$(curl -s "$BASE/rooms?search=$ROOM_NUM" -H "$AUTH" | jget items.0.status)"
R=$(curl -s -X POST "$BASE/rooms/$(curl -s "$BASE/rooms?search=$ROOM_NUM" -H "$AUTH" | jget items.0.id)/status" -H "$AUTH" -H "$CT" -d '{"status":"AVAILABLE"}')
check "housekeeping clean room" "AVAILABLE" "$(echo "$R" | jget status)"

# ── cancel flow ──
R=$(curl -s -X POST $BASE/reservations -H "$AUTH" -H "$CT" -d "{\"guestId\":\"$GID\",\"roomTypeId\":\"$STD_ID\",\"checkIn\":\"$CI2\",\"checkOut\":\"$CO2\",\"adults\":1,\"source\":\"PHONE\"}")
RSV2=$(echo "$R" | jget id)
code=$(curl -s -o /dev/null -w '%{http_code}' -X POST "$BASE/reservations/$RSV2/cancel" -H "$AUTH" -H "$CT" -d '{"reason":"test"}')
check "cancel reservation" 200 "$code"

# ── website booking ──
R=$(curl -s -X POST $BASE/website/book -H "$CT" -d "{\"guest\":{\"firstName\":\"Web\",\"lastName\":\"Booker\",\"email\":\"webbooker@test.example\",\"phone\":\"+91 97777 66666\"},\"roomTypeId\":\"$STD_ID\",\"checkIn\":\"$CI2\",\"checkOut\":\"$CO2\",\"adults\":2}")
WEB_CODE=$(echo "$R" | jget reservation.code)
check "website booking" "OK" "$( [ -n "$WEB_CODE" ] && echo OK || echo "EMPTY:$R" )"
echo "Web booking: $WEB_CODE"

# ── dashboard & reports ──
R=$(curl -s "$BASE/dashboard" -H "$AUTH")
check "dashboard stats" "OK" "$( [ -n "$(echo "$R" | jget stats.totalRooms)" ] && echo OK || echo EMPTY )"
echo "Dashboard: totalRooms=$(echo "$R" | jget stats.totalRooms) occupied=$(echo "$R" | jget stats.occupiedRooms) occRate=$(echo "$R" | jget stats.occupancyRate) todayRev=$(echo "$R" | jget stats.todayRevenue)"
for rep in revenue payments outstanding invoice-summary room-sales night-audit ota police occupancy reservations; do
  code=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/reports/$rep?from=$TODAY&to=$CI2" -H "$AUTH")
  check "report $rep" 200 "$code"
done

# ── folio settle ──
FOLIOS=$(curl -s "$BASE/folios?type=COMPANY" -H "$AUTH")
CFID=$(echo "$FOLIOS" | jget items.0.id)
code=$(curl -s -o /tmp/settle.json -w '%{http_code}' -X POST "$BASE/folios/$CFID/settle" -H "$AUTH" -H "$CT" -d '{"method":"BANK_TRANSFER"}')
check "company folio settle" 200 "$code"

# ── cleanup: delete test guest (has CHECKED_OUT/CANCELLED/CONFIRMED) ──
code=$(curl -s -o /tmp/gdel.json -w '%{http_code}' -X DELETE "$BASE/guests/$GID" -H "$AUTH")
if [ "$code" == "409" ]; then
  check "guest delete blocked by active reservation -> 409" 409 409
  # cancel the throwaway double-booking reservation + web booking, then delete
  [ -n "$DBL_ID" ] && curl -s -o /dev/null -X POST "$BASE/reservations/$DBL_ID/cancel" -H "$AUTH" -H "$CT" -d '{}'
  WID=$(curl -s "$BASE/reservations?search=Web+Booker" -H "$AUTH" | jget items.0.id)
  [ -n "$WID" ] && curl -s -o /dev/null -X POST "$BASE/reservations/$WID/cancel" -H "$AUTH" -H "$CT" -d '{}'
  code=$(curl -s -o /dev/null -w '%{http_code}' -X DELETE "$BASE/guests/$GID" -H "$AUTH")
  check "guest delete after cancelling" 200 "$code"
else
  check "guest delete" 200 "$code"
fi

echo ""
echo "================ E2E SUMMARY: $PASS passed, $FAIL failed ================"
[ $FAIL -gt 0 ] && printf 'Failed: %s\n' "${FAILURES[@]}"
exit $FAIL
