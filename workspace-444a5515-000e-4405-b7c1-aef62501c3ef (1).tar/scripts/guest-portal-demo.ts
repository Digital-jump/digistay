/**
 * One-off cleanup + guest portal demo data:
 * - Removes API smoke-test artifacts (rohan.test user/profile, test reservations, test contact message)
 * - Ensures the demo guest account (guest@digistay.com) has a linked Guest profile
 *   and two website bookings (one upcoming CONFIRMED, one past CHECKED_OUT)
 */
import { randomBytes, scryptSync } from "crypto";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

async function nextCode(prefix: string) {
  const yearPrefix = `${prefix}-${new Date().getFullYear()}-`;
  const rows = await prisma.reservation.findMany({
    where: { code: { startsWith: yearPrefix } },
    select: { code: true },
  });
  let max = 0;
  for (const r of rows) {
    const n = parseInt(String(r.code).slice(yearPrefix.length), 10);
    if (!isNaN(n) && n > max) max = n;
  }
  return `${yearPrefix}${String(max + 1).padStart(4, "0")}`;
}

async function main() {
  // ── Cleanup smoke-test artifacts ──
  const testUser = await prisma.user.findUnique({ where: { email: "rohan.test@example.com" } });
  if (testUser) await prisma.user.delete({ where: { id: testUser.id } });
  const testGuests = await prisma.guest.findMany({ where: { email: "rohan.test@example.com" } });
  for (const g of testGuests) {
    await prisma.reservation.deleteMany({ where: { guestId: g.id } });
    await prisma.guest.delete({ where: { id: g.id } });
  }
  await prisma.contactMessage.deleteMany({
    where: { OR: [{ email: "visitor@test.com" }, { name: "Frontend Smoke Test" }] },
  });

  // ── Demo guest account profile + bookings ──
  const email = "guest@digistay.com";
  let guest = await prisma.guest.findFirst({ where: { email } });
  if (!guest) {
    guest = await prisma.guest.create({
      data: { firstName: "Aisha", lastName: "Kapoor", email, phone: "+91 98200 11005", city: "Mumbai" },
    });
  }

  const suite = await prisma.roomType.findFirst({ where: { name: "Executive Suite" } });
  const standard = await prisma.roomType.findFirst({ where: { name: "Standard Room" } });
  const day = (offset: number) => {
    const d = new Date();
    d.setDate(d.getDate() + offset);
    d.setHours(14, 0, 0, 0);
    return d;
  };
  const endDay = (offset: number) => {
    const d = day(offset);
    d.setHours(11, 0, 0, 0);
    return d;
  };

  const hasBookings = await prisma.reservation.count({ where: { guestId: guest.id } });
  if (suite && standard && hasBookings === 0) {
    await prisma.reservation.create({
      data: {
        code: await nextCode("RSV"),
        guestId: guest.id,
        roomTypeId: suite.id,
        checkIn: day(21),
        checkOut: endDay(24),
        adults: 2,
        children: 0,
        status: "CONFIRMED",
        source: "WEBSITE",
        rate: suite.baseRate,
        totalAmount: suite.baseRate * 3,
        specialRequests: "High floor with sea view, please.",
      },
    });
    await prisma.reservation.create({
      data: {
        code: await nextCode("RSV"),
        guestId: guest.id,
        roomTypeId: standard.id,
        checkIn: day(-40),
        checkOut: endDay(-38),
        adults: 1,
        children: 0,
        status: "CHECKED_OUT",
        source: "WEBSITE",
        rate: standard.baseRate,
        totalAmount: standard.baseRate * 2,
        actualCheckIn: day(-40),
        actualCheckOut: endDay(-38),
      },
    });
    console.log("guest portal demo bookings created");
  }
  console.log("cleanup + demo data done");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
